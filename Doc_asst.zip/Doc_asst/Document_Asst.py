
import re
import uuid
import tempfile
from pathlib import Path

import streamlit as st
import random

from config import SUPPORTED_EXTENSIONS, MAX_HISTORY_TURNS,MAX_IMAGES_PER_QUERY
from extractor import extract_document, cleanup_session_images
from ollama_connect import (
    build_prompt,
    check_ollama_connection,
    stream_response,
    GenerationStats,
)
from logger import get_logger, activity_log

log = get_logger("app")


# ── page config ───────────────────────────────────────────────

st.set_page_config(
    page_title = "Document Assistant",
    page_icon  = "📄",
    layout     = "wide",
)


# ──Ollama connection check ────────────────────────────

@st.cache_data(ttl=60, show_spinner=False)
def _cached_ollama_check() -> tuple:
    return check_ollama_connection()


# ── client IP ─────────────────────────────────────────────────

def _get_client_ip() -> str:
    
    # ── Approach 1: Streamlit 1.37+ (st.context.headers) ─────
    try:
        headers = getattr(st.context, "headers", None)
        if headers:
            for key in ("x-forwarded-for", "x-real-ip", "remote-addr"):
                val = headers.get(key, "").split(",")[0].strip()
                if val and val != "unknown":
                    return val
    except Exception:
        pass

    # ── Approach 2: Streamlit runtime session info ────────────
    try:
        from streamlit.runtime import get_instance
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        runtime = get_instance()
        ctx     = get_script_run_ctx()
        if runtime and ctx:
            session_info = runtime.get_session_info(ctx.session_id)
            if session_info:
                request = getattr(session_info, "request", None)
                if request:
                    ip = getattr(request, "remote_ip", None) or                          getattr(request, "remote_addr", None)
                    if ip and ip != "unknown":
                        return str(ip)
    except Exception:
        pass

    # ── Approach 3: Script run context request headers ────────
    try:
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        ctx = get_script_run_ctx()
        if ctx:
            req = getattr(ctx, "request", None)
            if req:
                hdrs = getattr(req, "headers", {})
                for key in ("x-forwarded-for", "x-real-ip"):
                    val = hdrs.get(key, "").split(",")[0].strip()
                    if val and val != "unknown":
                        return val
                ip = getattr(req, "remote_ip", None)
                if ip:
                    return str(ip)
    except Exception:
        pass

    # ── Approach 4: Environment variable (proxy setups) ───────
    try:
        import os
        ip = os.getenv("REMOTE_ADDR", "")
        if ip and ip != "unknown":
            return ip
    except Exception:
        pass

    return "unknown"


# ── session init ──────────────────────────────────────────────

def _init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = _get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        st.session_state.qa_turn    = 0
        activity_log.log_session_start(sid, ip)
        log.info(f"New session id={sid} ip={ip}")

    defaults = {
        "extracted_text": None,
        "image_map":      {},
        "table_count":    0,
        "chat_history":   [],
        "messages":       [],
        "doc_name":       None,
        "doc_pages":      None,
        "doc_chars":      None,
        "doc_images":     0,
        "doc_tables":     0,
        "doc_scanned":    False,
        "md_saved_path":  None,
        "qa_turn":        0,
        "uploader_key":   0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_session()


# ── helpers ───────────────────────────────────────────────────
# Pattern to find "See Image N" or "Image N" in LLM answer
# Covers: "See Image 1", "see image 2", "Image 3", "image 3"
_IMAGE_REF_RE = re.compile(r"(?:see\s+)?[Ii]mage\s+(\d+)", re.IGNORECASE)


def _render_referenced_images(answer_text: str, image_map: dict):
    """
    Parse the LLM answer for "Image N" references and render those images.
    Returns list of rendered image paths.
    """
    rendered = []
    seen     = set()
    for m in _IMAGE_REF_RE.finditer(answer_text):
        n = int(m.group(1))
        if n not in seen and n in image_map:
            seen.add(n)
            img_path = image_map[n]
            if Path(img_path).exists():
                rendered.append(img_path)
                st.image(img_path, caption=f"Image {n}", width=700)
    return rendered


# ── sidebar ───────────────────────────────────────────────────

with st.sidebar:
    st.title("")
    st.caption("")
    #st.divider()

    # Ollama status — reads from 60-second cache
    #ok, info = _cached_ollama_check()
    #if ok:
        #st.success("Ollama connected ")
        #st.caption(info)
    #else:
        #st.error("Ollama not reachable ")
        #st.caption(info)

    #st.divider()

    # ── file uploader ──────────────────────────────────────────
    st.subheader(" Upload Document")
    st.caption("PDF · DOCX · TXT  |  Max 100 pages")

    uploaded_file = st.file_uploader(
        label            = "Choose a file",
        type             = SUPPORTED_EXTENSIONS,
        label_visibility = "collapsed",
        key              = f"uploader_{st.session_state.uploader_key}",
    )

    if uploaded_file is not None:
        if uploaded_file.name != st.session_state.doc_name:
            with st.spinner(f"Please wait....\n I'm processing your {uploaded_file.name} "):
                try:
                    suffix = Path(uploaded_file.name).suffix
                    tmp    = tempfile.NamedTemporaryFile(
                        delete=False, suffix=suffix
                    )
                    tmp.write(uploaded_file.read())
                    tmp.flush()
                    tmp.close()

                    res = extract_document(
                        file_path         = tmp.name,
                        file_ext          = suffix.lstrip("."),
                        session_id        = st.session_state.session_id,
                        original_filename = uploaded_file.name,
                    )

                    st.session_state.extracted_text = res.full_text
                    st.session_state.image_map      = res.image_map
                    st.session_state.table_count    = res.table_count
                    st.session_state.doc_name       = uploaded_file.name
                    st.session_state.doc_pages      = res.page_count
                    st.session_state.doc_chars      = len(res.full_text)
                    st.session_state.doc_images     = len(res.image_map)
                    st.session_state.doc_tables     = res.table_count
                    st.session_state.doc_scanned    = res.is_scanned
                    st.session_state.md_saved_path  = res.md_saved_path
                    st.session_state.chat_history   = []
                    st.session_state.messages       = []
                    st.session_state.qa_turn        = 0

                    activity_log.log_document(
                        filename = uploaded_file.name,
                        pages    = res.page_count,
                        chars    = len(res.full_text),
                        images   = len(res.image_map),
                        tables   = res.table_count,
                    )
                    activity_log.log_extraction_timing(
                        t_page_check = res.t_page_check,
                        t_text       = res.t_text_extraction,
                        t_images     = res.t_image_extraction,
                        t_total      = res.t_total,
                        t_tables     = res.t_table_extraction,
                    )

                    log.info(f"processing completed : {uploaded_file.name} | {res.summary}")
                    st.success(" I'M Ready to Answer Your Questions ")

                except ValueError as exc:
                    st.error(str(exc))
                    log.warning(str(exc))
                except Exception as exc:
                    st.error(f"Extraction error: {exc}")
                    log.exception(str(exc))

    st.divider()

    # ── document info panel ────────────────────────────────────
    if st.session_state.doc_name:
        st.subheader(" Document Info")
        st.markdown(f"**File:** {st.session_state.doc_name}")
        st.markdown(f"**Pages:** {st.session_state.doc_pages}")
        #st.markdown(f"**Characters:** {st.session_state.doc_chars:,}")

        img_count = st.session_state.doc_images
        tbl_count = st.session_state.doc_tables
        st.markdown(f"**Images :** {img_count}" + (" " if img_count else ""))
        st.markdown(f"**Tables :** {tbl_count}" + (" " if tbl_count else ""))

        if st.session_state.doc_scanned:
            st.caption(" Scanned PDF")
            #st.caption(" Scanned PDF — EasyOCR was used")
        else:
            st.caption(" Digital document")

        #if st.session_state.md_saved_path:
            #st.caption(f" Saved: `{st.session_state.md_saved_path}`")

        st.divider()

        if st.button("️ Clear Document", use_container_width=True):
            for k, v in {
                "extracted_text": None,
                "image_map":      {},
                "table_count":    0,
                "doc_name":       None,
                "doc_pages":      None,
                "doc_chars":      None,
                "doc_images":     0,
                "doc_tables":     0,
                "doc_scanned":    False,
                "md_saved_path":  None,
                "chat_history":   [],
                "messages":       [],
                "qa_turn":        0,
            }.items():
                st.session_state[k] = v
            st.session_state["uploader_key"] += 1
            log.info("Document cleared")
            st.rerun()


# ── main chat area ────────────────────────────────────────────

st.title(" AI Based Document Assistant")

if not st.session_state.extracted_text:
    st.markdown(
        """
        <div style="
          background: linear-gradient(#B3B3FF, #B3B3FF, #B3B3FF);
          padding-right: 20px;
          border-radius: 12px;
          color: black;
          margin-bottom: 1rem;
          padding-left: 20px;
          padding-right: 20px;
        ">
        <h3 style="display:inline; margin:0;">Disclaimer</h3>
        <p style="font-size: 20px;">This is a beta version, the generated responses may not be totally correct
        and are limited to the content of the uploaded document. Cross‑checking is
        strongly recommended before any critical use.</p>

        <h3 style="display:inline; margin:0;">About</h3>
        <p style="font-size: 18px;">Upload a **PDF**, **DOCX**, or **TXT** file from Browse files.
        Ask any question—including questions about **images, charts,
        graphs, or tables** inside the document.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

# Render previous messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        for img_path in msg.get("images", []):
            if Path(img_path).exists():
                st.image(img_path, width=700)


# ── chat input ────────────────────────────────────────────────

question = st.chat_input(
    placeholder = "Ask about text, tables, charts, or images in your document…",
    disabled    = not st.session_state.extracted_text,
)

if question:
    log.info(f"Q: {question[:120]}")

    # Show user message
    with st.chat_message("user"):
        st.markdown(question)
    st.session_state.messages.append({
        "role": "user", "content": question, "images": [], "mode": None,
    })

    # ── build prompt ───────────────────────────────────────────
    # Returns 4 values: prompt, images_b64, build_time, qtype
    prompt, images_b64, t_prompt, qtype = build_prompt(
        extracted_text = st.session_state.extracted_text,
        chat_history   = st.session_state.chat_history,
        question       = question,
        image_map      = st.session_state.image_map,
    )
    stats = GenerationStats(t_prompt_build=t_prompt)

    log.info(
        f"Prompt: {len(prompt):,} chars | mode={qtype.mode} | "
        f"{len(images_b64)} image(s) | build={t_prompt:.3f}s"
    )

    # ── stream answer ──────────────────────────────────────────
    full_answer       = ""
    referenced_images = []

    THINKING_MESSAGES = [
        "Analyzing your query against the available documents.",
        "Retrieving the most relevant information.",
        "Processing context to ensure an accurate response.",
        "Searching the knowledge base for matching insights.",
        "Reviewing related content to form a precise answer.",
        "Evaluating document sections for relevance.",
        "Synthesizing information from multiple sources.",
        "Aligning your question with stored knowledge.",
        "Identifying key details required for the response.",
        "Cross-checking facts to improve accuracy.",
        "Understanding the intent behind your question.",
        "Filtering unnecessary information.",
        "Assembling a clear and concise answer.",
        "Validating results before responding.",
        "Matching your query with indexed content.",
        "Optimizing the response for clarity.",
        "Finalizing the answer for delivery.",
    ]

    with st.spinner(random.choice(THINKING_MESSAGES)):
        try:
            full_answer = st.write_stream(
                stream_response(prompt, images_b64, stats)
            )
        except Exception as exc:
            full_answer = (
                f" Ollama error: `{exc}`\n\n"
                "Check Ollama is running and OLLAMA_HOST in config.py is correct."
            )
            st.error(full_answer)
            log.error(f"Ollama error: {exc}")

            # Show assistant message
            with st.chat_message("assistant"):
                st.markdown(full_answer)

        # Render images mentioned in the answer ("See Image N" / "Image N")
        if st.session_state.image_map:
            referenced_images = _render_referenced_images(
                full_answer, st.session_state.image_map
            )

    # ── update session state ───────────────────────────────────
    st.session_state.qa_turn += 1
    st.session_state.chat_history.append({
        "question": question,
        "answer":   full_answer,
    })
    if len(st.session_state.chat_history) > MAX_HISTORY_TURNS:
        st.session_state.chat_history = (
            st.session_state.chat_history[-MAX_HISTORY_TURNS:]
        )

    st.session_state.messages.append({
        "role":    "assistant",
        "content": full_answer,
        "images":  referenced_images,
        "mode":    qtype.mode,
    })

    # ── activity log ───────────────────────────────────────────
    activity_log.log_qa(
        turn          = st.session_state.qa_turn,
        question      = question,
        answer        = full_answer,
        t_prompt      = stats.t_prompt_build,
        t_ttft        = stats.t_ttft,
        t_total       = stats.t_total,
        chars_per_sec = stats.chars_per_sec,
        question_type = qtype.mode,
        images_sent   = len(images_b64),
    )

    log.info(
        f"QA done | Turn {st.session_state.qa_turn} | "
        f"mode={qtype.mode} | {stats.summary}"
    )
