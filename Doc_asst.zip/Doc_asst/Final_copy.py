import asyncio
import random
try:
    asyncio.get_running_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

import streamlit as st

st.set_page_config(page_title="Procurement Policy Related Assistant", layout="wide", initial_sidebar_state="collapsed")

st.markdown(
    """
    <style>
    /* Reduce top padding to remove empty space above heading */
    .block-container {
        padding-top: 1rem !important;
    }
    div[data-testid="stBottomBlockContainer"] {
        position: inherit;
        width: 80%;
        margin-left: auto;
        margin-right: auto;
    }

    div[data-testid="stChatInput"] {
        width: 80%;
        margin-left: auto;
        margin-right: auto;
    }
    </style>
    """,
    unsafe_allow_html=True
)
st.sidebar.markdown(
    """
    <style>
    .footer {
        padding: 5px;
        text-align: center;
        font-size: 12px;
        background-color: rgb(240, 234, 225);
        position:fixed;
        bottom:0px;
        border-radius:10px;
        margin:10px;
        width:250px;
    }
    </style>
    <div class="footer">Designed & Developed by DAIV Team<br>
        Powered by Opensource LLMs and Frameworks<br>
        For support, call 7192.</div>
    """,
    unsafe_allow_html=True
)

import ollama
from sentence_transformers import SentenceTransformer, CrossEncoder
import torch
import numpy as np
from whoosh.index import create_in
from whoosh.fields import Schema, TEXT, ID
from whoosh.qparser import QueryParser
from whoosh.qparser import syntax
from whoosh.analysis import StemmingAnalyzer, StopFilter
import os
import pickle
import hashlib
import json
import base64
from transformers import AutoTokenizer
from pymilvus import MilvusClient
import fitz
import time
from typing import List, Tuple, Dict
from whoosh.scoring import BM25F
from tqdm import tqdm
from pathlib import Path
import re
from datetime import datetime, timedelta
from threading import Lock
from functools import wraps
from collections import defaultdict
from datetime import datetime

# Global dict: {function_name: [elapsed_times]}
timing_stats: defaultdict = defaultdict(list)
function_timings: List[Tuple[datetime, str, float]] = []
current_interaction_times: List[Tuple[str, float]] = []
timing_details: List[Tuple[str, float]] = []

# ✅ CRITICAL FIX: Recreate Ollama client every N queries to prevent connection pool exhaustion
def get_ollama_client():
    """Get or recreate Ollama client every 15 queries to prevent connection pooling issues"""
    if 'ollama_client' not in st.session_state:
        st.session_state.ollama_client = ollama.Client(host='http://10.144.177.192:11000')
        st.session_state.ollama_query_count = 0
    
    st.session_state.ollama_query_count += 1
    
    # Recreate client every 15 queries to refresh connections
    if st.session_state.ollama_query_count % 15 == 0:
        print(f"♻️  Recreating Ollama client after {st.session_state.ollama_query_count} queries...")
        try:
            st.session_state.ollama_client = ollama.Client(host='http://10.144.177.192:11000')
            print("✅ Ollama client recreated successfully")
        except Exception as e:
            print(f"⚠️  Error recreating Ollama client: {e}")
    
    return st.session_state.ollama_client

if torch.cuda.is_available():
    device = torch.device("cuda")
    print(f"Using CUDA: {torch.cuda.get_device_name(0)}")
elif torch.backends.mps.is_available():
    device = torch.device("mps")
    print("Using MPS (Apple GPU)")
else:
    device = torch.device("cpu")
    print("Using CPU")

os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"

# Define paths to local models
local_model_path = "./models_for_transfer/"
# Define constants
CHUNK_SIZE = 512
OVERLAP = 128
TOKEN_LIMIT = 12000
MAX_DOCUMENTS = 5
EMBEDDER_MODEL = f"{local_model_path}/all-MiniLM-L6-v2"
RERANKER_MODEL = f"{local_model_path}/ms-marco-MiniLM-L-6-v2"
LLM_MODEL ="gpt-oss:20b"

# Admin credentials
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

# Persistent storage paths
STORAGE_DIR = "./persistent_storage"
DOCUMENT_STORE_FILE = os.path.join(STORAGE_DIR, "document_store.json")
CHAT_LOGS_DIR = "./chat_logs"
CHUNKS_LOGS_DIR = "./chunk_logs"

# Ensure storage directory exists
os.makedirs(STORAGE_DIR, exist_ok=True)
os.makedirs(CHAT_LOGS_DIR, exist_ok=True)
os.makedirs(CHUNKS_LOGS_DIR, exist_ok=True)

# Chat history logging
chat_history_file_lock = Lock()
chunk_logging_file_lock = Lock()

def timed(func):
    """Record elapsed time for a function and keep a per-query list."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        function_timings.append((datetime.now(), func.__name__, elapsed))
        if current_interaction_times is not None:
            current_interaction_times.append((func.__name__, elapsed))
        return result
    return wrapper

def get_chat_log_filename():
    """Generate chat log filename with current date"""
    return os.path.join(CHAT_LOGS_DIR, f"chat_history_{datetime.now().strftime('%Y-%m-%d')}.log")

def get_chunk_log_filename():
    """Generate chunk log filename with current date"""
    return os.path.join(CHUNKS_LOGS_DIR, f"retrieved_chunks_{datetime.now().strftime('%Y-%m-%d')}.txt")

def log_chat_interaction(username, query, response, response_time, remote_ip,timing_list: List[Tuple[str, float]] = None):
    """Log chat interaction to daily log file"""
    log_filename = get_chat_log_filename()
    with chat_history_file_lock:
        try:
            with open(log_filename, 'a', encoding='utf-8') as log_file:
                log_file.write(
                    f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}: {username}: IP: {remote_ip}\n"
                    f"Query: {query}\n"
                    f"Response: {response}\n"
                    f"Response Time: {response_time:.2f}s\n"
                )
                if timing_list:
                    log_file.write("---- Timing Details for this query ----\n")
                    for func_name, elapsed in timing_list:
                        log_file.write(f"{func_name:30s} : {elapsed:.6f}s\n")
                    log_file.write("---- End Timing ----\n\n")
                    log_file.write(f"{'*' * 80}\n\n")
        except Exception as e:
            st.error(f"Error logging chat: {e}")

def log_retrieved_chunks(username, query, chunks_used, remote_ip, main_chunk_indices=None):
    """Log retrieved chunks that were used to generate the response with context expansion details"""
    log_filename = get_chunk_log_filename()
    with chunk_logging_file_lock:
        try:
            with open(log_filename, 'a', encoding='utf-8') as chunk_file:
                chunk_file.write(
                    f"\n{'='*100}\n"
                    f"TIMESTAMP: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                    f"USER: {username}\n"
                    f"IP: {remote_ip}\n"
                    f"QUERY: {query}\n"
                    f"NUMBER OF CHUNKS RETRIEVED: {len(chunks_used)}\n"
                )
                if main_chunk_indices:
                    total_main = sum(len(indices) for indices in main_chunk_indices.values())
                    total_context = len(chunks_used) - total_main
                    chunk_file.write(
                        f"MAIN CHUNKS (from reranking): {total_main}\n"
                        f"CONTEXT CHUNKS (expanded): {total_context}\n"
                        f"CONTEXT EXPANSION RATIO: {total_context/total_main:.1f}x\n" if total_main > 0 else ""
                    )
                
                chunk_file.write(f"{'='*100}\n\n")

                current_doc = None
                for i, (chunk_text, formal_name, doc_id, chunk_idx) in enumerate(chunks_used, 1):
                    # Document separator
                    if current_doc != doc_id:
                        if current_doc is not None:
                            chunk_file.write(f"\n{'~'*80}\n")
                        chunk_file.write(f"\n📄 DOCUMENT: {formal_name}\n{'~'*80}\n\n")
                        current_doc = doc_id
                    
                    # Determine chunk type
                    is_main = False
                    if main_chunk_indices and doc_id in main_chunk_indices:
                        is_main = chunk_idx in main_chunk_indices[doc_id]
                    
                    chunk_type = "⭐ MAIN CHUNK" if is_main else "📄 CONTEXT CHUNK"

                    chunk_file.write(
                        f"{chunk_type} {i}:\n"
                        f"  Document: {formal_name}\n"
                        f"  Document ID: {doc_id}\n"
                        f"  Chunk Index: {chunk_idx}\n"
                        f"  Type: {'PRIMARY (High relevance)' if is_main else 'SUPPORTING (Context)'}\n"
                        f"  Content:\n"
                        f"  {'-'*50}\n"
                        f"  {chunk_text}\n"
                        f"  {'-'*50}\n\n"
                    )

                chunk_file.write(f"{'='*100}\n\n")

        except Exception as e:
            st.error(f"Error logging chunks: {e}")

def print_retrieved_chunks_to_terminal(username, query, chunks_used, main_chunk_indices=None):
    """Print retrieved chunks to terminal for debugging with context expansion visualization"""
    print(f"\n{'='*100}")
    print(f"RETRIEVED CHUNKS FOR QUERY: {query}")
    print(f"USER: {username}")
    print(f"TIMESTAMP: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"NUMBER OF CHUNKS: {len(chunks_used)}")
    
    if main_chunk_indices:
        total_main = sum(len(indices) for indices in main_chunk_indices.values())
        total_context = len(chunks_used) - total_main
        print(f"MAIN CHUNKS (from reranking): {total_main}")
        print(f"CONTEXT CHUNKS (expanded): {total_context}")
    
    print(f"{'='*100}")

    current_doc = None
    for i, (chunk_text, formal_name, doc_id, chunk_idx) in enumerate(chunks_used, 1):
        # Show document separator when switching documents
        if current_doc != doc_id:
            if current_doc is not None:
                print(f"\n{'~'*80}")
            print(f"\n📄 DOCUMENT: {formal_name} (ID: {doc_id})")
            print(f"{'~'*80}")
            current_doc = doc_id
            break  # Only print first document header, then stop

    print(f"\n{'='*100}")
    print(f"SUMMARY:")
    if main_chunk_indices:
        total_main = sum(len(indices) for indices in main_chunk_indices.values())
        total_context = len(chunks_used) - total_main
        print(f"  • Main chunks: {total_main}")
        print(f"  • Context chunks: {total_context}")
        print(f"  • Context expansion ratio: {total_context/total_main:.1f}x" if total_main > 0 else "  • Context expansion ratio: N/A")
    print(f"  • Total chunks sent to LLM: {len(chunks_used)}")
    print(f"{'='*100}\n")

def get_remote_ip():
    """Get remote IP address"""
    try:
        from streamlit import runtime
        from streamlit.runtime.scriptrunner import get_script_run_ctx

        ctx = get_script_run_ctx()
        if ctx is None:
            return "localhost"
        session_info = runtime.get_instance().get_client(ctx.session_id)
        if session_info is None:
            return "localhost"
        return f"{session_info.request.remote_ip}"
    except Exception:
        return "localhost"

# Cache model loading
@timed
@st.cache_resource
def load_models():
    """Load and cache embedding and reranker models"""
    with st.spinner("Loading embedding model..."):
        embedder = SentenceTransformer(EMBEDDER_MODEL, trust_remote_code=True, local_files_only=True)

    with st.spinner("Loading reranker model..."):
        reranker = CrossEncoder(RERANKER_MODEL, trust_remote_code=True, local_files_only=True)
    
    # Load tokenizer for token counting
    with st.spinner("Loading tokenizer..."):
        tokenizer = AutoTokenizer.from_pretrained(local_model_path + "/all-MiniLM-L6-v2", local_files_only=True)
    
    return embedder, reranker, tokenizer

def emb_text(text):
    return embedder.encode(text).tolist()

def get_document_id(filename: str, file_content: str) -> str:
    """Generate a unique document ID based on filename and content hash"""
    content_hash = hashlib.md5(file_content.encode()).hexdigest()
    return hashlib.md5(f"{filename}_{content_hash}".encode()).hexdigest()[:16]

def get_collection_name(doc_id: str) -> str:
    """Generate collection name for a document"""
    return f"doc_{doc_id}"

def get_index_dir(doc_id: str) -> str:
    """Generate index directory for a document"""
    return f"indexdir_{doc_id}"

def get_formal_name(filename: str) -> str:
    """Remove .md extension from filename to get formal name"""
    if filename.lower().endswith('.md'):
        return filename[:-3]
    return filename

def save_document_store():
    """Save document store to persistent storage"""
    try:
        with open(DOCUMENT_STORE_FILE, 'w') as f:
            json.dump(st.session_state.document_store, f, indent=2)
    except Exception as e:
        st.error(f"Error saving document store: {e}")

def load_document_store():
    """Load document store from persistent storage"""
    if os.path.exists(DOCUMENT_STORE_FILE):
        try:
            with open(DOCUMENT_STORE_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            st.error(f"Error loading document store: {e}")
            return {}
    return {}

def check_admin_login():
    """Check if user is logged in as admin"""
    return st.session_state.get('is_admin', False)

def admin_sidebar():
    """Admin login interface in sidebar"""
    st.sidebar.title("Admin Panel")
    st.subheader("🔒 Admin Login")
    with st.form("admin_login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        login_button = st.form_submit_button("Login")
        if login_button:
            if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
                st.session_state.is_admin = True
                st.sidebar.success("Admin login successful!")
                st.session_state.page=None
                st.rerun()
            else:
                st.sidebar.error("Invalid credentials")

def admin_document_management():
    """Admin document management interface"""
    st.subheader("📚 Document Management")
    # Show document limit status
    doc_count = len(st.session_state.document_store)
    st.write(f"**Documents: {doc_count}/{MAX_DOCUMENTS}**")

    # Progress bar for document limit
    progress_value = doc_count / MAX_DOCUMENTS
    st.progress(progress_value)

    if doc_count >= MAX_DOCUMENTS:
        st.warning(f"⚠️ Maximum document limit ({MAX_DOCUMENTS}) reached. Remove some documents to add new ones.")

    # Show existing documents
    if st.session_state.document_store:
        st.write("**Indexed Documents:**")
        for doc_id, doc_info in st.session_state.document_store.items():
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                st.write(f"📄 {doc_info['formal_name']}")
            with col2:
                st.write(f"{doc_info['chunk_count']} chunks")
            with col3:
                if st.button(f"🗑️ Remove", key=f"remove_{doc_id}"):
                    # Remove document
                    try:
                        collection_name = doc_info['collection_name']
                        if st.session_state.milvus_client.has_collection(collection_name):
                            st.session_state.milvus_client.drop_collection(collection_name)

                        # Remove BM25 index directory
                        import shutil
                        index_dir = get_index_dir(doc_id)
                        if os.path.exists(index_dir):
                            shutil.rmtree(index_dir)

                        del st.session_state.document_store[doc_id]
                        save_document_store()
                        st.success(f"Removed document: {doc_info['formal_name']}")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error removing document: {e}")
    else:
        st.info("No documents indexed yet. You can add up to 5 documents.")

    # File uploader section
    st.subheader("📤 Add New Documents")

    # Only show file uploader if we haven't reached the limit
    if doc_count < MAX_DOCUMENTS:
        uploaded_files = st.file_uploader(
            "Upload documents",
            type=["txt", "md", "rmd"],
            accept_multiple_files=True,
            help=f"You can upload up to {MAX_DOCUMENTS - doc_count} more document(s)"
        )

        if uploaded_files:
            valid_files = []
            for uploaded_file in uploaded_files:
                try:
                    file_extension = uploaded_file.name.split(".")[-1]
                    if file_extension in ["txt", "md", "rmd"]:
                        file_content = uploaded_file.getvalue().decode("utf-8")

                        # Check if document already exists
                        if not check_duplicate_document(uploaded_file.name, file_content):
                            valid_files.append((uploaded_file, file_content))
                        else:
                            st.warning(f"Document '{get_formal_name(uploaded_file.name)}' with this content is already indexed!")
                    else:
                        st.error(f"Unsupported file format for {uploaded_file.name}")
                except Exception as e:
                    st.error(f"Error processing file {uploaded_file.name}: {e}")

            if valid_files:
                # Document naming interface
                st.subheader("🏷 Document Names")
                doc_names = {}
                for uploaded_file, file_content in valid_files:
                    default_name = get_formal_name(uploaded_file.name)
                    doc_names[uploaded_file.name] = st.text_input(
                        f"Name for {uploaded_file.name}:",
                        value=default_name,
                        key=f"name_{uploaded_file.name}"
                    )

                if st.button("🚀 Index Selected Documents"):
                    for uploaded_file, file_content in valid_files:
                        # Save uploaded file
                        file_path = uploaded_file.name
                        with open(file_path, 'wb') as f:
                            f.write(uploaded_file.getvalue())
                        formal_name = doc_names[uploaded_file.name]
                        status = index_document(file_content, file_path, uploaded_file.name, file_content, formal_name)
                        if "successfully" in status:
                            st.success(status)
                        else:
                            st.error(status)
                    st.rerun()
    else:
        st.info(f"Maximum document limit ({MAX_DOCUMENTS}) reached. Please remove some documents to add new ones.")

# BM25 Indexing Setup
@timed
def setup_bm25(doc_id: str):
    """Setup Whoosh BM25 index for a specific document"""
    schema = Schema(
        content=TEXT(analyzer=StemmingAnalyzer() | StopFilter(), stored=True),
        doc_id=ID(stored=True)
    )
    index_dir = get_index_dir(doc_id)
    if not os.path.exists(index_dir):
        os.mkdir(index_dir)
        ix = create_in(index_dir, schema)
    else:
        from whoosh import index
        ix = index.open_dir(index_dir)
    return ix

def index_bm25(ix, text: str, doc_id: str):
    """Add text to BM25 index with document ID"""
    try:
        writer = ix.writer()
        writer.add_document(content=text, doc_id=doc_id)
        writer.commit()
        return True
    except Exception as e:
        st.error(f"Error indexing to BM25: {e}")
        return False

def count_tokens(text: str) -> int:
    """Count tokens in text using the tokenizer"""
    tokens = tokenizer.encode(text, add_special_tokens=False)
    return len(tokens)

@timed
def create_chunks(file_content: str) -> List[str]:
    """
    Create chunks from markdown file using <BREAK> tags.
    This replaces the hierarchical chunker with manual break-based chunking.
    
    Args:
        file_content: String content of the markdown file
        
    Returns:
        List of chunk texts
    """
    heading_pattern = re.compile(r"^#\s+(.*?)$", re.MULTILINE)
    
    chunks = []
    current_heading = None
    buffer = []
    chunk_number = 1
    
    def flush_buffer():
        nonlocal chunk_number
        if buffer:
            content = "\n".join(buffer).strip()
            token_count = count_tokens(content)
            
            if content:
                # Format chunk with heading if available
                if current_heading:
                    chunk_text = f"Heading: {current_heading}\n\n{content}"
                else:
                    chunk_text = content
                    
                chunks.append(chunk_text)
                print(f"  Created chunk {chunk_number}: {token_count} tokens, heading: {current_heading}")
                chunk_number += 1
        buffer.clear()
    
    print(f"\n🔍 Starting chunk creation from <BREAK> tags...")
    
    # Split content by lines
    lines = file_content.split('\n')
    
    for line in lines:
        line_stripped = line.rstrip()
        
        # Detect heading
        heading_match = heading_pattern.match(line_stripped)
        if heading_match:
            # Don't flush on heading - headings are part of the chunk
            current_heading = heading_match.group(1).strip()
            buffer.append(line_stripped)
            continue
        
        # Detect break tag
        if line_stripped.strip() == "<BREAK>":
            flush_buffer()
            current_heading = None  # Reset heading after break
            continue
        
        # Collect regular content lines
        buffer.append(line_stripped)
    
    # Flush any remaining content
    flush_buffer()
    
    print(f"✅ Created {len(chunks)} chunks from <BREAK> tags\n")
    
    return chunks

def check_duplicate_document(filename: str, file_content: str) -> bool:
    """Check if document already exists based on content"""
    doc_id = get_document_id(filename, file_content)
    return doc_id in st.session_state.document_store

# Process document with progress indicators
@timed
def index_document(document: str, file_path: str, filename: str, file_content: str, formal_name: str) -> str:
    """Index document with progress indicators"""
    # Check if we've reached the maximum number of documents
    if len(st.session_state.document_store) >= MAX_DOCUMENTS:
        return f"Maximum number of documents ({MAX_DOCUMENTS}) reached. Please remove some documents before adding new ones."

    doc_id = get_document_id(filename, file_content)

    # Check if document already exists
    if doc_id in st.session_state.document_store:
        return f"Document '{formal_name}' with this content is already indexed."

    collection_name = get_collection_name(doc_id)

    # Setup BM25 index for this document
    ix = setup_bm25(doc_id)

    # Use break-based chunking
    print(f"\n📄 Processing document: {formal_name}")
    chunks = create_chunks(file_content)

    if not chunks:
        return "No chunks created from document. Please check that <BREAK> tags are present in the content."

    embedding_dim = embedder.get_sentence_embedding_dimension()

    # Drop existing collection if it exists
    if st.session_state.milvus_client.has_collection(collection_name):
        st.session_state.milvus_client.drop_collection(collection_name)

    # Create new collection
    st.session_state.milvus_client.create_collection(
        collection_name=collection_name,
        dimension=embedding_dim,
        metric_type="IP",
        consistency_level="Strong",
    )

    # Store document metadata with formal name
    st.session_state.document_store[doc_id] = {
        'filename': filename,
        'formal_name': formal_name,
        'chunks': chunks,
        'collection_name': collection_name,
        'chunk_count': len(chunks),
        'file_content_hash': hashlib.md5(file_content.encode()).hexdigest()
    }

    # Process chunks with progress bar
    progress_bar = st.progress(0)
    status_text = st.empty()
    data = []
    for i, chunk in enumerate(tqdm(chunks, desc="Processing chunks")):
        progress = (i + 1) / len(chunks)
        progress_bar.progress(progress)
        status_text.text(f"Processing chunk {i + 1}/{len(chunks)}")
        embedding = emb_text(chunk)
        data.append({"id": i, "vector": embedding, "text": chunk})

        try:
            index_bm25(ix, chunk, doc_id)
        except Exception as e:
            st.error(f"BM25 error: {e}")

    # Insert embeddings to Milvus
    st.session_state.milvus_client.insert(collection_name=collection_name, data=data)

    if data:
        try:
            progress_bar.progress(1.0)
            status_text.text("Indexing complete!")
            time.sleep(1)
            status_text.empty()
            progress_bar.empty()

            # Save document store to persistent storage
            save_document_store()

            return f"Document '{formal_name}' indexed successfully! Created {len(chunks)} chunks."
        except Exception as e:
            return f"Error adding embeddings to index: {e}"
    else:
        return "No embeddings were created. Indexing failed."

@timed
def search_document(query: str, doc_id: str, top_k: int = 5) -> List[Tuple[str, int]]:
    """Search within a specific document, returning chunks with their indices"""
    if doc_id not in st.session_state.document_store:
        return []

    doc_info = st.session_state.document_store[doc_id]
    collection_name = doc_info['collection_name']

    # Setup BM25 index for this document
    ix = setup_bm25(doc_id)

    results = []

    # BM25 retrieval - INCREASED from 30 to 50
    bm25_results = []
    searcher = None
    try:
        searcher = ix.searcher(weighting=BM25F())
        query_parser = QueryParser("content", ix.schema, group=syntax.OrGroup)
        q = query_parser.parse(query)
        bm25_hits = searcher.search(q, limit=30)
        bm25_results = [hit["content"] for hit in bm25_hits]
    except Exception as e:
        st.warning(f"BM25 search error for document {doc_id}: {e}")
    finally:
        # ✅ CRITICAL FIX: Explicitly close searcher to prevent reader accumulation
        if searcher is not None:
            try:
                searcher.close()
            except:
                pass

    # Milvus retrieval - INCREASED from 30 to 50
    milvus_results = []
    try:
        query_embedding = emb_text(query)
        search_res = st.session_state.milvus_client.search(
            collection_name=collection_name,
            data=[query_embedding],
            limit=30,
            search_params={"metric_type": "IP", "params": {}},
            output_fields=["text"],
        )
        milvus_results = [(res["entity"]["text"], res["id"]) for res in search_res[0]]
    except Exception as e:
        st.warning(f"Vector search error for document {doc_id}: {e}")

    # Merge results (prioritize Milvus results with chunk indices)
    all_results = []
    for text, chunk_id in milvus_results:
        all_results.append((text, chunk_id))

    # Add BM25 results that aren't already included
    for text in bm25_results:
        if not any(text == result[0] for result in all_results):
            # Find chunk index in original chunks
            chunk_idx = -1
            for i, chunk in enumerate(doc_info['chunks']):
                if chunk == text:
                    chunk_idx = i
                    break
            all_results.append((text, chunk_idx))

    if not all_results:
        return []
    # Rerank
    try:
        texts = [result[0] for result in all_results]
        rerank_pairs = [(query, text) for text in texts]
        scores = reranker.predict(rerank_pairs)
        sorted_results = [all_results[i] for i in sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)]
        return sorted_results[:top_k]
    except Exception as e:
        st.warning(f"Reranking error for document {doc_id}: {e}")
        return all_results[:top_k]

def expand_chunk_context(doc_id: str, chunk_indices: List[int], window_size: int = 1) -> List[Tuple[str, int]]:
    """
    Expand chunk context by retrieving neighboring chunks
    
    Args:
        doc_id: Document ID
        chunk_indices: List of main chunk indices from reranking
        window_size: Number of chunks to retrieve before and after (default: 1)
    
    Returns:
        List of (chunk_text, chunk_idx) tuples with expanded context, sorted by chunk index
    """
    if doc_id not in st.session_state.document_store:
        return []
    
    doc_info = st.session_state.document_store[doc_id]
    all_chunks = doc_info['chunks']
    total_chunks = len(all_chunks)
    
    # Use a set to avoid duplicates
    expanded_indices = set()
    
    for main_idx in chunk_indices:
        # Add the main chunk
        expanded_indices.add(main_idx)
        
        # Add previous chunks
        for i in range(1, window_size + 1):
            prev_idx = main_idx - i
            if prev_idx >= 0:
                expanded_indices.add(prev_idx)
        
        # Add next chunks
        for i in range(1, window_size + 1):
            next_idx = main_idx + i
            if next_idx < total_chunks:
                expanded_indices.add(next_idx)
    
    # Sort indices to maintain document order
    sorted_indices = sorted(expanded_indices)
    
    # Return chunks with their indices
    expanded_chunks = [(all_chunks[idx], idx) for idx in sorted_indices]
    
    return expanded_chunks

# Hybrid Search across multiple documents with context expansion
@timed
def hybrid_search_multi_doc(query: str, selected_doc_ids: List[str], top_k: int = 5, expand_context: bool = True, window_size: int = 1) -> Tuple[List[Tuple[str, str, str, int]], Dict[str, List[int]]]:
    """
    Perform hybrid search across multiple selected documents with optional context expansion
    
    Args:
        query: Search query
        selected_doc_ids: List of document IDs to search
        top_k: Number of top chunks to return after reranking
        expand_context: Whether to expand chunks with neighboring context
        window_size: Number of chunks before/after to include (if expand_context=True)
    
    Returns:
        Tuple of:
        - List of tuples: (chunk_text, formal_name, doc_id, chunk_idx)
        - Dict of main chunk indices by doc_id (for logging/visualization)
    """
    all_results = []

    # Step 1: Search each document
    print(f"\n🔍 STEP 1: Initial Retrieval")
    print(f"   Searching {len(selected_doc_ids)} document(s)...")
    
    for doc_id in selected_doc_ids:
        doc_results = search_document(query, doc_id, top_k)
        doc_info = st.session_state.document_store[doc_id]
        formal_name = doc_info['formal_name']
        
        print(f"   - {formal_name}: Retrieved {len(doc_results)} chunks")

        # Add document context to results
        for result_text, chunk_idx in doc_results:
            all_results.append((result_text, formal_name, doc_id, chunk_idx))

    # Step 2: Rerank across all documents if we have too many results
    print(f"\n📊 STEP 2: Cross-Document Reranking")
    print(f"   Initial results: {len(all_results)} chunks")
    
    main_chunk_indices = {}  # Track which chunks are main chunks
    
    if len(all_results) > top_k:
        try:
            texts = [result[0] for result in all_results]
            rerank_pairs = [(query, text) for text in texts]
            scores = reranker.predict(rerank_pairs)
            sorted_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
            all_results = [all_results[i] for i in sorted_indices[:top_k]]
            print(f"   After reranking: {len(all_results)} chunks (top-{top_k})")
            
            # Track main chunk indices by document
            for result_text, formal_name, doc_id, chunk_idx in all_results:
                if doc_id not in main_chunk_indices:
                    main_chunk_indices[doc_id] = []
                main_chunk_indices[doc_id].append(chunk_idx)
        except Exception as e:
            st.warning(f"Cross-document reranking error: {e}")
            all_results = all_results[:top_k]
    else:
        # Track all as main chunks if no reranking needed
        for result_text, formal_name, doc_id, chunk_idx in all_results:
            if doc_id not in main_chunk_indices:
                main_chunk_indices[doc_id] = []
            main_chunk_indices[doc_id].append(chunk_idx)
    
    # Step 3: Expand context if enabled
    if expand_context and all_results:
        print(f"\n🔄 STEP 3: Context Expansion")
        print(f"   Window size: {window_size} chunk(s) before/after")
        
        expanded_results = []
        
        # Group chunks by document
        doc_chunks = defaultdict(list)
        for result_text, formal_name, doc_id, chunk_idx in all_results:
            doc_chunks[doc_id].append(chunk_idx)
        
        # Expand context for each document
        for doc_id, main_chunks in doc_chunks.items():
            doc_info = st.session_state.document_store[doc_id]
            formal_name = doc_info['formal_name']
            
            print(f"   - {formal_name}:")
            print(f"     Main chunks: {len(main_chunks)} → Indices: {sorted(main_chunks)}")
            
            # Get expanded chunks (already sorted by chunk index)
            expanded_chunks = expand_chunk_context(doc_id, main_chunks, window_size)
            
            print(f"     After expansion: {len(expanded_chunks)} chunks")
            print(f"     Added context: {len(expanded_chunks) - len(main_chunks)} chunks")
            
            # Add expanded chunks to results
            for chunk_text, chunk_idx in expanded_chunks:
                expanded_results.append((chunk_text, formal_name, doc_id, chunk_idx))
        
        # Sort by document ID and then chunk index to maintain coherent order
        expanded_results.sort(key=lambda x: (x[2], x[3]))
        
        print(f"\n   TOTAL: {len(all_results)} → {len(expanded_results)} chunks")
        print(f"   Context expansion: +{len(expanded_results) - len(all_results)} chunks")
        
        return expanded_results, main_chunk_indices
    
    print(f"\n   Context expansion: DISABLED")
    return all_results, main_chunk_indices

def format_chat_history_for_context(chat_history: List[Dict], max_turns: int = 3) -> str:
    """
    Format recent chat history for context.
    
    ✅ IMPORTANT: This function now only uses the LAST 3 turns (6 messages)
    from the full chat history for LLM context, but the UI displays ALL messages.
    """
    if not chat_history:
        return ""
    
    # ✅ Only take last 3 Q&A pairs (6 messages) for LLM context
    # This prevents memory issues while keeping full history visible to user
    recent_history = chat_history[-max_turns*2:]
    
    context_parts = []
    for entry in recent_history:
        role = entry['role']
        content = entry['content']
        if role == 'user':
            context_parts.append(f"User: {content}")
        else:
            context_parts.append(f"Assistant: {content}")
    return "\n".join(context_parts)

# RAG Query Processing with LIVE STREAMING
@timed
def retrieve_and_generate_multi_doc(query: str, selected_doc_ids: List[str],
                                   top_k: int = 5, token_limit: int = TOKEN_LIMIT,
                                   expand_context: bool = True, window_size: int = 1) -> Tuple[str, List[Tuple[str, str, str, int]]]:
    """Retrieve relevant chunks from multiple documents and generate response with optional context expansion
    
    Args:
        query: User query
        selected_doc_ids: List of document IDs to search
        top_k: Number of top chunks to retrieve
        token_limit: Maximum tokens for context
        expand_context: Whether to expand chunks with neighboring context
        window_size: Number of chunks before/after to include
        
    Return:
        full_answer          — the LLM answer
        final_chunks         — list of (chunk_text, formal_name, doc_id, chunk_idx)
        timing_details      — list of (step_name, elapsed_seconds)
    """
    timing_details: List[Tuple[str, float]] = []

    if not selected_doc_ids:
        return "No documents selected. Please select at least one document to search.", [], timing_details

    # Get relevant chunks from selected documents with context expansion
    start = time.perf_counter()
    with st.spinner("Retrieving relevant information with context expansion..."):
        selected_chunks, main_chunk_indices = hybrid_search_multi_doc(
            query, 
            selected_doc_ids, 
            top_k=5,  # Reduced since we're expanding context
            expand_context=expand_context,
            window_size=window_size
        )
    timing_details.append(("retrieval_with_context_expansion", time.perf_counter() - start))

    if not selected_chunks:
        return ("No relevant information found in the selected documents.", [], timing_details)
    
    # Prepare context
    start = time.perf_counter()
    total_tokens = 0
    final_chunks = []
    increased_token_limit = 12000

    for chunk_text, formal_name, doc_id, chunk_idx in selected_chunks:
        chunk_tokens = len(chunk_text.split())
        if total_tokens + chunk_tokens <= increased_token_limit:
            final_chunks.append((chunk_text, formal_name, doc_id, chunk_idx))
            total_tokens += chunk_tokens
        else:
            break
    timing_details.append(("context_construction", time.perf_counter() - start))
    
    if not final_chunks:
        return ("No relevant information found to answer your query.", [], timing_details)
    
    # Store statistics for UI display
    if main_chunk_indices:
        total_main = sum(len(indices) for indices in main_chunk_indices.values())
        total_context = len(final_chunks) - total_main
        st.session_state.last_retrieval_stats = {
            'main_chunks': total_main,
            'context_chunks': total_context,
            'total_chunks': len(final_chunks),
            'expansion_ratio': total_context / total_main if total_main > 0 else 0
        }
    else:
        st.session_state.last_retrieval_stats = {
            'main_chunks': len(final_chunks),
            'context_chunks': 0,
            'total_chunks': len(final_chunks),
            'expansion_ratio': 0
        }
    
    # Log retrieved chunks
    start = time.perf_counter()
    username = st.session_state.get('username', 'guest')
    remote_ip = get_remote_ip()
    print_retrieved_chunks_to_terminal(username, query, final_chunks, main_chunk_indices)
    log_retrieved_chunks(username, query, final_chunks, remote_ip, main_chunk_indices)
    timing_details.append(("logging", time.perf_counter() - start))

    # Prepare context with document sources
    start = time.perf_counter()
    context_parts = []
    for chunk_text, formal_name, doc_id, chunk_idx in final_chunks:
        context_parts.append(f"[Source: {formal_name}]\n{chunk_text}")
    context_text = "\n\n".join(context_parts)
    timing_details.append(("context_preparation", time.perf_counter() - start))

    # Get chat history context
    start = time.perf_counter()
    chat_context = format_chat_history_for_context(st.session_state.chat_history)
    timing_details.append(("chat_context", time.perf_counter() - start))

    # Generate response with streaming
    start = time.perf_counter()

    document_list = ", ".join([st.session_state.document_store[doc_id]['formal_name']
                              for doc_id in selected_doc_ids])

    # Detect if query requires complete lists
    requires_complete_list = any(keyword in query.lower() for keyword in
                                 ['steps', 'documents', 'requirements', 'aspects',
                                  'list', 'what are', 'enumerate', 'all', 'which'])

    if requires_complete_list:
        list_instruction = """
** CRITICAL: This query asks for a complete LIST or ENUMERATION **
- You MUST provide ALL items/points/steps mentioned in the context without omission
- Maintain the EXACT structure and numbering from the source document
- Do NOT summarize or combine list items
- If items are numbered (i), (ii), (iii) or lettered a), b), c), preserve that exact format
- Include EVERY SINGLE point mentioned in the source
- If the list spans multiple chunks, combine all parts to provide the complete list
"""
    else:
        list_instruction = "** Try to answer concisely based on the context provided."

    system_prompt = f"""You are a helpful Assistant. Answer the question based on the following documents: {document_list}

                            ### INSTRUCTIONS ###
                            {list_instruction}
                            ** If you find multiple chunks related to query please mention all of them.
                            ** Clearly cite the relevant section number(s) where the information is sourced, using the format `X.Y.Z` or `X.Y` (e.g., "As per section 2.3.1 of {{formal_name}}, ...").
                            ** Always mention the source document name when referencing information.
                            ** Do not use personal knowledge or external information to answer queries.
                            ** Do not mention context_id or chunk_id.
                            ** If you know the answer but it is not based in the provided context, don't provide the answer, just state the answer is not in the context provided.
                            ** Mention the names of all searched documents at the end of response.
                            ** Consider the conversation history for context but prioritize the current query.
                            ** Do not provide any technical information or programming language coding responses when asked.
                            ** Do not hallucinate; only use the provided context.
                           
                           
                           ### IMAGE AND MEDIA HANDLING ###
                           ** IMPORTANT: If the context contains any image URLs, markdown image syntax (![alt](url)), or media links, you MUST reproduce them EXACTLY as they appear in the context.
                           ** Preserve all markdown formatting including image syntax: ![description](image_url)
                           ** Include image URLs and media links in your response when they are relevant to the query.
                           ** Do not modify or paraphrase image URLs - copy them exactly as they appear.
                           ** If an image or diagram is referenced in the context, include the actual image markdown in your response."""

    user_message = f"""Conversation History:\n{chat_context}\n\nDocument Content:\n{context_text}\n\nCurrent Question: {query}
                    """
    timing_details.append(("user_message", time.perf_counter() - start))
    
    start_llm = time.perf_counter()
    first_token_time = None
    last_token_time = None
    
    # ✅ Get Ollama client with connection pooling management
    client = get_ollama_client()

    ################################################################################
    THINKING_MESSAGES = [
        "Analyzing your query against the available documents.",
        "Retrieving the most relevant information.",
        "Processing context to ensure an accurate response.",
        "Searching the knowledge base for matching insights.",
        "Reviewing related content to form a precise answer.",
        "Evaluating document sections for relevance.",
        "Synthesizing information from multiple sources.",
        "Aligning your question with stored knowledge.",
        "Identifying key details required for the response.",
        "Cross-checking facts to improve accuracy.",
        "Understanding the intent behind your question.",
        "Filtering unnecessary information.",
        "Assembling a clear and concise answer.",
        "Validating results before responding.",
        "Matching your query with indexed content.",
        "Optimizing the response for clarity.",
        "Finalizing the answer for delivery.",
    ]

    ################################################################################S

    # Create a placeholder that we will update with each chunk
    with st.spinner("Thinking... " + random.choice(THINKING_MESSAGES)):

        placeholder = st.empty()
        full_answer = ""
        stream = None
        try:
            stream = client.chat(
                    model=LLM_MODEL,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message}
                    ],
                    options={"num_ctx": 32000, "temperature": 0.1},  # Reduced from 0.2
                    stream=True)

            for chunk in stream:
                if first_token_time is None:
                    first_token_time = time.perf_counter()
                    # Record latency to first token
                    timing_details.append(("first_token_latency", first_token_time - start_llm))
                    first_token_time=1
                chunk_text = chunk["message"]["content"]
                full_answer += chunk_text
                placeholder.markdown(full_answer)
            last_token_time = time.perf_counter()

        except Exception as e:
            st.error(f"Error generating response: {e}")
            return (f"Error generating response: {e}", [], timing_details)
        finally:
            # ✅ CRITICAL FIX: Explicitly close the stream
            if stream is not None and hasattr(stream, 'close'):
                try:
                    stream.close()
                except:
                    pass
            # Force garbage collection
            import gc
            gc.collect()

        timing_details.append(("llm_call", time.perf_counter() - start_llm))
        timing_details.append(("last_token_latency", last_token_time - start_llm))

        return full_answer, final_chunks, timing_details

def imageNtxt(text):
    image_pattern = r'!\[(.*?)\]\((.*?)\)'

    # Split the markdown into chunks around the image patterns
    chunks = re.split(image_pattern, text)

    i = 0
    while i < len(chunks):
        # Print text part (before image or between images)
        if chunks[i].strip():
            st.write(chunks[i])
        i += 1

        # If there's an image in this position
        if i + 1 < len(chunks):
            alt_text = chunks[i]
            image_path = f"./static/{chunks[i + 1]}"
            print(image_path)
            try:
                st.image(str(image_path), caption=alt_text)
            except:
                st.warning(f"Image not found: {image_path}")
            i += 2  # move past alt + image

def display_chat_history():
    """
    Display FULL chat history using st.chat_message
    
    ✅ Shows ALL messages to the user (unlimited)
    ✅ Only recent messages are used for LLM context (handled in format_chat_history_for_context)
    """
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []

    # Display ALL messages - no limit for UI
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            imageNtxt(message["content"])
@timed
def process_search(query: str, selected_doc_ids: List[str], expand_context: bool = True, window_size: int = 1):
    """
    Process search query and update chat history

    ✅ NEW BEHAVIOR:
    - Displays ALL messages in UI (unlimited)
    - Only passes last 3 Q&A pairs (6 messages) to LLM for context
    - This prevents memory issues while maintaining full conversation visibility
    """
    global current_interaction_times, function_timings
    current_interaction_times = []

    # ✅ CRITICAL FIX: Clear old timing data to prevent memory accumulation
    if len(function_timings) > 100:
        function_timings = function_timings[-100:]  # Keep only last 100 entries

    if not selected_doc_ids:
        st.error("⚠️ Please select at least one document to search.")
        return

    start_time = time.time()

    # ✅ Add user query to FULL chat history (for UI display)
    st.session_state.chat_history.append({"role": "user", "content": query})

    # ✅ NO TRIMMING HERE - Keep full history for UI display
    # The format_chat_history_for_context() function handles limiting context for LLM

    with st.chat_message("user"):
        st.write(query)

    # Show assistant message container - streaming happens inside
    with st.chat_message("assistant"):
        # Call the function - LIVE streaming happens inside retrieve_and_generate_multi_doc
        # Note: Only last 3 Q&A pairs will be used as context (handled internally)
        response, chunks_used, timing_details = retrieve_and_generate_multi_doc(
            query, selected_doc_ids, top_k=5, expand_context=expand_context, window_size=window_size
        )

    response_time = time.time() - start_time

    # Log the interaction
    username = st.session_state.get('username', 'guest')
    remote_ip = get_remote_ip()
    log_chat_interaction(
        username, query, response, response_time, remote_ip, timing_list=timing_details
    )
    for x in timing_details:
        print(f"{x[0]}\t\t{x[1]}")
    print("", flush=True)

    # ✅ Add assistant response to FULL chat history (for UI display)
    st.session_state.chat_history.append({"role": "assistant", "content": response})

    # ✅ NO TRIMMING - Full history stays in session_state for UI
    # Only the format_chat_history_for_context() function limits what goes to LLM

# Main Streamlit UI
def main():
    st.title("📚 Procurement Policy Related Assistant")

    # Get PDF files - store filenames only, load on-demand
    PDF_DIR = "/home/dlpda/production_v3/procurement_chatbot_v1.0/documents"
    pdf_files = {}
    if os.path.exists(PDF_DIR):
        for file_name in os.listdir(PDF_DIR):
            if file_name.lower().endswith(".pdf"):
                pdf_files[file_name] = os.path.join(PDF_DIR, file_name)  # Store paths only

    # ---------- Build download links using on-demand loading ----------
    doc1_link, doc2_link = "", ""
    doc1_file, doc2_file = None, None
    
    for filename, filepath in pdf_files.items():
        if "procurement" in filename.lower() or "manual" in filename.lower() or "2025" in filename:
            doc1_file = filepath
            doc1_link = f'<span style="font-weight:bold;color:#0066cc;">1. Procurement Manual (PM-2025)</span>'
        elif "delegation" in filename.lower() or "financial" in filename.lower() or "2019" in filename:
            doc2_file = filepath
            doc2_link = f'<span style="font-weight:bold;color:#0066cc;">2. Delegation of Financial Powers (2019)</span>'

    # Fallback text if a link was not created
    if not doc1_link:
        doc1_link = '<span style="font-weight:bold;color:#000000;">1. Procurement Manual (PM-2025)</span>'
    if not doc2_link:
        doc2_link = '<span style="font-weight:bold;color:#000000;">2. Delegation of Financial Powers (2019)</span>'

    # ---------- Single background container ----------
    with st.container():
        st.markdown(
            f"""
            <div style="
                background-color:#e6f7ff;
                padding:15px;
                border-radius:15px;
                ">
                <div style="display:flex; gap:20px;">
                    <!-- Column 1 -->
                    <div style="flex:1;">
                        <p>
                            <b>Acknowledgment:</b><br>
                            This chatbot has been developed with inputs from DCMM & its team.<br>
                            <b>Disclaimer:</b><br>
                            The chatbot's responses are limited to the content of these two policy documents:<br>
                            {doc1_link}<br>
                            {doc2_link}<br>
                        </p>
                    </div>
                    <!-- Column 2 -->
                    <div style="flex:1;">
                        <p>
                           <b> Please note the following: </b><br>
                            • The chatbot will attempt to provide accurate responses based on the information available in these policy documents.<br>
                            • Please use the chatbot's responses as a general guideline, as in some cases the response may not be entirely accurate.<br>
                            • The chatbot will provide references indicating which sources the response is based on.<br>
                            • Users are advised to refer to the original policy documents for confirmation of the chatbot's responses using the sources provided.<br>
                            • Please provide feedback on any factual errors to help us improve the chatbot.
                        </p>
                    </div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        
        # Add download buttons for PDFs (loaded on-demand only when clicked)

        with st.expander("📄 Show Policy Document Downloads"):

            col1, col2 = st.columns(2)

            with col1:
                if doc1_file and os.path.exists(doc1_file):
                    # Load the file only when the expander is opened
                    with open(doc1_file, "rb") as f:
                        st.download_button(
                            label="📥 Download Procurement Manual (PM‑2025)",
                            data=f,
                            file_name=os.path.basename(doc1_file),
                            mime="application/pdf",
                            use_container_width=True,
                        )

            with col2:
                if doc2_file and os.path.exists(doc2_file):
                    # Load the file only when the expander is opened
                    with open(doc2_file, "rb") as f:
                        st.download_button(
                            label="📥 Download Delegation of Financial Powers (2019)",
                            data=f,
                            file_name=os.path.basename(doc2_file),
                            mime="application/pdf",
                            use_container_width=True,
                        )
    # Initialize session state
    if "document_store" not in st.session_state:
        st.session_state.document_store = load_document_store()
        st.session_state.milvus_client = None
        st.session_state.chat_history = []  # FULL chat history for UI display (unlimited)
        st.session_state.is_admin = False
        st.session_state.username = "guest"  # Default username for logging
        st.session_state.expand_context = True  # Default: context expansion enabled
        st.session_state.window_size = 1  # Default: 1 chunk before/after

    # Setup Milvus client
    if st.session_state.milvus_client is None:
        st.session_state.milvus_client = MilvusClient(uri="./milvus_lite_st.db")

    # Admin sidebar
    if not check_admin_login():
        with st.sidebar:
            if st.button("Admin Login"):
                st.session_state.page="Admin"
                st.rerun()

    # Main interface tabs
    if check_admin_login():
        st.sidebar.success("✅ Logged in as Admin")
        if st.sidebar.button("Logout"):
            st.session_state.is_admin = False
            st.session_state.page=None
            st.rerun()
        tab1, tab2 = st.tabs(["🔎 Search Interface", "⚙️ Admin Panel"])

        with tab2:
            admin_document_management()

        with tab1:
            search_interface()
    else:
        search_interface()

def search_interface():
    """Main search interface - NO follow-up questions"""
    # Document selection for search
    st.subheader("📚 Document Selection")
    if st.session_state.document_store:
        document_options = {doc_info['formal_name']: doc_id
                          for doc_id, doc_info in st.session_state.document_store.items()}
        st.write("Select documents to search:")

        # Initialize selected documents in session state if not exists
        if 'selected_doc_names' not in st.session_state:
            # Default: select only first document
            st.session_state.selected_doc_names = [list(document_options.keys())[0]] if document_options else []

        # Create checkboxes for each document
        selected_documents = []

        for doc_name in document_options.keys():
            # Check if this document should be checked by default
            default_checked = doc_name in st.session_state.selected_doc_names

            # Create checkbox for each document
            is_selected = st.checkbox(
                f"**📄 {doc_name}**",
                value=default_checked,
                key=f"doc_checkbox_{doc_name}"
            )

            if is_selected:
                selected_documents.append(doc_name)

        # Update session state
        st.session_state.selected_doc_names = selected_documents

        # Get document IDs for selected documents
        selected_doc_ids = [document_options[doc] for doc in selected_documents]

        if selected_documents:
            st.success(f"✅ Selected {len(selected_documents)} document(s) for generating response")
        else:
            st.warning("⚠️ Please select at least one document to search")
            selected_doc_ids = []
    else:
        st.info("ℹ️ No documents available for search. Please contact admin to add documents.")
        selected_doc_ids = []

    # Context expansion is always enabled with default settings
    expand_context = True
    window_size = 1
    
    st.session_state.expand_context = expand_context
    st.session_state.window_size = window_size
    
    # ✅ NEW: Show chat history status
    MAX_CHAT_HISTORY = 10  # 5 questions + 5 answers
    if 'chat_history' in st.session_state and len(st.session_state.chat_history) > 0:
        qa_pairs = len(st.session_state.chat_history) // 2
        # st.info(f"📄 Chat History: {qa_pairs} Q&A pair(s) (max {MAX_CHAT_HISTORY // 2} kept in memory)")

    # Chat History Display
    st.subheader("💬 Conversation")
    chat_container = st.container()

    # Display all chat history
    display_chat_history()

    # Query input section - Fixed at bottom using Streamlit's native chat_input
    query = st.chat_input("Type your question here...", key="user_query_input")


    # Process search when user submits query via chat_input
    if query:
        if not selected_doc_ids:
            st.error("⚠️ Please select at least one document to search.")
        else:
            # Add user message to chat history
            st.session_state.chat_history.append({"role": "user", "content": query})

            # Display user message immediately
            with st.chat_message("user"):
                st.write(query)

            # Generate and display assistant response
            with st.chat_message("assistant"):
                start_time = time.time()

                # Call the function with streaming
                response, chunks_used, timing_details = retrieve_and_generate_multi_doc(
                    query,
                    selected_doc_ids,
                    top_k=5,
                    expand_context=expand_context,
                    window_size=window_size
                )

                response_time = time.time() - start_time

                # Log the interaction
                username = st.session_state.get('username', 'guest')
                remote_ip = get_remote_ip()
                log_chat_interaction(
                    username, query, response, response_time, remote_ip, timing_list=timing_details
                )

                # ✅ FIX 1: Print timing details to terminal (same as now.py)
                for x in timing_details:
                    print(f"{x[0]}\t\t{x[1]}")
                print("", flush=True)

                # Add assistant response to chat history
                st.session_state.chat_history.append({"role": "assistant", "content": response})

            st.rerun()

footer_html = """
<style>
/* Container that holds the footer text */
footer {
    position: fixed;          /* Keep it fixed relative to the viewport */
    left: 0;
    bottom: 0;
    width: 100%;              /* Span the full width of the page */
    background-color: #f8fafc;/* Light background (optional) */
    color: #64748b;           /* Text colour – matches your original style */
    text-align: center;
    font-size: 15px;
    padding: 0 0;           /* Vertical spacing */
    z-index: 999;             /* Ensure it appears above other elements */
}
</style>

<footer>

Designed & Developed by DAIV, RCI Team
For Support  Call 040-2430 7192

</footer>
"""

st.markdown(footer_html, unsafe_allow_html=True)

if __name__ == "__main__":
    if "page" not in st.session_state:
        st.session_state.page = None
    embedder, reranker, tokenizer = load_models()
    if st.session_state.page == "Admin":
        admin_sidebar()
    else:
        main()
