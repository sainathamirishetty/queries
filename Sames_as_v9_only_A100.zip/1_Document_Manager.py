"""
1_Document_Manager.py – Upload, browse and delete documents
Run with:
    streamlit run 1_Document_Manager.py

Companion pages live in pages/
    pages/3_Chat_Assistant.py
"""

import os
import shutil
import hashlib
from datetime import date, datetime
from pathlib import Path

import streamlit as st
import config
import shared_db
from login_page import run as login_run

# ----------------------------------------------------------------------
# 0️⃣  Constants & helper functions (must be defined before use)
# ----------------------------------------------------------------------
_BASE_DOCS_DIR = Path(config.DOCUMENTS_INPUT_DIR)
_BASE_DOCS_DIR.mkdir(parents=True, exist_ok=True)

def _user_docs_dir(user_name: str) -> Path:
    d = _BASE_DOCS_DIR / user_name
    d.mkdir(parents=True, exist_ok=True)
    return d

# ----------------------------------------------------------------------
# 1️⃣  Show login UI first
# ----------------------------------------------------------------------
login_run()

# If the user did not log in, stop the script.
if "user" not in st.session_state:
    st.stop()

# Alias used throughout the file
current_user = st.session_state["user"]

# 🔒 Resolve the per-user upload directory now that we know who is logged in
DOCS_DIR = _user_docs_dir(current_user)

# ----------------------------------------------------------------------
# 2️⃣  Page configuration
# ----------------------------------------------------------------------
st.set_page_config(
    page_title="Document Manager",
    page_icon="📁",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----------------------------------------------------------------------
# 3️⃣  Global CSS (kept from the original file)
# ----------------------------------------------------------------------
st.markdown(
    """
<style>
/* Sidebar styling */
[data-testid="stSidebar"] {
    background: #181c27 !important;
    border-right: 1px solid #2a3050 !important;
}
[data-testid="stSidebar"] * { color: #e2e8f0 !important; }

.sb-heading {
    font-size: 1.1rem; font-weight: 700;
    margin: 0 0 .8rem;
    padding-bottom: .5rem;
    border-bottom: 1px solid #2a3050;
}
.sb-file-card {
    background: #1f2435; border: 1px solid #2a3050;
    border-radius: 10px; padding: .6rem .8rem;
    margin-bottom: .5rem; display: flex;
    align-items: flex-start; gap: .6rem;
}
.sb-file-icon { font-size: 1.2rem; flex-shrink: 0; margin-top: .05rem; }
.sb-file-info  { flex: 1; min-width: 0; }
.sb-file-name  { font-size: .82rem; font-weight: 600;
                  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sb-file-date  { font-size: .72rem; color: #8892a4; margin-top: .15rem; }
.sb-stats { display: flex; flex-wrap: wrap; gap: .4rem; margin-bottom: .8rem; }
.sb-chip  { font-size: .7rem; font-weight: 600; padding: 2px 8px; border-radius: 20px;
            background: #1f2435; border: 1px solid #2a3050; color: #8892a4; }
.sb-chip b { color: #4f8ef7; }

/* status badges */
.badge-pending  { background:#2a3050; color:#f0c040; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-running  { background:#1a3a5c; color:#4f8ef7; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-enriching { background:#241a3a; color:#b388ff; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-indexing { background:#123a3a; color:#00bcd4; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-done     { background:#1a3a2a; color:#4caf50; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-failed   { background:#3a1a1a; color:#ef5350; border-radius:6px; padding:1px 7px; font-size:.72rem; }

[data-testid="stSidebar"] .stTextInput > div > div > input,
[data-testid="stSidebar"] .stDateInput  > div > div > input {
    background: #1f2435 !important; border: 1px solid #2a3050 !important;
    border-radius: 8px !important; font-size: .82rem !important;
}
[data-testid="stSidebar"] .stButton > button {
    background: linear-gradient(135deg, #4f8ef7, #7c5cfc) !important;
    border: none !important; border-radius: 7px !important;
    color: #fff !important; font-weight: 600 !important; font-size: .8rem !important;
}
</style>
""",
    unsafe_allow_html=True,
)

# ----------------------------------------------------------------------
# 4️⃣  Additional constants & helper functions
# ----------------------------------------------------------------------
DOCS_PER_PAGE = 3

# Single source of truth for "which file types does this app ingest" — used
# by both the individual-file uploader and the folder-bulk scanner below,
# so the two upload modes never disagree on what's supported.
ALLOWED_UPLOAD_TYPES = [
    "pdf", "pptx", "ppt", "docx", "doc",
    "xlsx", "xls", "txt", "md", "csv",
]
ALLOWED_UPLOAD_EXTS = {f".{t}" for t in ALLOWED_UPLOAD_TYPES}

EXT_ICON = {
    ".pdf": "📄", ".ppt": "📊", ".pptx": "📊",
    ".doc": "📝", ".docx": "📝", ".xls": "📈",
    ".xlsx": "📈", ".txt": "📃", ".md": "📃", ".csv": "📋",
}


def file_icon(ext: str) -> str:
    """Return an emoji based on file extension."""
    return EXT_ICON.get(ext.lower(), "📁")


def human_size(n: int) -> str:
    """Convert a size in bytes to a human‑readable string."""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def list_docs(user_name: str):
    """Return only the files that belong to *user_name* (per DB records)."""
    meta = shared_db.load_all_documents(user_name)
    user_dir = _user_docs_dir(user_name)
    result = []
    for filename in meta:
        f = user_dir / filename
        if f.exists():
            result.append(f)
    # Sort newest-first by modification time
    return sorted(result, key=lambda f: f.stat().st_mtime, reverse=True)


# ----------------------------------------------------------------------
# 5️⃣  Session‑state initialisation
# ----------------------------------------------------------------------
if "file_metadata_store" not in st.session_state:
    # Load metadata for the current user
    st.session_state.file_metadata_store = shared_db.load_all_documents(current_user)
else:
    # Refresh on every run (keeps it in sync with DB)
    st.session_state.file_metadata_store = shared_db.load_all_documents(current_user)

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0

# Upload‑related state (new)
if "uploaded_files" not in st.session_state:
    st.session_state.uploaded_files = []          # list of UploadedFile objects
if "upload_meta" not in st.session_state:
    st.session_state.upload_meta = {}            # filename → dict of meta
if "upload_idx" not in st.session_state:
    st.session_state.upload_idx = 0              # which file we are editing now

# Folder (bulk) upload state — separate from the individual-file state above
if "bulk_folder_path" not in st.session_state:
    st.session_state.bulk_folder_path = ""
if "bulk_scan_results" not in st.session_state:
    st.session_state.bulk_scan_results = None      # {"root", "files", "skipped"} once scanned

# ----------------------------------------------------------------------
# 6️⃣  Sidebar – Document Library (no upload UI)
# ----------------------------------------------------------------------
with st.sidebar:
    st.markdown(
        '<div class="sb-heading">📁 Document Library</div>',
        unsafe_allow_html=True,
    )
    # Library list – unchanged from original
    all_docs = list_docs(current_user)
    meta_store = st.session_state.file_metadata_store
    jobs = {
        j["filename"]: j
        for j in shared_db.get_all_jobs(current_user)
    }

    if not all_docs:
        st.caption("No documents yet. Upload one above.")
    else:
        total_size = sum(f.stat().st_size for f in all_docs)
        chips = '<div class="sb-stats">'
        chips += f'<span class="sb-chip"><b>{len(all_docs)}</b> files</span>'
        chips += f'<span class="sb-chip"><b>{human_size(total_size)}</b></span>'
        chips += "</div>"
        st.markdown(chips, unsafe_allow_html=True)

        search_q = st.text_input(
            "search", placeholder="🔍 Search…", label_visibility="collapsed"
        )

        filtered_docs = [
            f
            for f in all_docs
            if not search_q
            or search_q.lower()
            in (
                (meta_store.get(f.name, {}).get("title") or f.stem) + f.name
            ).lower()
        ]

        total_pages = max(1, -(-len(filtered_docs) // DOCS_PER_PAGE))

        if "doc_page" not in st.session_state:
            st.session_state.doc_page = 1
        if "last_search_q" not in st.session_state:
            st.session_state.last_search_q = ""
        if search_q != st.session_state.last_search_q:
            st.session_state.doc_page = 1
            st.session_state.last_search_q = search_q

        st.session_state.doc_page = max(
            1, min(st.session_state.doc_page, total_pages)
        )
        page = st.session_state.doc_page
        page_docs = filtered_docs[
            (page - 1) * DOCS_PER_PAGE : page * DOCS_PER_PAGE
        ]

        for f in page_docs:
            meta = meta_store.get(f.name, {})
            title = meta.get("title") or f.stem
            doc_date = meta.get("date", "")
            uploaded_at = meta.get("uploaded_at", "")
            job = jobs.get(f.name)

            # Date label
            if doc_date:
                date_label = f"📅 {doc_date}"
            elif uploaded_at:
                try:
                    dt = datetime.fromisoformat(uploaded_at)
                    friendly = dt.strftime("%-d %b %Y, %I:%M %p")
                except Exception:
                    friendly = uploaded_at[:16].replace("T", " ")
                date_label = f"🕒 Uploaded: {friendly}"
            else:
                date_label = "📅 No date"

            # Status badge – prefer job status, fall back to documents.status
            if job:
                s = job["status"]
                badge_cls = f"badge-{s}"
                status_html = f'<span class="{badge_cls}">{s.upper()}</span>'
            else:
                # Check the documents table status column
                doc_status = meta.get("status", "pending")
                if doc_status in ("done",):
                    status_html = '<span class="badge-done">DONE</span>'
                elif doc_status in ("running",):
                    status_html = '<span class="badge-running">RUNNING</span>'
                elif doc_status in ("failed",):
                    status_html = '<span class="badge-failed">FAILED</span>'
                else:
                    status_html = '<span class="badge-pending">PENDING</span>'

            icon = file_icon(f.suffix)
            st.markdown(
                f"""
<div class="sb-file-card">
  <div class="sb-file-icon">{icon}</div>
  <div class="sb-file-info">
    <div class="sb-file-name" title="{f.name}">{title}</div>
    <div class="sb-file-date">{date_label} · {human_size(f.stat().st_size)}</div>
    <div style="margin-top:.2rem">{status_html}</div>
  </div>
</div>
""",
                unsafe_allow_html=True,
            )

            # ---- Delete with confirmation ----
            del_key = f"del_{f.name}"
            confirm_key = f"confirm_{f.name}"
            if st.session_state.get(confirm_key, False):
                col1, col2 = st.columns([1, 1])
                with col1:
                    if st.button(
                        "✅ Yes, delete", key=f"yes_{f.name}", use_container_width=True
                    ):
                        with st.spinner("Deleting document and all related files…"):
                            result = shared_db.purge_document_artifacts(f.name, current_user)
                        st.session_state.file_metadata_store.pop(f.name, None)
                        st.session_state.pop(confirm_key, None)
                        if result["errors"]:
                            st.warning(
                                "Deleted with some warnings:\n" +
                                "\n".join(result["errors"])
                            )
                        st.rerun()
                with col2:
                    if st.button(
                        "❌ Cancel", key=f"cancel_{f.name}", use_container_width=True
                    ):
                        st.session_state.pop(confirm_key, None)
                        st.rerun()
            else:
                if st.button("🗑 Delete", key=del_key, use_container_width=True):
                    st.session_state[confirm_key] = True
                    st.rerun()

        # Pagination controls (unchanged)
        if total_pages > 1:
            st.markdown(
                f'<div style="text-align:center;font-size:.72rem;color:#8892a4;margin:.4rem 0 .2rem;">'
                f'Page {page} of {total_pages}  ·  {len(filtered_docs)} doc(s)</div>',
                unsafe_allow_html=True,
            )
            prev_col, mid_col, next_col = st.columns([1, 2, 1])
            with prev_col:
                if st.button(
                    "◄",
                    key="pg_prev",
                    use_container_width=True,
                    disabled=(page <= 1),
                ):
                    st.session_state.doc_page -= 1
                    st.rerun()
            with mid_col:
                st.markdown(
                    f'<div style="text-align:center;padding:.35rem 0;font-size:.8rem;color:#e2e8f0;">'
                    f'{page} / {total_pages}</div>',
                    unsafe_allow_html=True,
                )
            with next_col:
                if st.button(
                    "►",
                    key="pg_next",
                    use_container_width=True,
                    disabled=(page >= total_pages),
                ):
                    st.session_state.doc_page += 1
                    st.rerun()

# ----------------------------------------------------------------------
# 7️⃣  Main area – Upload & summary
# ----------------------------------------------------------------------
st.markdown(
    '<h1 style="text-align:center">📁 Document Manager</h1>', unsafe_allow_html=True
)
st.markdown(
    """
<div style="text-align:center;color:#8892a4;margin-bottom:2rem;">
Upload and manage your documents here. Processing happens automatically in the background.
</div>
""",
    unsafe_allow_html=True,
)

# ---------- Upload section ----------
st.subheader("📂 Upload Documents")

upload_mode = st.radio(
    "How would you like to add documents?",
    options=[
        "📄 Individual file(s)",
        "📁 Entire folder (bulk — for 100s to 15,000+ documents)",
    ],
    horizontal=True,
    key="upload_mode",
    label_visibility="collapsed",
)

if upload_mode == "📄 Individual file(s)":
    uploaded = st.file_uploader(
        "Select files",
        type=ALLOWED_UPLOAD_TYPES,
        accept_multiple_files=True,
        label_visibility="collapsed",
        key=f"file_uploader_{st.session_state.uploader_key}",
    )

    if uploaded:
        # Store the list only once (avoid resetting while navigating)
        if not st.session_state.uploaded_files:
            st.session_state.uploaded_files = uploaded
            st.session_state.upload_idx = 0
            # Initialise empty meta dict for each file
            for uf in uploaded:
                st.session_state.upload_meta[uf.name] = {
                    "project_name": "",
                    "title": Path(uf.name).stem.replace("_", " ").replace("-", " "),
                    "date": date.today(),
                    "category": "",
                    "remarks": "",
                }
else:
    # ---------- Folder (bulk) upload ----------
    # This app runs on the same server as your documents, so "folder upload"
    # here means pointing it at a folder that already exists on that
    # server's filesystem, rather than picking one in the browser. For
    # 10,000-15,000+ documents that's dramatically faster and more reliable
    # than a browser multipart upload of that many files one at a time —
    # it's a local disk copy instead of thousands of HTTP requests.
    st.caption(
        "Point this at a folder **on the server this app runs on**. It is scanned "
        "**recursively** — supported files in any subfolder, any number of levels deep, "
        "are found automatically. Non-matching files are skipped, not rejected."
    )

    folder_path_input = st.text_input(
        "Folder path on the server",
        value=st.session_state.bulk_folder_path,
        placeholder="/home/youruser/big_documents_folder",
        key="bulk_folder_path_input",
    )

    move_instead_of_copy = st.checkbox(
        "Move files instead of copying (frees up space in the source folder — the "
        "originals will no longer be there afterward)",
        value=False,
        key="bulk_move_files",
    )

    scan_clicked = st.button("🔍 Scan Folder", use_container_width=False)

    if scan_clicked:
        candidate = folder_path_input.strip()
        st.session_state.bulk_folder_path = candidate
        src_root = Path(candidate) if candidate else None

        if not candidate:
            st.error("Please enter a folder path first.")
            st.session_state.bulk_scan_results = None
        elif not src_root.exists() or not src_root.is_dir():
            st.error(f"❌ Folder not found (or not a directory): `{candidate}`")
            st.session_state.bulk_scan_results = None
        else:
            found, skipped = [], 0
            for root, _dirs, files in os.walk(str(src_root)):
                for fname in files:
                    fp = Path(root) / fname
                    if fp.suffix.lower() in ALLOWED_UPLOAD_EXTS:
                        found.append(fp)
                    else:
                        skipped += 1
            st.session_state.bulk_scan_results = {
                "root": str(src_root),
                "files": found,
                "skipped": skipped,
            }

    scan_results = st.session_state.bulk_scan_results
    if scan_results:
        n_found = len(scan_results["files"])
        root_display = scan_results["root"]

        if n_found == 0:
            st.warning(
                "⚠️ No supported documents found anywhere in that folder "
                "(including its subfolders)."
            )
        else:
            skip_note = (
                f" &nbsp;|&nbsp; ⏭️ skipped {scan_results['skipped']} unsupported file(s)."
                if scan_results["skipped"] else "."
            )
            st.markdown(
                f"✅ Found **{n_found}** supported document(s) across all subfolders of "
                f"`{root_display}`{skip_note}",
                unsafe_allow_html=True,
            )

            preview = scan_results["files"][:25]
            with st.expander(f"Preview first {len(preview)} of {n_found} file(s)"):
                for fp in preview:
                    try:
                        rel = fp.relative_to(root_display)
                    except ValueError:
                        rel = fp.name
                    st.caption(f"{file_icon(fp.suffix)} {rel}")
                if n_found > len(preview):
                    st.caption(f"…and {n_found - len(preview)} more.")

            if st.button(
                f"🚀 Queue All {n_found} Document(s) for Processing",
                type="primary",
                use_container_width=True,
            ):
                total = n_found
                progress_bar = st.progress(0.0)
                status_txt = st.empty()
                queued = duplicates = errors = 0
                error_samples = []

                for i, src_fp in enumerate(scan_results["files"], start=1):
                    try:
                        dest_fp = DOCS_DIR / src_fp.name

                        if dest_fp.exists() and dest_fp.stat().st_size == src_fp.stat().st_size:
                            # Same name + same size already present for this user —
                            # treat as already-uploaded and skip (safe to re-scan
                            # the same folder more than once, e.g. after an
                            # interruption, without duplicating work).
                            duplicates += 1
                        else:
                            if dest_fp.exists():
                                # Same filename but a *different* file (e.g. two
                                # subfolders both had "report.pdf") — disambiguate
                                # instead of overwriting.
                                digest = hashlib.sha1(str(src_fp).encode()).hexdigest()[:8]
                                dest_fp = DOCS_DIR / f"{src_fp.stem}__{digest}{src_fp.suffix}"

                            if move_instead_of_copy:
                                shutil.move(str(src_fp), str(dest_fp))
                            else:
                                shutil.copy2(str(src_fp), str(dest_fp))

                            record = {
                                "filename": dest_fp.name,
                                "project_name": "",
                                "title": dest_fp.stem.replace("_", " ").replace("-", " "),
                                "date": str(date.today()),
                                "category": "",
                                "doc_id": "",
                                "uploaded_at": datetime.now().isoformat(),
                                "size_bytes": dest_fp.stat().st_size,
                                "status": "pending",
                            }
                            shared_db.save_document(record, current_user)
                            shared_db.enqueue_job(dest_fp.name, current_user)
                            st.session_state.file_metadata_store[dest_fp.name] = record
                            queued += 1

                    except Exception as e:
                        errors += 1
                        if len(error_samples) < 5:
                            error_samples.append(f"{src_fp.name}: {e}")

                    if i % 10 == 0 or i == total:
                        progress_bar.progress(i / total)
                        status_txt.text(
                            f"{i}/{total} scanned — {queued} queued, "
                            f"{duplicates} already present, {errors} failed"
                        )

                st.session_state.bulk_scan_results = None
                summary = f"✅ Done! {queued} document(s) queued for processing"
                if duplicates:
                    summary += f", {duplicates} already existed and were skipped"
                if errors:
                    summary += f", {errors} failed"
                st.success(summary + ".")
                if error_samples:
                    st.warning("Some files failed:\n" + "\n".join(error_samples))
                st.rerun()

# Navigation & metadata form ----------
if st.session_state.uploaded_files:
    idx = st.session_state.upload_idx
    cur_file = st.session_state.uploaded_files[idx]
    cur_meta = st.session_state.upload_meta[cur_file.name]

    col_left, col_mid, col_right = st.columns([1, 6, 1])
    with col_left:
        if st.button("← Prev", disabled=idx == 0):
            st.session_state.upload_idx -= 1
            st.rerun()
    with col_right:
        if st.button("Next →", disabled=idx == len(st.session_state.uploaded_files) - 1):
            st.session_state.upload_idx += 1
            st.rerun()

    # File preview (icon + name)
    st.markdown(
        f"""
<div style="display:flex;align-items:center;margin:1rem 0;">
  <div style="font-size:2rem;margin-right:.5rem;">{file_icon(Path(cur_file.name).suffix)}</div>
  <div style="font-size:1.1rem;">{cur_file.name}</div>
</div>
""",
        unsafe_allow_html=True,
    )

    # ---- Metadata fields ----
    new_project_name = st.text_input(
        "Project Name", value=cur_meta.get("project_name", ""), key=f"project_{cur_file.name}"
    )
    new_title = st.text_input(
        "Document Title", value=cur_meta["title"], key=f"title_{cur_file.name}"
    )
    new_date = st.date_input(
        "Date", value=cur_meta["date"], key=f"date_{cur_file.name}"
    )

    CATEGORY_OPTIONS = [
        "Select",
        "PMRC",
        "Executive Board",
        "Project Review",
        "Quality Document",
        "Sanction Letters",
        "Closure Document",
        "Others",
    ]
    current_category = cur_meta.get("category", "")
    default_idx = CATEGORY_OPTIONS.index(current_category) if current_category in CATEGORY_OPTIONS else 0
    new_category = st.selectbox(
        "Category",
        options=CATEGORY_OPTIONS,
        index=default_idx,
        key=f"cat_{cur_file.name}",
    )
    if new_category == "Select":
        new_category = ""

    new_remarks = st.text_input(
        "Remarks", value=cur_meta.get("remarks", cur_meta.get("doc_id", "")), key=f"id_{cur_file.name}"
    )

    # Save changes back to session state
    st.session_state.upload_meta[cur_file.name] = {
        "project_name": new_project_name,
        "title": new_title,
        "date": new_date,
        "category": new_category,
        "remarks": new_remarks,
    }

    # Save All button (appears once we have at least one file)
    if st.button(
        f"📤 Submit All {len(st.session_state.uploaded_files)} Document(s)",
        use_container_width=True,
    ):
        saved = []
        for uf in st.session_state.uploaded_files:
            dest = DOCS_DIR / uf.name
            dest.write_bytes(uf.getbuffer())

            meta = st.session_state.upload_meta.get(uf.name, {})
            record = {
                "filename": uf.name,
                "project_name": meta.get("project_name", ""),
                "title": meta.get("title", Path(uf.name).stem),
                "date": str(meta.get("date", date.today())),
                "category": meta.get("category", ""),
                "doc_id": meta.get("remarks", ""),
                "uploaded_at": datetime.now().isoformat(),
                "size_bytes": len(uf.getbuffer()),
                "status": "pending",  # immediately visible in the sidebar
            }
            shared_db.save_document(record, current_user)
            shared_db.enqueue_job(uf.name, current_user)
            st.session_state.file_metadata_store[uf.name] = record
            saved.append(uf.name)

        # Reset upload‑related state
        st.session_state.uploaded_files = []
        st.session_state.upload_meta = {}
        st.session_state.upload_idx = 0
        st.session_state.uploader_key += 1
        st.success(f"✅ {len(saved)} file(s) saved & queued for processing!")
        st.rerun()

# ---------- Summary cards ----------
all_docs = list_docs(current_user)
counts = shared_db.count_by_status(current_user)

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.metric("📂 Total Documents", len(all_docs))
with c2:
    st.metric("✅ Ready to Query", counts.get("done", 0))
with c3:
    st.metric(
        "⏳ Processing / Queued", counts.get("running", 0) + counts.get("pending", 0)
    )
with c4:
    st.metric("❌ Failed", counts.get("failed", 0))

st.markdown("---")

# ---------- Tip line ----------
st.caption(
    "💡 **Tip:** After uploading, head to **Chat Assistant** to query already‑processed documents."
)

# End of file