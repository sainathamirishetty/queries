"""
Centralized configuration for RAG pipeline
"""

import os
from pathlib import Path


# ==========================================
# BASE DIRECTORY (auto-detected, no hardcoded paths)
# ==========================================
# Resolution order:
#   1. PLANNING_APP_HOME env var, if set — lets you point the app at any
#      folder (e.g. a data disk) without touching this file.
#   2. Otherwise, a "project_application" folder created right next to this
#      config.py (i.e. planning_app/project_application).
#
# Everything below (HOME, APP_CACHE/MARKDOWNS, APP_CACHE/QDRANT_STORAGE,
# APP_CACHE/DOCUMENT_CACHE, APP_CACHE/chunk_info/..., DOCUMENTS, etc.) is
# created automatically under BASE_DIR — nothing needs to be pre-created
# by hand.
if "PLANNING_APP_HOME" in os.environ:
    BASE_DIR = Path(os.environ["PLANNING_APP_HOME"])
else:
    BASE_DIR = Path(__file__).resolve().parent / "project_application"

BASE_DIR.mkdir(parents=True, exist_ok=True)

# ==========================================
# CACHE DIRECTORIES
# ==========================================
MODEL_CACHE_DIR = BASE_DIR / "HOME"
MODEL_CACHE_DIR.mkdir(parents=True, exist_ok=True)

os.environ['HOME'] = str(MODEL_CACHE_DIR)

# ==========================================
# PATHS
# ==========================================
MARKDOWN_OUTPUT_DIR = BASE_DIR / "APP_CACHE" / "MARKDOWNS"
MARKDOWN_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

QDRANT_STORAGE_PATH = BASE_DIR / "APP_CACHE" / "QDRANT_STORAGE"
QDRANT_STORAGE_PATH.mkdir(parents=True, exist_ok=True)

DOCUMENTS_INPUT_DIR = BASE_DIR / "DOCUMENTS"

DOCUMENT_CACHE = BASE_DIR / "APP_CACHE" / "DOCUMENT_CACHE"
DOCUMENT_CACHE.mkdir(parents=True, exist_ok=True)

# ==========================================
# Rag Contextual cache dir paths
# ==========================================

CONTEXT_CACHE_PATH = BASE_DIR / "APP_CACHE" / "chunk_info" / "chunk_cache" / "contextual_chunks.json"

# Create parent directory for file path
CONTEXT_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)

# Create file if missing
if not CONTEXT_CACHE_PATH.exists():
    CONTEXT_CACHE_PATH.touch()

CONTEXT_PROMPT_VERSION = "version-1"
CHUNK_DUMP_DIR = str(BASE_DIR / "APP_CACHE" / "chunk_info" / "cache_list")

# ==========================================
# OLLAMA SETTINGS
# ==========================================
BASE_URL = "http://172.27.30.222:12000"
OLLAMA_IMAGE_MODEL = "qwen3-vl:4b"
OLLAMA_LLM_MODEL = "gpt-oss:20b"
LLM_TEMPERATURE = 0.1
MAX_LEFT_CONTEXT_CHARS = 10000


OLLAMA_IMAGE_NUM_CTX = 65536

# ==========================================
# OLLAMA REQUEST TIMEOUTS  (HANG FIX)
# ==========================================
# BUG FIX: none of the Ollama clients (the raw `ollama.Client` used for
# image description, and langchain's `ChatOllama` / `OllamaEmbeddings` used
# for chunk-summary + embeddings) had a timeout configured anywhere, and
# their underlying httpx default is timeout=None — i.e. NO timeout. If the
# remote Ollama server (BASE_URL, over the network) ever stops responding
# mid-request — a dropped connection, a model swap that never completes, a
# GPU-contention stall — the call blocks forever with no exception raised.
# Because the enrichment and indexer thread pools are a FIXED size
# (ENRICH_MAX_CONCURRENCY / INDEXER_MAX_CONCURRENCY workers), one hung call
# permanently consumes one worker slot; over a run of thousands of
# documents, all workers in a pool eventually get "used up" by hung calls
# and the whole stage silently stops making progress — which looks exactly
# like "the app is stuck after some documents, only a restart fixes it".
# Restarting worker.py just gives the pools a fresh set of threads, which
# is why it appears to "work" again for a while.
#
# Setting explicit, generous-but-bounded timeouts here means a stalled
# Ollama call now raises after a few minutes instead of hanging forever, so
# the calling code's existing per-document/per-image error handling can
# retry or skip it and the worker keeps making progress on its own —
# no manual restart needed.
OLLAMA_CONNECT_TIMEOUT_SECONDS = int(os.environ.get("OLLAMA_CONNECT_TIMEOUT_SECONDS", "30"))
OLLAMA_IMAGE_TIMEOUT_SECONDS   = int(os.environ.get("OLLAMA_IMAGE_TIMEOUT_SECONDS", "180"))
OLLAMA_LLM_TIMEOUT_SECONDS     = int(os.environ.get("OLLAMA_LLM_TIMEOUT_SECONDS", "300"))
OLLAMA_EMBED_TIMEOUT_SECONDS   = int(os.environ.get("OLLAMA_EMBED_TIMEOUT_SECONDS", "120"))

# ==========================================
# EMBEDDING MODELS
# ==========================================
DENSE_EMBEDDING_MODEL = "qwen3-embedding:0.6b"
SPARSE_EMBEDDING_MODEL = "Qdrant/bm25"
RERANKER_MODEL = "ms-marco-MiniLM-L-12-v2"

# ==========================================
# QDRANT SETTINGS
# ==========================================
QDRANT_COLLECTION_NAME = "planning_documents"
DENSE_EMBEDDING_DIMENSION = 1024

# BUG FIX: QDRANT_URL was missing from config — rag_pipeline used getattr fallback.
# Now explicit so every module reads the same value.
QDRANT_URL = "http://localhost:6333"

# BUG FIX: INGESTION_CACHE_PATH was missing from config — rag_pipeline silently
# fell back to a relative path "ingestion_cache.json" in whatever the working dir
# was, which differs between streamlit and the worker.  Now pinned to APP_CACHE.
INGESTION_CACHE_PATH = str(BASE_DIR / "APP_CACHE" / "ingestion_cache.json")

# ==========================================
# MINERU API SETTINGS
# ==========================================
# document_ingestion.py calls mineru-api (FastAPI) servers over HTTP.
# Two local A100 mineru-api instances run on ports 9866 and 9867; worker.py
# sends one document to each of them, so two files are OCR'd in parallel
# (one at a time per instance).
MINERU_API_URLS = [
    "http://172.27.30.222:9866",
    "http://172.27.30.222:9867",
]

MINERU_BACKEND: str = "vlm-auto-engine"

# How long (seconds) to wait for a single PDF to finish parsing remotely.
MINERU_TIMEOUT_SECONDS = 10800
MINERU_HARD_DEADLINE_SECONDS = 1800

# ==========================================
# DOCUMENT PROCESSING
# ==========================================
IMAGE_RESOLUTION_SCALE = 2.0
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

# ==========================================
# RETRIEVAL SETTINGS
# ==========================================
RETRIEVAL_CANDIDATES_COUNT = 40
RERANKING_TOP_RESULTS = 20

# ==========================================
# PARALLEL PIPELINE SETTINGS
# ==========================================

ENRICH_MAX_CONCURRENCY = int(os.environ.get("ENRICH_MAX_CONCURRENCY", "3"))


INDEXER_MAX_CONCURRENCY = int(os.environ.get("INDEXER_MAX_CONCURRENCY", "3"))

# ==========================================
# LOGGING
# ==========================================
LOG_LEVEL = "INFO"


NOISY_LIBRARY_LOG_LEVEL = os.environ.get("NOISY_LIBRARY_LOG_LEVEL", "WARNING")

# ==========================================
# TRANSIENT-FAILURE AUTO-RETRY
# ==========================================

MAX_TRANSIENT_RETRIES = int(os.environ.get("MAX_TRANSIENT_RETRIES", "3"))

print("✅ Configuration loaded")
