# ==========================================================
#
# FINAL: JSON-FIRST UNIFIED DOCUMENT INGESTION PIPELINE
# (GPU-SAFE EDITION)
#
# FIX SUMMARY
# -----------
# 1. CUDA OOM  – the ONNXRuntime / ORT env-vars below reduce VRAM
#    fragmentation for anything on this process that still touches the
#    local GPU (e.g. docling, the VLM client). The caller (worker.py)
#    still wraps every ingestion job in a file-level GPU lock.
#
# 2. GPU DEVICE DISCOVERY WARNING – ORT_DISABLE_GPU_DEVICE_DISCOVERY=1 is
#    set at import time so ONNXRuntime skips the sysfs vendor-file read
#    that produced:
#      "GPU device discovery failed: ReadFileContents Failed to open file:
#       /sys/class/drm/card0/device/vendor"
#    so the warning does not appear in the Streamlit process.
#
# MINERU – convert_with_mineru calls a mineru-api (FastAPI) server over HTTP
# (one of config.MINERU_API_URLS, chosen by worker.py).
#
# ==========================================================

import os
import json
import base64
import hashlib
import logging
import subprocess
import shutil
import warnings
import httpx
from pathlib import Path
from typing import Dict, Tuple, Any

# ── Apply GPU-warning suppression in THIS process immediately ──────────────
os.environ.setdefault("ORT_DISABLE_GPU_DEVICE_DISCOVERY", "1")
os.environ.setdefault("PYTORCH_ALLOC_CONF", "expandable_segments:True")
logging.getLogger("onnxruntime").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", message=".*GPU device discovery failed.*")
warnings.filterwarnings("ignore", message=".*device_discovery.*")
try:
    import onnxruntime as _ort
    _ort.set_default_logger_severity(3)   # ERROR and above only
except Exception:
    pass

import config
import ollama

# httpx (used directly below, and transitively by the `ollama` client) logs
# every HTTP request at INFO by default — quiet it along with the other
# chatty HTTP libraries so the worker/Streamlit terminal isn't flooded.
for _noisy in ("httpx", "httpcore", "urllib3"):
    logging.getLogger(_noisy).setLevel(
        getattr(logging, getattr(config, "NOISY_LIBRARY_LOG_LEVEL", "WARNING"), logging.WARNING)
    )
from docling.document_converter import DocumentConverter

# ==========================================================
# LOGGING
# ==========================================================

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL))
logger = logging.getLogger(__name__)

# ==========================================================
# CACHE
# ==========================================================

CACHE_FILE = Path(config.DOCUMENT_CACHE) / "document_cache.json"

CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
if not CACHE_FILE.exists():
    CACHE_FILE.write_text("{}", encoding="utf-8")
    logger.info(f"Created missing cache file: {CACHE_FILE}")


def compute_file_hash(file_path: Path) -> str:
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def load_cache() -> Dict[str, str]:
    if CACHE_FILE.exists():
        return json.loads(CACHE_FILE.read_text())
    return {}


def save_cache(cache: Dict[str, str]) -> None:
    CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(cache, indent=2))


# ==========================================================
# OFFICE → PDF
# ==========================================================

OFFICE_EXTENSIONS = {".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx"}


def convert_office_to_pdf(input_file: Path, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    output_pdf = output_dir / f"{input_file.stem}.pdf"

    if output_pdf.exists():
        return output_pdf

    logger.info(f"Office → PDF: {input_file.name}")

    subprocess.run(
        [
            "libreoffice",
            "--headless",
            "--convert-to", "pdf",
            "--outdir", str(output_dir),
            str(input_file),
        ],
        check=True,
        timeout=180,
    )

    return output_pdf


# ==========================================================
# MINERU OCR  (calls a local mineru-api server over HTTP)
# ==========================================================

import concurrent.futures

_MINERU_HTTP_TIMEOUT = httpx.Timeout(
    connect=30.0,
    read=config.MINERU_HARD_DEADLINE_SECONDS,
    write=60.0,
    pool=10.0,
)


def _call_mineru_api(pdf_path: Path, endpoint_url: str) -> dict:
    with open(pdf_path, "rb") as f:
        resp = httpx.post(
            f"{endpoint_url}/file_parse",
            files={"files": (pdf_path.name, f, "application/pdf")},
            data={
                "backend": config.MINERU_BACKEND,
                "lang_list": "en",
                "return_content_list": "true",
                "return_images": "true",
            },
            timeout=_MINERU_HTTP_TIMEOUT,
        )
    resp.raise_for_status()
    return resp.json()


def convert_with_mineru(
    pdf_path: Path,
    output_root: Path,
    endpoint_url: str | None = None,
) -> Path:
    """
    Send a PDF to a mineru-api server and materialize its response on disk
    (<stem>.json + images/ + <stem>.pdf). endpoint_url defaults to the first
    entry of config.MINERU_API_URLS; worker.py passes the endpoint it
    assigned to this job.
    """
    endpoint_url = endpoint_url or config.MINERU_API_URLS[0]
    logger.info(f"OCR with MinerU ({endpoint_url}): {pdf_path.name}")

    # Fresh single-use executor per call: a hung HTTP call can't be killed, so
    # a shared executor would be poisoned forever. Abandoning one thread is cheap.
    ex = concurrent.futures.ThreadPoolExecutor(
        max_workers=1, thread_name_prefix="mineru-api-call"
    )
    try:
        future = ex.submit(_call_mineru_api, pdf_path, endpoint_url)
        try:
            payload = future.result(timeout=config.MINERU_HARD_DEADLINE_SECONDS)
        except concurrent.futures.TimeoutError:
            logger.error(
                "MinerU API call for %s did not return within the hard "
                "deadline (%ds) — abandoning that thread and treating the "
                "job as failed so the rest of the queue is not blocked. "
                "If this keeps happening, that mineru-api server "
                "itself is likely wedged and needs a restart.",
                pdf_path.name, config.MINERU_HARD_DEADLINE_SECONDS,
            )
            raise RuntimeError(
                f"MinerU API call exceeded hard deadline of "
                f"{config.MINERU_HARD_DEADLINE_SECONDS}s for {pdf_path.name} — "
                f"treating as failed so the rest of the batch can continue. "
                f"This usually means the mineru-api server is backed up or has "
                f"leaked GPU memory from a prior request."
            )
    finally:
        ex.shutdown(wait=False)

    results = payload.get("results", {})
    if not results:
        raise RuntimeError(f"MinerU API returned no results: {payload}")

    # One entry per uploaded file — we only sent one, so take it directly.
    pdf_result = next(iter(results.values()))

    content_list_raw = pdf_result.get("content_list")
    if not content_list_raw:
        raise RuntimeError("MinerU API produced no content_list")

    final_dir = output_root / pdf_path.stem
    final_dir.mkdir(parents=True, exist_ok=True)

    # content_list_raw is already JSON text (the server returns file
    # contents as a string) — write it straight through.
    json_path = final_dir / f"{pdf_path.stem}.json"
    json_path.write_text(content_list_raw, encoding="utf-8")

    # Images come back as {filename: "data:<mime>;base64,<data>"}
    images = pdf_result.get("images") or {}
    if images:
        images_dir = final_dir / "images"
        images_dir.mkdir(parents=True, exist_ok=True)
        for img_name, data_uri in images.items():
            try:
                _, b64data = data_uri.split(",", 1)
                (images_dir / img_name).write_bytes(base64.b64decode(b64data))
            except Exception as e:
                logger.warning(f"Failed to save image {img_name}: {e}")

    # Copy original PDF (kept for parity with the old pipeline)
    shutil.copy2(str(pdf_path), str(final_dir / f"{pdf_path.stem}.pdf"))

    return final_dir


# ==========================================================
# IMAGE ENRICHMENT
# ==========================================================

MODEL = config.OLLAMA_IMAGE_MODEL

PROMPT = """
You are a vision-language extraction engine.

Rules (STRICT):
- Output ONLY valid JSON
- Do NOT add explanations
- Do NOT use Markdown
- Tables MUST be in pure HTML
- If no table exists, set "table" to null

Task:
1 Describe image (max 100 words)
2 Extract table if present

Output format STRICT:

{
"description":"text",
"table":"html or null"
}
"""

SUPPORTED_EXTS = (".png", ".jpg", ".jpeg", ".webp")

# HANG FIX: ollama.Client defaults to timeout=None (no timeout at all) —
# see config.py's "OLLAMA REQUEST TIMEOUTS" note for why that's the root
# cause of the worker appearing to freeze. Give every request through this
# client a bounded httpx timeout instead.
_OLLAMA_IMAGE_HTTP_TIMEOUT = httpx.Timeout(
    connect=config.OLLAMA_CONNECT_TIMEOUT_SECONDS,
    read=config.OLLAMA_IMAGE_TIMEOUT_SECONDS,
    write=60.0,
    pool=10.0,
)


def find_image(doc_dir: Path, img_rel_path: str):
    candidate = doc_dir / img_rel_path
    if candidate.exists():
        return candidate.resolve()

    stem = Path(img_rel_path).stem
    for ext in SUPPORTED_EXTS:
        matches = list(doc_dir.rglob(f"{stem}{ext}"))
        if matches:
            return matches[0]
    return None


def describe_image(client, img_path: Path):
    logger.debug(f"Running VLM on image: {img_path.name}")
    with open(img_path, "rb") as f:
        image_bytes = f.read()

    response = client.generate(
        model=MODEL,
        prompt=PROMPT,
        images=[image_bytes],
        stream=False,
        options={"num_ctx": config.OLLAMA_IMAGE_NUM_CTX},
    )

    raw = response.get("response", "").strip()
    try:
        return json.loads(raw)
    except Exception:
        logger.warning("VLM returned non-JSON")
        return {"description": raw, "table": None}


def enrich_images_with_descriptions(content_json_path: Path):
    logger.info(f"Starting image enrichment → {content_json_path.name}")

    client = ollama.Client(config.BASE_URL)

    with open(content_json_path, "r", encoding="utf-8") as f:
        content = json.load(f)

    doc_dir     = content_json_path.parent
    image_count = 0

    for block in content:
        block_type = block.get("type", "")
        logger.debug(f"Block type: {block_type}")

        if block_type not in ["image", "figure", "img"]:
            continue

        img_rel = (
            block.get("img_path")
            or block.get("image_path")
            or block.get("path")
        )

        if not img_rel:
            logger.warning("Image block without path")
            continue

        logger.debug(f"Image relative path: {img_rel}")
        img_path = find_image(doc_dir, img_rel)

        if img_path:
            logger.debug(f"Image found: {img_path}")
            try:
                block["image_description"] = describe_image(client, img_path)
                image_count += 1
            except Exception as exc:
                # HANG FIX: with the timeout above, a stalled Ollama call
                # now raises (httpx.TimeoutException / ConnectError / etc.)
                # instead of blocking this thread forever. Treat it the
                # same as "image not found" — skip just this one image and
                # keep going, rather than losing the whole document (or,
                # before this fix, the whole enrichment worker thread) to
                # one bad image.
                logger.warning(
                    f"[ENRICH] VLM call failed/timed out on {img_path.name} "
                    f"(skipping this image, continuing document): {exc}"
                )
                block["image_description"] = {
                    "description": "Image description unavailable (VLM request failed or timed out)",
                    "table": None,
                }
        else:
            logger.warning(f"Image NOT FOUND: {img_rel}")
            block["image_description"] = {
                "description": "Image file not found",
                "table": None,
            }

    logger.info(f"Images processed: {image_count}")

    with open(content_json_path, "w", encoding="utf-8") as f:
        json.dump(content, f, indent=2, ensure_ascii=False)

    return content_json_path


# ==========================================================
# FINAL MARKDOWN WITH UNIQUE PAGE TAGS
# ==========================================================

def build_final_markdown_from_json(content_json_path: Path) -> None:
    logger.info(f"Creating final markdown with page tags → {content_json_path.name}")

    try:
        with open(content_json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        pages: Dict[int, list] = {}
        for item in data:
            p = item.get("page_idx", 0)
            pages.setdefault(p, []).append(item)

        md = ""
        for p in sorted(pages):
            md += f"\n\n<<!PAGE {p+1}>>\n\n"
            for item in pages[p]:
                t = item.get("type", "")

                if t == "text":
                    txt = item.get("text", "").strip()
                    if txt:
                        md += (f"# {txt}\n\n" if item.get("text_level") == 1
                               else txt + "\n\n")

                elif t == "list":
                    for li in item.get("list_items", []):
                        if li.strip():
                            md += "- " + li.strip() + "\n"
                    md += "\n"

                elif t == "image":
                    desc = item.get("image_description", {})
                    d = (desc.get("description", "").strip()
                         or desc.get("Description", "").strip())
                    if d:
                        md += f"*Image Description:* {d}\n\n"

                elif t == "table":
                    for cap in item.get("table_caption", []):
                        if cap.strip():
                            md += f"**{cap.strip()}**\n\n"
                    body = item.get("table_body", "")
                    if body:
                        md += body + "\n\n"
                    for foot in item.get("table_footnote", []):
                        if foot.strip():
                            md += f"*{foot.strip()}*\n"

        out_md = content_json_path.with_suffix(".md")
        out_md.write_text(md, encoding="utf-8")
        logger.info(f"Final markdown saved → {out_md}")

    except Exception as e:
        logger.error(f"Final markdown build failed: {e}")


# ==========================================================
# MAIN PIPELINE  (legacy direct-call path)
# ==========================================================

def ingest_documents(
    input_directory: str | None = None,
    output_directory: str | None = None,
) -> Dict[str, Tuple[Path, Any]]:
    """
    Direct ingestion path (used when NOT running the background worker).
    NOTE: for production multi-user use, prefer running worker.py which
    serialises GPU access properly.
    """
    input_dir = Path(input_directory or config.DOCUMENTS_INPUT_DIR)
    output_dir = Path(output_directory or config.MARKDOWN_OUTPUT_DIR)
    output_dir.mkdir(parents=True, exist_ok=True)

    temp_pdf_dir = output_dir / "_temp_pdfs"
    temp_pdf_dir.mkdir(parents=True, exist_ok=True)

    cache            = load_cache()
    loaded_documents = {}
    docling          = DocumentConverter()

    for file in input_dir.iterdir():
        if not file.is_file():
            continue
        if file.name.startswith(".-lock") or file.name.endswith("#"):
            logger.info(f"Skipping lock file: {file.name}")
            continue

        file_hash = compute_file_hash(file)
        if file_hash in cache:
            logger.info(f"Skipped (cached): {file.name}")
            loaded_documents[file.name] = (file, None)
            continue

        # STEP 1 – convert
        if file.suffix.lower() in OFFICE_EXTENSIONS:
            pdf     = convert_office_to_pdf(file, temp_pdf_dir)
            doc_dir = convert_with_mineru(pdf, output_dir)

        elif file.suffix.lower() == ".pdf":
            doc_dir = convert_with_mineru(file, output_dir)

        else:
            logger.info(f"Docling fallback: {file.name}")
            result = docling.convert(file)
            if not result.document:
                continue
            doc_dir = output_dir / file.stem
            doc_dir.mkdir(parents=True, exist_ok=True)
            (doc_dir / f"{file.stem}.md").write_text(
                result.document.export_to_markdown(), encoding="utf-8"
            )

        # STEP 2 – enrich + markdown
        json_file = doc_dir / f"{doc_dir.name}.json"
        if json_file.exists():
            try:
                enriched_json = enrich_images_with_descriptions(json_file)
                build_final_markdown_from_json(enriched_json)
            except Exception as e:
                logger.error(f"Post-processing failed for {file.name}: {e}")

        # STEP 3 – cache
        cache[file_hash] = "cached"
        save_cache(cache)
        loaded_documents[file.name] = (file, None)

    logger.info(f"Ingested {len(loaded_documents)} documents")
    return loaded_documents


# ==========================================================
# ENTRY POINT
# ==========================================================

if __name__ == "__main__":
    ingest_documents()
