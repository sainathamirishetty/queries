"""
login_page.py
==============

Streamlit login page used by ``1_Document_Manager.py``.
It can operate in two modes:

* Real LDAP authentication (default) – uses the ldap3 library.
* Mock authentication – checks a hard‑coded dict of test users.

Set ``USE_MOCK_AUTH = True`` for quick UI testing without an AD server.
"""

import re
import logging
from typing import Tuple

import streamlit as st

# ----------------------------------------------------------------------
# 1️⃣  Mock / local credentials
# ----------------------------------------------------------------------
MOCK_USERS = {
    "rci": "rci123",
    "daiv":   "daiv123",
}

# ----------------------------------------------------------------------
# 2️⃣  LDAP / Active Directory configuration
# ----------------------------------------------------------------------
DOMAIN         = "hastinapur"
LDAP_SERVER_IP = "172.30.1.136"

# ----------------------------------------------------------------------
# 3️⃣  Logging
# ----------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("auth")


# ----------------------------------------------------------------------
# 4️⃣  Individual auth backends (both always active)
# ----------------------------------------------------------------------

def _auth_local(username: str, password: str, client_ip: str = "unknown") -> Tuple[bool, str]:
    """Try to authenticate against the hard-coded MOCK_USERS dict."""
    uname = username.strip().lower()
    pwd   = password.strip()
    if uname in MOCK_USERS and MOCK_USERS[uname] == pwd:
        logger.info(f"[LOCAL] Auth success for {uname} from {client_ip}")
        return True, uname
    logger.info(f"[LOCAL] No match for {uname} — will try LDAP next")
    return False, "Invalid credentials (local)"


def _auth_ldap(username: str, password: str, client_ip: str = "unknown") -> Tuple[bool, str]:
    """Try to authenticate against Active Directory via LDAP."""
    try:
        from ldap3 import Server, Connection, ALL, SIMPLE, SUBTREE
        from ldap3.core.exceptions import LDAPException
    except ImportError:
        logger.warning("[LDAP] ldap3 not installed — skipping LDAP auth")
        return False, "LDAP unavailable (ldap3 not installed)"

    try:
        user_principal = f"{DOMAIN}\\{username}"
        server = Server(f"ldap://{LDAP_SERVER_IP}", get_info=ALL, use_ssl=False)
        conn   = Connection(
            server,
            user=user_principal,
            password=password,
            authentication=SIMPLE,
            auto_bind="NO_TLS",
        )

        if not conn.bind():
            logger.warning(f"[LDAP] Auth failed for {username} from {client_ip}")
            return False, "Invalid credentials (LDAP)"

        # Try to fetch a friendly display name from AD
        search_base   = f"DC={DOMAIN},DC=res"
        search_filter = f"(&(objectClass=user)(sAMAccountName={username}))"
        conn.search(
            search_base=search_base,
            search_filter=search_filter,
            search_scope=SUBTREE,
            attributes=["displayName", "mail"],
        )

        if conn.entries:
            dn    = conn.entries[0].entry_dn
            match = re.search(r"CN=([^,]+)", dn)
            display_name = match.group(1) if match else username
            logger.info(f"[LDAP] Auth success: {username} ({display_name}) from {client_ip}")
            return True, display_name

        logger.info(f"[LDAP] Auth success (no extra attrs): {username} from {client_ip}")
        return True, username

    except Exception as exc:
        logger.error(f"[LDAP] Error for {username}: {exc}")
        return False, f"LDAP error: {str(exc)}"


# ----------------------------------------------------------------------
# 5️⃣  Combined authenticator — tries Local then LDAP automatically
# ----------------------------------------------------------------------

def authenticate(username: str, password: str, client_ip: str = "unknown") -> Tuple[bool, str]:
    """
    Try Local auth first; fall through to LDAP if it fails.
    Returns (True, display_name) on success, (False, error_msg) on total failure.
    """
    # --- Step 1: Local ---
    ok, info = _auth_local(username, password, client_ip)
    if ok:
        return True, info

    # --- Step 2: LDAP ---
    ok, info = _auth_ldap(username, password, client_ip)
    if ok:
        return True, info

    # --- Both failed ---
    logger.warning(f"[AUTH] Both local and LDAP failed for {username} from {client_ip}")
    return False, "Invalid username or password."


# ----------------------------------------------------------------------
# 6️⃣  Streamlit UI helpers
# ----------------------------------------------------------------------
def _rerun():
    if hasattr(st, "rerun"):
        st.rerun()
    else:
        st.experimental_rerun()


# ----------------------------------------------------------------------
# 7️⃣  Main UI entry point — UI is exactly as before, no changes
# ----------------------------------------------------------------------
def run():
    """
    Render the login page.  If the user authenticates successfully,
    ``st.session_state["user"]`` is set and the script is rerun so that
    the main Document Manager UI can be displayed.
    """
    # ── Already logged in ─────────────────────────────────────────────
    if st.session_state.get("user"):
        col_msg, col_btn = st.columns([4, 1])
        with col_msg:
            st.success(f"✅ Logged in as **{st.session_state['user']}**")
        with col_btn:
            if st.button("🚪 Logout", key="logout_btn", use_container_width=True):
                for key in list(st.session_state.keys()):
                    del st.session_state[key]
                _rerun()
        return

    # ── Page styling (unchanged) ──────────────────────────────────────
    st.markdown(
        """
        <style>
        .login-box {
            background: rgba(255,255,255,0.12);
            backdrop-filter: blur(12px);
            border-radius: 12px;
            padding: 2rem 2.5rem;
            max-width: 380px;
            margin: 4rem auto;
            color: #fff;
            text-align: center;
        }
        .login-box h1 { margin-bottom: 0.5rem; font-size: 2rem; }
        .login-box p { margin-bottom: 1.5rem; color: #e0e0e0; }
        .login-box input { width: 100%; padding: 0.8rem; margin-bottom: 1rem;
                           border: none; border-radius: 6px; }
        .login-box button {
            width: 100%; padding: 0.9rem; border: none; border-radius: 6px;
            background: linear-gradient(135deg, #ffeb3b, #ffc107);
            font-weight: 600; cursor: pointer;
        }
        .login-box .msg { margin-top: 1rem; }
        </style>
        """,
        unsafe_allow_html=True,
    )

    with st.container():
        st.markdown(
            """
            <div class="login-box">
                <h1>Login</h1>
                <p>Enter your RCNET username and password</p>
            """,
            unsafe_allow_html=True,
        )

        # --------------------------------------------------------------
        # Form fields  (Enter key OR button click both submit)
        # --------------------------------------------------------------
        with st.form(key="login_form"):
            username = st.text_input("PIS Number / Username", key="login_user")
            password = st.text_input("Password", type="password", key="login_pass")
            login_btn = st.form_submit_button("Login")

        # ── Handle submission ─────────────────────────────────────────
        if login_btn:
            if not username or not password:
                st.markdown(
                    '<div class="msg" style="color:#ff5252;">⚠️ Both fields are required.</div>',
                    unsafe_allow_html=True,
                )
            else:
                ok, info = authenticate(username, password, client_ip="streamlit")
                if ok:
                    st.session_state["user"] = info
                    st.success(f"✅ Welcome, **{info}**")
                    _rerun()
                else:
                    st.markdown(
                        f'<div class="msg" style="color:#ff5252;">❌ {info}</div>',
                        unsafe_allow_html=True,
                    )

        st.markdown("</div>", unsafe_allow_html=True)
