# migrate_schema.py
"""
One‑off (repeatable) migration script that adds any missing columns
to the SQLite tables used by the Document Manager.

Run it once (or as many times as you like):
    python migrate_schema.py
"""

import sqlite3
from pathlib import Path
import config

# ----------------------------------------------------------------------
# Path to the DB used by shared_db.py
# ----------------------------------------------------------------------
DB_PATH = Path(config.DOCUMENTS_INPUT_DIR).parent / "APP_CACHE" / "file_metadata.db"


def _col_exists(cur: sqlite3.Cursor, table: str, column: str) -> bool:
    """Return True if *column* exists in *table*."""
    cur.execute(f"PRAGMA table_info({table});")
    return any(row[1] == column for row in cur.fetchall())   # row[1] = column name


def _trigger_exists(cur: sqlite3.Cursor, trigger_name: str) -> bool:
    """Return True if a trigger with *trigger_name* already exists."""
    cur.execute(
        "SELECT name FROM sqlite_master WHERE type='trigger' AND name=?;",
        (trigger_name,),
    )
    return cur.fetchone() is not None


def _add_column(
    cur: sqlite3.Cursor,
    table: str,
    column: str,
    col_type: str,
    default: str | None = None,
    not_null: bool = False,
) -> None:
    """Add *column* to *table* if it does not already exist."""
    if _col_exists(cur, table, column):
        return

    stmt = f"ALTER TABLE {table} ADD COLUMN {column} {col_type}"
    if not_null:
        stmt += " NOT NULL"
    if default is not None:
        stmt += f" DEFAULT {default}"
    stmt += ";"

    cur.execute(stmt)
    print(f"✅ Added column `{column}` to {table}")


def _populate_and_trigger(
    cur: sqlite3.Cursor,
    table: str,
    column: str,
    fill_sql: str,
    trigger_name: str,
    trigger_sql: str,
) -> None:
    """
    Fill existing rows for *column* and create a trigger (if missing).
    """
    # 1️⃣ Populate existing rows
    cur.execute(fill_sql)
    # 2️⃣ Create trigger only once
    if not _trigger_exists(cur, trigger_name):
        cur.execute(trigger_sql)
        print(f"   → Added trigger `{trigger_name}`")
    else:
        print(f"   → Trigger `{trigger_name}` already exists – skipped")


def migrate() -> None:
    con = sqlite3.connect(str(DB_PATH))
    cur = con.cursor()

    # ------------------------------------------------------------------
    # documents table
    # ------------------------------------------------------------------
    _add_column(cur, "documents", "doc_date", "TEXT")
    _add_column(cur, "documents", "created_at", "TEXT")
    _add_column(cur, "documents", "updated_at", "TEXT")
    _add_column(cur, "documents", "size_bytes", "INTEGER")
    _add_column(
        cur,
        "documents",
        "status",
        "TEXT",
        default="'pending'",
        not_null=True,
    )
    _add_column(cur, "documents", "user_name", "TEXT")
    _add_column(cur, "documents", "category", "TEXT")
    _add_column(cur, "documents", "doc_id", "TEXT")

    # Populate defaults for newly added columns that need them
    if _col_exists(cur, "documents", "created_at"):
        _populate_and_trigger(
            cur,
            table="documents",
            column="created_at",
            fill_sql="""
                UPDATE documents
                SET created_at = datetime('now')
                WHERE created_at IS NULL;
            """,
            trigger_name="set_created_at_documents",
            trigger_sql="""
                CREATE TRIGGER set_created_at_documents
                AFTER INSERT ON documents
                WHEN NEW.created_at IS NULL
                BEGIN
                    UPDATE documents SET created_at = datetime('now')
                    WHERE rowid = NEW.rowid;
                END;
            """,
        )

    # Ensure every row has a user_name – use a placeholder for old rows
    if _col_exists(cur, "documents", "user_name"):
        cur.execute(
            """
            UPDATE documents
            SET user_name = 'unknown'
            WHERE user_name IS NULL;
            """
        )
        if not _trigger_exists(cur, "set_user_name_documents"):
            cur.execute(
                """
                CREATE TRIGGER set_user_name_documents
                AFTER INSERT ON documents
                WHEN NEW.user_name IS NULL
                BEGIN
                    UPDATE documents SET user_name = 'unknown'
                    WHERE rowid = NEW.rowid;
                END;
                """
            )
            print("   → Added trigger `set_user_name_documents`")
        else:
            print("   → Trigger `set_user_name_documents` already exists – skipped")

    # ------------------------------------------------------------------
    # processing_jobs table
    # ------------------------------------------------------------------
    _add_column(cur, "processing_jobs", "queued_at", "TEXT")
    _add_column(cur, "processing_jobs", "started_at", "TEXT")
    _add_column(cur, "processing_jobs", "finished_at", "TEXT")
    _add_column(cur, "processing_jobs", "error_message", "TEXT")
    _add_column(cur, "processing_jobs", "user_name", "TEXT")

    # Populate placeholder user_name for existing job rows
    if _col_exists(cur, "processing_jobs", "user_name"):
        cur.execute(
            """
            UPDATE processing_jobs
            SET user_name = 'unknown'
            WHERE user_name IS NULL;
            """
        )
        if not _trigger_exists(cur, "set_user_name_processing_jobs"):
            cur.execute(
                """
                CREATE TRIGGER set_user_name_processing_jobs
                AFTER INSERT ON processing_jobs
                WHEN NEW.user_name IS NULL
                BEGIN
                    UPDATE processing_jobs SET user_name = 'unknown'
                    WHERE rowid = NEW.rowid;
                END;
                """
            )
            print("   → Added trigger `set_user_name_processing_jobs`")
        else:
            print(
                "   → Trigger `set_user_name_processing_jobs` already exists – skipped"
            )

    # ------------------------------------------------------------------
    con.commit()
    con.close()
    print("\n✅ Migration complete – you can now start the Streamlit app.")


if __name__ == "__main__":
    migrate()