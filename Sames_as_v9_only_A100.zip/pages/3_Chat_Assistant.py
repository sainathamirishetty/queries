# =====================================================================
#  pages/3_Chat_Assistant.py
#  Query already-processed documents; notified when new ones finish
# =====================================================================

import random
import uuid
import time
from pathlib import Path
from datetime import datetime
from threading import Lock

import streamlit as st

import config
import shared_db
from streamlit import runtime
from streamlit.runtime.scriptrunner import get_script_run_ctx

chat_hist_ts = datetime.now().strftime("%d-%m-%Y_%H%M%S").split("_")[0]
chat_history_file = open(f"chat_hist/chat_hist_{chat_hist_ts}.log", "+a")
chat_history_file_lock = Lock()
from rag_pipeline import (
    create_vector_store,
    generate_streaming_answer,
)

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Chat Assistant",
    page_icon="📘",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
.center-title { text-align: center !important; width: 100%; }

[data-testid="stSidebar"] {
    background: #181c27 !important;
    border-right: 1px solid #2a3050 !important;
}
[data-testid="stSidebar"] * { color: #e2e8f0 !important; }

.sb-heading {
    font-size: 1.1rem; font-weight: 700;
    margin: 0 0 .8rem; padding-bottom: .5rem;
    border-bottom: 1px solid #2a3050;
}
.sb-file-card {
    background: #1f2435; border: 1px solid #2a3050;
    border-radius: 10px; padding: .6rem .8rem;
    margin-bottom: .5rem; display: flex;
    align-items: flex-start; gap: .6rem;
}
.sb-file-icon { font-size: 1.2rem; flex-shrink: 0; margin-top: .05rem; }
.sb-file-info  { flex: 1; min-width: 0; }
.sb-file-name  { font-size: .82rem; font-weight: 600;
                  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sb-file-date  { font-size: .72rem; color: #8892a4; margin-top: .15rem; }
.sb-stats { display: flex; flex-wrap: wrap; gap: .4rem; margin-bottom: .8rem; }
.sb-chip  { font-size: .7rem; font-weight: 600; padding: 2px 8px; border-radius: 20px;
            background: #1f2435; border: 1px solid #2a3050; color: #8892a4; }
.sb-chip b { color: #4f8ef7; }

.notif-banner {
    background: linear-gradient(135deg,#1a3a2a,#143020);
    border: 1px solid #4caf50; border-radius: 12px;
    padding: .8rem 1.2rem; margin-bottom: 1rem;
    display: flex; align-items: center; gap: .8rem;
}
.notif-text  { color:#a5d6a7; font-size:.9rem; }
.notif-badge { font-size:1.4rem; }

[data-testid="stSidebar"] .stButton > button {
    background: linear-gradient(135deg, #4f8ef7, #7c5cfc) !important;
    border: none !important; border-radius: 7px !important;
    color: #fff !important; font-weight: 600 !important; font-size: .8rem !important;
}
</style>
""", unsafe_allow_html=True)

# ── Constants ─────────────────────────────────────────────────────────────────
DOCS_DIR = Path(config.DOCUMENTS_INPUT_DIR)

EXT_ICON = {
    ".pdf": "📄", ".ppt": "📊", ".pptx": "📊",
    ".doc": "📝", ".docx": "📝", ".xls": "📈",
    ".xlsx": "📈", ".txt": "📃", ".md": "📃", ".csv": "📋",
}


def file_icon(ext: str) -> str:
    return EXT_ICON.get(ext.lower(), "📁")


def human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"

def get_remote_ip() -> str:
    try:
        ctx = get_script_run_ctx()
        if ctx is None:
            return "None"
        session_info = runtime.get_instance().get_client(ctx.session_id)
        if session_info is None:
            return "None"
    except Exception:
        return "Unable to fetch"
    return f"{session_info.request.remote_ip}"

# ── Auth guard ────────────────────────────────────────────────────────────────
if "user" not in st.session_state:
    st.warning("Please log in first.")
    st.stop()

user_name: str = st.session_state["user"]

# ── Session state init ────────────────────────────────────────────────────────
if "message_history" not in st.session_state:
    st.session_state.message_history = []

if "thread_id" not in st.session_state:
    st.session_state.thread_id = str(uuid.uuid4())

if "done_count_at_load" not in st.session_state:
    st.session_state.done_count_at_load = 0

if "notif_pending" not in st.session_state:
    st.session_state.notif_pending = False

# ── Sidebar: processed document list ─────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="sb-heading">📚 Processed Documents</div>',
                unsafe_allow_html=True)

    # -------------------------------------------------
    # 1️⃣  Get the logged‑in user name
    # -------------------------------------------------
    user_name = st.session_state.get("user")          # set by login_page.run()
    if not user_name:
        st.warning("🔐 Please log in to see your documents.")
        # Stop further sidebar rendering – the rest of the page will still load.
        st.stop()

    # -------------------------------------------------
    # 2️⃣  Fetch data **for this user only**
    # -------------------------------------------------
    jobs = shared_db.get_all_jobs(user_name)          # ← pass the name
    meta_store = shared_db.load_all_documents(user_name)

    done_jobs   = [j for j in jobs if j["status"] == "done"]
    active_jobs = [j for j in jobs if j["status"] in ("pending", "running", "enriching", "indexing")]

    chips  = '<div class="sb-stats">'
    chips += f'<span class="sb-chip"><b>{len(done_jobs)}</b> ready</span>'
    if active_jobs:
        chips += f'<span class="sb-chip"><b>{len(active_jobs)}</b> processing</span>'
    chips += "</div>"
    st.markdown(chips, unsafe_allow_html=True)

    CHAT_DOCS_PER_PAGE = 3
    if not done_jobs:
        st.caption(
            "No documents ready yet. Head to **Document Manager** to upload and process documents."
        )
    else:
        if "chat_doc_page" not in st.session_state:
            st.session_state.chat_doc_page = 1

        total_chat_pages = max(1, -(-len(done_jobs) // CHAT_DOCS_PER_PAGE))
        st.session_state.chat_doc_page = max(
            1, min(st.session_state.chat_doc_page, total_chat_pages)
        )
        chat_page      = st.session_state.chat_doc_page
        page_done_jobs = done_jobs[
            (chat_page - 1) * CHAT_DOCS_PER_PAGE : chat_page * CHAT_DOCS_PER_PAGE
        ]

        for job in page_done_jobs:
            fname = job["filename"]
            meta  = meta_store.get(fname, {})
            title = meta.get("title") or Path(fname).stem
            icon  = file_icon(Path(fname).suffix)
            size  = meta.get("size_bytes", 0)
            st.markdown(
                f"""
                <div class="sb-file-card">
                  <div class="sb-file-icon">{icon}</div>
                  <div class="sb-file-info">
                    <div class="sb-file-name" title="{fname}">{title}</div>
                    <div class="sb-file-date">✅ Ready · {human_size(size)}</div>
                  </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        if total_chat_pages > 1:
            st.markdown(
                f'<div style="text-align:center;font-size:.72rem;color:#8892a4;margin:.4rem 0 .2rem;">'
                f'Page {chat_page} of {total_chat_pages}  ·  {len(done_jobs)} doc(s)</div>',
                unsafe_allow_html=True,
            )
            prev_col, mid_col, next_col = st.columns([1, 2, 1])
            with prev_col:
                if st.button("◄", key="chat_pg_prev", use_container_width=True,
                             disabled=(chat_page <= 1)):
                    st.session_state.chat_doc_page -= 1
                    st.rerun()
            with mid_col:
                st.markdown(
                    f'<div style="text-align:center;padding:.35rem 0;font-size:.8rem;color:#e2e8f0;">'
                    f'{chat_page} / {total_chat_pages}</div>',
                    unsafe_allow_html=True,
                )
            with next_col:
                if st.button("►", key="chat_pg_next", use_container_width=True,
                             disabled=(chat_page >= total_chat_pages)):
                    st.session_state.chat_doc_page += 1
                    st.rerun()

    if active_jobs:
        st.markdown("---")
        st.caption(f"⏳ {len(active_jobs)} document(s) still processing…")
        for job in active_jobs:
            fname = job["filename"]
            meta  = meta_store.get(fname, {})
            title = meta.get("title") or Path(fname).stem
            spin  = "🔄" if job["status"] == "running" else (
                    "🖼️" if job["status"] == "enriching" else (
                    "🔷" if job["status"] == "indexing" else "⏳"))
            st.caption(f"{spin} {title}")


# ── Notification banner: new docs auto-added to assistant ─────────────────────
current_done = shared_db.get_newly_done_since(0, user_name=user_name)

if (
    "vector_store" in st.session_state
    and current_done > st.session_state.done_count_at_load
):
    new_count = current_done - st.session_state.done_count_at_load
    try:
        st.session_state.pop("vector_store", None)
        st.session_state.done_count_at_load = current_done
        st.session_state.notif_pending      = False
        st.markdown(f"""
        <div class="notif-banner">
          <div class="notif-badge">🎉</div>
          <div class="notif-text">
            <b>{new_count} new document(s) added to the assistant automatically!</b>
            They are now included in your searches.
          </div>
        </div>
        """, unsafe_allow_html=True)
    except Exception:
        pass


# ── Main header ───────────────────────────────────────────────────────────────
st.markdown('<h1 class="center-title">📘 Document Assistant</h1>', unsafe_allow_html=True)
st.markdown("""
<div style="padding:20px;width:100%;display:flex;justify-content:center;align-items:center;">
  <p style="text-align:center;margin:0;">
    WELCOME!<br>
    I am Offline AI Document Assistant, specialised to provide accurate and helpful responses
    based on the processed documents.<br>
    Sometimes my answers may not be perfect. If you find my answer inaccurate, let me know.
  </p>
</div>
""", unsafe_allow_html=True)
st.markdown("")


# ── Vector store initialisation (only over DONE docs) ─────────────────────────
def vector_store_exists() -> bool:
    try:
        from rag_pipeline import start_qdrant_server
        start_qdrant_server()
        from qdrant_client import QdrantClient
        client      = QdrantClient(url="http://localhost:6333", timeout=10)
        collections = [c.name for c in client.get_collections().collections]
        if config.QDRANT_COLLECTION_NAME not in collections:
            return False
        info = client.get_collection(config.QDRANT_COLLECTION_NAME)
        return (info.points_count or 0) > 0
    except Exception:
        return False


if "vector_store" not in st.session_state:
    if not done_jobs:
        st.warning(
            "⚠️ No documents have been processed yet.  \n"
            "Please **upload documents** in Document Manager and wait for the "
            "background worker to finish, then return here."
        )
        st.stop()

    if not vector_store_exists():
        st.warning(
            "⚠️ The vector index is not ready yet.  \n"
            "The background worker builds it automatically after processing — "
            "please wait a moment and refresh this page."
        )
        st.stop()

    status_placeholder = st.empty()
    progress_bar       = st.progress(0)

    with status_placeholder.container():
        st.info("🔄 Connecting to pre-built vector index…")
        try:
            progress_bar.progress(0.5)
            st.write("🗄️ **Loading vector store…**")
            st.session_state.vector_store       = create_vector_store([])
            st.session_state.done_count_at_load = current_done
            progress_bar.progress(1.0)
            st.success("✅ **Index loaded — ready to chat!**")
        except Exception as error:
            st.error(f"❌ Failed to connect to vector index: {error}")
            import traceback
            with st.expander("Show error details"):
                st.code(traceback.format_exc())
            st.stop()

    time.sleep(1)
    status_placeholder.empty()
    progress_bar.empty()


# ── Render chat history ────────────────────────────────────────────────────────
for msg_index, msg in enumerate(st.session_state.message_history):
    avatar_icon = "📚" if msg["role"] == "assistant" else "👤"
    with st.chat_message(msg["role"], avatar=avatar_icon):
        st.markdown(msg["content"])

        if msg["role"] == "assistant" and msg.get("sources"):
            sources = msg["sources"]
            with st.expander(f"📄 Sources ({len(sources)})"):
                for src_index, src in enumerate(sources):
                    fname    = src.get("filename", "Unknown")
                    pdf_url  = src.get("pdf_url")
                    page_num = src.get("page", "?")
                    store    = shared_db.load_all_documents(user_name=user_name)
                    title    = fname
                    if fname in store:
                        title = store[fname].get("title") or fname
                    else:
                        for ext in (".pdf", ".pptx", ".ppt", ".docx", ".doc",
                                    ".xlsx", ".xls", ".txt", ".md", ".csv"):
                            if (fname + ext) in store:
                                title = store[fname + ext].get("title") or fname
                                break
                    if pdf_url:
                        pdf_path = Path(pdf_url)
                        if pdf_path.exists():
                            with open(pdf_path, "rb") as fh:
                                st.download_button(
                                    label=f"📄 {title}  |  Page: {page_num}",
                                    data=fh,
                                    file_name=Path(pdf_url).name,
                                    mime="application/pdf",
                                    key=f"history_{msg_index}_{src_index}",
                                )
                        else:
                            st.caption(f"📄 {title}  |  Page: {page_num}  – file not found")
                    else:
                        st.caption(f"📄 {title}  |  Page: {page_num}  – PDF not available")


# ── Chat input ────────────────────────────────────────────────────────────────
user_input = st.chat_input("Ask a question about the documents")

if user_input:
    st.session_state.message_history.append({"role": "user", "content": user_input})
    with st.chat_message("user", avatar="👤"):
        st.markdown(user_input)

    THINKING_MESSAGES = [
        "Analysing your query against the available documents.",
        "Retrieving the most relevant information.",
        "Processing context to ensure an accurate response.",
        "Searching the knowledge base for matching insights.",
        "Reviewing related content to form a precise answer.",
        "Evaluating document sections for relevance.",
        "Synthesising information from multiple sources.",
        "Aligning your question with stored knowledge.",
        "Identifying key details required for the response.",
        "Cross-checking facts to improve accuracy.",
        "Understanding the intent behind your question.",
        "Filtering unnecessary information.",
        "Assembling a clear and concise answer.",
        "Validating results before responding.",
        "Matching your query with indexed content.",
        "Optimising the response for clarity.",
        "Finalising the answer for delivery.",
    ]

    with st.chat_message("assistant", avatar="📚"):
        placeholder   = st.empty()
        full_response = ""

        t1 = time.time()
        with st.spinner("Thinking… " + random.choice(THINKING_MESSAGES)):
            stream_gen, retrieved_documents = generate_streaming_answer(
                st.session_state.vector_store,
                user_input,
                user_name=user_name,
            )
            for token in stream_gen:
                full_response += token
                placeholder.markdown(full_response)

        response_time = time.time() - t1

        with chat_history_file_lock:
            chat_history_file.write(
                f"{datetime.now()}: {user_name}: IP: {get_remote_ip()}\n"
                f"Chat_Query: {user_input} \n"
                f"Thinking: \n"
                f"Answer: {full_response}\n"
                f"ResponseTime: {response_time}\n\n")
            chat_history_file.flush()

    # ── Gather & deduplicate sources ──────────────────────────────────────────
    def _resolve_title(stem: str) -> str:
        store = shared_db.load_all_documents(user_name=user_name)
        if stem in store:
            return store[stem].get("title") or stem
        for ext in (".pdf", ".pptx", ".ppt", ".docx", ".doc",
                    ".xlsx", ".xls", ".txt", ".md", ".csv"):
            if (stem + ext) in store:
                return store[stem + ext].get("title") or stem
        return stem

    unique_sources: dict = {}
    for doc in retrieved_documents:
        meta     = doc.metadata or {}
        filename = meta.get("filename", "Unknown")
        pdf_url  = meta.get("pdf_url")
        page_num = meta.get("page_number", "?")
        key = (filename, page_num)
        if key not in unique_sources:
            unique_sources[key] = {"filename": filename, "pdf_url": pdf_url, "page": page_num}

    source_items = list(unique_sources.values())

    if source_items:
        with st.expander(f"📄 Sources ({len(source_items)})"):
            for src_index, src in enumerate(source_items):
                fname    = src["filename"]
                url      = src["pdf_url"]
                page_num = src["page"]
                title    = _resolve_title(fname)

                if url:
                    pdf_path = Path(url)
                    if pdf_path.exists():
                        with open(pdf_path, "rb") as fh:
                            st.download_button(
                                label=f"📄 {title}  |  Page: {page_num}",
                                data=fh,
                                file_name=Path(url).name,
                                mime="application/pdf",
                                key=f"current_{len(st.session_state.message_history)}_{src_index}",
                            )
                    else:
                        st.caption(f"📄 {title}  |  Page: {page_num}  – file not found")
                else:
                    st.caption(f"📄 {title}  |  Page: {page_num}  – PDF not available")
    else:
        st.info("No source documents were found for this query.")

    st.session_state.message_history.append({
        "role":    "assistant",
        "content": full_response,
        "sources": source_items,
    })

    # ── Check for newly finished docs after each chat turn ────────────────────
    new_done = shared_db.get_newly_done_since(0, user_name=user_name)
    if new_done > st.session_state.done_count_at_load:
        st.session_state.notif_pending = True
        st.rerun()
