#!/usr/bin/env python3
"""
worker.py
=========
Standalone background worker - run ONCE alongside Streamlit:

    python worker.py

Pipeline stages (each on its own threads, all running in parallel):
  1. OCR       - two local mineru-api servers (config.MINERU_API_URLS,
                 ports 9866 and 9867). Each server takes one document at a
                 time, so two documents are OCR'd simultaneously.
  2. Enrich    - image description via Ollama (qwen3-vl).
  3. Index     - chunk summary + embeddings via Ollama, then Qdrant.
"""

# ============================================================
# STEP 0 – apply environment patches BEFORE any GPU import
# ============================================================
import os
import logging
import warnings

# Suppress ONNXRuntime sysfs GPU-discovery warning
os.environ.setdefault("ORT_DISABLE_GPU_DEVICE_DISCOVERY", "1")
# Reduce CUDA allocator fragmentation
os.environ.setdefault("PYTORCH_ALLOC_CONF", "expandable_segments:True")

# Silence the ORT warning at the Python-logging level as well
logging.getLogger("onnxruntime").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", message=".*GPU device discovery failed.*")
warnings.filterwarnings("ignore", message=".*device_discovery.*")

# ============================================================
# Standard imports
# ============================================================
import sys
import time
from pathlib import Path

import config
import shared_db
from document_ingestion import (
    compute_file_hash,
    convert_office_to_pdf,
    convert_with_mineru,
    enrich_images_with_descriptions,
    build_final_markdown_from_json,
    OFFICE_EXTENSIONS,
)

import threading
import concurrent.futures
import queue
import httpx

# ============================================================
# Logging
# ============================================================

_LOG_DIR = Path(__file__).parent / "logs"
_LOG_DIR.mkdir(parents=True, exist_ok=True)

_INDEXER_THREAD_NAME = "indexer-loop"
_ENRICH_THREAD_PREFIX = "enrich"


def _is_indexer_thread(name: str) -> bool:

    return name.startswith(_INDEXER_THREAD_NAME)


def _is_enrich_thread(name: str) -> bool:
    return name.startswith(_ENRICH_THREAD_PREFIX)


class _OnlyIndexing(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return _is_indexer_thread(record.threadName)


class _OnlyEnrich(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return _is_enrich_thread(record.threadName)


class _OcrOnly(logging.Filter):
    """Everything that is NEITHER indexing NOR image-description."""
    def filter(self, record: logging.LogRecord) -> bool:
        return not _is_indexer_thread(record.threadName) and not _is_enrich_thread(record.threadName)


_CONSOLE_IMPORTANT_MARKERS = (
    "Worker started.",
    "Background enrichment",
    "Background image-description thread pool started",
    "Background indexer thread started",
)


class _ConsoleImportantOnly(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if record.levelno >= logging.WARNING:
            return True
        msg = record.getMessage()
        return any(marker in msg for marker in _CONSOLE_IMPORTANT_MARKERS)


_console_handler = logging.StreamHandler(sys.stdout)
_console_handler.setFormatter(
    logging.Formatter("%(asctime)s [WORKER] %(levelname)s  %(message)s")
)
_console_handler.addFilter(_ConsoleImportantOnly())

_ocr_handler = logging.FileHandler(_LOG_DIR / "ocr.log", encoding="utf-8")
_ocr_handler.setFormatter(
    logging.Formatter("%(asctime)s [OCR] %(levelname)s  %(message)s")
)
_ocr_handler.addFilter(_OcrOnly())

_enrich_handler = logging.FileHandler(_LOG_DIR / "enrich.log", encoding="utf-8")
_enrich_handler.setFormatter(
    logging.Formatter("%(asctime)s [ENRICH] %(levelname)s  %(message)s")
)
_enrich_handler.addFilter(_OnlyEnrich())

_index_handler = logging.FileHandler(_LOG_DIR / "indexing.log", encoding="utf-8")
_index_handler.setFormatter(
    logging.Formatter("%(asctime)s [INDEX] %(levelname)s  %(message)s")
)
_index_handler.addFilter(_OnlyIndexing())

logging.basicConfig(
    level=logging.INFO,
    handlers=[_console_handler, _ocr_handler, _enrich_handler, _index_handler],
    force=True,
)
logger = logging.getLogger(__name__)


for _noisy in ("httpx", "httpcore", "urllib3", "qdrant_client"):
    logging.getLogger(_noisy).setLevel(
        getattr(logging, getattr(config, "NOISY_LIBRARY_LOG_LEVEL", "WARNING"), logging.WARNING)
    )

# ============================================================
# HANG DIAGNOSTICS
# ============================================================
# The whole reason previous hangs were hard to diagnose from the logs
# alone is that a genuine hang produces NO exception and NO log line —
# the thread is just sitting inside some blocking call (network read,
# lock acquire, etc.) with nothing to report. The only way to actually
# see WHERE a thread is stuck is to look at its live Python call stack
# at the moment it's stuck, which is what this section provides, via two
# mechanisms:
#
#   1. On-demand: `kill -USR1 <worker.py pid>` at any time writes every
#      thread's exact current stack frame to logs/thread_dump.log — no
#      restart needed, and it can be run the moment things look stuck.
#
#   2. Automatic: a background watchdog tracks how long each in-flight
#      OCR/enrichment/indexing job has been running. If one runs past a
#      generous per-stage threshold, the watchdog writes that same full
#      thread dump automatically — so even if nobody was watching when it
#      first got stuck, the dump still exists afterward showing exactly
#      which call, in which file, on which line, every thread was blocked
#      in at that moment.
#
# Next time something looks hung, check logs/thread_dump.log before
# restarting — it will show the exact blocking call (e.g. stuck in an
# httpx read, a lock acquire, etc.), which is the
# difference between guessing and knowing.
import faulthandler
import signal

_progress_lock = threading.Lock()
_active_since: dict[str, float] = {}   # label -> start timestamp (time.time())
_dumped_labels: set[str] = set()        # labels we've already auto-dumped for (avoid repeat spam)


def _track_start(label: str) -> None:
    with _progress_lock:
        _active_since[label] = time.time()
        _dumped_labels.discard(label)


def _track_end(label: str) -> None:
    with _progress_lock:
        _active_since.pop(label, None)
        _dumped_labels.discard(label)


# ------------------------------------------------------------------
# LOOP HEARTBEATS — covers the gap _track_start/_track_end can't see.
# ------------------------------------------------------------------
# _track_start/_track_end only cover time spent actually PROCESSING a
# job (inside process_single_file_ocr / _run_enrichment_job /
# chunk_and_index_for_user). But every loop also calls shared_db
# functions BEFORE any job is picked up — shared_db.get_all_
# pending_jobs(), shared_db.get_jobs_at_status(...), shared_db.
# get_users_with_status(...). If any of THOSE hang (a stuck SQLite
# lock, a stale OS-level file lock, a slow/stuck disk), the loop never
# gets far enough to set any _track_start label — so the previous
# watchdog would stay silent forever even though the whole process is
# frozen, which matches "all three logs and the terminal go completely
# silent, nothing processes, until I restart".
#
# Each loop calls _beat(name) once per iteration, right at the top,
# before doing anything else. If a loop hasn't beaten in far longer
# than its own poll interval, it's stuck somewhere in that iteration
# — most likely in the shared_db/pool call — and this fires a full
# thread dump the same way a stuck job does.
_loop_heartbeat: dict[str, float] = {}
_loop_dumped: set[str] = set()
_LOOP_STALL_THRESHOLD_SECONDS = 120  # generous vs. every loop's 3-10s poll interval


def _beat(loop_name: str) -> None:
    with _progress_lock:
        _loop_heartbeat[loop_name] = time.time()
        _loop_dumped.discard(loop_name)


def _dump_all_threads(reason: str) -> None:
    dump_path = _LOG_DIR / "thread_dump.log"
    try:
        with open(dump_path, "a", encoding="utf-8") as f:
            f.write(
                f"\n\n===== THREAD DUMP  "
                f"{time.strftime('%Y-%m-%d %H:%M:%S')}  ({reason}) =====\n"
            )
            faulthandler.dump_traceback(file=f, all_threads=True)
        logger.warning(
            "[WATCHDOG] Wrote a full thread dump to %s (%s). Every thread's exact "
            "current line of code is in that file — open it to see what's actually "
            "stuck instead of guessing.",
            dump_path, reason,
        )
    except Exception as exc:
        logger.error("[WATCHDOG] Failed to write thread dump: %s", exc)


def _install_manual_dump_signal() -> None:
    def _handler(signum, frame):
        _dump_all_threads(reason="manual SIGUSR1 request")

    try:
        signal.signal(signal.SIGUSR1, _handler)
        logger.info(
            "[WATCHDOG] Run `kill -USR1 %d` at any time to dump every thread's "
            "current stack to logs/thread_dump.log without restarting.", os.getpid(),
        )
    except (ValueError, AttributeError):
        # SIGUSR1 doesn't exist on this platform (e.g. native Windows) — skip.
        pass


# Per-stage stall thresholds before the watchdog auto-dumps. OCR already
# has its own MINERU_HARD_DEADLINE_SECONDS enforced via future.result(), so
# anything stuck past that PLUS a buffer is stuck OUTSIDE that mechanism.
# Enrichment/indexing have no built-in deadline of their own, so use a
# tighter threshold for those.
_STALL_THRESHOLDS = {
    "ocr":    getattr(config, "MINERU_HARD_DEADLINE_SECONDS", 1800) + 300,
    "enrich": 600,
    "index":  600,
}


def _watchdog_loop(poll_interval: float = 60.0) -> None:
    while True:
        time.sleep(poll_interval)
        now = time.time()

        with _progress_lock:
            snapshot = dict(_active_since)
            loop_snapshot = dict(_loop_heartbeat)

        for label, started in snapshot.items():
            stage = label.split(":", 1)[0]
            threshold = _STALL_THRESHOLDS.get(stage, 600)
            elapsed = now - started
            if elapsed > threshold and label not in _dumped_labels:
                with _progress_lock:
                    _dumped_labels.add(label)
                logger.warning(
                    "[WATCHDOG] '%s' has been running %.0fs (> %.0fs threshold) — "
                    "looks stuck. Auto-dumping every thread's stack now.",
                    label, elapsed, threshold,
                )
                _dump_all_threads(reason=f"{label} stalled {elapsed:.0f}s")

        # A loop that hasn't beaten in far longer than its own poll interval
        # is stuck BEFORE it even got to pick up a job (most likely inside
        # a shared_db/pool call) — see the note above _loop_heartbeat.
        for loop_name, last_beat in loop_snapshot.items():
            elapsed = now - last_beat
            if elapsed > _LOOP_STALL_THRESHOLD_SECONDS and loop_name not in _loop_dumped:
                with _progress_lock:
                    _loop_dumped.add(loop_name)
                logger.warning(
                    "[WATCHDOG] Loop '%s' hasn't completed an iteration in %.0fs "
                    "(> %ds) — it's stuck somewhere BEFORE picking up a job "
                    "(most likely a shared_db call). Auto-dumping every "
                    "thread's stack now.",
                    loop_name, elapsed, _LOOP_STALL_THRESHOLD_SECONDS,
                )
                _dump_all_threads(reason=f"loop '{loop_name}' stalled {elapsed:.0f}s")


_install_manual_dump_signal()

try:
    import onnxruntime as _ort
    _ort.set_default_logger_severity(3)
except Exception:
    pass

# ============================================================
# Configuration
# ============================================================
POLL_INTERVAL  = 10   # seconds between queue polls
JOB_PAUSE      = 2    # seconds between consecutive jobs
OOM_RETRY_WAIT = 30   # seconds to wait before retrying after CUDA OOM
MAX_OOM_RETRY  = 2    # max automatic retries on OOM per job

_BASE_INPUT_DIR = Path(config.DOCUMENTS_INPUT_DIR)
OUTPUT_DIR      = Path(config.MARKDOWN_OUTPUT_DIR)


# ============================================================
# MinerU endpoint pool (two local mineru-api servers)
# ============================================================

class _EndpointPool:
    """
    Hands out mineru-api endpoints, one job per endpoint at a time.
    Free endpoints sit in a queue; acquire() never blocks (returns None
    when both servers are busy) so the dispatch loop just retries next poll.
    """

    def __init__(self, urls: list[str]):
        self._free: "queue.Queue[str]" = queue.Queue()
        for url in urls:
            self._free.put(url)
        self.size = len(urls)

    def acquire(self) -> str | None:
        try:
            return self._free.get_nowait()
        except queue.Empty:
            return None

    def release(self, url: str) -> None:
        self._free.put(url)


# ============================================================
# Per-user directory helper
# ============================================================

def _user_input_dir(user_name: str) -> Path:
    d = _BASE_INPUT_DIR / user_name
    d.mkdir(parents=True, exist_ok=True)
    return d


# ============================================================
# Core processing logic
# ============================================================

# Concurrent soffice (LibreOffice) invocations sharing the default user
# profile can crash each other, so serialise just this cheap CPU step.
_LIBREOFFICE_LOCK = threading.Lock()

# One lock per user so two files finishing for the same user at nearly the
# same time can't both trigger chunk_and_index_for_user() concurrently and
# corrupt that user's Qdrant collection.
_user_index_locks: dict[str, threading.Lock] = {}
_user_index_locks_guard = threading.Lock()


def _index_lock_for(user_name: str) -> threading.Lock:
    with _user_index_locks_guard:
        return _user_index_locks.setdefault(user_name, threading.Lock())


def _resolve_input_file(filename: str, user_name: str = "") -> Path:
    if user_name:
        file = _user_input_dir(user_name) / filename
        if not file.exists():
            file = _BASE_INPUT_DIR / filename
    else:
        file = _BASE_INPUT_DIR / filename

    if not file.exists():
        raise FileNotFoundError(f"Document not found on disk: {filename}")
    return file


def process_single_file_ocr(filename: str, user_name: str, endpoint_url: str) -> bool:
    """
    STAGE 1 ONLY: convert + OCR one document file on the given mineru-api
    endpoint. Image description (Ollama qwen3-vl) and chunk-summary/indexing
    (Ollama) run later on their own thread pools, so the endpoint is freed
    as soon as OCR finishes.

    On CUDA OOM the function waits OOM_RETRY_WAIT seconds and retries up to
    MAX_OOM_RETRY times before re-raising so the job is marked failed.

    Returns True if the file was already fully cached (OCR + image-desc both
    previously done), False if OCR just ran and the file still needs image
    description + indexing.
    """
    file = _resolve_input_file(filename, user_name)

    output_dir   = OUTPUT_DIR
    temp_pdf_dir = output_dir / "_temp_pdfs"
    output_dir.mkdir(parents=True, exist_ok=True)
    temp_pdf_dir.mkdir(parents=True, exist_ok=True)

    file_hash = compute_file_hash(file)

    if shared_db.is_file_cached(file_hash):
        logger.info("Already cached, skipping heavy work: %s", filename)
        return True

    oom_attempts = 0
    while True:
        try:
            if file.suffix.lower() in OFFICE_EXTENSIONS:
                logger.info("Office→PDF: %s", filename)
                with _LIBREOFFICE_LOCK:
                    pdf = convert_office_to_pdf(file, temp_pdf_dir)
                convert_with_mineru(pdf, output_dir, endpoint_url)

            elif file.suffix.lower() == ".pdf":
                convert_with_mineru(file, output_dir, endpoint_url)

            else:
                # Plain text / CSV / MD — CPU-only Docling path
                from docling.document_converter import DocumentConverter
                logger.info("Docling fallback: %s", filename)
                docling = DocumentConverter()
                result  = docling.convert(file)
                if not result.document:
                    raise RuntimeError("Docling produced no document")
                doc_dir = output_dir / file.stem
                doc_dir.mkdir(parents=True, exist_ok=True)
                (doc_dir / f"{file.stem}.md").write_text(
                    result.document.export_to_markdown(), encoding="utf-8"
                )
            break  # success – exit retry loop

        except RuntimeError as exc:
            if "CUDA out of memory" in str(exc) and oom_attempts < MAX_OOM_RETRY:
                oom_attempts += 1
                logger.warning(
                    "[OOM] CUDA out of memory on attempt %d/%d for %s — "
                    "retrying in %ds …",
                    oom_attempts, MAX_OOM_RETRY, filename, OOM_RETRY_WAIT,
                )
                time.sleep(OOM_RETRY_WAIT)
            else:
                raise  # give up – caller marks job as failed

    logger.info("[OCR] Done (mineru %s): %s", endpoint_url, filename)
    return False


def _run_enrichment_job(filename: str, user_name: str) -> None:
    """
    STAGE 2 ONLY: image description (Ollama qwen3-vl) + page-tagged
    markdown + cache update, for one file whose OCR has already finished.

    Runs on the dedicated enrichment thread pool (_enrichment_loop below),
    entirely separate from the OCR dispatch — it talks only to the
    Ollama qwen3-vl server, never to mineru-api, so it never blocks (and is
    never blocked by) OCR. On success the file moves to 'indexing', where the
    dedicated indexer thread pool picks up chunk-summary + embedding.
    """
    file = _resolve_input_file(filename, user_name)
    file_hash = compute_file_hash(file)

    stem      = Path(filename).stem
    doc_dir   = OUTPUT_DIR / stem
    json_file = doc_dir / f"{stem}.json"

    shared_db.mark_stage(filename, user_name, "🖼️ Describing images (Ollama qwen3-vl)")

    _track_start(f"enrich:{user_name}:{filename}")
    try:
        if json_file.exists():
            enriched_json = enrich_images_with_descriptions(json_file)
            build_final_markdown_from_json(enriched_json)
        else:
            logger.warning(
                "[ENRICH] %s has no %s — nothing to enrich, moving straight to indexing.",
                filename, json_file.name,
            )
    finally:
        _track_end(f"enrich:{user_name}:{filename}")

    # OCR + image-desc are now BOTH done — this is what "cached" means.
    shared_db.mark_file_cached(file_hash, filename, user_name)

    shared_db.mark_indexing(filename, user_name)
    shared_db.update_document_status(filename, user_name, "indexing")
    shared_db.mark_stage(filename, user_name, "📦 Queued for chunk summarization (gpt-oss:20b)")
    logger.info("[ENRICH] Done: %s (user: %s) → indexing", filename, user_name)


def _enrichment_loop(poll_interval: float = 3.0) -> None:
    """
    Dedicated background thread pool for Ollama qwen3-vl image-description.

    _handle_job() releases its mineru-api endpoint the moment OCR finishes
    and hands the file off to this loop, so a freed endpoint can start the
    next pending file while image description for the previous one runs
    here, bounded only by config.ENRICH_MAX_CONCURRENCY.

    Poll-based (reads status='enriching' from the DB) rather than an
    in-memory queue so it also picks up files restored to 'enriching' by
    the crash-recovery logic in run_worker() after a restart. Runs on a
    thread named "enrichment-loop" — see the logging setup above for how
    that's routed to its own log file, same as "indexer-loop".
    """
    max_workers = max(getattr(config, "ENRICH_MAX_CONCURRENCY", 3), 1)
    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=max_workers, thread_name_prefix="enrich"
    )
    in_flight: set[tuple[str, str]] = set()
    guard = threading.Lock()

    logger.info(
        "[ENRICH] Background image-description thread pool started "
        "(%d concurrent, poll every %ss).", max_workers, poll_interval,
    )

    while True:
        _beat("enrichment-loop")
        try:
            jobs = shared_db.get_jobs_at_status("enriching")
            for job in jobs:
                filename, user_name = job["filename"], job["user_name"]
                key = (filename, user_name)
                with guard:
                    if key in in_flight:
                        continue
                    in_flight.add(key)

                def _run(filename=filename, user_name=user_name, key=key):
                    try:
                        _run_enrichment_job(filename, user_name)
                    except Exception as exc:
                        shared_db.mark_failed(filename, str(exc), user_name)
                        shared_db.update_document_status(filename, user_name, "failed")
                        logger.error(
                            "[ENRICH] Failed on %s (user: %s): %s",
                            filename, user_name, exc, exc_info=True,
                        )
                    finally:
                        with guard:
                            in_flight.discard(key)

                executor.submit(_run)
        except Exception as exc:
            logger.error("[ENRICH] Loop error (will retry): %s", exc, exc_info=True)
        time.sleep(poll_interval)


def chunk_and_index_for_user(user_name: str) -> None:
    """
    Chunk + vector-store ingestion for all documents of a user currently
    sitting at 'indexing'. Called immediately after EACH file's own OCR
    finishes (not deferred until the whole per-user queue drains), so a
    file goes running -> indexing -> done on its own timeline. Guarded by
    a per-user lock so concurrent calls (both OCR servers finishing
    close together) don't double-process the same file.

    PER-DOCUMENT, not batched: each document's chunks are contextualized
    (gpt-oss) AND inserted into Qdrant AND verified/marked 'done' before
    moving on to the next document. This means a document becomes
    queryable as soon as its own turn finishes, instead of every document
    in the batch waiting for the single slowest one (or the whole batch)
    to complete before any of them are searchable.

    A document sits at 'indexing' (set right after its own image
    description finishes, in _run_enrichment_job) until its chunks are
    actually confirmed present in Qdrant here — not just because this call
    returned without raising.

    Errors on one document are logged and that document is skipped (stays
    at 'indexing', retried on the next batch run) — they do NOT block or
    roll back documents that already finished earlier in this same loop.
    """
    logger.info("[CHUNK+INDEX] Starting for user: %s", user_name)
    with _index_lock_for(user_name):
        from rag_pipeline import (
            create_contextualized_documents_for_file,
            create_vector_store,
            get_existing_chunk_hashes_for_filenames,
            get_markdown_files,
            get_qdrant_client,
            initialize_embeddings,
            load_context_cache,
            save_context_cache,
        )

        # Snapshot of who is actually waiting on this run, taken before the
        # (possibly slow) work below starts.
        awaiting = {j["filename"] for j in shared_db.get_jobs_by_status(user_name, "indexing")}
        if not awaiting:
            logger.info("[CHUNK+INDEX] Nothing awaiting indexing for user: %s", user_name)
            return

        files = get_markdown_files(user_name)
        files_by_stem = {f.stem: f for f in files}
        cache = load_context_cache()

        # Initialize ONCE, reuse for every document in this run — avoids
        # re-loading the embedding models and reopening a Qdrant client
        # connection on every single iteration (see create_vector_store's
        # docstring). At 500-1000 documents this is the difference between
        # 1 embedding-model load and 500-1000 of them.
        dense_embeddings, sparse_embeddings = initialize_embeddings()
        client = get_qdrant_client()

        for filename in sorted(awaiting):
            stem = Path(filename).stem
            file = files_by_stem.get(stem)
            if file is None:
                logger.warning(
                    "[CHUNK+INDEX] %s has no markdown file yet — skipping this run.", filename
                )
                continue

            try:
                _track_start(f"index:{user_name}:{filename}")
                # 1. Chunk-summary (gpt-oss) for THIS document only.
                shared_db.mark_stage(filename, user_name, "✂️ Summarizing chunks (gpt-oss:20b)")
                doc_chunks = create_contextualized_documents_for_file(
                    file, cache, user_name=user_name
                )
                save_context_cache(cache)  # persist immediately

                if not doc_chunks:
                    logger.warning("[CHUNK+INDEX] No chunks produced for %s — skipping.", filename)
                    continue

                # 2. Index THIS document only, reusing the shared
                #    embeddings/client instead of re-initializing them.
                shared_db.mark_stage(filename, user_name, "📈 Embedding & indexing (qwen-embedding → Qdrant)")
                create_vector_store(
                    doc_chunks,
                    dense_embeddings=dense_embeddings,
                    sparse_embeddings=sparse_embeddings,
                    client=client,
                )

                # 3. Verify THIS document's chunks are actually in Qdrant

                confirmed_hashes = get_existing_chunk_hashes_for_filenames(client, [stem], user_name=user_name)
                if all(c.metadata.get("chunk_hash") in confirmed_hashes for c in doc_chunks):
                    shared_db.mark_done(filename, user_name)
                    shared_db.update_document_status(filename, user_name, "done")
                    logger.info(
                        "[CHUNK+INDEX] %s confirmed in Qdrant → done "
                        "(ready for querying now, independent of the rest of the batch).",
                        filename,
                    )
                else:
                    logger.warning(
                        "[CHUNK+INDEX] %s not confirmed in Qdrant — left at 'indexing', "
                        "will be retried on the next batch run.",
                        filename,
                    )
            except Exception as exc:
                logger.error(
                    "[CHUNK+INDEX] Failed on %s (user: %s): %s — leaving it at 'indexing', "
                    "continuing with the remaining documents.",
                    filename, user_name, exc, exc_info=True,
                )
                continue
            finally:
                _track_end(f"index:{user_name}:{filename}")

        logger.info("[CHUNK+INDEX] Finished run for user: %s", user_name)


def _indexer_loop(poll_interval: float = 5.0) -> None:
    """
    Dedicated background thread for gpt-oss chunk-summary + Qdrant indexing.

    Runs completely independently of the OCR ThreadPoolExecutor used by the
    main dispatch loop below.

    Moving indexing to its own always-on thread — entirely separate from
    the OCR executor's thread pool AND from the _enrichment_loop's image-
    description pool — means OCR dispatch, image description, and
    indexing genuinely run in parallel: an executor thread is never held
    hostage by indexing (or image-description) work. A document only
    reaches 'indexing' once its own image description
    (_run_enrichment_job) has finished, so no further gating on other
    users'/documents' pending/running/enriching state is needed here.
    """
    max_workers = max(getattr(config, "INDEXER_MAX_CONCURRENCY", 3), 1)
    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=max_workers, thread_name_prefix=_INDEXER_THREAD_NAME
    )
    in_flight: set[str] = set()
    guard = threading.Lock()

    logger.info(
        "[INDEXER] Background indexer thread pool started "
        "(%d concurrent user(s), poll every %ss).", max_workers, poll_interval,
    )

    while True:
        _beat("indexer-loop")
        try:
            users_needing_index = shared_db.get_users_with_status("indexing")
            if users_needing_index:
                logger.info(
                    "[INDEXER] %d user(s) have documents awaiting indexing: %s",
                    len(users_needing_index), ", ".join(users_needing_index),
                )
            for user_name in users_needing_index:
                with guard:
                    if user_name in in_flight:
                        continue  # already being indexed on another pool thread
                    in_flight.add(user_name)

                def _run(user_name=user_name):
                    try:
                        # NOTE: deliberately NOT gated on "the user's OCR
                        # queue has drained". An earlier version skipped
                        # any user that still had pending/running jobs —
                        # with a queue of thousands of documents that
                        # condition never became true, so indexing never
                        # ran at all. Documents are indexed as soon as
                        # they reach 'indexing', continuously, while OCR
                        # keeps running in parallel.
                        chunk_and_index_for_user(user_name)
                    except Exception as exc:
                        logger.error(
                            "[INDEXER] Loop error for user %s (will retry): %s",
                            user_name, exc, exc_info=True,
                        )
                    finally:
                        with guard:
                            in_flight.discard(user_name)

                executor.submit(_run)
        except Exception as exc:
            logger.error("[INDEXER] Loop error (will retry): %s", exc, exc_info=True)
        time.sleep(poll_interval)


# ============================================================
# Concurrent dispatcher
# ============================================================
#
# Pending documents are handed to whichever mineru-api endpoint (9866 or
# 9867) is free, so two documents are OCR'd at the same time.

def _is_transient_infra_error(exc: BaseException) -> bool:
    """
    True for failures that are about the INFRASTRUCTURE being momentarily
    unavailable, not about the document itself — the kind that a retry will
    very plausibly succeed at:
      - ConnectionRefusedError / httpx.ConnectError: nothing listening yet
        on the other end (e.g. mineru-api still loading, or restarting).
      - ConnectionResetError / httpx.ReadError ('Connection reset by
        peer'): the mineru-api process died/was killed mid-request.
      - httpx.RemoteProtocolError ('Server disconnected without sending a
        response'): the mineru-api process closed the connection cleanly before
        writing anything.
      - httpx.HTTPStatusError with status 409: the target mineru-api is
        still processing a PREVIOUS request that this app already gave up
        on client-side (its hard deadline fired) — retrying is the safe
        move rather than a permanent failure.
    Walks exc.__cause__ once because these are usually reraised/wrapped
    (see convert_with_mineru), so the interesting type is often one
    level down from what worker.py actually catches.
    """
    for e in (exc, getattr(exc, "__cause__", None)):
        if e is None:
            continue
        if isinstance(e, (ConnectionRefusedError, ConnectionResetError)):
            return True
        if isinstance(e, (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError)):
            return True
        if isinstance(e, httpx.HTTPStatusError) and e.response is not None and e.response.status_code == 409:
            return True
    return False


def _handle_job(job: dict, endpoint_url: str, pool: _EndpointPool) -> None:
    """
    Runs OCR ONLY on this executor thread / this mineru-api endpoint. The
    endpoint is released the INSTANT OCR returns — image description and
    chunk-summary/indexing happen afterward on their own thread pools
    (_enrichment_loop / _indexer_loop), so the endpoint can start the next
    file's OCR immediately.
    """
    filename  = job["filename"]
    user_name = job["user_name"]
    port = endpoint_url.rsplit(":", 1)[-1]
    processed_by = f"Local A100 (port {port})"
    released = False
    try:
        shared_db.mark_running(filename, user_name, processed_by=processed_by)
        shared_db.update_document_status(filename, user_name, "running")
        shared_db.mark_stage(filename, user_name, f"🔎 OCR via {processed_by} (mineru)")
        logger.info("[%s] Picked up job: %s (user: %s)", processed_by, filename, user_name)

        _track_start(f"ocr:{user_name}:{filename}")
        try:
            already_cached = process_single_file_ocr(filename, user_name, endpoint_url)
        finally:
            _track_end(f"ocr:{user_name}:{filename}")

        # OCR is done — release the endpoint before anything else.
        pool.release(endpoint_url)
        released = True

        if already_cached:
            # OCR + image-desc already finished for this exact file content —
            # just put it at the stage the indexer picks up.
            shared_db.mark_indexing(filename, user_name)
            shared_db.update_document_status(filename, user_name, "indexing")
            shared_db.mark_stage(filename, user_name, "📦 Queued for chunk summarization (gpt-oss:20b)")
        else:
            # Hand off to the enrichment thread pool (image description).
            shared_db.mark_enriching(filename, user_name)
            shared_db.update_document_status(filename, user_name, "enriching")
            shared_db.mark_stage(filename, user_name, "🖼️ Queued for image description (Ollama qwen3-vl)")

        logger.info(
            "[%s] OCR done for %s (user: %s); endpoint released, handed "
            "off to the background image-description pool.",
            processed_by, filename, user_name,
        )

    except Exception as exc:
        if _is_transient_infra_error(exc):
            retry_count = shared_db.get_retry_count(filename, user_name)
            if retry_count < config.MAX_TRANSIENT_RETRIES:
                new_count = shared_db.requeue_for_transient_retry(filename, user_name, str(exc))
                shared_db.update_document_status(filename, user_name, "pending")
                logger.warning(
                    "[%s] Transient infra error on %s (user: %s), auto-retrying "
                    "(%d/%d): %s",
                    processed_by, filename, user_name,
                    new_count, config.MAX_TRANSIENT_RETRIES, exc,
                )
            else:
                # Retry budget exhausted — needs a person to look at it.
                shared_db.mark_failed(
                    filename,
                    f"Gave up after {retry_count} automatic retries: {exc}",
                    user_name,
                )
                shared_db.update_document_status(filename, user_name, "failed")
                logger.error(
                    "[%s] Job failed [%s] after %d automatic retries: %s",
                    processed_by, filename, retry_count, exc, exc_info=True,
                )
        else:
            # A real content/processing failure (corrupt PDF, model crash on
            # a specific page, etc.) — retrying won't help.
            shared_db.mark_failed(filename, str(exc), user_name)
            shared_db.update_document_status(filename, user_name, "failed")
            logger.error("[%s] Job failed [%s]: %s", processed_by, filename, exc, exc_info=True)
    finally:
        if not released:
            pool.release(endpoint_url)


def run_worker() -> None:
    """
    Main loop: every POLL_INTERVAL, pull pending jobs and hand each one to a
    free mineru-api endpoint (9866 / 9867), running both concurrently.
    """
    # ── Crash / power-cut recovery ──────────────────────────────────────
    # 'running' jobs died mid-OCR — no guarantee of flushed output, always
    # unsafe to trust, so they're unconditionally redone.
    requeued = shared_db.requeue_stale_jobs()
    if requeued:
        logger.warning(
            "[RECOVERY] Found %d job(s) stuck mid-OCR from a previous run "
            "(likely an interrupted/crashed process) — requeued as 'pending': %s",
            len(requeued),
            ", ".join(f"{j['filename']}({j['previous_status']})" for j in requeued),
        )

    # 'indexing' jobs are different: their OCR step already finished
    # successfully (that's what put them at 'indexing' in the first place).
    # Blindly resetting these to 'pending' — as the old code did — redoes
    # OCR for work that's already sitting on disk, wasting hours of GPU
    # time and leaving stray duplicate MARKDOWN output folders behind.
    # Instead, check file_hash_cache per file: if the hash is present, OCR
    # genuinely completed and was cached — restore straight to 'indexing'
    # (skip OCR) and let chunk-summary/indexing pick it up below. Only
    # files with NO cache entry (e.g. the process died between finishing
    # OCR and writing the cache row) go back to 'pending'.
    stuck_indexing = shared_db.get_indexing_status_jobs()
    restored_to_indexing, requeued_for_ocr = [], []
    affected_users = set()
    for job in stuck_indexing:
        filename, user_name = job["filename"], job["user_name"]
        try:
            file = _user_input_dir(user_name) / filename
            if not file.exists():
                file = _BASE_INPUT_DIR / filename
            file_hash = compute_file_hash(file) if file.exists() else None
        except Exception:
            file_hash = None

        if file_hash and shared_db.is_file_cached(file_hash):
            shared_db.reset_job_status(filename, user_name, "indexing",
                                        reason="restored after restart — OCR already cached")
            restored_to_indexing.append(filename)
        else:
            shared_db.reset_job_status(filename, user_name, "pending",
                                        reason="auto-requeued after restart — no cache entry, OCR redone")
            requeued_for_ocr.append(filename)
        affected_users.add(user_name)

    if restored_to_indexing:
        logger.warning(
            "[RECOVERY] %d file(s) had OCR already cached from before the restart — "
            "skipping straight to indexing (no OCR rework): %s",
            len(restored_to_indexing), ", ".join(restored_to_indexing),
        )
    if requeued_for_ocr:
        logger.warning(
            "[RECOVERY] %d file(s) at 'indexing' had NO cache entry — requeued as 'pending' "
            "(OCR will be redone): %s",
            len(requeued_for_ocr), ", ".join(requeued_for_ocr),
        )

    stuck_enriching = shared_db.get_jobs_at_status("enriching")
    for job in stuck_enriching:
        shared_db.reset_job_status(
            job["filename"], job["user_name"], "enriching",
            reason="restored after restart — OCR already done, retrying image description",
        )
    if stuck_enriching:
        logger.warning(
            "[RECOVERY] %d file(s) were mid image-description from a previous run "
            "(OCR already done, endpoint already free) — retrying image description "
            "only: %s",
            len(stuck_enriching),
            ", ".join(j["filename"] for j in stuck_enriching),
        )

    pool = _EndpointPool(config.MINERU_API_URLS)

    threading.Thread(target=_watchdog_loop, daemon=True, name="hang-watchdog").start()
    threading.Thread(target=_enrichment_loop, daemon=True, name="enrichment-loop").start()
    threading.Thread(target=_indexer_loop, daemon=True, name="indexer-loop").start()

    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=pool.size, thread_name_prefix="job-dispatch"
    )
    in_flight: set[tuple[str, str]] = set()
    in_flight_guard = threading.Lock()

    logger.info(
        "Worker started. MinerU endpoints=%s | Poll interval=%ds",
        ", ".join(config.MINERU_API_URLS), POLL_INTERVAL,
    )

    while True:
        _beat("dispatch-loop")

        # ── 1. fetch queue ──────────────────────────────────────────────────
        try:
            pending = shared_db.get_all_pending_jobs()
        except Exception as exc:
            logger.exception("Failed to fetch pending jobs: %s", exc)
            time.sleep(POLL_INTERVAL)
            continue

        # ── 2. dispatch one job per free mineru-api endpoint ────────────────
        for job in pending:
            key = (job["filename"], job["user_name"])
            with in_flight_guard:
                if key in in_flight:
                    continue
            endpoint_url = pool.acquire()
            if endpoint_url is None:
                break  # both endpoints busy — try again next poll

            with in_flight_guard:
                in_flight.add(key)

            def _run(job=job, endpoint_url=endpoint_url, key=key):
                try:
                    _handle_job(job, endpoint_url, pool)
                finally:
                    with in_flight_guard:
                        in_flight.discard(key)

            executor.submit(_run)

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    run_worker()
