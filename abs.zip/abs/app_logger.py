import logging
from logging.handlers import RotatingFileHandler

LOG_FILE = "procurement_logs.log"

# ══════════════════════════════════════════════════════════
#  LOGGER SETUP
# ══════════════════════════════════════════════════════════
_logger = logging.getLogger("procurement_app")
_logger.setLevel(logging.INFO)

# Avoid adding duplicate handlers on Streamlit reruns
if not _logger.handlers:
    handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=5 * 1024 * 1024,  # 5 MB max per log file
        backupCount=3,              # keeps last 3 rotated files
        encoding="utf-8",
    )
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    _logger.addHandler(handler)


# ══════════════════════════════════════════════════════════
#  PUBLIC FUNCTIONS
# ══════════════════════════════════════════════════════════
def log_login(username: str, ip: str):
    """Log when a user successfully logs in."""
    _logger.info(f"LOGIN      | user={username} | ip={ip}")


def log_logout(username: str):
    """Log when a user logs out."""
    _logger.info(f"LOGOUT     | user={username}")


def log_justification(username: str, item_name: str):
    """Log when a justification is successfully generated."""
    _logger.info(f"JUSTIFICATION GENERATED | user={username} | item={item_name}")




config={
    "height": 300,
    "language": "en",
    "buttons": [
        "bold", "italic", "underline", "strikethrough", "|",
        "ul", "ol", "|",
        "font", "fontsize", "|",
        "left", "center", "right", "justify", "|",
        "table", "|",
        "undo", "redo"
    ],
}


config.toml
[theme]
base = "light"
st.markdown("Any Committee Recommendation? <span style='color:red'>*</span>", unsafe_allow_html=True)
st.radio(
    "Any Committee Recommendation?",
    ["Yes", "No"],
    key="f_any_committee_recommendation",
    label_visibility="collapsed",


st.markdown("Project/Directorate Name <span style='color:red'>*</span>", unsafe_allow_html=True)
st.text_input(
    "Project/Directorate Name",
    key="f_project_name",
    label_visibility="collapsed",
)
st.markdown("Technical Parameters Calculation <span style='color:red'>*</span>", unsafe_allow_html=True)