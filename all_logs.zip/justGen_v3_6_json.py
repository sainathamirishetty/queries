import io
import json
import sqlite3
import hashlib
import requests
import streamlit as st
from datetime import datetime
from docx import Document
import re
import logging

from streamlit_jodit import st_jodit

#login imports
from ldap3 import Server, Connection, ALL, SIMPLE, SUBTREE
from ldap3.core.exceptions import LDAPBindError,LDAPException

logger = logging.getLogger(__name__)

import app_logger

# ══════════════════════════════════════════════════════════
#  HTML (rich-text) -> JSON CLEANUP
#  The Jodit editor stores its content as HTML. Before printing
#  the form data or sending it to the LLM, convert those HTML
#  fields into structured JSON (tables become arrays of rows,
#  <br> becomes a newline). The raw HTML in st.session_state is
#  left untouched so saving/loading/editing keeps its formatting.
# ══════════════════════════════════════════════════════════
from bs4 import BeautifulSoup

# form_data keys that come from the Jodit rich-text editor
HTML_FIELDS = [
    "technical_parameters",
    "line_item_quantity",
    "proposed_distribution",
    "Addl. General Justification details",
]


def _table_to_rows(table):
    """Convert one HTML <table> into a list of row-lists."""
    rows = []
    for tr in table.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["th", "td"])]
        if cells:
            rows.append(cells)
    return rows


def html_field_to_json(html: str):
    """
    Convert a single HTML field into structured data.
    - No table  -> clean plain-text string.
    - Has table -> {"text": <leftover text>, "tables": [[[...]]]}.
    """
    if not html or not str(html).strip():
        return ""
    soup = BeautifulSoup(str(html), "html.parser")
    for br in soup.find_all("br"):          # <br> -> newline
        br.replace_with("\n")
    tables = soup.find_all("table")
    if not tables:                           # no table -> just clean text
        return soup.get_text("\n", strip=True)
    structured = []
    for t in tables:
        structured.append(_table_to_rows(t))
        t.decompose()                        # remove table so leftover text is separate
    return {"text": soup.get_text("\n", strip=True), "tables": structured}


def clean_form_data(form_data: dict) -> dict:
    """Return a COPY of form_data with HTML fields converted to JSON structure."""
    cleaned = dict(form_data)  # shallow copy — original stays intact
    for key in HTML_FIELDS:
        val = cleaned.get(key)
        if isinstance(val, str) and val.strip():
            cleaned[key] = html_field_to_json(val)
    return cleaned


def ad_auth(username: str, password: str, client_ip: str):
    """Return (True, display_name) on success, (False, error_msg) on failure."""
    domain = 'hastinapur'
    server_ip = '172.30.1.136'
    user_principal = f"{domain}\\{username}"
    ldap_server = f"ldap://{server_ip}"
    server = Server(ldap_server, get_info=ALL, use_ssl=False)

    try:
        conn = Connection(
            server,
            user=user_principal,
            password=password,
            authentication=SIMPLE,
            auto_bind="NO_TLS"
        )

        if not conn.bind():
            logger.warning(f"AD Auth Failed: {username} from {client_ip}")
            return False, "Invalid credentials"

        # Pull display name (CN) – optional but handy for UI
        search_base = f"DC={domain},DC=res"
        search_filter = f"(&(objectClass=user)(sAMAccountName={username}))"
        conn.search(
            search_base=search_base,
            search_filter=search_filter,
            search_scope=SUBTREE,
            attributes=['displayName']
        )
        if conn.entries:
            dn = conn.entries[0].entry_dn
            cn_match = re.search(r'CN=([^,]+)', dn)
            display_name = cn_match.group(1) if cn_match else username
            logger.info(f"AD Auth Success: {username} ({display_name}) from {client_ip}")
            return True, display_name

        # Fallback – user exists but no CN found
        logger.info(f"AD Auth Success: {username} from {client_ip}")
        return True, username

    except LDAPBindError as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {str(e)}")
        return False, "Invalid credentials"
    except LDAPException as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {str(e)}")
        return False, "Invalid credentials"
    except Exception as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {str(e)}")
        return False, "Invalid credentials"

# ══════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════
OLLAMA_URL = "http://172.27.30.222:12000/api/generate"
MODEL_NAME = "gpt-oss:20b"
DB_PATH    = "procurement.db"

# ══════════════════════════════════════════════════════════
#  PAGE CONFIG
# ══════════════════════════════════════════════════════════
st.set_page_config(page_title="Procurement Justification Generator", layout="wide")

# ══════════════════════════════════════════════════════════
#  COOKIE MANAGER
# ══════════════════════════════════════════════════════════
try:
    import extra_streamlit_components as stx

    @st.cache_resource
    def _get_cm():
        return stx.CookieManager()

    _cm        = _get_cm()
    COOKIES_OK = True
except Exception:
    _cm        = None
    COOKIES_OK = False


def _set_cookie(key, value):
    if COOKIES_OK:
        _cm.set(key, str(value))


def _get_cookie(key):
    if COOKIES_OK:
        return _cm.get(key)
    return None


def _del_cookie(key):
    if COOKIES_OK:
        try:
            _cm.delete(key)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════
#  DATABASE
# ══════════════════════════════════════════════════════════
def _conn():
    return sqlite3.connect(DB_PATH, check_same_thread=False)


def init_db():
    with _conn() as c:
        # ---- users table (kept for possible future use) ----
        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """)

        # ---- sessions table -------------------------------------------------
        # If you **do not** need per‑AD‑user isolation, drop the ad_username column.
        c.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER,                     -- 0 for AD users
                title         TEXT    NOT NULL,
                form_data     TEXT,
                conversation  TEXT,
                answers       TEXT,
                justification TEXT,
                created_at    TEXT DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')),
                ad_username   TEXT                         -- optional, can be NULL
            )
        """)
        c.commit()


def db_verify(username, password):
    pw = hashlib.sha256(password.encode()).hexdigest()
    with _conn() as c:
        row = c.execute(
            "SELECT id FROM users WHERE username=? AND password=?",
            (username, pw),
        ).fetchone()
    return row[0] if row else None


def db_get_sessions(user_id):
    with _conn() as c:
        if user_id == 0:   # AD login
            ad_user = st.session_state.username
            return c.execute(
                "SELECT id, title, created_at FROM sessions "
                "WHERE ad_username=? ORDER BY created_at DESC",
                (ad_user,),
            ).fetchall()
        else:
            return c.execute(
                "SELECT id, title, created_at FROM sessions "
                "WHERE user_id=? ORDER BY created_at DESC",
                (user_id,),
            ).fetchall()


def db_save_session(user_id, title, form_data, conversation, answers, justification):
    user_id = user_id or 0
    ad_user = st.session_state.username if user_id == 0 else None
    with _conn() as c:
        cur = c.execute(
            """
            INSERT INTO sessions
            (user_id, title, form_data, conversation, answers,
             justification, ad_username)
            VALUES (?,?,?,?,?,?,?)
            """,
            (
                user_id,
                title,
                json.dumps(form_data),
                json.dumps(conversation),
                json.dumps(answers),
                justification,
                ad_user,
            ),
        )
        c.commit()
        return cur.lastrowid
    
    
def db_update_session(session_id, form_data, conversation, answers, justification):
    with _conn() as c:
        c.execute(
            """
            UPDATE sessions
            SET form_data=?, conversation=?, answers=?, justification=?
            WHERE id=?
            """,
            (
                json.dumps(form_data),
                json.dumps(conversation),
                json.dumps(answers),
                justification,
                session_id,
            ),
        )
        c.commit()


def db_rename(session_id, new_title):
    with _conn() as c:
        c.execute(
            "UPDATE sessions SET title=? WHERE id=?", (new_title, session_id)
        )
        c.commit()


def db_delete(session_id):
    with _conn() as c:
        c.execute("DELETE FROM sessions WHERE id=?", (session_id,))
        c.commit()


def db_load(session_id):
    with _conn() as c:
        row = c.execute(
            "SELECT form_data, conversation, answers, justification "
            "FROM sessions WHERE id=?",
            (session_id,),
        ).fetchone()
    if not row:
        return None
    return {
        "form_data":     json.loads(row[0]) if row[0] else {},
        "conversation":  json.loads(row[1]) if row[1] else [],
        "answers":       json.loads(row[2]) if row[2] else {},
        "justification": row[3] or "",
    }


# ══════════════════════════════════════════════════════════
#  SESSION STATE DEFAULTS
# ══════════════════════════════════════════════════════════
_DEFAULTS = dict(
    logged_in=False, user_id=None, username=None,
    form_submitted=False, conversation=[], answers={},
    current_question=None, justification_generated=False,
    final_justification="", question_count=0,
    form_data={}, current_session_id=None,
    unsaved_work=False, sessions_list=[],
    # dialog flags
    show_save_dialog=False,
    rename_id=None, rename_title="",
    delete_id=None,
    update_id=None,
    pending_new_session=False,
)
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

init_db()



def collect_form_data():
    ss = st.session_state
    data = {
        #0.directorate name
        "project_name": ss.get("f_project_name", ""),
        # 1. Nature of Item
        "nature_of_item": ss.get("f_nature_of_item", ""),
        # 2. Item Nomenclature
        "item_nomenclature": ss.get("f_item_nomenclature", ""),
        # 3. Technical Parameters
        "technical_parameters": ss.get("f_technical_parameters", ""),
        # 4. Committee recommendation
        "any_committee_recommendation": ss.get("f_any_committee_recommendation", "No"),
        "doc_no": ss.get("f_doc_no", ""),
        "date": ss.get("f_date").strftime("%Y-%m-%d") if ss.get("f_date") else None,  # Convert to string
        "mom_committee_suggestions": ss.get("f_mom_committee_suggestions", ""),
        # 5. Fresh purchase
        "fresh_purchase": ss.get("f_fresh_purchase", "No"),
        "fresh_purchase_purpose_served": ss.get("f_fresh_purchase_purpose_served", ""),
        "fresh_purchase_reason": ss.get("f_fresh_purchase_reason", ""),
        "previous_supply_order_no": ss.get("f_previous_supply_order_no", ""),
        "previous_supply_order_date": ss.get("f_previous_supply_order_date").strftime("%Y-%m-%d") if ss.get("f_previous_supply_order_date") else None,  # Convert to string
        # 6. Sensitive items
        "are_items_sensitive": ss.get("f_are_items_sensitive", "No"),
        "sensitive_items_details": ss.get("f_sensitive_items_details", ""),
        # 7. SBC
        "sbc_applicable": ss.get("f_sbc_applicable", "No"),
        "sbc_doc_no": ss.get("f_sbc_doc_no", ""),
        "sbc_doc_date": ss.get("f_sbc_doc_date").strftime("%Y-%m-%d") if ss.get("f_sbc_doc_date") else None,  # Convert to string
        "sbc_reason": ss.get("f_sbc_reason", ""),
        #8 PAC
        "pac_applicable": ss.get("f_pac_applicable", "No"),
        "pac_doc_no": ss.get("f_pac_doc_no", ""),
        "pac_reason": ss.get("f_pac_reason", ""),
        "pac_doc_date": ss.get("f_pac_doc_date").strftime("%Y-%m-%d") if ss.get("f_pac_doc_date") else None,
        # 9. Quantity
        #"item_quantity": ss.get("f_item_quantity", 0),
        # 10. Base of quantity
        "line_item_quantity": ss.get("f_line_item_quantity", ""),
        # 11. Proposed distribution
        "proposed_distribution": ss.get("f_proposed_distribution", ""),
        # 12. Tender type
        "tender_type": ss.get("f_tender_type", ""),
        # — tdoc_no and tdoc_date now collected
        "tdoc_no": ss.get("f_tdoc_no", ""),
        "tdoc_date": ss.get("f_tdoc_date").strftime("%Y-%m-%d")
        if ss.get("f_tdoc_date") else None,
        "tender_type_reason": ss.get("f_tender_type_reason", ""),
        # 13. Tender mode
        "tender_mode": ss.get("f_tender_mode", ""),
        "tender_mode_reason": ss.get("f_tender_mode_reason", ""),
        # 14. Bid type
        "bid_type": ss.get("f_bid_type", ""),
        "bid_type_reason": ss.get("f_bid_type_reason", ""),
        # 15. Total demand value
        "total_demand_value": ss.get("f_total_demand_value", 0.0),
        #16 Addl Gen Justification
        "Addl. General Justification details": ss.get("f_Gen_justification")
        
    }
    
    # ── 2.  Remove fields that are not applicable ───────────────────────
    # Committee recommendation
    if data["any_committee_recommendation"] == "No":
        data.pop("doc_no", None)
        data.pop("date", None)
        data.pop("mom_committee_suggestions", None)
        data.pop("any_committee_recommendation", None)

    # SBC – only keep doc_no/doc_date/reason when applicable
    if data["sbc_applicable"] == "No":
        data.pop("sbc_doc_no", None)
        data.pop("sbc_doc_date", None)
        data.pop("sbc_reason", None)
        data.pop("sbc_applicable", None)

    # PAC – only keep doc_no/reason when applicable
    if data["pac_applicable"] == "No":
        data.pop("pac_doc_no", None)
        data.pop("pac_doc_date", None)
        data.pop("pac_reason", None)
        data.pop("pac_applicable", None)

    # Tender type – if GeM, drop the tender‑type specific fields
    if data["tender_type"] == "GeM":
        data.pop("tdoc_no", None)
        data.pop("tdoc_date", None)
        data.pop("tender_type_reason", None)
        data.pop("tender_type", None)

    # Tender mode – if Open, drop the mode‑reason field
    if data["tender_mode"] == "Open":
        data.pop("tender_mode_reason", None)
        data.pop("tender_mode", None)

    # Bid type – if Two, drop the bid‑type reason field
    if data["bid_type"] == "Two":
        data.pop("bid_type_reason", None)
        data.pop("bid_type", None)

    return data

def populate_form_fields(form_data):
    ss = st.session_state
    # 0.directorate name
    ss["f_project_name"] = form_data.get("project_name", "")
    # 1. Nature of Item
    ss["f_nature_of_item"] = form_data.get("nature_of_item", "")

    # 2. Item Nomenclature
    ss["f_item_nomenclature"] = form_data.get("item_nomenclature", "")

    # 3. Technical Parameters
    ss["f_technical_parameters"] = form_data.get("technical_parameters", "")

    # 4. Committee recommendation
    ss["f_any_committee_recommendation"] = form_data.get("any_committee_recommendation", "No")
    ss["f_doc_no"] = form_data.get("doc_no", "")
    # Handle date conversion - if it's a string, convert back to datetime
    date_val = form_data.get("date")
    ss["f_date"] = datetime.strptime(date_val, "%Y-%m-%d") if isinstance(date_val, str) and date_val else None
    ss["f_mom_committee_suggestions"] = form_data.get("mom_committee_suggestions", "")


    # 5. Fresh purchase
    ss["f_fresh_purchase"] = form_data.get("fresh_purchase", "No")
    ss["f_fresh_purchase_purpose_served"] = form_data.get("fresh_purchase_purpose_served", "")
    ss["f_fresh_purchase_reason"] = form_data.get("fresh_purchase_reason", "")
    ss["f_previous_supply_order_no"] = form_data.get("previous_supply_order_no", "")
    # Handle previous supply order date conversion
    prev_date_val = form_data.get("previous_supply_order_date")
    ss["f_previous_supply_order_date"] = datetime.strptime(prev_date_val, "%Y-%m-%d") if isinstance(prev_date_val, str) and prev_date_val else None

    # 6. Sensitive items
    ss["f_are_items_sensitive"] = form_data.get("are_items_sensitive", "No")
    ss["f_sensitive_items_details"] = form_data.get("sensitive_items_details", "")

    # 7. SBC
    ss["f_sbc_applicable"] = form_data.get("sbc_applicable", "No")
    ss["f_sbc_doc_no"] = form_data.get("sbc_doc_no", "")
    # Handle SBC doc date conversion
    sbc_date_val = form_data.get("sbc_doc_date")
    ss["f_sbc_doc_date"] = datetime.strptime(sbc_date_val, "%Y-%m-%d") if isinstance(sbc_date_val, str) and sbc_date_val else None
    ss["f_sbc_reason"] = form_data.get("sbc_reason", "")

    #8.PAC
    ss["f_pac_applicable"] = form_data.get("pac_applicable", "No")
    ss["f_pac_doc_no"] = form_data.get("pac_doc_no", "")
    ss["f_pac_reason"] = form_data.get("pac_reason", "")
    pac_date = form_data.get("pac_doc_date")
    ss["f_pac_doc_date"] = datetime.strptime(pac_date, "%Y-%m-%d") if pac_date else None

    # 9. Quantity
    #ss["f_item_quantity"] = form_data.get("item_quantity", 0)

    # 10. Base of quantity
    ss["f_line_item_quantity"] = form_data.get("line_item_quantity", "")

    # 11. Proposed distribution
    ss["f_proposed_distribution"] = form_data.get("proposed_distribution", "")

    # 12. Tender type
    ss["f_tender_type"] = form_data.get("tender_type", "")
    ss["f_tdoc_no"] = form_data.get("tdoc_no", "")
    tdoc_date_val = form_data.get("tdoc_date")
    ss["f_tdoc_date"] = (
        datetime.strptime(tdoc_date_val, "%Y-%m-%d") if tdoc_date_val else None
    )
    ss["f_tender_type_reason"] = form_data.get("tender_type_reason", "")

    # 13. Tender mode
    ss["f_tender_mode"] = form_data.get("tender_mode", "")
    ss["f_tender_mode_reason"] = form_data.get("tender_mode_reason", "")

    # 14. Bid type
    ss["f_bid_type"] = form_data.get("bid_type", "")
    ss["f_bid_type_reason"] = form_data.get("bid_type_reason", "")

    # 15. Total demand value
    ss["f_total_demand_value"] = form_data.get("total_demand_value", 0.0)

    #16. Addl. General Justification
    ss["f_Gen_justification"] = form_data.get("Addl. General Justification details", "")


# ══════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════
def refresh_sessions():
    """
    Load the list of sessions for the current user.
    AD users (user_id is None) use the sentinel 0.
    """
    uid = st.session_state.user_id or 0
    st.session_state.sessions_list = db_get_sessions(uid)


def reset_work():
    """Clear active-work state and wipe all form field keys."""
    st.session_state.update(
        form_submitted=False, conversation=[], answers={},
        current_question=None, justification_generated=False,
        final_justification="", question_count=0,
        form_data={}, current_session_id=None, unsaved_work=False,
    )
    populate_form_fields({})   # blank out all fields


def group_by_date(sessions):
    grouped = {}
    for sid, title, created_at in sessions:
        dt  = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
        key = dt.strftime("%d %b %Y")
        grouped.setdefault(key, []).append((sid, title, dt.strftime("%H:%M")))
    return grouped


def has_active_work():
    """True if user has filled any field OR started a conversation."""
    any_field = any(
        bool(st.session_state.get(k, ""))
        for k in ("f_initiator_name", "f_item_nomenclature", "f_nature_of_item")
    )
    return any_field or bool(st.session_state.form_data) or bool(st.session_state.conversation)


# ══════════════════════════════════════════════════════════
#  OLLAMA
# ══════════════════════════════════════════════════════════
def call_ollama(prompt: str) -> str:
    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "stream": False,
        "temperature": 0.05
    }

    try:
        r = requests.post(OLLAMA_URL, json=payload, timeout=120)
        #st.write(f"DEBUG: Ollama status={r.status_code}")
        #st.write(f"DEBUG: Ollama body={r.text[:200]}…")   # first 200 chars
    except Exception as exc:
        st.write(f"DEBUG: request failed: {exc}")
        return ""

    if r.status_code != 200:
        st.write(f"DEBUG: non‑200 status: {r.status_code} {r.text}")
        return ""

    try:
        data = r.json()
    except json.JSONDecodeError:
        st.write("DEBUG: JSON decode error")
        return r.text.strip()

    if "response" in data:
        return data["response"]
    if "error" in data:
        err = data["error"]
        if "raw='" in err:
            start = err.find("raw='") + len("raw='")
            end = err.find("'", start)
            return err[start:end]
        return err
    return str(data)



# ══════════════════════════════════════════════════════════
#  PROMPTS
# ══════════════════════════════════════════════════════════
def build_question_prompt(form_data, conversation, answers):
    return f"""
    You are an enterprise procurement assistant and you have technical knowledge on the given product too.
    Your goal is to collect enough information regarding the product to generate a detailed procurement justification note.

Rules:
1. Ask only ONE simple question at a time.
2. Questions must dynamically depend on previous answers.
3. Ask questions only regarding (reframe naturally based on context):
    - Any additional information you want to provide?
    - Why were these specific technical specs needed and how did the user arrive at these.
4. Do not ask duplicate or repeated questions. Only ONE question (not your thinking).
5. Ask at most 3 questions then respond ONLY with: JUSTIFICATION_COMPLETE

    FORM DATA:
    {json.dumps(form_data, indent=2)}

    ANSWERS:
    {json.dumps(answers, indent=2)}

    CONVERSATION:
    {conversation}
    """

def build_justification_prompt(form_data, answers):

    style_block = """
    Write the justification in a **neutral, objective tone**.
    - Use third‑person only; avoid “we”, “I”, or any first‑person references.
    - Do not use promotional adjectives (e.g., “excellent”, “state‑of‑the‑art”).
    - Do not add commentary that is not present in the supplied data.
    - Follow the three‑paragraph structure required by the procurement template.

    Do:
    - State facts exactly as given.
    - Use passive voice only when it improves clarity.
    - Write numbers in digits (e.g., 66.6 kVA).

    Don’t:
    - Insert opinions, recommendations, or justifications not in the data.
    - Use emotive words (e.g., “critical”, “urgent”, “important”).
    - Add headings, bullet points, or extra line breaks.
    """

    # Optional one‑shot example (kept generic)

    prompt = f"""
    {style_block}
    You are an enterprise procurement assistant specialized in drafting official
    justification notes for government and public‑sector purchases.

    Using **only** the information provided in the sections **FORM DATA** and
    **QUESTION ANSWERS**, produce a **single, continuous justification note** that
    consists of **exactly three paragraphs**:

    1. **Technical Justification** – Explain how the need for the product(s) arose,
       referencing relevant project details, operational requirements, or regulatory
       drivers found in the form data and answers.

    2. **Quantity & Distribution Justification** – Detail the required quantity,
       any proposed allocation across departments or locations, and why this amount
       is appropriate given the stated need.

    3. **Tender Type, Tender Mode & Bid Type Explanation** – Detail the reasons why the specific tender, bid 
        and mode were selected. **GENERATE THIS PARAGRAPH ONLY IF THE DETAILS ARE PROVIDED**. 

    **Formatting Rules**
    - Produce three plain paragraphs with no headings, bullet points, or numbered
      lists.
    - Use simple sentences.
    - Use formal, corporate language appropriate for official documentation.
    - Keep the text continuous; do not insert line breaks within a paragraph
      except for the paragraph separation.
    - Don't refer to the form in the text.
    - Generate tables wherever necessary.
    - Generate the content in 300 words.
    - Always provide the content that is talked about (Basically the justification must be self contained).
    - **ELABORATE THE TEXT**

    **Input Sections**

    FORM DATA:
    {json.dumps(form_data, indent=2)}

    QUESTION ANSWERS:
    {json.dumps(answers, indent=2)}
    """
    return prompt


# ══════════════════════════════════════════════════════════
#  DOCX  (fixed — uses params, returns in-memory buffer)
# ══════════════════════════════════════════════════════════
def generate_docx(item_name, justification_text):
    doc = Document()
    doc.add_heading("Procurement Justification Note", level=1)
    
    doc.add_paragraph(f"Item: {item_name}")
    doc.add_paragraph(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    for para in justification_text.split("\n\n"):
        para = para.strip()
        if para:
            doc.add_paragraph(para)
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf


# ══════════════════════════════════════════════════════════
#  DIALOGS
# ══════════════════════════════════════════════════════════
@st.dialog(" Save Session")
def save_dialog():
    title = st.text_input(
        "Enter a title for this session",
        placeholder="",
    )
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Save", use_container_width=True):
            if title.strip():
                # Always collect freshest form state before saving
                current_fd = collect_form_data()
                st.session_state.form_data = current_fd
                sid = db_save_session(
                    st.session_state.user_id,
                    title.strip(),
                    current_fd,
                    st.session_state.conversation,
                    st.session_state.answers,
                    st.session_state.final_justification,
                )
                st.session_state.current_session_id = sid
                st.session_state.unsaved_work       = False
                st.session_state.show_save_dialog   = False
                refresh_sessions()
                st.rerun()
            else:
                st.warning("Please enter a title.")
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.show_save_dialog = False
            st.rerun()


@st.dialog(" Rename Session")
def rename_dialog():
    new = st.text_input("Session title", value=st.session_state.rename_title)
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Update", use_container_width=True):
            if new.strip():
                db_rename(st.session_state.rename_id, new.strip())
                st.session_state.rename_id    = None
                st.session_state.rename_title = ""
                refresh_sessions()
                st.rerun()
            else:
                st.warning("Title cannot be empty.")
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.rename_id = None
            st.rerun()


@st.dialog(" Delete Session")
def delete_dialog():
    st.warning("Are you sure you want to delete this session? This cannot be undone.")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Yes, Delete", use_container_width=True):
            sid = st.session_state.delete_id
            if st.session_state.current_session_id == sid:
                reset_work()
            db_delete(sid)
            st.session_state.delete_id = None
            refresh_sessions()
            st.rerun()
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.delete_id = None
            st.rerun()


@st.dialog(" Update Session")
def update_dialog():
    st.info("This will overwrite the saved session with your current form data. Are you sure?")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Yes, Update", use_container_width=True):
            current_fd = collect_form_data()
            st.session_state.form_data = current_fd
            db_update_session(
                st.session_state.update_id,
                current_fd,
                st.session_state.conversation,
                st.session_state.answers,
                st.session_state.final_justification,
            )
            st.session_state.unsaved_work = False
            st.session_state.update_id   = None
            refresh_sessions()
            st.rerun()
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.update_id = None
            st.rerun()


@st.dialog(" ")
def unsaved_dialog():
    st.warning("You have unsaved work. What would you like to do?")
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button(" Save", use_container_width=True):
            st.session_state.pending_new_session = False
            st.session_state.show_save_dialog    = True
            st.rerun()
    with c2:
        if st.button("Continue to create New session", use_container_width=True):
            st.session_state.pending_new_session = False
            reset_work()
            st.rerun()
    with c3:
        if st.button("Cancel", use_container_width=True):
            st.session_state.pending_new_session = False
            st.rerun()


# ══════════════════════════════════════════════════════════
#  SIDEBAR
# ══════════════════════════════════════════════════════════
def show_sidebar():
    with st.sidebar:

        st.markdown(f"###  Welcome, **{st.session_state.username}**")
        st.divider()

        # New Session | Logout
        c1, c2 = st.columns(2)
        with c1:
            if st.button("➕ New Session", use_container_width=True):
                if has_active_work():
                    st.session_state.pending_new_session = True
                else:
                    reset_work()
                st.rerun()
        with c2:
            if st.button(" Logout", use_container_width=True):
                app_logger.log_logout(st.session_state.username)
                _del_cookie("username")
                _del_cookie("user_id")
                for k in list(st.session_state.keys()):
                    del st.session_state[k]
                st.rerun()

        # Save — always visible when any work exists
        if has_active_work():
            if st.button(" Save", use_container_width=True):
                st.session_state.show_save_dialog = True
                st.rerun()

        st.divider()

        # Chat history
        if not st.session_state.sessions_list:
            st.caption("No saved sessions yet.")
        else:
            grouped = group_by_date(st.session_state.sessions_list)
            for date_str, items in grouped.items():
                st.markdown(f"**{date_str}**")
                for sid, title, time_str in items:
                    is_active     = (sid == st.session_state.current_session_id)
                    col_t, col_m  = st.columns([5, 1])
                    with col_t:
                        if st.button(
                            f"{time_str} - {title}",
                            key=f"sess_{sid}",
                            use_container_width=True,
                            type="primary" if is_active else "secondary",
                        ):
                            data = db_load(sid)
                            if data:
                                populate_form_fields(data["form_data"])
                                st.session_state.form_data               = data["form_data"]
                                st.session_state.conversation            = data["conversation"]
                                st.session_state.answers                 = data["answers"]
                                st.session_state.final_justification     = data["justification"]
                                st.session_state.justification_generated = bool(data["justification"])
                                #st.session_state.form_submitted          = False
                                st.session_state.form_submitted = (
                                        bool(data["conversation"]) or bool(data["justification"])
                                )
                                st.session_state.current_session_id = sid
                                st.session_state.unsaved_work        = False
                            st.rerun()
                    with col_m:
                        with st.popover("⋮"):
                            if st.button(
                                " Update",
                                key=f"upd_{sid}",
                                use_container_width=True,
                                disabled=not is_active,  # only active session can be updated
                            ):
                                st.session_state.update_id = sid
                                st.rerun()
                            if st.button(" Rename", key=f"ren_{sid}", use_container_width=True):
                                st.session_state.rename_id    = sid
                                st.session_state.rename_title = title
                                st.rerun()
                            if st.button(" Delete", key=f"del_{sid}", use_container_width=True):
                                st.session_state.delete_id = sid
                                st.rerun()


# ══════════════════════════════════════════════════════════
#  LOGIN PAGE
# ══════════════════════════════════════════════════════════
def show_login():
    st.markdown(
        "<h1 style='text-align: center;'>Login with RCNET/PIS Details</h1>",
        unsafe_allow_html=True
    )
    _, col, _ = st.columns([1, 1, 1])
    with col:
        st.subheader("Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login", use_container_width=True):
            client_ip = st.session_state.get("client_ip") or "unknown"
            success, info = ad_auth(username, password, client_ip)

            if success:
                # Store a *virtual* user record in the session (no DB row needed)
                st.session_state.logged_in = True
                st.session_state.username  = info          # display name or username
                st.session_state.user_id   = None          # AD users have no local ID
                _set_cookie("username", info)
                _set_cookie("user_id", "ad")               # marker that we used AD
                app_logger.log_login(info, client_ip)
                refresh_sessions()                         # loads any saved sessions
                st.rerun()
            else:
                st.error(info)   # `info` contains the error message



# -------------------------------------------------------------
#  MAIN APP
# -------------------------------------------------------------
def show_main_app():
    st.markdown(
        "<h1 style='text-align:center;'>AI BASED PROCUREMENT JUSTIFICATION GENERATOR</h1>",
        unsafe_allow_html=True,
        )


    # ── PHASE 1 : NEW FORM (single page, no expanders) ──
    if not st.session_state.form_submitted:
        # 1.  Project/Directorate Name – top of the form
        st.markdown("Project/Directorate Name <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.text_input(
            "Project/Directorate Name",
            key="f_project_name",
            label_visibility="collapsed",
        )
        # 2. Nature of Item (dropdown)
        col1, col2 = st.columns([1,2])
        with col1:
            st.markdown("Nature of Item(same as entered in IMMS) <span style='color:red'>*</span>", unsafe_allow_html=True)
            st.selectbox(
                "Nature of Item",
                [
                    "ACCESSORIES",
                    "AMMUNITION",
                    "ARBORICULTURE (special services)",
                    "BUILDUP ITEMS",
                    "CAPITAL",
                    "CONSERVANCY (SPECIAL SERVICES)",
                    "CONSUMABLES",
                    "COTS",
                    "DEVELOPMENT",
                    "EQUIPMENTS",
                    "EXPLOSIVE",
                    "FABRICATION",
                    "FIREFIGHTING (SPECIAL SERVICES)",
                    "HARDWARE",
                    "HYGIENE AND MAINTEINANCE (special services)",
                    "IT HARDWARE",
                    "IT SOFTWARE",
                    "MISCELLANEOUS",
                    "RAW MATERIAL",
                    "REPLACEMENT (Repair/Maintenance Contracts)",
                    "SECURITY SERVICES DGR (Special services)",
                    "SERVICES",
                    "SPACES",
                    "SUPPORT SERVICES TO DSC (special services)",
                    "TRANSPORTATION",
                    "WET CANTEEN SERVICES (special services)",
                    "Others"
                ],
                key="f_nature_of_item",
                label_visibility="collapsed",
            )

        with col2:
            # 2. Item Nomenclature (input box)
            st.markdown("Item Nomenclature <span style='color:red'>*</span>", unsafe_allow_html=True)
            st.text_input("Item Nomenclature", key="f_item_nomenclature",label_visibility="collapsed")

        # 4. Technical Parameters Calculation (rich text)
        st.markdown("Technical Parameters Calculation")
        _tech_val = st_jodit(
            value=st.session_state.get("f_technical_parameters", ""),
            key="jodit_technical_parameters",
            config={
                "height": 300,
                "language": "en",
                "removeButtons": ["mic", "print", "image", "video", "file","spellcheck","link","Open in fullsize"],
            },
        )
        if _tech_val is not None:
            st.session_state["f_technical_parameters"] = _tech_val

        # 5. Any Committee Recommendation (radio + conditional fields)
        st.markdown("Any Committe Recommendation? <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.radio(
            "Any Committee Recommendation?",
            ["Yes", "No"],
            key="f_any_committee_recommendation",
            label_visibility="collapsed",
        )
        doc_no_disabled      = st.session_state.f_any_committee_recommendation == "No"
        doc_date_disabled    = st.session_state.f_any_committee_recommendation == "No"
        mom_suggestions_disabled = st.session_state.f_any_committee_recommendation == "No" 
        
        col_docno, col_docdate = st.columns([2, 1])
        with col_docno:
            st.text_input("Document No", key="f_doc_no",disabled=doc_no_disabled,)
        with col_docdate:
            st.date_input("Document Date", key="f_date",disabled=doc_date_disabled,)

        st.text_area(
            "MOM Committee Suggestions *",
            height=80,key="f_mom_committee_suggestions",
            disabled=mom_suggestions_disabled,
        )


        # 6. Fresh Purchase (radio + conditional fields)
        st.markdown("Fresh Purchase? <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.radio(
            "Fresh Purchase?",
            ["Yes", "No"],
            key="f_fresh_purchase",label_visibility="collapsed",
        )
        disable_prev_supply = st.session_state.f_fresh_purchase == "Yes"
        
        if st.session_state.f_fresh_purchase == "Yes":
            st.markdown("How was the purpose served till now? <span style='color:red'>*</span>", unsafe_allow_html=True)
            st.text_area(
                "How was the purpose served till now?",
                height=80,
                key="f_fresh_purchase_purpose_served",label_visibility="collapsed",
            )
        else:
            st.markdown("Why upgradation of existing is not enough? <span style='color:red'>*</span>", unsafe_allow_html=True)
            st.text_area(
                "Why upgradation of existing is not enough?",
                height=80,
                key="f_fresh_purchase_reason",label_visibility="collapsed",
            )
        col_order_no, col_order_date = st.columns([2, 1])
        
        with col_order_no:
            st.text_input(
                "Previous Supply Order No",
                key="f_previous_supply_order_no",disabled=disable_prev_supply,
            )

        with col_order_date:
            st.date_input(
                "Previous Supply Order Date",
                key="f_previous_supply_order_date",disabled=disable_prev_supply,
            )

        # 7. Are Items Sensitive in Nature (radio + conditional field)
        st.markdown("Are Items Sensitive in Nature? <span style='color:red'>*</span>", unsafe_allow_html=True)
        choice= st.radio(
            "Are Items Sensitive in Nature?",
            ["Yes", "No"],
            key="f_are_items_sensitive",index=0,label_visibility="collapsed",
        )
        disabled = st.session_state.f_are_items_sensitive == "No"
        #st.markdown("Explain how and if FIM will be issued? <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.text_area(
            "Explain how and if FIM will be issued? *",
            height=80,
            key="f_sensitive_items_details",
            disabled=disabled,
        )
        

        # 8. SBC (radio + conditional fields + reason)
        st.markdown("Is SBC(Specific Brand Certificate) applicable? <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.radio(
            "Is SBC (Specific Brand Ceritificate) applicable? *",
            ["Yes", "No"],
            key="f_sbc_applicable",label_visibility="collapsed",
        )
        disabled = st.session_state.f_sbc_applicable == "No"
        
        col_docno, col_docdate = st.columns([2, 1])
            
        with col_docno:
            st.text_input("SBC Doc No", key="f_sbc_doc_no",disabled=disabled,)
            st.text_input("SBC Reason *", key="f_sbc_reason",disabled=disabled,)
        
        with col_docdate:
            st.date_input("SBC Doc Date", key="f_sbc_doc_date",disabled=disabled,)

        # 9.PAC – bottom of the form (after Total Demand Value)
        st.markdown("Is PAC(Proprietory Article Certificate) Applicable? <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.radio(
            "Is PAC(Proprietory Article Certificate) Applicable? ",
            ["Yes", "No"],
            key="f_pac_applicable",label_visibility="collapsed"
        )
        pac_disabled = st.session_state.f_pac_applicable == "No"

        col_pac_docno, col_pac_docdate = st.columns([2, 1])
        with col_pac_docno:
            st.text_input(
                "PAC Doc No",
                key="f_pac_doc_no",
                disabled=pac_disabled,
            )
            st.text_input(
                "PAC Reason *",
                key="f_pac_reason",
                disabled=pac_disabled,
            )
        with col_pac_docdate:
            st.date_input(
                "PAC Doc Date",
                key="f_pac_doc_date",
                disabled=pac_disabled,
            )

        # 10.Line item Quantity (text input)
        #st.text_area("Line item Quantity & Justification",height=120, key="f_line_item_quantity")
        st.markdown("Line item Quantity & Justification")
        _tech_val = st_jodit(
            value=st.session_state.get("f_line_item_quantity", ""),
            key="jodit_line_item_quantity",
            config={
                "height": 300,
                "language": "en",
                "removeButtons": ["mic", "print", "image", "video", "file","spellcheck","link","Open in fullsize"],
            },
        )
        if _tech_val is not None:
            st.session_state["f_line_item_quantity"] = _tech_val

        # 11. Proposed Distribution of Items (long text)
        st.markdown("Proposed Distribution of Items")
        _tech_val = st_jodit(
            value=st.session_state.get("f_proposed_distribution", ""),
            key="jodit_proposed_distribution",
            config={
                "height": 300,
                "language": "en",
                "removeButtons": ["mic", "print", "image", "video", "file","spellcheck","link","Open in fullsize"],
            },
        )
        if _tech_val is not None:
            st.session_state["f_proposed_distribution"] = _tech_val

        #12. tendertype# Clear hidden fields when the user switches back to GeM
        if st.session_state.get("f_tender_type") == "GeM":
            st.session_state.f_tdoc_no = ""
            st.session_state.f_tdoc_date = None
            st.session_state.f_tender_type_reason = ""

        # Now create the widgets
        st.markdown("Tender Type <span style='color:red'>*</span>",
            unsafe_allow_html=True)
        st.selectbox(
            "Tender Type *",
            [
                "GeM",
                "Annual Maint. Cont",
                "Cash Purchase Scientific Equipment",
                "CARS for Research Services",
                "Cash Purchase",
                "Development Contract",
                "Fabrication Order",
                "Imports",
                "CAPSI",
                "Rate Contracts",
                "Supply Order",
            ],
            key="f_tender_type",label_visibility="collapsed"
        )

        # Conditional block – only when the type is NOT GeM
        disabled = st.session_state.f_tender_type == "GeM"
        
        col_docno, col_docdate = st.columns([2, 1])

        with col_docno:
            st.text_input("Document No", key="f_tdoc_no",disabled=disabled,)
            st.text_area(
                "Tender Type Reason *",
                height=120,
                key="f_tender_type_reason",disabled=disabled
            )

        with col_docdate:
            st.date_input("Document Date", key="f_tdoc_date",disabled=disabled,)

            

        # 13. Tender Mode (radio + reason)
        st.markdown("Tender Mode <span style='color:red'>*</span>",
            unsafe_allow_html=True)
        st.radio(
            "Tender Mode *",
            ["Single", "Limited", "Open"],
            key="f_tender_mode",label_visibility="collapsed"
        )
        
        disabled = st.session_state.f_tender_mode == "Open"

        # 3️⃣  Show/hide the reason field based on the selected mode
        st.text_input(
            "Tender Mode Reason *",
            key="f_tender_mode_reason",
            disabled=disabled,          
        )
        

        # 14. Bid Type (radio + reason)
        st.markdown("Bid Type <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.radio(
            "Bid Type *",
            ["Single", "Two"],
            key="f_bid_type",label_visibility="collapsed"
        )
        disabled = st.session_state.f_bid_type == "Two"

        st.text_input(
            "Bid Type Reason *",
            key="f_bid_type_reason",
            disabled=disabled,
        )

        # 15. Total Demand Value (number input)
        st.markdown("Total Demand value (Rupees) <span style='color:red'>*</span>", unsafe_allow_html=True)
        st.number_input(
            "Total Demand Value (Rupees) *",
            min_value=0.0,
            step=1.0,
            key="f_total_demand_value",label_visibility="collapsed"
        )

        # 16.Addl. General Justification details 
        st.markdown("Addl. General Justification details")
        _tech_val = st_jodit(
            value=st.session_state.get("f_Gen_justification", ""),
            key="jodit_Gen_justification",
            config={
                "height": 300,
                "language": "en",
                "buttons": ["bold", "italic", "underline", "strikethrough", "|","ul", "ol", "|","font", "fontsize", "|",
                            "left", "center", "right", "justify", "|","table", "|",
                            "undo", "redo"],
            },
        )
        if _tech_val is not None:
            st.session_state["f_Gen_justification"] = _tech_val

        # ------------------------------------------------------------------
        #   1.Compute “disabled” flags for the conditional fields
        # ------------------------------------------------------------------
        def is_filled(key: str, disabled: bool) -> bool:
            """
            Return True if the field is either disabled or contains a value.
            """
            if disabled:
                return True

            val = st.session_state.get(key)

            # Strings – strip whitespace
            if isinstance(val, str):
                return bool(val.strip())

            # Numbers – treat 0 as “not filled” (change if 0 is valid)
            if isinstance(val, (int, float)):
                return val is not None and val != 0

            # Dates – just check for None
            if isinstance(val, datetime):
                return val is not None

            # Lists – non‑empty
            if isinstance(val, list):
                return len(val) > 0

            # Fallback
            return bool(val)


        # ------------------------------------------------------------------
        #    2.Flags that decide whether a field is enabled/disabled
        # ------------------------------------------------------------------
        # Committee recommendation
        #doc_optional = st.session_state.f_any_committee_recommendation == "No"

        # Fresh purchase
        disable_prev_supply = st.session_state.f_fresh_purchase == "Yes"
        disabled_fresh_purchase_purpose_served = st.session_state.f_fresh_purchase == "No"
        disabled_fresh_purchase_reason       = st.session_state.f_fresh_purchase == "Yes"
            
        # 12. Sensitive items details – required when “Yes”
        # (the flag name must match the one used in required_fields)
        disabled_sensitive_items_details = st.session_state.f_are_items_sensitive == "No"

        # SBC 
        disabled_sbc = st.session_state.f_sbc_applicable == "No"
        # PAC
        disabled_pac = st.session_state.f_pac_applicable == "No"

        # Tender type
        disabled_tdoc = st.session_state.f_tender_type == "GeM"

        # Tender mode
        disabled_tmode = st.session_state.f_tender_mode == "Open"

        # Bid type
        disabled_bid = st.session_state.f_bid_type == "Two"

        # ------------------------------------------------------------------
        #  3. List of all required fields 
        # ------------------------------------------------------------------
        required_fields = [
            # 1.  Project/Directorate Name – always required
            ("f_project_name", False),

            # 2.  Nature of Item – always required
            ("f_nature_of_item", False),

            # 3.  Item Nomenclature – always required
            ("f_item_nomenclature", False),

            # 4.  Technical Parameters Calculation – optional 

            # 5.  Committee recommendation – 
            ("f_any_committee_recommendation", False),

            # 5.1.  Doc No / Date – optional, enabled only when recommendation is “Yes”
            #("f_doc_no", doc_no_disabled),
            #("f_date", doc_date_disabled),

            # 5.2.  MOM Committee Suggestions – required when recommendation is “Yes”
            ("f_mom_committee_suggestions", mom_suggestions_disabled),

            # 6.  Fresh Purchase – the radio itself is required
            ("f_fresh_purchase", False),

            # 6.1.  How was the purpose served till now – required when Fresh Purchase = “Yes”
            ("f_fresh_purchase_purpose_served", disabled_fresh_purchase_purpose_served),

            # 6.2.  Why upgrade of existing is not enough – required when Fresh Purchase = “No”
            ("f_fresh_purchase_reason", disabled_fresh_purchase_reason),

            # 6.3. Previous Supply Order No / Date – **optional** (never required)
            ("f_previous_supply_order_no", True),
            ("f_previous_supply_order_date", True),

            # 7. Sensitive items – the radio itself is required
            ("f_are_items_sensitive", False),

            # 7.1. Sensitive items details – required when “Yes”
            ("f_sensitive_items_details", disabled_sensitive_items_details),

            # 8. SBC – the radio itself is required
            ("f_sbc_applicable", False),

            #  SBC Doc No / Date – optional, enabled only when SBC = “Yes”
            #("f_sbc_doc_no", disabled_sbc),
            ("f_sbc_reason", disabled_sbc),
            #("f_sbc_doc_date", disabled_sbc),

            # 9. PAC – the radio itself is required
            ("f_pac_applicable", False),

            #  PAC Doc No / Date – optional, enabled only when PAC = “Yes”
            #("f_pac_doc_no", disabled_pac),
            ("f_pac_reason", disabled_pac),
            #("f_pac_doc_date", disabled_pac),

            # 10. Line item quantity – 
            ("f_line_item_quantity", True),
                
            # 11. Proposed distribution – optional
            ("f_proposed_distribution", True),

            # 12. Tender type – the selectbox itself is required
            ("f_tender_type", False),

            # 12.1. Tender type Doc No / Date – optional, enabled only when not “GeM”
            #("f_tdoc_no", disabled_tdoc),
            #("f_tdoc_date", disabled_tdoc),
            ("f_tender_type_reason", disabled_tdoc),

            # 13. Tender mode – the radio itself is required
            ("f_tender_mode", False),

            # 13.1. Tender mode reason – required when mode is “Single” or “Limited”
            ("f_tender_mode_reason", disabled_tmode),

            # 14. Bid type – the radio itself is required
            ("f_bid_type", False),

            # 14.1 Bid type reason – required when bid type is “Single”
            ("f_bid_type_reason", disabled_bid),

            # 15. Total demand value – always required
            ("f_total_demand_value", False),

            # 16. General (Gen) justification – optional
            ("f_Gen_justification", True),
        ]

        # ------------------------------------------------------------------
        #   4.Is the form ready to be submitted?
        # ------------------------------------------------------------------
        all_filled = all(is_filled(key, disabled) for key, disabled in required_fields)

        # ------------------------------------------------------------------
        # 5. Start button – enabled only when all required fields are filled
        # ------------------------------------------------------------------
        st.caption(
            "<strong>NOTE: Please fill all mandatory fields * to start.</strong>",
            unsafe_allow_html=True,
        )
        st.write("")
        if st.button("Start", type="primary", disabled=not all_filled):
            form_data = collect_form_data()
            st.session_state.form_data = form_data
            st.session_state.form_submitted = True
            st.session_state.unsaved_work = True

            # ---- cleaned copy (HTML -> markdown) for printing + LLM ----
            clean_fd = clean_form_data(form_data)

            # ---- Print to terminal only ----
            print("=== filled data sent to LLM ===")
            print(json.dumps(clean_fd, indent=2, ensure_ascii=False))
            # --Continue with LLm call--
            with st.spinner("Thinking…"):
                first_q = call_ollama(build_question_prompt(clean_fd, [], {}))
                st.session_state.current_question = first_q
                st.session_state.form_submitted = True
                print("check1: first_q =", first_q)

                import time  # 0.5‑second delay before switching to chat
                time.sleep(0.5)
                st.rerun()

    # ── PHASE 2 : Chat ──
    else:
        for msg in st.session_state.conversation:
            with st.chat_message(msg["role"]):
                st.write(msg["content"])

        if st.session_state.justification_generated:
            st.subheader("Generated Justification")
            st.write(st.session_state.final_justification)

            buf = generate_docx(
                st.session_state.form_data.get("item_nomenclature", ""),
                st.session_state.final_justification,
            )
            fname = (
                f"{st.session_state.form_data.get('item_nomenclature','item').replace(' ', '_')}.docx"
            )
            st.download_button(
                "Download DOCX",
                data=buf,
                file_name=fname,
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            )

        else:
            with st.chat_message("assistant"):
                st.write(st.session_state.current_question)

            user_answer = st.chat_input("Enter your answer")

            if user_answer:
                st.session_state.conversation.append(
                    {"role": "assistant", "content": st.session_state.current_question}
                )
                st.session_state.conversation.append(
                    {"role": "user", "content": user_answer}
                )
                qkey = f"question_{st.session_state.question_count + 1}"
                st.session_state.answers[qkey] = {
                    "question": st.session_state.current_question,
                    "answer": user_answer,
                }
                st.session_state.question_count += 1
                st.session_state.unsaved_work = True

                with st.spinner("Thinking..."):
                    next_q = call_ollama(build_question_prompt(
                        clean_form_data(st.session_state.form_data),
                        st.session_state.conversation,
                        st.session_state.answers,
                    ))

                if "JUSTIFICATION_COMPLETE" in next_q:
                    with st.spinner("Generating justification..."):
                        final = call_ollama(build_justification_prompt(
                            clean_form_data(st.session_state.form_data),
                            st.session_state.answers,
                        ))
                    st.session_state.final_justification = final
                    st.session_state.justification_generated = True
                    st.session_state.unsaved_work = True
                    app_logger.log_justification(
                        st.session_state.username,
                        st.session_state.form_data.get("item_nomenclature", "unknown"),
                    )
                else:
                    st.session_state.current_question = next_q

                st.rerun()


# ══════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════

# Restore login from cookie
if not st.session_state.logged_in and COOKIES_OK:
    _u = _get_cookie("username")
    _i = _get_cookie("user_id")
    if _u and _i:
        st.session_state.logged_in = True
        st.session_state.username  = _u
        st.session_state.user_id = int(_i) if _i.isdigit() else None
        refresh_sessions()

if not st.session_state.logged_in:
    show_login()

else:
    show_sidebar()
    show_main_app()

    # Modal dialogs — rendered as overlays on top of the page
    if st.session_state.show_save_dialog:
        save_dialog()

    if st.session_state.rename_id is not None:
        rename_dialog()

    if st.session_state.delete_id is not None:
        delete_dialog()

    if st.session_state.pending_new_session:
        unsaved_dialog()
