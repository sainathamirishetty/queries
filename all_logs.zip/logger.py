#!/usr/bin/env python3
"""
logger.py – Same public API as before, but every calendar day gets its OWN
dated log file from the very first write:

    logs/system_2026-08-05.log
    logs/activity_2026-08-05.log

When the date changes, a new dated file is created automatically (even while
the process keeps running) and old files are never deleted.
"""

import os
import logging
from datetime import datetime
from pathlib import Path

from config import LOG_DIR as _LOG_DIR_STR

LOG_DIR = Path(_LOG_DIR_STR)
LOG_DIR.mkdir(exist_ok=True)

_DATE_FMT = "%Y-%m-%d %H:%M:%S"
_SYSTEM_FMT = "[%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s"


# ── daily-rotating file handler ───────────────────────────────────────────────

class DailyFileHandler(logging.FileHandler):
    """
    Writes to a date-stamped file like  <prefix>_2026-08-05.log
    and switches to a new file automatically when the calendar day changes.
    Previous days' files are kept (never deleted).

    Unlike TimedRotatingFileHandler, the *current* day's file is dated too —
    there is no undated base file that only gets renamed at midnight.
    """

    def __init__(self, log_dir, prefix: str,
                 date_fmt: str = "%Y-%m-%d", encoding: str = "utf-8"):
        self._log_dir  = Path(log_dir)
        self._prefix   = prefix
        self._date_fmt = date_fmt
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._current_date = datetime.now().strftime(date_fmt)
        # delay=False → file is opened immediately so it exists from the start
        super().__init__(self._build_path(), encoding=encoding, delay=False)

    def _build_path(self) -> str:
        return str(self._log_dir / f"{self._prefix}_{self._current_date}.log")

    def emit(self, record):
        # emit() runs under the handler lock, so this day-check is thread-safe.
        today = datetime.now().strftime(self._date_fmt)
        if today != self._current_date:
            self._current_date = today
            if self.stream:
                self.stream.close()
                self.stream = None
            self.baseFilename = os.path.abspath(self._build_path())
            self.stream = self._open()
        super().emit(record)


# ── system logger ─────────────────────────────────────────────────────────────

def get_logger(name: str) -> logging.Logger:
    logger_name = f"system.{name}"
    logger = logging.getLogger(logger_name)

    # Handler already configured -> reuse
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Console handler – unchanged
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(
        logging.Formatter("[%(asctime)s] [%(levelname)-8s] %(message)s", datefmt=_DATE_FMT)
    )
    logger.addHandler(console)

    # File handler – one dated file per day, kept forever
    fh = DailyFileHandler(LOG_DIR, prefix="system")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_SYSTEM_FMT, datefmt=_DATE_FMT))
    logger.addHandler(fh)

    return logger


# ── activity logger ───────────────────────────────────────────

class ActivityLogger:
    def __init__(self):
        self._logger = logging.getLogger("activity")
        if self._logger.handlers:
            return

        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        fh = DailyFileHandler(LOG_DIR, prefix="activity")
        fh.setLevel(logging.INFO)
        fh.setFormatter(logging.Formatter("%(message)s"))
        self._logger.addHandler(fh)

    def _write(self, line: str):
        self._logger.info(line)

    def log_session_start(self, session_id: str, ip: str):
        self._write(
            f"\n{'═'*80}\n"
            f"SESSION    | {datetime.now().strftime(_DATE_FMT)} "
            f"| IP: {ip} | Session: {session_id}"
        )

    def log_document(self, filename: str, pages: int, chars: int,
                     images: int, tables: int = 0):
        self._write(
            f"DOCUMENT   | {filename} | Pages: {pages} "
            f"| Chars: {chars:,} | Images: {images} | Tables: {tables}"
        )

    def log_extraction_timing(self, t_page_check: float, t_text: float,
                               t_images: float, t_total: float,
                               t_tables: float = 0.0):
        self._write(
            f"EXTRACTION | Page check: {t_page_check:.2f}s | "
            f"Text: {t_text:.2f}s | Images: {t_images:.2f}s | "
            f"Tables: {t_tables:.2f}s | Total: {t_total:.2f}s"
        )

    def log_qa(self, turn: int, question: str, answer: str,
               t_prompt: float, t_ttft: float, t_total: float,
               chars_per_sec: float, question_type: str = "text",
               images_sent: int = 0, ip: str = "unknown"):
        question = question.replace("\n", " ").strip()
        answer = answer.strip()
        type_tag = question_type.upper()
        img_tag = f" | Images sent: {images_sent}" if images_sent else ""

        self._write(
            f"{'─'*80}\n"
            f"{datetime.now().strftime(_DATE_FMT)} | IP: {ip} | "
            f"Turn: {turn} | {type_tag}{img_tag}\n"
            f"QUESTION:\n{question}\n"
            f"ANSWER:\n{answer}\n"
            f"TIMING | Prompt: {t_prompt:.2f}s | TTFT: {t_ttft:.2f}s | "
            f"Total: {t_total:.2f}s | Speed: {chars_per_sec:.1f} chars/s"
        )

    def log_session_end(self, session_id: str, total_questions: int):
        self._write(
            f"SESSION END| {datetime.now().strftime(_DATE_FMT)} "
            f"| Session: {session_id} | Total Questions: {total_questions}\n"
            f"{'═'*80}"
        )

# single shared instance
activity_log = ActivityLogger()
