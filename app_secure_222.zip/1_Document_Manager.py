"""
1_Document_Manager.py – Upload, browse and delete documents
Run with:
    streamlit run 1_Document_Manager.py

Companion pages live in pages/
    pages/3_Chat_Assistant.py
"""

from datetime import date, datetime
from pathlib import Path
import os
import shutil
import tkinter as tk
from tkinter import filedialog

import streamlit as st
import config
import shared_db
from login_page import run as login_run

# ----------------------------------------------------------------------
# Constants & helper functions (must be defined before use)
# ----------------------------------------------------------------------
_BASE_DOCS_DIR = Path(config.DOCUMENTS_INPUT_DIR)
_BASE_DOCS_DIR.mkdir(parents=True, exist_ok=True)

def _user_docs_dir(user_name: str) -> Path:
    d = _BASE_DOCS_DIR / user_name
    d.mkdir(parents=True, exist_ok=True)
    return d

# ----------------------------------------------------------------------
# Bulk folder import (native OS folder picker - this is a local desktop
# app, so the Streamlit server and the browser run on the same machine,
# which means a native tkinter dialog works fine here)
# ----------------------------------------------------------------------
_BULK_ALLOWED_EXTS = {
    ".pdf", ".pptx", ".ppt", ".docx", ".doc",
    ".xlsx", ".xls", ".txt", ".md", ".csv",
}


def _pick_folder() -> str | None:
    """Open a native Windows folder picker and return the chosen path."""
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    folder = filedialog.askdirectory(title="Select folder to bulk import")
    root.destroy()
    return folder or None


def _collect_files_recursive(root_folder: Path) -> list[Path]:
    """Walk the folder tree and return every matching document, at any depth.
    Empty folders and unsupported file types are simply skipped."""
    found = []
    for dirpath, _dirnames, filenames in os.walk(root_folder):
        for fn in filenames:
            if Path(fn).suffix.lower() in _BULK_ALLOWED_EXTS:
                found.append(Path(dirpath) / fn)
    return found


def _safe_dest_name(src_path: Path, root_folder: Path) -> str:
    """Flatten into a single collision-safe filename that still encodes
    which subfolder(s) the file came from, e.g. 'Reports_Q1__budget.pdf'."""
    rel_parent = src_path.parent.relative_to(root_folder)
    if str(rel_parent) in (".", ""):
        return src_path.name
    prefix = "_".join(rel_parent.parts)
    return f"{prefix}__{src_path.name}"

# ----------------------------------------------------------------------
# Show login UI first
# ----------------------------------------------------------------------
login_run()

# If the user did not log in, stop the script.
if "user" not in st.session_state:
    st.stop()

# Alias used throughout the file
current_user = st.session_state["user"]

# 🔒 Resolve the per-user upload directory now that we know who is logged in
DOCS_DIR = _user_docs_dir(current_user)

# ----------------------------------------------------------------------
# Page configuration
# ----------------------------------------------------------------------
st.set_page_config(
    page_title="Document Manager",
    page_icon="📁",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----------------------------------------------------------------------
# Global CSS (kept from the original file)
# ----------------------------------------------------------------------
st.markdown(
    """
<style>
/* Sidebar styling */
[data-testid="stSidebar"] {
    background: #181c27 !important;
    border-right: 1px solid #2a3050 !important;
}
[data-testid="stSidebar"] * { color: #e2e8f0 !important; }

.sb-heading {
    font-size: 1.1rem; font-weight: 700;
    margin: 0 0 .8rem;
    padding-bottom: .5rem;
    border-bottom: 1px solid #2a3050;
}
.sb-file-card {
    background: #1f2435; border: 1px solid #2a3050;
    border-radius: 10px; padding: .6rem .8rem;
    margin-bottom: .5rem; display: flex;
    align-items: flex-start; gap: .6rem;
}
.sb-file-icon { font-size: 1.2rem; flex-shrink: 0; margin-top: .05rem; }
.sb-file-info  { flex: 1; min-width: 0; }
.sb-file-name  { font-size: .82rem; font-weight: 600;
                  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sb-file-date  { font-size: .72rem; color: #8892a4; margin-top: .15rem; }
.sb-stats { display: flex; flex-wrap: wrap; gap: .4rem; margin-bottom: .8rem; }
.sb-chip  { font-size: .7rem; font-weight: 600; padding: 2px 8px; border-radius: 20px;
            background: #1f2435; border: 1px solid #2a3050; color: #8892a4; }
.sb-chip b { color: #4f8ef7; }

/* status badges */
.badge-pending  { background:#2a3050; color:#f0c040; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-running  { background:#1a3a5c; color:#4f8ef7; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-done     { background:#1a3a2a; color:#4caf50; border-radius:6px; padding:1px 7px; font-size:.72rem; }
.badge-failed   { background:#3a1a1a; color:#ef5350; border-radius:6px; padding:1px 7px; font-size:.72rem; }

[data-testid="stSidebar"] .stTextInput > div > div > input,
[data-testid="stSidebar"] .stDateInput  > div > div > input {
    background: #1f2435 !important; border: 1px solid #2a3050 !important;
    border-radius: 8px !important; font-size: .82rem !important;
}
[data-testid="stSidebar"] .stButton > button {
    background: linear-gradient(135deg, #4f8ef7, #7c5cfc) !important;
    border: none !important; border-radius: 7px !important;
    color: #fff !important; font-weight: 600 !important; font-size: .8rem !important;
}
</style>
""",
    unsafe_allow_html=True,
)

# ----------------------------------------------------------------------
# Additional constants & helper functions
# ----------------------------------------------------------------------
DOCS_PER_PAGE = 3

EXT_ICON = {
    ".pdf": "📄", ".ppt": "📊", ".pptx": "📊",
    ".doc": "📝", ".docx": "📝", ".xls": "📈",
    ".xlsx": "📈", ".txt": "📃", ".md": "📃", ".csv": "📋",
}


def file_icon(ext: str) -> str:
    """Return an emoji based on file extension."""
    return EXT_ICON.get(ext.lower(), "📁")


def human_size(n: int) -> str:
    """Convert a size in bytes to a human‑readable string."""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def list_docs(user_name: str):
    """Return only the files that belong to *user_name* (per DB records)."""
    meta = shared_db.load_all_documents(user_name)
    user_dir = _user_docs_dir(user_name)
    result = []
    for filename in meta:
        f = user_dir / filename
        if f.exists():
            result.append(f)
    # Sort newest-first by modification time
    return sorted(result, key=lambda f: f.stat().st_mtime, reverse=True)


# ----------------------------------------------------------------------
# Session‑state initialisation
# ----------------------------------------------------------------------
if "file_metadata_store" not in st.session_state:
    # Load metadata for the current user
    st.session_state.file_metadata_store = shared_db.load_all_documents(current_user)
else:
    # Refresh on every run (keeps it in sync with DB)
    st.session_state.file_metadata_store = shared_db.load_all_documents(current_user)

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0

# Upload‑related state (new)
if "uploaded_files" not in st.session_state:
    st.session_state.uploaded_files = []          # list of UploadedFile objects
if "upload_meta" not in st.session_state:
    st.session_state.upload_meta = {}            # filename → dict of meta
if "upload_idx" not in st.session_state:
    st.session_state.upload_idx = 0              # which file we are editing now

# ----------------------------------------------------------------------
# Sidebar – Document Library (no upload UI)
# ----------------------------------------------------------------------
with st.sidebar:
    st.markdown(
        '<div class="sb-heading">📁 Document Library</div>',
        unsafe_allow_html=True,
    )
    # Library list – unchanged from original
    all_docs = list_docs(current_user)
    meta_store = st.session_state.file_metadata_store
    jobs = {
        j["filename"]: j
        for j in shared_db.get_all_jobs(current_user)
    }

    if not all_docs:
        st.caption("No documents yet. Upload one above.")
    else:
        total_size = sum(f.stat().st_size for f in all_docs)
        chips = '<div class="sb-stats">'
        chips += f'<span class="sb-chip"><b>{len(all_docs)}</b> files</span>'
        chips += f'<span class="sb-chip"><b>{human_size(total_size)}</b></span>'
        chips += "</div>"
        st.markdown(chips, unsafe_allow_html=True)

        search_q = st.text_input(
            "search", placeholder="🔍 Search…", label_visibility="collapsed"
        )

        filtered_docs = [
            f
            for f in all_docs
            if not search_q
            or search_q.lower()
            in (
                (meta_store.get(f.name, {}).get("title") or f.stem) + f.name
            ).lower()
        ]

        total_pages = max(1, -(-len(filtered_docs) // DOCS_PER_PAGE))

        if "doc_page" not in st.session_state:
            st.session_state.doc_page = 1
        if "last_search_q" not in st.session_state:
            st.session_state.last_search_q = ""
        if search_q != st.session_state.last_search_q:
            st.session_state.doc_page = 1
            st.session_state.last_search_q = search_q

        st.session_state.doc_page = max(
            1, min(st.session_state.doc_page, total_pages)
        )
        page = st.session_state.doc_page
        page_docs = filtered_docs[
            (page - 1) * DOCS_PER_PAGE : page * DOCS_PER_PAGE
        ]

        for f in page_docs:
            meta = meta_store.get(f.name, {})
            title = meta.get("title") or f.stem
            doc_date = meta.get("date", "")
            uploaded_at = meta.get("uploaded_at", "")
            job = jobs.get(f.name)

            # Date label
            if doc_date:
                date_label = f"📅 {doc_date}"
            elif uploaded_at:
                try:
                    dt = datetime.fromisoformat(uploaded_at)
                    friendly = dt.strftime("%-d %b %Y, %I:%M %p")
                except Exception:
                    friendly = uploaded_at[:16].replace("T", " ")
                date_label = f"🕒 Uploaded: {friendly}"
            else:
                date_label = "📅 No date"

            # Status badge – prefer job status, fall back to documents.status
            if job:
                s = job["status"]
                badge_cls = f"badge-{s}"
                status_html = f'<span class="{badge_cls}">{s.upper()}</span>'
            else:
                # Check the documents table status column
                doc_status = meta.get("status", "pending")
                if doc_status in ("done",):
                    status_html = '<span class="badge-done">DONE</span>'
                elif doc_status in ("running",):
                    status_html = '<span class="badge-running">RUNNING</span>'
                elif doc_status in ("failed",):
                    status_html = '<span class="badge-failed">FAILED</span>'
                else:
                    status_html = '<span class="badge-pending">PENDING</span>'

            icon = file_icon(f.suffix)
            st.markdown(
                f"""
<div class="sb-file-card">
  <div class="sb-file-icon">{icon}</div>
  <div class="sb-file-info">
    <div class="sb-file-name" title="{f.name}">{title}</div>
    <div class="sb-file-date">{date_label} · {human_size(f.stat().st_size)}</div>
    <div style="margin-top:.2rem">{status_html}</div>
  </div>
</div>
""",
                unsafe_allow_html=True,
            )

            # ---- Delete with confirmation ----
            del_key = f"del_{f.name}"
            confirm_key = f"confirm_{f.name}"
            if st.session_state.get(confirm_key, False):
                col1, col2 = st.columns([1, 1])
                with col1:
                    if st.button(
                        "✅ Yes, delete", key=f"yes_{f.name}", use_container_width=True
                    ):
                        with st.spinner("Deleting document and all related files…"):
                            result = shared_db.purge_document_artifacts(f.name, current_user)
                        st.session_state.file_metadata_store.pop(f.name, None)
                        st.session_state.pop(confirm_key, None)
                        if result["errors"]:
                            st.warning(
                                "Deleted with some warnings:\n" +
                                "\n".join(result["errors"])
                            )
                        st.rerun()
                with col2:
                    if st.button(
                        "❌ Cancel", key=f"cancel_{f.name}", use_container_width=True
                    ):
                        st.session_state.pop(confirm_key, None)
                        st.rerun()
            else:
                if st.button("🗑 Delete", key=del_key, use_container_width=True):
                    st.session_state[confirm_key] = True
                    st.rerun()

        # Pagination controls (unchanged)
        if total_pages > 1:
            st.markdown(
                f'<div style="text-align:center;font-size:.72rem;color:#8892a4;margin:.4rem 0 .2rem;">'
                f'Page {page} of {total_pages}  ·  {len(filtered_docs)} doc(s)</div>',
                unsafe_allow_html=True,
            )
            prev_col, mid_col, next_col = st.columns([1, 2, 1])
            with prev_col:
                if st.button(
                    "◄",
                    key="pg_prev",
                    use_container_width=True,
                    disabled=(page <= 1),
                ):
                    st.session_state.doc_page -= 1
                    st.rerun()
            with mid_col:
                st.markdown(
                    f'<div style="text-align:center;padding:.35rem 0;font-size:.8rem;color:#e2e8f0;">'
                    f'{page} / {total_pages}</div>',
                    unsafe_allow_html=True,
                )
            with next_col:
                if st.button(
                    "►",
                    key="pg_next",
                    use_container_width=True,
                    disabled=(page >= total_pages),
                ):
                    st.session_state.doc_page += 1
                    st.rerun()

# ----------------------------------------------------------------------
# Main area – Upload & summary
# ----------------------------------------------------------------------
st.markdown(
    '<h1 style="text-align:center">📁 Document Manager</h1>', unsafe_allow_html=True
)
st.markdown(
    """
<div style="text-align:center;color:#8892a4;margin-bottom:2rem;">
Upload and manage your documents here. Processing happens automatically in the background.
</div>
""",
    unsafe_allow_html=True,
)

# ---------- Upload section ----------
st.subheader("📂 Upload Documents")
uploaded = st.file_uploader(
    "Select files",
    type=[
        "pdf", "pptx", "ppt", "docx", "doc",
        "xlsx", "xls", "txt", "md", "csv",
    ],
    accept_multiple_files=True,
    label_visibility="collapsed",
    key=f"file_uploader_{st.session_state.uploader_key}",
)

if uploaded:
    # Store the list only once (avoid resetting while navigating)
    if not st.session_state.uploaded_files:
        st.session_state.uploaded_files = uploaded
        st.session_state.upload_idx = 0
        # Initialise empty meta dict for each file
        for uf in uploaded:
            st.session_state.upload_meta[uf.name] = {
                "project_name": "",
                "title": Path(uf.name).stem.replace("_", " ").replace("-", " "),
                "date": date.today(),
                "category": "",
                "remarks": "",
            }

# Navigation & metadata form ----------
if st.session_state.uploaded_files:
    idx = st.session_state.upload_idx
    cur_file = st.session_state.uploaded_files[idx]
    cur_meta = st.session_state.upload_meta[cur_file.name]

    col_left, col_mid, col_right = st.columns([1, 6, 1])
    with col_left:
        if st.button("← Prev", disabled=idx == 0):
            st.session_state.upload_idx -= 1
            st.rerun()
    with col_right:
        if st.button("Next →", disabled=idx == len(st.session_state.uploaded_files) - 1):
            st.session_state.upload_idx += 1
            st.rerun()

    # File preview (icon + name)
    st.markdown(
        f"""
<div style="display:flex;align-items:center;margin:1rem 0;">
  <div style="font-size:2rem;margin-right:.5rem;">{file_icon(Path(cur_file.name).suffix)}</div>
  <div style="font-size:1.1rem;">{cur_file.name}</div>
</div>
""",
        unsafe_allow_html=True,
    )

    # ---- Metadata fields ----
    new_project_name = st.text_input(
        "Project Name", value=cur_meta.get("project_name", ""), key=f"project_{cur_file.name}"
    )
    new_title = st.text_input(
        "Document Title", value=cur_meta["title"], key=f"title_{cur_file.name}"
    )
    new_date = st.date_input(
        "Date", value=cur_meta["date"], key=f"date_{cur_file.name}"
    )

    CATEGORY_OPTIONS = [
        "Select",
        "PMRC",
        "Executive Board",
        "Project Review",
        "Quality Document",
        "Sanction Letters",
        "Closure Document",
        "Others",
    ]
    current_category = cur_meta.get("category", "")
    default_idx = CATEGORY_OPTIONS.index(current_category) if current_category in CATEGORY_OPTIONS else 0
    new_category = st.selectbox(
        "Category",
        options=CATEGORY_OPTIONS,
        index=default_idx,
        key=f"cat_{cur_file.name}",
    )
    if new_category == "Select":
        new_category = ""

    new_remarks = st.text_input(
        "Remarks", value=cur_meta.get("remarks", cur_meta.get("doc_id", "")), key=f"id_{cur_file.name}"
    )

    # Save changes back to session state
    st.session_state.upload_meta[cur_file.name] = {
        "project_name": new_project_name,
        "title": new_title,
        "date": new_date,
        "category": new_category,
        "remarks": new_remarks,
    }

    # Save All button (appears once we have at least one file)
    if st.button(
        f"📤 Submit All {len(st.session_state.uploaded_files)} Document(s)",
        use_container_width=True,
    ):
        saved = []
        for uf in st.session_state.uploaded_files:
            dest = DOCS_DIR / uf.name
            dest.write_bytes(uf.getbuffer())

            meta = st.session_state.upload_meta.get(uf.name, {})
            record = {
                "filename": uf.name,
                "project_name": meta.get("project_name", ""),
                "title": meta.get("title", Path(uf.name).stem),
                "date": str(meta.get("date", date.today())),
                "category": meta.get("category", ""),
                "doc_id": meta.get("remarks", ""),
                "uploaded_at": datetime.now().isoformat(),
                "size_bytes": len(uf.getbuffer()),
                "status": "pending",  # immediately visible in the sidebar
            }
            shared_db.save_document(record, current_user)
            shared_db.enqueue_job(uf.name, current_user)
            st.session_state.file_metadata_store[uf.name] = record
            saved.append(uf.name)

        # Reset upload‑related state
        st.session_state.uploaded_files = []
        st.session_state.upload_meta = {}
        st.session_state.upload_idx = 0
        st.session_state.uploader_key += 1
        st.success(f"✅ {len(saved)} file(s) saved & queued for processing!")
        st.rerun()

# ---------- Bulk folder import section ----------
st.markdown("---")
st.subheader("📁 Bulk Import from Folder")
st.caption(
    "Select a folder containing subfolders of documents (PDF/PPT/DOC/etc). "
    "All matching files are found recursively, at any depth. Empty folders "
    "and unsupported file types are skipped automatically."
)

if st.button("Choose Folder..."):
    picked = _pick_folder()
    if picked:
        st.session_state.bulk_import_folder = picked
        st.rerun()

if st.session_state.get("bulk_import_folder"):
    _bulk_folder = Path(st.session_state.bulk_import_folder)
    _bulk_files = _collect_files_recursive(_bulk_folder)
    st.info(f"Found **{len(_bulk_files)}** document(s) in `{_bulk_folder}` (including subfolders).")

    col_a, col_b = st.columns([1, 1])
    with col_a:
        do_import = st.button(
            f"📤 Import & Queue All {len(_bulk_files)} Document(s)",
            use_container_width=True,
            disabled=len(_bulk_files) == 0,
        )
    with col_b:
        if st.button("Cancel", use_container_width=True):
            st.session_state.bulk_import_folder = None
            st.rerun()

    if do_import:
        saved, skipped = 0, 0
        for src in _bulk_files:
            dest_name = _safe_dest_name(src, _bulk_folder)
            dest = DOCS_DIR / dest_name
            try:
                shutil.copy2(src, dest)
            except Exception:
                skipped += 1
                continue

            record = {
                "filename": dest_name,
                "project_name": "",
                "title": Path(dest_name).stem.replace("_", " "),
                "date": str(date.today()),
                "category": "",
                "doc_id": "",
                "uploaded_at": datetime.now().isoformat(),
                "size_bytes": dest.stat().st_size,
                "status": "pending",
            }
            shared_db.save_document(record, current_user)
            shared_db.enqueue_job(dest_name, current_user)
            st.session_state.file_metadata_store[dest_name] = record
            saved += 1

        st.session_state.bulk_import_folder = None
        msg = f"✅ {saved} file(s) imported and queued for processing"
        if skipped:
            msg += f" ({skipped} skipped due to a file error)"
        st.success(msg)
        st.rerun()

# ---------- Summary cards ----------
all_docs = list_docs(current_user)
counts = shared_db.count_by_status(current_user)

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.metric("📂 Total Documents", len(all_docs))
with c2:
    st.metric("✅ Ready to Query", counts.get("done", 0))
with c3:
    st.metric(
        "⏳ Processing / Queued", counts.get("running", 0) + counts.get("pending", 0)
    )
with c4:
    st.metric("❌ Failed", counts.get("failed", 0))

st.markdown("---")

# ---------- Tip line ----------
st.caption(
    "💡 **Tip:** After uploading, head to **Chat Assistant** to query already‑processed documents."
)
