"""
Centralized configuration for RAG pipeline
"""

import os
from pathlib import Path


# ==========================================
# CACHE DIRECTORIES
# ==========================================
MODEL_CACHE_DIR = Path("/home/dlpda/PLANNING/planning_testing_sep_UI/HOME")
MODEL_CACHE_DIR.mkdir(parents=True, exist_ok=True)

os.environ['HOME'] = str(MODEL_CACHE_DIR)

# ==========================================
# PATHS
# ==========================================
MARKDOWN_OUTPUT_DIR = Path("/home/dlpda/PLANNING/planning_testing_sep_UI/APP_CACHE/MARKDOWNS")
MARKDOWN_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

QDRANT_STORAGE_PATH = Path("/home/dlpda/PLANNING/planning_testing_sep_UI/APP_CACHE/QDRANT_STORAGE")
QDRANT_STORAGE_PATH.mkdir(parents=True, exist_ok=True)

DOCUMENTS_INPUT_DIR = Path("/home/dlpda/PLANNING/planning_testing_sep_UI/DOCUMENTS")

DOCUMENT_CACHE = Path("/home/dlpda/PLANNING/planning_testing_sep_UI/APP_CACHE/DOCUMENT_CACHE")
DOCUMENT_CACHE.mkdir(parents=True, exist_ok=True)

# ==========================================
# Rag Contextual cache dir paths
# ==========================================

CONTEXT_CACHE_PATH = Path("/home/dlpda/PLANNING/planning_testing_sep_UI/APP_CACHE/chunk_info/chunk_cache/contextual_chunks.json")

# Create parent directory for file path
CONTEXT_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)

# Create file if missing
if not CONTEXT_CACHE_PATH.exists():
    CONTEXT_CACHE_PATH.touch()

CONTEXT_PROMPT_VERSION = "version-1"
CHUNK_DUMP_DIR = "/home/dlpda/PLANNING/planning_testing_sep_UI/APP_CACHE/chunk_info/cache_list"

# ==========================================
# OLLAMA SETTINGS
# ==========================================
BASE_URL = "http://172.27.30.222:12000"
OLLAMA_IMAGE_MODEL = "qwen3-vl:4b"
OLLAMA_LLM_MODEL = "gpt-oss:20b"
LLM_TEMPERATURE = 0.1
MAX_LEFT_CONTEXT_CHARS = 10000

# ==========================================
# EMBEDDING MODELS
# ==========================================
DENSE_EMBEDDING_MODEL = "qwen3-embedding:0.6b"
SPARSE_EMBEDDING_MODEL = "Qdrant/bm25"
RERANKER_MODEL = "ms-marco-MiniLM-L-12-v2"

# ==========================================
# QDRANT SETTINGS
# ==========================================
QDRANT_COLLECTION_NAME = "planning_documents"
DENSE_EMBEDDING_DIMENSION = 1024

# BUG FIX: QDRANT_URL was missing from config — rag_pipeline used getattr fallback.
# Now explicit so every module reads the same value.
QDRANT_URL = "http://localhost:6333"

INGESTION_CACHE_PATH = str(Path("/home/dlpda/PLANNING/planning_testing_sep_UI/APP_CACHE/ingestion_cache.json"))

# ==========================================
# DOCUMENT PROCESSING
# ==========================================
IMAGE_RESOLUTION_SCALE = 2.0
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

# ==========================================
# RETRIEVAL SETTINGS
# ==========================================
RETRIEVAL_CANDIDATES_COUNT = 40
RERANKING_TOP_RESULTS = 20

# ==========================================
# LOGGING
# ==========================================
LOG_LEVEL = "INFO"

print("✅ Configuration loaded")