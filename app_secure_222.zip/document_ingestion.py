# ==========================================================
#
# FINAL: JSON-FIRST UNIFIED DOCUMENT INGESTION PIPELINE
# (GPU-SAFE EDITION)
#
# FIX SUMMARY
# -----------
# 1. CUDA OOM  – convert_with_mineru now passes two extra env-vars to
#    the MinerU subprocess:
#      • PYTORCH_ALLOC_CONF=expandable_segments:True  (reduces fragmentation)
#      • CUDA_LAUNCH_BLOCKING=0                        (default, keeps perf)
#    The caller (worker.py) wraps every call in a file-level GPU lock so
#    only one MinerU subprocess runs at a time, preventing the
#    multi-process VRAM exhaustion seen in the logs.
#
# 2. GPU DEVICE DISCOVERY WARNING – ORT_DISABLE_GPU_DEVICE_DISCOVERY=1 is
#    injected into the MinerU subprocess environment so ONNXRuntime skips
#    the sysfs vendor-file read that produced:
#      "GPU device discovery failed: ReadFileContents Failed to open file:
#       /sys/class/drm/card0/device/vendor"
#    The same variable is also set in THIS process's environment at import
#    time so the warning does not appear in the Streamlit process either.
#
# ==========================================================

import os
import json
import hashlib
import logging
import subprocess
import shutil
import warnings
from pathlib import Path
from typing import Dict, Tuple, Any, Optional

# ── Apply GPU-warning suppression in THIS process immediately ──────────────
os.environ.setdefault("ORT_DISABLE_GPU_DEVICE_DISCOVERY", "1")
os.environ.setdefault("PYTORCH_ALLOC_CONF", "expandable_segments:True")
logging.getLogger("onnxruntime").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", message=".*GPU device discovery failed.*")
warnings.filterwarnings("ignore", message=".*device_discovery.*")

import config
import ollama
from docling.document_converter import DocumentConverter

# ==========================================================
# LOGGING
# ==========================================================

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL))
logger = logging.getLogger(__name__)

# ==========================================================
# CACHE
# ==========================================================

CACHE_FILE = Path(config.DOCUMENT_CACHE) / "document_cache.json"

CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
if not CACHE_FILE.exists():
    CACHE_FILE.write_text("{}", encoding="utf-8")
    logger.info(f"Created missing cache file: {CACHE_FILE}")


def compute_file_hash(file_path: Path) -> str:
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def load_cache() -> Dict[str, str]:
    if CACHE_FILE.exists():
        return json.loads(CACHE_FILE.read_text())
    return {}


def save_cache(cache: Dict[str, str]) -> None:
    CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(cache, indent=2))


# ==========================================================
# OFFICE → PDF
# ==========================================================

OFFICE_EXTENSIONS = {".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx"}


def convert_office_to_pdf(input_file: Path, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    output_pdf = output_dir / f"{input_file.stem}.pdf"

    if output_pdf.exists():
        return output_pdf

    logger.info(f"Office → PDF: {input_file.name}")

    subprocess.run(
        [
            "libreoffice",
            "--headless",
            "--convert-to", "pdf",
            "--outdir", str(output_dir),
            str(input_file),
        ],
        check=True,
        timeout=180,
    )

    return output_pdf


# ==========================================================
# MINERU OCR  (Fix 1 + Fix 2 applied here)
# ==========================================================

def _build_mineru_env() -> dict:
    """
    Build an environment dict for the MinerU subprocess that:
    - Inherits the full current environment (PATH, CUDA_HOME, etc.)
    - Adds PYTORCH_ALLOC_CONF to reduce VRAM fragmentation (Fix 1)
    - Adds ORT_DISABLE_GPU_DEVICE_DISCOVERY to silence sysfs warning (Fix 2)
    """
    env = os.environ.copy()
    env["PYTORCH_ALLOC_CONF"]            = "expandable_segments:True"
    env["ORT_DISABLE_GPU_DEVICE_DISCOVERY"] = "1"
    # Ensure CUDA errors surface immediately (helps with OOM diagnostics)
    env["CUDA_LAUNCH_BLOCKING"]          = "0"
    return env


def convert_with_mineru(pdf_path: Path, output_root: Path) -> Path:
    """
    Run MinerU OCR on a PDF and return the output document directory.

    The subprocess receives the patched environment (_build_mineru_env) so
    both the VRAM-fragmentation fix and the ORT warning suppression are
    active inside MinerU without requiring any change to MinerU itself.
    """
    logger.info(f"OCR with MinerU: {pdf_path.name}")

    tmp_dir = output_root / f"{pdf_path.stem}_tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)

    subprocess.run(
        [
            "mineru",
            "-p", str(pdf_path),
            "-o", str(tmp_dir),
            "-m", "ocr",
            "-b", "vlm-auto-engine",
            "-l", "en",
        ],
        check=True,
        env=_build_mineru_env(),   # ← GPU fixes injected here
    )

    hybrid_dir = tmp_dir / pdf_path.stem / "vlm"

    md_files = list(hybrid_dir.glob("*.md"))
    if not md_files:
        raise RuntimeError("MinerU produced no markdown")

    final_dir = output_root / pdf_path.stem
    final_dir.mkdir(parents=True, exist_ok=True)

    # Move markdown
    shutil.move(str(md_files[0]), str(final_dir / f"{pdf_path.stem}.md"))

    # Move and rename JSON
    src_json = hybrid_dir / f"{pdf_path.stem}_content_list.json"
    if not src_json.exists():
        raise RuntimeError("_content_list.json missing")
    shutil.move(str(src_json), str(final_dir / f"{pdf_path.stem}.json"))

    # Move images directory if present
    src_images = hybrid_dir / "images"
    if src_images.is_dir():
        dst_images = final_dir / "images"
        if dst_images.exists():
            shutil.rmtree(dst_images)
        shutil.move(str(src_images), str(dst_images))

    # Copy original PDF
    shutil.copy2(str(pdf_path), str(final_dir / f"{pdf_path.stem}.pdf"))

    # Clean up temp dir
    shutil.rmtree(tmp_dir, ignore_errors=True)
    return final_dir


# ==========================================================
# IMAGE ENRICHMENT
# ==========================================================

MODEL = config.OLLAMA_IMAGE_MODEL

PROMPT = """
You are a vision-language extraction engine.

Rules (STRICT):
- Output ONLY valid JSON
- Do NOT add explanations
- Do NOT use Markdown
- Tables MUST be in pure HTML
- If no table exists, set "table" to null

Task:
1 Describe image (max 100 words)
2 Extract table if present

Output format STRICT:

{
"description":"text",
"table":"html or null"
}
"""

SUPPORTED_EXTS = (".png", ".jpg", ".jpeg", ".webp")


def find_image(doc_dir: Path, img_rel_path: str):
    candidate = doc_dir / img_rel_path
    if candidate.exists():
        return candidate.resolve()

    stem = Path(img_rel_path).stem
    for ext in SUPPORTED_EXTS:
        matches = list(doc_dir.rglob(f"{stem}{ext}"))
        if matches:
            return matches[0]
    return None


def describe_image(client, img_path: Path):
    logger.info(f"Running VLM on image: {img_path.name}")
    with open(img_path, "rb") as f:
        image_bytes = f.read()

    response = client.generate(
        model=MODEL,
        prompt=PROMPT,
        images=[image_bytes],
        stream=False,
    )

    raw = response.get("response", "").strip()
    try:
        return json.loads(raw)
    except Exception:
        logger.warning("VLM returned non-JSON")
        return {"description": raw, "table": None}


def enrich_images_with_descriptions(content_json_path: Path):
    logger.info(f"Starting image enrichment → {content_json_path.name}")
    client = ollama.Client(config.BASE_URL)

    with open(content_json_path, "r", encoding="utf-8") as f:
        content = json.load(f)

    doc_dir     = content_json_path.parent
    image_count = 0

    for block in content:
        block_type = block.get("type", "")
        logger.info(f"Block type: {block_type}")

        if block_type not in ["image", "figure", "img"]:
            continue

        img_rel = (
            block.get("img_path")
            or block.get("image_path")
            or block.get("path")
        )

        if not img_rel:
            logger.warning("Image block without path")
            continue

        logger.info(f"Image relative path: {img_rel}")
        img_path = find_image(doc_dir, img_rel)

        if img_path:
            logger.info(f"Image found: {img_path}")
            block["image_description"] = describe_image(client, img_path)
            image_count += 1
        else:
            logger.warning(f"Image NOT FOUND: {img_rel}")
            block["image_description"] = {
                "description": "Image file not found",
                "table": None,
            }

    logger.info(f"Images processed: {image_count}")

    with open(content_json_path, "w", encoding="utf-8") as f:
        json.dump(content, f, indent=2, ensure_ascii=False)

    return content_json_path


# ==========================================================
# FINAL MARKDOWN WITH UNIQUE PAGE TAGS
# ==========================================================

def build_final_markdown_from_json(content_json_path: Path) -> None:
    logger.info(f"Creating final markdown with page tags → {content_json_path.name}")

    try:
        with open(content_json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        pages: Dict[int, list] = {}
        for item in data:
            p = item.get("page_idx", 0)
            pages.setdefault(p, []).append(item)

        md = ""
        for p in sorted(pages):
            md += f"\n\n<<!PAGE {p+1}>>\n\n"
            for item in pages[p]:
                t = item.get("type", "")

                if t == "text":
                    txt = item.get("text", "").strip()
                    if txt:
                        md += (f"# {txt}\n\n" if item.get("text_level") == 1
                               else txt + "\n\n")

                elif t == "list":
                    for li in item.get("list_items", []):
                        if li.strip():
                            md += "- " + li.strip() + "\n"
                    md += "\n"

                elif t == "image":
                    desc = item.get("image_description", {})
                    d = (desc.get("description", "").strip()
                         or desc.get("Description", "").strip())
                    if d:
                        md += f"*Image Description:* {d}\n\n"

                elif t == "table":
                    for cap in item.get("table_caption", []):
                        if cap.strip():
                            md += f"**{cap.strip()}**\n\n"
                    body = item.get("table_body", "")
                    if body:
                        md += body + "\n\n"
                    for foot in item.get("table_footnote", []):
                        if foot.strip():
                            md += f"*{foot.strip()}*\n"

        out_md = content_json_path.with_suffix(".md")
        out_md.write_text(md, encoding="utf-8")
        logger.info(f"Final markdown saved → {out_md}")

    except Exception as e:
        logger.error(f"Final markdown build failed: {e}")


# ==========================================================
# MAIN PIPELINE  (legacy direct-call path)
# ==========================================================

def ingest_documents(
    input_directory: str | None = None,
    output_directory: str | None = None,
) -> Dict[str, Tuple[Path, Any]]:
    """
    Direct ingestion path (used when NOT running the background worker).
    NOTE: for production multi-user use, prefer running worker.py which
    serialises GPU access properly.
    """
    input_dir = Path(input_directory or config.DOCUMENTS_INPUT_DIR)
    output_dir = Path(output_directory or config.MARKDOWN_OUTPUT_DIR)
    output_dir.mkdir(parents=True, exist_ok=True)

    temp_pdf_dir = output_dir / "_temp_pdfs"
    temp_pdf_dir.mkdir(parents=True, exist_ok=True)

    cache            = load_cache()
    loaded_documents = {}
    docling          = DocumentConverter()

    for file in input_dir.iterdir():
        if not file.is_file():
            continue
        if file.name.startswith(".-lock") or file.name.endswith("#"):
            logger.info(f"Skipping lock file: {file.name}")
            continue

        file_hash = compute_file_hash(file)
        if file_hash in cache:
            logger.info(f"Skipped (cached): {file.name}")
            loaded_documents[file.name] = (file, None)
            continue

        # STEP 1 – convert
        if file.suffix.lower() in OFFICE_EXTENSIONS:
            pdf     = convert_office_to_pdf(file, temp_pdf_dir)
            doc_dir = convert_with_mineru(pdf, output_dir)

        elif file.suffix.lower() == ".pdf":
            doc_dir = convert_with_mineru(file, output_dir)

        else:
            logger.info(f"Docling fallback: {file.name}")
            result = docling.convert(file)
            if not result.document:
                continue
            doc_dir = output_dir / file.stem
            doc_dir.mkdir(parents=True, exist_ok=True)
            (doc_dir / f"{file.stem}.md").write_text(
                result.document.export_to_markdown(), encoding="utf-8"
            )

        # STEP 2 – enrich + markdown
        json_file = doc_dir / f"{doc_dir.name}.json"
        if json_file.exists():
            try:
                enriched_json = enrich_images_with_descriptions(json_file)
                build_final_markdown_from_json(enriched_json)
            except Exception as e:
                logger.error(f"Post-processing failed for {file.name}: {e}")

        # STEP 3 – cache
        cache[file_hash] = "cached"
        save_cache(cache)
        loaded_documents[file.name] = (file, None)

    logger.info(f"Ingested {len(loaded_documents)} documents")
    return loaded_documents


# ==========================================================
# ENTRY POINT
# ==========================================================

if __name__ == "__main__":
    ingest_documents()
