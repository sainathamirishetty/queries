# =====================================================================
#  pages/2_Document_Processor.py
#  Live background-processing dashboard
# =====================================================================

from datetime import datetime
from pathlib import Path
import time

import streamlit as st

import config
import shared_db

st.set_page_config(
    page_title="Document Processor",
    page_icon="⚙️",
    layout="wide",
)

# ── Auth guard ────────────────────────────────────────────────────────────────
if "user" not in st.session_state:
    st.warning("Please log in first.")
    st.stop()

current_user: str = st.session_state["user"]

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
body, [data-testid="stAppViewContainer"] { background: #0f1117; }

.job-card {
    border-radius: 12px; padding: 1rem 1.2rem;
    margin-bottom: .7rem;
    border: 1px solid #2a3050;
}
.job-card-pending  { background: #1c1f2e; border-left: 4px solid #f0c040; }
.job-card-running  { background: #111d2e; border-left: 4px solid #4f8ef7; }
.job-card-indexing { background: #12201f; border-left: 4px solid #00bcd4; }
.job-card-done     { background: #0f1f19; border-left: 4px solid #4caf50; }
.job-card-failed   { background: #1f1111; border-left: 4px solid #ef5350; }

.job-title  { font-size:.95rem; font-weight:700; color:#e2e8f0; }
.job-meta   { font-size:.75rem; color:#8892a4; margin-top:.25rem; }
.job-err    { font-size:.75rem; color:#ef9a9a; margin-top:.3rem;
              background:#2a1111; border-radius:6px; padding:.4rem .6rem; }

.stat-box {
    background:#1f2435; border:1px solid #2a3050; border-radius:12px;
    padding:1.2rem; text-align:center;
}
.stat-num   { font-size:2rem; font-weight:800; }
.stat-label { font-size:.8rem; color:#8892a4; margin-top:.2rem; }

.page-info {
    text-align:center; color:#8892a4; font-size:.8rem; margin: .4rem 0;
}

.pulse { animation: pulse 1.4s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
</style>
""", unsafe_allow_html=True)


# ── Constants ─────────────────────────────────────────────────────────────────
JOBS_PER_PAGE = 10


# ── Helpers ───────────────────────────────────────────────────────────────────
def fmt_dt(iso: str | None) -> str:
    if not iso:
        return "—"
    try:
        return datetime.fromisoformat(iso).strftime("%-d %b %Y, %I:%M %p")
    except Exception:
        return iso[:16].replace("T", " ")


def elapsed(start: str | None, end: str | None) -> str:
    if not start:
        return ""
    try:
        s = datetime.fromisoformat(start)
        e = datetime.fromisoformat(end) if end else datetime.now()
        secs = int((e - s).total_seconds())
        if secs < 60:
            return f"{secs}s"
        if secs < 3600:
            return f"{secs//60}m {secs%60}s"
        return f"{secs//3600}h {(secs%3600)//60}m"
    except Exception:
        return ""


EXT_ICON = {
    ".pdf": "📄", ".ppt": "📊", ".pptx": "📊",
    ".doc": "📝", ".docx": "📝", ".xls": "📈",
    ".xlsx": "📈", ".txt": "📃", ".md": "📃", ".csv": "📋",
}


def file_icon(name: str) -> str:
    return EXT_ICON.get(Path(name).suffix.lower(), "📁")


STATUS_LABEL = {
    "pending":  "⏳ PENDING",
    "running":  "🔄 RUNNING",
    "indexing": "🔷 INDEXING — building vector index…",
    "done":     "✅ READY",
    "failed":   "❌ FAILED",
}


def paginate_key(tab_key: str) -> str:
    """Session state key for each tab's current page."""
    return f"dp_page_{tab_key}"


def render_jobs(job_list: list, tab_key: str = ""):
    """Render job cards with 10-per-page pagination."""
    if not job_list:
        st.caption("Nothing here.")
        return

    total_jobs = len(job_list)
    total_pages = max(1, -(-total_jobs // JOBS_PER_PAGE))  # ceil division

    # Initialise page counter in session state
    page_key = paginate_key(tab_key)
    if page_key not in st.session_state:
        st.session_state[page_key] = 1

    # Clamp page if job list shrank (e.g. after re-queue)
    if st.session_state[page_key] > total_pages:
        st.session_state[page_key] = total_pages

    current_page = st.session_state[page_key]

    # Slice the job list for current page
    start_idx = (current_page - 1) * JOBS_PER_PAGE
    end_idx   = start_idx + JOBS_PER_PAGE
    page_jobs = job_list[start_idx:end_idx]

    # ── Job cards ─────────────────────────────────────────────────────────────
    for job in page_jobs:
        fname  = job["filename"]
        status = job["status"]
        meta   = meta_store.get(fname, {})
        title  = meta.get("title") or Path(fname).stem
        icon   = file_icon(fname)

        q_str  = fmt_dt(job.get("queued_at"))
        s_str  = fmt_dt(job.get("started_at"))
        f_str  = fmt_dt(job.get("finished_at"))
        dur    = elapsed(job.get("started_at"), job.get("finished_at"))

        running_anim = ' class="pulse"' if status in ("running", "indexing") else ""

        meta_parts = [f"Queued: {q_str}"]
        if s_str != "—":
            meta_parts.append(f"Started: {s_str}")
        if f_str != "—":
            meta_parts.append(f"Finished: {f_str}")
        if dur:
            meta_parts.append(f"Time: {dur}")
        meta_str = "  ·  ".join(meta_parts)

        err_html = ""
        if status == "failed" and job.get("error_message"):
            err_html = f'<div class="job-err">⚠️ {job["error_message"][:300]}</div>'

        st.markdown(f"""
        <div class="job-card job-card-{status}">
          <div{running_anim}>
            <span style="font-size:1.1rem">{icon}</span>
            <span class="job-title" style="margin-left:.4rem">{title}</span>
            <span style="font-size:.75rem;color:#8892a4;margin-left:.8rem">{fname}</span>
            <span style="float:right;font-size:.8rem;font-weight:700;color:#e2e8f0">
              {STATUS_LABEL.get(status, status.upper())}
            </span>
          </div>
          <div class="job-meta">{meta_str}</div>
          {err_html}
        </div>
        """, unsafe_allow_html=True)

        # Re-queue button for failed jobs
        if status == "failed":
            if st.button(f"🔁 Re-queue {fname}", key=f"requeue_{tab_key}_{fname}"):
                shared_db.enqueue_job(fname, current_user)
                st.session_state[page_key] = 1
                st.rerun()

    # ── Pagination controls ────────────────────────────────────────────────────
    if total_pages > 1:
        st.markdown("")
        prev_col, info_col, next_col = st.columns([1, 3, 1])

        with prev_col:
            if st.button("◀ Prev", key=f"prev_{tab_key}",
                         disabled=(current_page <= 1)):
                st.session_state[page_key] -= 1
                st.rerun()

        with info_col:
            showing_from = start_idx + 1
            showing_to   = min(end_idx, total_jobs)
            st.markdown(
                f'<div class="page-info">'
                f'Page {current_page} of {total_pages} &nbsp;·&nbsp; '
                f'Showing {showing_from}–{showing_to} of {total_jobs} documents'
                f'</div>',
                unsafe_allow_html=True,
            )

        with next_col:
            if st.button("Next ▶", key=f"next_{tab_key}",
                         disabled=(current_page >= total_pages)):
                st.session_state[page_key] += 1
                st.rerun()


# ── Main ──────────────────────────────────────────────────────────────────────
st.markdown('<h1 style="text-align:center">⚙️ Document Processor</h1>', unsafe_allow_html=True)
st.markdown("""
<div style="text-align:center;color:#8892a4;margin-bottom:1.5rem;">
Documents are processed by the background worker. This page shows live status.<br>
Documents move through: <b>Pending → Running (OCR) → Indexing (vectors) → Ready</b>.<br>
The Chat Assistant is available only for <b>Ready</b> documents — Indexing documents are not yet queryable.
</div>
""", unsafe_allow_html=True)

# ── Auto-refresh controls ──────────────────────────────────────────────────────
refresh_col, gap_col = st.columns([2, 6])
with refresh_col:
    auto_refresh = st.toggle("🔄 Auto-refresh (every 5 s)", value=True)

if auto_refresh:
    REFRESH_EVERY = 5
    if "last_refresh" not in st.session_state:
        st.session_state.last_refresh = time.time()
    if time.time() - st.session_state.last_refresh >= REFRESH_EVERY:
        st.session_state.last_refresh = time.time()
        st.rerun()

# ── Stats row ─────────────────────────────────────────────────────────────────
counts  = shared_db.count_by_status(current_user)
total   = sum(counts.values())
done    = counts.get("done", 0)
indexing = counts.get("indexing", 0)
running = counts.get("running", 0)
pending = counts.get("pending", 0)
failed  = counts.get("failed", 0)

overall_pct = int(done / total * 100) if total else 0

s1, s2, s3, s4, s5, s6 = st.columns(6)
for col, num, label, color in [
    (s1, total,    "Total Jobs",   "#e2e8f0"),
    (s2, done,     "✅ Ready",     "#4caf50"),
    (s3, indexing, "🔷 Indexing",  "#00bcd4"),
    (s4, running,  "🔄 Running",   "#4f8ef7"),
    (s5, pending,  "⏳ Pending",   "#f0c040"),
    (s6, failed,   "❌ Failed",    "#ef5350"),
]:
    col.markdown(f"""
    <div class="stat-box">
      <div class="stat-num" style="color:{color}">{num}</div>
      <div class="stat-label">{label}</div>
    </div>
    """, unsafe_allow_html=True)

# ── Overall progress bar ───────────────────────────────────────────────────────
if total:
    st.markdown("")
    st.markdown(f"**Overall progress: {done}/{total} documents ready ({overall_pct}%)**")
    st.progress(overall_pct / 100)
    st.markdown("")

# ── Manual refresh button ──────────────────────────────────────────────────────
if st.button("🔄 Refresh Now"):
    st.rerun()

st.markdown("---")

# ── Job cards with pagination ──────────────────────────────────────────────────
jobs = shared_db.get_all_jobs(current_user)
meta_store = shared_db.load_all_documents(current_user)

if not jobs:
    st.info("📭 No processing jobs yet. Upload documents in **Document Manager** to get started.")
else:
    # Active jobs (running/indexing/pending) first, then newest-queued first within each group
    order = {"running": 0, "indexing": 1, "pending": 2, "done": 3, "failed": 4}
    jobs_sorted = sorted(
        jobs,
        key=lambda j: (order.get(j["status"], 9), (j.get("queued_at") or "").replace("T", "").replace("-", "").replace(":", "") or "0"),
    )
    # Within each status group sort by queued_at descending (newest first)
    from itertools import groupby
    final_sorted = []
    for _status_order, group in groupby(
        jobs_sorted, key=lambda j: order.get(j["status"], 9)
    ):
        final_sorted.extend(
            sorted(list(group), key=lambda j: j.get("queued_at") or "", reverse=True)
        )
    jobs_sorted = final_sorted

    tab_all, tab_active, tab_done, tab_failed = st.tabs([
        f"All ({len(jobs)})",
        f"Active ({running + pending + indexing})",
        f"Ready ({done})",
        f"Failed ({failed})",
    ])

    with tab_all:
        render_jobs(jobs_sorted, tab_key="all")

    with tab_active:
        render_jobs(
            [j for j in jobs_sorted if j["status"] in ("running", "indexing", "pending")],
            tab_key="active",
        )

    with tab_done:
        render_jobs(
            [j for j in jobs_sorted if j["status"] == "done"],
            tab_key="ready",
        )

    with tab_failed:
        render_jobs(
            [j for j in jobs_sorted if j["status"] == "failed"],
            tab_key="failed",
        )

# ── Worker status hint ─────────────────────────────────────────────────────────
st.markdown("---")
if running or indexing:
    active_name = next(
        (j["filename"] for j in jobs_sorted if j["status"] in ("running", "indexing")),
        ""
    )
    st.success(f"✅ Background worker is active — processing **{active_name}**")
elif pending:
    st.warning(
        f"⚠️ {pending} document(s) are queued but no worker is running.  \n"
        "Start the worker in a terminal: `python worker.py`"
    )
else:
    st.info("ℹ️ Start the background worker to enable automatic processing: `python worker.py`")
