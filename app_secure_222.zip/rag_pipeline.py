import os
import re
import json
import time
import hashlib
import logging
import uuid
import subprocess
import shutil
import requests
from pathlib import Path
from typing import List, Tuple, Optional

from langchain_classic.retrievers import MultiQueryRetriever
from langchain_classic.schema import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaEmbeddings, ChatOllama
from langchain_qdrant import QdrantVectorStore, FastEmbedSparse, RetrievalMode
from qdrant_client import QdrantClient
from qdrant_client.http.models import Filter, FieldCondition, MatchValue
from langchain_core.prompts import PromptTemplate
from langchain_community.document_compressors import FlashrankRerank
from flashrank import Ranker

import config

# ------------------------------------------------------------------------------
# Logging
# ------------------------------------------------------------------------------
LOG_FORMAT = "[%(asctime)s] [%(levelname)s] - %(message)s"
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL, logging.INFO),
    format=LOG_FORMAT,
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("RAG_PIPELINE")
MAX_LEFT_CONTEXT_CHARS = config.MAX_LEFT_CONTEXT_CHARS

# ------------------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------------------
CONTEXT_CACHE_PATH = config.CONTEXT_CACHE_PATH
CONTEXT_PROMPT_VERSION = config.CONTEXT_PROMPT_VERSION
CHUNK_DUMP_DIR = config.CHUNK_DUMP_DIR
PAGE_PATTERN = re.compile(r"<<!PAGE (\d+)>>")
INGESTION_CACHE_PATH = getattr(config, "INGESTION_CACHE_PATH", str(Path("ingestion_cache.json")))
QDRANT_URL = getattr(config, "QDRANT_URL", "http://localhost:6333")

# ------------------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------------------
def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_context_cache():
    if not os.path.exists(CONTEXT_CACHE_PATH):
        return {}
    try:
        with open(CONTEXT_CACHE_PATH,"r") as f:
            content = f.read().strip()
            if not content:
                return {}
            return json.loads(content)
    except Exception:
        logger.warning("Context cache corrupted → resetting")
        return {}


def save_context_cache(cache: dict):
    os.makedirs(os.path.dirname(CONTEXT_CACHE_PATH), exist_ok=True)
    with open(CONTEXT_CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump(cache, f, indent=2)


def load_ingestion_cache() -> dict:
    if os.path.exists(INGESTION_CACHE_PATH):
        with open(INGESTION_CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_ingestion_cache(cache: dict):
    with open(INGESTION_CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump(cache, f, indent=2)


def dump_chunks_for_viewing(filename: str, chunk_number: int, content: str):
    Path(CHUNK_DUMP_DIR).mkdir(exist_ok=True)
    path = Path(CHUNK_DUMP_DIR) / f"{filename}_all_chunks.txt"
    with open(path, "a", encoding="utf-8") as f:
        f.write("\n")
        f.write("*" * 30 + f" CHUNK {chunk_number} " + "*" * 30 + "\n")
        f.write(content.strip() + "\n")


def find_page_for_chunk(full_text: str, chunk_text: str, start_pos=0) -> int:
    idx = full_text.find(chunk_text, start_pos)
    if idx == -1:
        return 1

    before = full_text[:idx]
    matches = list(PAGE_PATTERN.finditer(before))
    if not matches:
        return 1
    return int(matches[-1].group(1))


def get_markdown_files(user_name: str = "") -> List[Path]:
    markdown_dir = Path(config.MARKDOWN_OUTPUT_DIR)
    if user_name:
        user_input_dir = Path(config.DOCUMENTS_INPUT_DIR) / user_name
        if not user_input_dir.exists():
            return []
        user_filestems = {f.stem for f in user_input_dir.iterdir() if f.is_file()}
        return [
            p for p in markdown_dir.rglob("*.md")
            if p.stem in user_filestems
        ]
    return list(markdown_dir.rglob("*.md"))


def documents_changed() -> Tuple[List[Path], dict]:
    cache = load_ingestion_cache()
    files = get_markdown_files()
    current_hashes = {}
    changed_files = []

    for file in files:
        text = file.read_text(encoding="utf-8")
        file_key = str(file.resolve())
        file_hash = sha256(text)
        current_hashes[file_key] = file_hash

        if cache.get(file_key) != file_hash:
            changed_files.append(file)

    return changed_files, current_hashes

# ------------------------------------------------------------------------------
# Qdrant startup
# ------------------------------------------------------------------------------
def _qdrant_binary() -> str:
    """Find the qdrant binary via env override, PATH, or common fallback paths."""
    env_override = os.environ.get("QDRANT_BIN")
    if env_override:
        if os.path.isfile(env_override) and os.access(env_override, os.X_OK):
            return env_override
        raise FileNotFoundError(f"QDRANT_BIN is set to '{env_override}' but is not executable.")

    found = shutil.which("qdrant")
    if found:
        return found

    for candidate in [
        "/usr/local/bin/qdrant",
        "/usr/bin/qdrant",
        str(Path.home() / ".cargo/bin/qdrant"),
        "/snap/bin/qdrant",
    ]:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            logger.warning("qdrant found at fallback path: %s", candidate)
            return candidate

    raise FileNotFoundError(
        "qdrant binary not found. Install it or set the QDRANT_BIN env var."
    )


def _qdrant_alive() -> bool:
    """Return True if Qdrant is already responding on port 6333."""
    try:
        requests.get("http://localhost:6333", timeout=5)
        return True
    except requests.RequestException:
        return False


def _release_qdrant_storage_lock():
    """
    Remove ALL lock files left behind by an unclean Qdrant shutdown.

    Qdrant exit code 101 means its storage is locked. It writes several
    lock files across its storage tree — deleting only the top-level .lock
    is not always enough. We clear every known lock pattern:
        <storage>/.lock                          (top-level process lock)
        <storage>/meta.json.lock                 (metadata WAL lock)
        <storage>/collection/*/LOCK              (RocksDB per-collection lock)
        <storage>/collection/*/segments/*/LOCK   (RocksDB segment locks)

    Safe to call only when Qdrant is confirmed NOT responding (stale locks).
    """
    storage = config.QDRANT_STORAGE_PATH
    removed = []

    # 1. Top-level process lock and metadata WAL lock
    for name in [".lock", "meta.json.lock"]:
        p = storage / name
        if p.exists():
            try:
                p.unlink()
                removed.append(str(p))
            except OSError as e:
                logger.error("Could not remove lock file %s: %s", p, e)

    # 2. RocksDB LOCK files anywhere inside the storage tree
    for lock_file in storage.rglob("LOCK"):
        try:
            lock_file.unlink()
            removed.append(str(lock_file))
        except OSError as e:
            logger.error("Could not remove RocksDB lock file %s: %s", lock_file, e)

    if removed:
        logger.warning(
            "Removed %d stale Qdrant lock file(s) (normal after unclean shutdown):\n  %s",
            len(removed), "\n  ".join(removed)
        )
    else:
        logger.info("No stale Qdrant lock files found.")


# One process-level startup lock so that when worker handles multiple users
# simultaneously, only ONE of them actually launches Qdrant. The others wait
# and reuse the instance that is already starting up.
import threading
_qdrant_start_lock = threading.Lock()


def start_qdrant_server():
    """
    Ensure Qdrant is running on localhost:6333.

    Thread-safe: when multiple worker threads call this simultaneously
    (e.g. alice and bob jobs running at the same time), only the first
    thread launches Qdrant. The rest wait and then reuse it.

    Also handles the 'code 101' crash that happens on System B after an
    unclean shutdown by removing the stale storage .lock file before launch.
    """
    # ── Fast path: already up (no lock needed) ────────────────────────────
    if _qdrant_alive():
        logger.info("Qdrant already running")
        return None

    # ── Serialise startup across threads ──────────────────────────────────
    with _qdrant_start_lock:

        # Re-check inside the lock: another thread may have started it
        # while we were waiting.
        if _qdrant_alive():
            logger.info("Qdrant already running (started by another thread)")
            return None

        # ── Remove stale storage lock (causes exit code 101) ──────────────
        _release_qdrant_storage_lock()

        # ── Find binary ───────────────────────────────────────────────────
        binary = _qdrant_binary()
        logger.info("Starting Qdrant: %s", binary)

        process = subprocess.Popen(
            [binary],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        # ── Wait up to 60 s for healthy response ──────────────────────────
        for i in range(60):
            time.sleep(1)
            ret = process.poll()
            if ret is not None:
                raise RuntimeError(
                    f"Qdrant exited immediately with code {ret}.\n"
                    "Common causes:\n"
                    "  • Port 6333 in use  → sudo ss -tlnp | grep 6333\n"
                    "  • Wrong binary arch → file /usr/local/bin/qdrant\n"
                    "  • Permissions       → ls -la "
                    f"{config.QDRANT_STORAGE_PATH}"
                )
            if _qdrant_alive():
                logger.info("Qdrant started successfully (waited %ds)", i + 1)
                return process
            logger.info("Waiting for Qdrant... %d/60", i + 1)

        process.terminate()
        raise RuntimeError("Qdrant did not become healthy within 60 seconds.")

# ------------------------------------------------------------------------------
# Splitter
# ------------------------------------------------------------------------------
class DocumentAwareSplitter(RecursiveCharacterTextSplitter):
    def __init__(self, chunk_size=None, chunk_overlap=None):
        chunk_size = int(chunk_size or config.CHUNK_SIZE)
        chunk_overlap = int(chunk_overlap or config.CHUNK_OVERLAP)
        super().__init__(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=["\n\n"],
        )

    def create_documents(self, texts, filename=None, pdf_url=None):
        documents = []
        chunk_counter = 1

        for text in texts:
            chunks = super().split_text(text)
            search_pos = 0

            for chunk in chunks:
                page = find_page_for_chunk(text, chunk, search_pos)
                pos = text.find(chunk, search_pos)
                if pos != -1:
                    search_pos = pos + len(chunk)

                clean_chunk = chunk.strip()
                documents.append(
                    Document(
                        page_content=clean_chunk,
                        metadata={
                            "filename": filename,
                            "page_number": page,
                            "chunk_number": chunk_counter,
                            "pdf_url": pdf_url,
                            "chunk_hash": sha256(clean_chunk),
                        },
                    )
                )
                chunk_counter += 1

        return documents


def format_docs_for_llm(documents):
    formatted = []
    for d in documents:
        meta = d.metadata
        filename = meta.get("filename", "unknown")
        page = meta.get("page_number", "?")
        block = f"{d.page_content}\n[SOURCE FILE: {filename} | Page: {page}]"
        formatted.append(block)
    return "\n\n".join(formatted)

# ------------------------------------------------------------------------------
# LLM
# ------------------------------------------------------------------------------
def get_llm():
    return ChatOllama(
        model=config.OLLAMA_LLM_MODEL,
        temperature=config.LLM_TEMPERATURE,
        base_url=config.BASE_URL,
        num_ctx=24000,
    )

# ------------------------------------------------------------------------------
# Contextualization helpers
# ------------------------------------------------------------------------------
def build_sliding_window(full_text: str, chunk_text: str) -> str:
    idx = full_text.find(chunk_text)
    if idx == -1:
        left_context = full_text[-MAX_LEFT_CONTEXT_CHARS:]
        return left_context + "\n\n" + chunk_text

    left_start = max(0, idx - MAX_LEFT_CONTEXT_CHARS)
    left_context = full_text[left_start:idx]
    return left_context + "\n\n" + chunk_text


def generate_chunk_context(windowed_document: str, chunk: str) -> str:
    llm = get_llm()
    prompt = f"""
<document>
{windowed_document}
</document>

Here is the chunk we want to situate within the whole document
<chunk>
{chunk}
</chunk>

Please give a short succinct context to situate this chunk within the overall document for the purposes of improving search retrieval of the chunk.
Answer only with the succinct context and nothing else.
"""
    response = llm.invoke(prompt)
    return str(response.content).strip()

# ------------------------------------------------------------------------------
# Document creation
# ------------------------------------------------------------------------------
def create_non_llm_documents(files_to_process: Optional[List[Path]] = None, user_name: str = "") -> List[Document]:
    logger.info("Starting chunk creation (no LLM context)")

    markdown_dir = Path(config.MARKDOWN_OUTPUT_DIR)
    files = files_to_process if files_to_process is not None else get_markdown_files(user_name)

    if not files:
        logger.warning("No markdown files found")
        return []

    splitter = DocumentAwareSplitter()
    total_chunks = 0
    documents = []

    for file in files:
        logger.info(f"Processing document: {file.name}")
        pdf_url = f"{markdown_dir}/{file.stem}/{file.stem}.pdf"

        text = file.read_text(encoding="utf-8")
        doc_hash = sha256(text)
        chunks = splitter.create_documents([text], filename=file.stem, pdf_url=pdf_url)

        logger.info(f"  → {len(chunks)} chunks created")

        for chunk in chunks:
            total_chunks += 1
            chunk.metadata["doc_hash"] = doc_hash
            chunk.metadata["pdf_url"] = pdf_url
            chunk.metadata["user_name"] = user_name

            dump_chunks_for_viewing(
                chunk.metadata["filename"],
                chunk.metadata["chunk_number"],
                chunk.page_content,
            )
            documents.append(chunk)

    logger.info(f"  Total chunks : {total_chunks}")
    logger.info("Chunk creation completed")
    return documents


def create_contextualized_documents(files_to_process: Optional[List[Path]] = None, user_name: str = "") -> List[Document]:
    logger.info("Starting contextualized chunk creation")

    markdown_dir = Path(config.MARKDOWN_OUTPUT_DIR)
    files = files_to_process if files_to_process is not None else get_markdown_files(user_name)

    if not files:
        logger.warning("No markdown files found")
        return []

    splitter = DocumentAwareSplitter()
    cache = load_context_cache()

    total_chunks = 0
    cache_hits = 0
    llm_calls = 0
    documents = []

    for file in files:
        logger.info(f"Processing document: {file.name}")
        pdf_url = f"{markdown_dir}/{file.stem}/{file.stem}.pdf"

        text = file.read_text(encoding="utf-8")
        doc_hash = sha256(text)
        chunks = splitter.create_documents([text], filename=file.stem, pdf_url=pdf_url)

        logger.info(f"  → {len(chunks)} chunks created")

        for chunk in chunks:
            total_chunks += 1
            ch = chunk.metadata["chunk_hash"]

            if (
                doc_hash in cache
                and ch in cache[doc_hash]
                and cache[doc_hash][ch]["prompt_version"] == CONTEXT_PROMPT_VERSION
            ):
                context = cache[doc_hash][ch]["context"]
                cache_hits += 1
            else:
                windowed_doc = build_sliding_window(text, chunk.page_content)
                context = generate_chunk_context(windowed_doc, chunk.page_content)
                llm_calls += 1
                cache.setdefault(doc_hash, {})[ch] = {
                    "context": context,
                    "prompt_version": CONTEXT_PROMPT_VERSION,
                }

            final_content = f"[CONTEXT] {context}\n\n{chunk.page_content}"
            chunk.page_content = final_content
            chunk.metadata["doc_hash"] = doc_hash
            chunk.metadata["pdf_url"] = pdf_url
            chunk.metadata["user_name"] = user_name

            dump_chunks_for_viewing(
                chunk.metadata["filename"],
                chunk.metadata["chunk_number"],
                final_content,
            )
            documents.append(chunk)

    save_context_cache(cache)
    logger.info(f"  Total chunks : {total_chunks}")
    logger.info(f"  Cache hits   : {cache_hits}")
    logger.info(f"  LLM calls    : {llm_calls}")
    logger.info("Contextual chunking completed")
    return documents

# ------------------------------------------------------------------------------
# Qdrant / Vector store
# ------------------------------------------------------------------------------
def initialize_embeddings():
    dense_embeddings = OllamaEmbeddings(
        model=config.DENSE_EMBEDDING_MODEL,
        base_url=config.BASE_URL,
    )

    sparse_embeddings = FastEmbedSparse(
        model_name=config.SPARSE_EMBEDDING_MODEL,
        cache_dir=config.MODEL_CACHE_DIR,
        local_cache_dir=config.MODEL_CACHE_DIR,
        local_files_only=True,
    )

    return dense_embeddings, sparse_embeddings


def get_qdrant_client():
    start_qdrant_server()
    return QdrantClient(
        url="http://localhost:6333",
        timeout=60
    )


def collection_exists(client: QdrantClient) -> bool:
    collections = client.get_collections().collections
    return any(c.name == config.QDRANT_COLLECTION_NAME for c in collections)


def get_existing_chunk_hashes(client: QdrantClient) -> set:
    existing_hashes = set()
    offset = None

    try:
        while True:
            records, offset = client.scroll(
                collection_name=config.QDRANT_COLLECTION_NAME,
                limit=1000,
                offset=offset,
                with_payload=["metadata"],
                with_vectors=False,
            )

            for record in records:
                metadata = record.payload.get("metadata", {})
                chunk_hash = metadata.get("chunk_hash")
                if chunk_hash:
                    existing_hashes.add(chunk_hash)

            if offset is None:
                break

        logger.info(f"Found {len(existing_hashes)} existing chunk hashes in collection")

    except Exception as e:
        logger.warning(f"Error fetching existing chunk hashes: {e}")

    return existing_hashes


def ingest_documents(store: QdrantVectorStore, document_chunks: List[Document]) -> int:
    if not document_chunks:
        logger.info("No document chunks provided for ingestion")
        return 0

    existing_hashes = get_existing_chunk_hashes(store.client)

    new_chunks = [
        chunk for chunk in document_chunks
        if chunk.metadata.get("chunk_hash") not in existing_hashes
    ]

    if not new_chunks:
        logger.info("All chunks already exist in vector store — nothing to insert")
        return 0

    logger.info(f"Inserting {len(new_chunks)} new chunks (skipped {len(document_chunks) - len(new_chunks)} duplicates)")

    texts = [chunk.page_content for chunk in new_chunks]
    metadatas = [chunk.metadata for chunk in new_chunks]
    ids = [
        str(uuid.uuid5(uuid.NAMESPACE_DNS, chunk.metadata["chunk_hash"]))
        for chunk in new_chunks
    ]

    store.add_texts(texts=texts, metadatas=metadatas, ids=ids)

    logger.info(f"Successfully inserted {len(new_chunks)} chunks")
    return len(new_chunks)


def create_vector_store(document_chunks: List[Document]) -> QdrantVectorStore:
    dense_embeddings, sparse_embeddings = initialize_embeddings()
    client = get_qdrant_client()
    exists = collection_exists(client)

    if exists:
        logger.info("Loading existing Qdrant collection")
        vector_store = QdrantVectorStore.from_existing_collection(
            embedding=dense_embeddings,
            sparse_embedding=sparse_embeddings,
            collection_name=config.QDRANT_COLLECTION_NAME,
            url=QDRANT_URL,
            retrieval_mode=RetrievalMode.HYBRID,
        )
        if document_chunks:
            ingest_documents(vector_store, document_chunks)
        return vector_store

    if not document_chunks:
        raise ValueError(
            "Qdrant collection does not exist and no document chunks were provided. "
            "Wait for the background worker to finish processing your documents, "
            "then refresh the Chat Assistant page."
        )

    logger.info("Creating new Qdrant collection")
    vector_store = QdrantVectorStore.from_documents(
        documents=document_chunks,
        embedding=dense_embeddings,
        sparse_embedding=sparse_embeddings,
        url=QDRANT_URL,
        collection_name=config.QDRANT_COLLECTION_NAME,
        retrieval_mode=RetrievalMode.HYBRID,
    )
    logger.info(f"Created collection with {len(document_chunks)} chunks")
    return vector_store

# ------------------------------------------------------------------------------
# Reranker
# ------------------------------------------------------------------------------
ranker = Ranker(model_name=config.RERANKER_MODEL, cache_dir=config.MODEL_CACHE_DIR)
RERANKER = FlashrankRerank(
    client=ranker,
    model=config.RERANKER_MODEL,
    top_n=config.RERANKING_TOP_RESULTS,
)

# ------------------------------------------------------------------------------
# Dynamic Retrieval Logic
# ------------------------------------------------------------------------------
def compute_dynamic_drop_threshold(
    scores: List[float],
    reference_k: int = 4,
    multiplier: float = 3.0,
    min_threshold: float = 0.03,
    max_threshold: float = 0.2,
) -> float:
    if len(scores) <= reference_k:
        return min_threshold

    scores = sorted(scores, reverse=True)
    drops = [scores[i] - scores[i + 1] for i in range(reference_k)]
    avg_drop = sum(drops) / len(drops)
    return max(min_threshold, min(avg_drop * multiplier, max_threshold))


def select_until_dynamic_drop(
    docs_with_scores: List[Tuple[Document, float]],
    min_chunks: int = 3,
    max_chunks: int = 15,
) -> List[Document]:
    scores = [s for _, s in docs_with_scores]
    threshold = compute_dynamic_drop_threshold(scores)

    selected = []
    for i, (doc, score) in enumerate(docs_with_scores):
        selected.append(doc)
        if len(selected) < min_chunks:
            continue
        if len(selected) >= max_chunks:
            break
        if i + 1 < len(docs_with_scores):
            if score - docs_with_scores[i + 1][1] > threshold:
                break

    return selected


def fetch_chunk_by_metadata(
    store: QdrantVectorStore,
    filename: str,
    chunk_number: int,
    user_name: str = "",
) -> Optional[Document]:
    if chunk_number <= 0:
        return None

    must_conditions = [
        FieldCondition(key="metadata.filename", match=MatchValue(value=filename)),
        FieldCondition(key="metadata.chunk_number", match=MatchValue(value=chunk_number)),
    ]
    if user_name:
        must_conditions.append(
            FieldCondition(key="metadata.user_name", match=MatchValue(value=user_name))
        )

    query_filter = Filter(must=must_conditions)

    try:
        records, _ = store.client.scroll(
            collection_name=config.QDRANT_COLLECTION_NAME,
            scroll_filter=query_filter,
            limit=1,
            with_payload=True,
            with_vectors=False,
        )
        if records:
            payload = records[0].payload
            return Document(page_content=payload["page_content"], metadata=payload["metadata"])
    except Exception as e:
        logger.warning("[NEIGHBOR FETCH ERROR] filename=%s chunk=%d | %s", filename, chunk_number, str(e))

    return None

# ------------------------------------------------------------------------------
# Retrieval
# ------------------------------------------------------------------------------
def retrieve_context(query: str, store: QdrantVectorStore, user_name: str = "") -> List[Document]:
    logger.info("======================================================")
    logger.info("[QUERY] %s", query)

    search_filter = None
    if user_name:
        search_filter = Filter(
            must=[FieldCondition(key="metadata.user_name", match=MatchValue(value=user_name))]
        )

    try:
        results = store.similarity_search_with_score(
            query=query,
            k=config.RETRIEVAL_CANDIDATES_COUNT,
            filter=search_filter,
        )
    except TypeError:
        raw_docs = store.similarity_search(
            query=query,
            k=config.RETRIEVAL_CANDIDATES_COUNT,
            filter=search_filter,
        )
        results = [(d, 0.0) for d in raw_docs]

    results = sorted(results, key=lambda x: x[1], reverse=True)
    logger.info("[RETRIEVAL] Retrieved=%d", len(results))

    if not results:
        logger.info("[FINAL] No chunks retrieved.")
        return []

    pruned_docs = [d for d, _ in results]
    logger.info("[DYNAMIC-1] After dynamic drop=%d", len(pruned_docs))

    if not pruned_docs:
        return []

    score_map = {d.metadata.get("chunk_hash"): s for d, s in results}

    logger.info("[RERANKING] Before rerank count=%d", len(pruned_docs))
    try:
        reranked_docs = RERANKER.compress_documents(pruned_docs, query=query)
    except Exception as e:
        logger.warning("Reranker failed: %s", str(e))
        reranked_docs = pruned_docs

    logger.info("[RERANKING] After rerank count=%d", len(reranked_docs))

    reranked_with_scores = [
        (d, score_map.get(d.metadata.get("chunk_hash"), 0.0))
        for d in reranked_docs
    ]

    final_selected = select_until_dynamic_drop(reranked_with_scores)
    logger.info("[DYNAMIC-2] After rerank dynamic drop=%d", len(final_selected))

    if not final_selected:
        return []

    expanded_docs = []
    seen_hashes = set()
    top_k_for_window = 5

    for idx, doc in enumerate(final_selected):
        filename = doc.metadata.get("filename")
        chunk_number = int(doc.metadata.get("chunk_number", 0))
        ch = doc.metadata.get("chunk_hash")

        if idx < top_k_for_window:
            logger.info("[WINDOW] Expanding chunk | file=%s chunk=%d", filename, chunk_number)

            prev_doc = fetch_chunk_by_metadata(store, filename, chunk_number - 1, user_name)
            if prev_doc:
                prev_hash = prev_doc.metadata.get("chunk_hash")
                if prev_hash not in seen_hashes:
                    expanded_docs.append(prev_doc)
                    seen_hashes.add(prev_hash)
                    logger.info("   + Added previous chunk=%d", chunk_number - 1)

            if ch not in seen_hashes:
                expanded_docs.append(doc)
                seen_hashes.add(ch)

            next_doc = fetch_chunk_by_metadata(store, filename, chunk_number + 1, user_name)
            if next_doc:
                next_hash = next_doc.metadata.get("chunk_hash")
                if next_hash not in seen_hashes:
                    expanded_docs.append(next_doc)
                    seen_hashes.add(next_hash)
                    logger.info("   + Added next chunk=%d", chunk_number + 1)
        else:
            if ch not in seen_hashes:
                expanded_docs.append(doc)
                seen_hashes.add(ch)

    logger.info("[WINDOW] After expansion count=%d", len(expanded_docs))
    expanded_docs.sort(
        key=lambda d: (
            d.metadata.get("filename", ""),
            int(d.metadata.get("chunk_number", 0)),
        )
    )
    logger.info("[FINAL] Total chunks sent to LLM=%d", len(expanded_docs))
    logger.info("======================================================")
    return expanded_docs

# ------------------------------------------------------------------------------
# Streaming Answer
# ------------------------------------------------------------------------------
def generate_streaming_answer(store: QdrantVectorStore, question: str, user_name: str = ""):
    documents = retrieve_context(question, store, user_name)

    if not documents:
        return iter(["No relevant context found."]), []

    context = format_docs_for_llm(documents)

    prompt = PromptTemplate(
        template="""
You are a data expert assistant.

STRICT INSTRUCTIONS:
- Use ONLY the information explicitly present in the CONTEXT.
- Do NOT use external knowledge.
- Do NOT infer beyond what is stated.
- If the answer is not present in the CONTEXT, respond exactly with:
  "I don't know — the information is not in the provided context."

RESPONSE REQUIREMENTS:
- Provide a concise but complete answer.
- Elaborate only if required for clarity.
- Preserve numerical values, technical terms, and factual details exactly as written.
- Format the response in Markdown.

CONTEXT (DELIMITED — READ CAREFULLY):
------------------------------------
{context}
------------------------------------

QUESTION:
{question}

OUTPUT FORMAT (STRICTLY FOLLOW):

### Answer
<your grounded answer>

### Sources
    File: <source filename>| Page: <page_number>
""",
        input_variables=["context", "question"],
    )

    formatted = prompt.invoke({"context": context, "question": question})
    llm = get_llm()

    def stream():
        for chunk in llm.stream(formatted):
            if chunk and chunk.content:
                yield chunk.content

    return stream(), documents


def generate_answer(store: QdrantVectorStore, question: str, user_name: str = ""):
    documents = retrieve_context(question, store, user_name)
    context = "\n\n".join(d.page_content for d in documents)

    prompt = PromptTemplate(
        template="""You are a data expert assistant. Use ONLY the information provided in the CONTEXT section below to answer the QUESTION in Markdown format.
Do not use any external knowledge not present in CONTEXT. If the question cannot be answered from CONTEXT, reply: "I don't know — the information is not in the provided context." Give a short and concise answer to the question.

CONTEXT (DELIMITED - READ CAREFULLY):
---------
{context}
---------

QUESTION:
{question}

Answer should be in the form:
Answer:
Sources: .
""",
        input_variables=["context", "question"],
    )

    formatted = prompt.invoke({"context": context, "question": question})
    llm = get_llm()
    answer = llm.invoke(formatted).content
    return answer, documents

# ------------------------------------------------------------------------------
# Main
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    logger.info("RAG pipeline started")

    changed_files, current_hashes = documents_changed()

    client = get_qdrant_client()
    collection_ready = collection_exists(client)

    if not collection_ready:
        docs = create_non_llm_documents()
        store = create_vector_store(docs)
        save_ingestion_cache(current_hashes)
    else:
        if changed_files:
            logger.info("New or modified markdown files detected")
            docs = create_non_llm_documents(changed_files)
            store = create_vector_store(docs)
            save_ingestion_cache(current_hashes)
        else:
            logger.info("No markdown changes detected; loading existing Qdrant collection")
            store = create_vector_store([])

    stream, docs = generate_streaming_answer(store, "What is this document about?")

    print("\nAnswer:\n")
    for token in stream:
        print(token, end="", flush=True)
