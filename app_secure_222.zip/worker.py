#!/usr/bin/env python3
"""
worker.py  (GPU-SAFE EDITION)
==============================
Standalone background worker – run ONCE alongside Streamlit:

    python worker.py

FIX SUMMARY
-----------
1. CUDA OOM  – MinerU loads the Qwen2-VL model (~8-9 GiB) once per subprocess.
   When multiple uploads arrive quickly, several subprocesses run simultaneously
   and exhaust the 20 GiB GPU.  Fix: a file-based GPU lock
   (gpu.lock) makes every MinerU call strictly sequential, and
   torch.cuda.empty_cache() is called after each job to return cached-but-free
   VRAM to the driver.  Also sets PYTORCH_ALLOC_CONF=expandable_segments:True
   so PyTorch handles fragmentation gracefully if pressure ever gets close.

2. GPU DEVICE DISCOVERY WARNING – ONNXRuntime tries to read
   /sys/class/drm/card0/device/vendor at startup and prints a harmless but
   noisy warning when that sysfs file is absent (common on some kernels /
   container setups).  Fix: ONNXRUNTIME_DEVICE_DISCOVERY is set to skip GPU
   discovery, and the warning is filtered from the log so it no longer appears.

Both fixes are applied at process start before any imports touch CUDA.
"""

# ============================================================
# STEP 0 – apply environment patches BEFORE any GPU import
# ============================================================
import os
import logging
import warnings

# Fix 2: suppress ONNXRuntime sysfs GPU-discovery warning
os.environ.setdefault("ORT_DISABLE_GPU_DEVICE_DISCOVERY", "1")
# Fix 1: tell PyTorch allocator to use expandable segments → reduces fragmentation
os.environ.setdefault("PYTORCH_ALLOC_CONF", "expandable_segments:True")

# Silence the ORT warning at the Python-logging level as well
logging.getLogger("onnxruntime").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", message=".*GPU device discovery failed.*")
warnings.filterwarnings("ignore", message=".*device_discovery.*")

# ============================================================
# Standard imports
# ============================================================
import sys
import time
import fcntl
import json
import urllib.request
import urllib.error
from pathlib import Path

import config
import shared_db
from document_ingestion import (
    compute_file_hash,
    load_cache,
    save_cache,
    convert_office_to_pdf,
    convert_with_mineru,
    enrich_images_with_descriptions,
    build_final_markdown_from_json,
    OFFICE_EXTENSIONS,
)

# ============================================================
# Logging
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [WORKER] %(levelname)s  %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# ============================================================
# Configuration
# ============================================================
POLL_INTERVAL  = 10   # seconds between queue polls
JOB_PAUSE      = 2    # seconds between consecutive jobs
OOM_RETRY_WAIT = 30   # seconds to wait before retrying after CUDA OOM
MAX_OOM_RETRY  = 2    # max automatic retries on OOM per job

# File-lock path – lives next to the output dir so every process sees it
_GPU_LOCK_FILE = Path(config.MARKDOWN_OUTPUT_DIR) / ".gpu.lock"
_BASE_INPUT_DIR = Path(config.DOCUMENTS_INPUT_DIR)
OUTPUT_DIR      = Path(config.MARKDOWN_OUTPUT_DIR)


# ============================================================
# Ollama VRAM eviction helpers
# ============================================================
# When Ollama keeps large models loaded (e.g. gpt-oss:20b at ~14 GiB),
# MinerU cannot allocate the ~3–4 GiB it needs even though the GPU lock
# ensures only one MinerU job runs at a time.  The fix: ask Ollama to
# unload all GPU-resident models before MinerU starts, and reload them
# afterward.  Ollama's REST API supports this via keep_alive=0 (unload)
# and keep_alive=-1 (pin until next eviction).

_OLLAMA_BASE = "http://localhost:11434"

# Models that should be reloaded after MinerU finishes.
# Derive from config so there is only one place to change them.
_OLLAMA_LLM_MODEL   = None   # filled lazily from config
_OLLAMA_EMBED_MODEL = None

def _ollama_get(path: str) -> dict:
    """Tiny helper: GET from Ollama API, return parsed JSON or {}."""
    try:
        with urllib.request.urlopen(f"{_OLLAMA_BASE}{path}", timeout=5) as r:
            return json.loads(r.read())
    except Exception:
        return {}

def _ollama_post(path: str, payload: dict) -> None:
    """Tiny helper: POST JSON to Ollama API (fire-and-forget)."""
    try:
        data = json.dumps(payload).encode()
        req  = urllib.request.Request(
            f"{_OLLAMA_BASE}{path}",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10):
            pass
    except Exception as exc:
        logger.debug("[OLLAMA] POST %s failed (ignored): %s", path, exc)

def _get_ollama_models() -> list[str]:
    """Return the names of all models Ollama currently has resident in VRAM."""
    data = _ollama_get("/api/ps")
    return [m.get("name", "") for m in data.get("models", [])]

def _evict_ollama_models() -> list[str]:
    """
    Unload every Ollama model from VRAM (keep_alive=0).
    Returns the list of model names that were evicted so they can be reloaded.
    """
    resident = _get_ollama_models()
    if not resident:
        return []

    logger.info("[OLLAMA] Evicting %d model(s) from VRAM: %s", len(resident), resident)
    for model in resident:
        # Sending keep_alive=0 to /api/generate with no prompt triggers an unload.
        _ollama_post("/api/generate", {"model": model, "keep_alive": 0})

    # Wait up to 15 s for Ollama to actually free the memory
    for _ in range(15):
        time.sleep(1)
        if not _get_ollama_models():
            break

    remaining = _get_ollama_models()
    if remaining:
        logger.warning("[OLLAMA] Models still in VRAM after eviction: %s", remaining)
    else:
        logger.info("[OLLAMA] All models evicted from VRAM.")

    return resident

def _restore_ollama_models(models: list[str]) -> None:
    """
    Warm up previously-evicted Ollama models so chat / embedding latency is not
    impacted for the user.  Uses keep_alive=-1 (never auto-evict).
    Only the LLM and embedding models defined in config are restored; any other
    model that happened to be running is intentionally not pinned.
    """
    global _OLLAMA_LLM_MODEL, _OLLAMA_EMBED_MODEL
    if _OLLAMA_LLM_MODEL is None:
        try:
            import config as _cfg
            _OLLAMA_LLM_MODEL   = getattr(_cfg, "OLLAMA_LLM_MODEL",   "")
            _OLLAMA_EMBED_MODEL = getattr(_cfg, "DENSE_EMBEDDING_MODEL", "")
        except Exception:
            pass

    to_restore = {m for m in models if m in (_OLLAMA_LLM_MODEL, _OLLAMA_EMBED_MODEL)}
    if not to_restore:
        return

    logger.info("[OLLAMA] Restoring model(s) to VRAM: %s", to_restore)
    for model in to_restore:
        # Sending an empty prompt with keep_alive=-1 warms the model without
        # generating output and pins it until the next explicit eviction.
        _ollama_post("/api/generate", {"model": model, "keep_alive": -1, "prompt": ""})
    logger.info("[OLLAMA] Model restore requests sent.")


# ============================================================
# GPU helpers  (Fix 1)
# ============================================================

def _free_gpu_memory() -> None:
    """
    Return all cached-but-free VRAM to the driver.
    Called after every document job finishes (success or failure).
    """
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            free, total = torch.cuda.mem_get_info()
            logger.info(
                "[GPU] VRAM after cleanup → free: %.2f GiB / total: %.2f GiB",
                free  / 1024**3,
                total / 1024**3,
            )
    except Exception as exc:
        logger.warning("[GPU] Could not clear VRAM cache: %s", exc)


class _GpuLock:
    """
    Cross-process exclusive lock around any call that loads a model onto the GPU.

    Uses an OS-level flock so it works even if the worker spawns subprocesses
    (which MinerU does).  Guarantees only ONE MinerU process holds the GPU at a time.

    Additionally evicts Ollama models from VRAM *after* acquiring the lock so that
    MinerU has enough headroom (Ollama's LLM can occupy 14+ GiB), then restores
    them after MinerU finishes so chat/embedding latency is not impacted.
    """

    def __init__(self, path: Path):
        self._path    = path
        self._fh      = None
        self._evicted = []   # remember which Ollama models to restore

    def __enter__(self):
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self._path, "w")
        logger.info("[GPU-LOCK] Waiting for exclusive GPU access …")
        fcntl.flock(self._fh, fcntl.LOCK_EX)   # blocks until free
        logger.info("[GPU-LOCK] GPU lock acquired.")
        # Evict Ollama *after* the lock is held so we don't disturb a
        # concurrently running MinerU job on another worker.
        self._evicted = _evict_ollama_models()
        return self

    def __exit__(self, *_):
        try:
            _free_gpu_memory()                   # free VRAM before releasing lock
            fcntl.flock(self._fh, fcntl.LOCK_UN)
            self._fh.close()
            logger.info("[GPU-LOCK] GPU lock released.")
        except Exception as exc:
            logger.warning("[GPU-LOCK] Error releasing lock: %s", exc)
        finally:
            # Restore Ollama models after the lock is released so the next
            # queued job is not delayed by model warm-up time.
            if self._evicted:
                _restore_ollama_models(self._evicted)


# ============================================================
# Per-user directory helper
# ============================================================

def _user_input_dir(user_name: str) -> Path:
    d = _BASE_INPUT_DIR / user_name
    d.mkdir(parents=True, exist_ok=True)
    return d


# ============================================================
# Core processing logic
# ============================================================

def _run_mineru_with_lock(pdf_path: Path, output_dir: Path) -> Path:
    """
    Wrap convert_with_mineru in the GPU lock so only one instance runs at a time.
    """
    with _GpuLock(_GPU_LOCK_FILE):
        return convert_with_mineru(pdf_path, output_dir)


def process_single_file(filename: str, user_name: str = "") -> None:
    """
    Full ingestion pipeline for one document file.
    GPU-heavy steps (MinerU OCR) are serialised via _GpuLock.
    On CUDA OOM the function waits OOM_RETRY_WAIT seconds and retries up to
    MAX_OOM_RETRY times before re-raising so the job is marked failed.
    """
    # Resolve file path (per-user dir first, then global fallback)
    if user_name:
        file = _user_input_dir(user_name) / filename
        if not file.exists():
            file = _BASE_INPUT_DIR / filename
    else:
        file = _BASE_INPUT_DIR / filename

    if not file.exists():
        raise FileNotFoundError(f"Document not found on disk: {filename}")

    output_dir   = OUTPUT_DIR
    temp_pdf_dir = output_dir / "_temp_pdfs"
    output_dir.mkdir(parents=True, exist_ok=True)
    temp_pdf_dir.mkdir(parents=True, exist_ok=True)

    cache     = load_cache()
    file_hash = compute_file_hash(file)

    if file_hash in cache:
        logger.info("Already cached, skipping heavy work: %s", filename)
        return

    # ── STEP 1: Convert & OCR (GPU-locked, OOM-retried) ────────────────────
    oom_attempts = 0
    while True:
        try:
            if file.suffix.lower() in OFFICE_EXTENSIONS:
                logger.info("Office→PDF: %s", filename)
                pdf     = convert_office_to_pdf(file, temp_pdf_dir)
                doc_dir = _run_mineru_with_lock(pdf, output_dir)

            elif file.suffix.lower() == ".pdf":
                doc_dir = _run_mineru_with_lock(file, output_dir)

            else:
                # Plain text / CSV / MD — CPU-only Docling path (no lock needed)
                from docling.document_converter import DocumentConverter
                logger.info("Docling fallback: %s", filename)
                docling = DocumentConverter()
                result  = docling.convert(file)
                if not result.document:
                    raise RuntimeError("Docling produced no document")
                doc_dir = output_dir / file.stem
                doc_dir.mkdir(parents=True, exist_ok=True)
                (doc_dir / f"{file.stem}.md").write_text(
                    result.document.export_to_markdown(), encoding="utf-8"
                )
            break  # success – exit retry loop

        except RuntimeError as exc:
            if "CUDA out of memory" in str(exc) and oom_attempts < MAX_OOM_RETRY:
                oom_attempts += 1
                logger.warning(
                    "[OOM] CUDA out of memory on attempt %d/%d for %s — "
                    "clearing VRAM and retrying in %ds …",
                    oom_attempts, MAX_OOM_RETRY, filename, OOM_RETRY_WAIT,
                )
                _free_gpu_memory()
                time.sleep(OOM_RETRY_WAIT)
            else:
                raise  # give up – caller marks job as failed

    # ── STEP 2: Image enrichment + page-tagged markdown ─────────────────────
    json_file = doc_dir / f"{doc_dir.name}.json"
    if json_file.exists():
        enriched_json = enrich_images_with_descriptions(json_file)
        build_final_markdown_from_json(enriched_json)

    # ── STEP 3: Cache update ─────────────────────────────────────────────────
    cache[file_hash] = "cached"
    save_cache(cache)
    logger.info("Done: %s", filename)


def chunk_and_index_for_user(user_name: str) -> None:
    """
    Chunk + vector-store ingestion for all done documents of a user.
    Called after queue is drained to avoid redundant rebuilds.
    Errors here are logged but do NOT affect the job's 'done' status.
    """
    logger.info("[CHUNK+INDEX] Starting for user: %s", user_name)
    try:
        from rag_pipeline import create_contextualized_documents, create_vector_store
        chunks = create_contextualized_documents(user_name=user_name)
        if not chunks:
            logger.warning("[CHUNK+INDEX] No chunks produced for user: %s", user_name)
            return
        logger.info("[CHUNK+INDEX] %d chunks → ingesting into vector store …", len(chunks))
        create_vector_store(chunks)
        logger.info("[CHUNK+INDEX] Vector store ready for user: %s", user_name)
    except Exception as exc:
        logger.error("[CHUNK+INDEX] Failed for user %s: %s", user_name, exc, exc_info=True)


# ============================================================
# Main worker loop
# ============================================================

def run_worker() -> None:
    """Poll the DB, pick up pending jobs one-at-a-time, process them."""
    logger.info(
        "Worker started (GPU-safe mode). "
        "PYTORCH_ALLOC_CONF=%s | Poll interval=%ds",
        os.environ.get("PYTORCH_ALLOC_CONF", "not set"),
        POLL_INTERVAL,
    )

    while True:
        # ── fetch queue ──────────────────────────────────────────────────────
        try:
            pending = shared_db.get_all_pending_jobs()
        except Exception as exc:
            logger.exception("Failed to fetch pending jobs: %s", exc)
            time.sleep(POLL_INTERVAL)
            continue

        if not pending:
            time.sleep(POLL_INTERVAL)
            continue

        # ── pick first job (sequential – safe for GPU) ───────────────────────
        job       = pending[0]
        filename  = job["filename"]
        user_name = job["user_name"]
        logger.info("Picked up job: %s (user: %s)", filename, user_name)

        try:
            shared_db.mark_running(filename, user_name)
            shared_db.update_document_status(filename, user_name, "running")

            process_single_file(filename, user_name)

            # OCR/processing done — mark as indexing (NOT yet queryable)
            # mark_done is called only AFTER vectors are fully written to Qdrant
            shared_db.mark_indexing(filename, user_name)
            shared_db.update_document_status(filename, user_name, "indexing")
            logger.info("Job OCR done, indexing: %s (user: %s)", filename, user_name)

            # Only rebuild the vector index when the user's queue is empty
            remaining = [
                j for j in shared_db.get_all_pending_jobs()
                if j["user_name"] == user_name
            ]
            if remaining:
                logger.info(
                    "[CHUNK+INDEX] %d more job(s) pending for %s — "
                    "deferring index rebuild.",
                    len(remaining), user_name,
                )
            else:
                chunk_and_index_for_user(user_name)

            # Vectors are now fully in Qdrant — document is truly queryable
            shared_db.mark_done(filename, user_name)
            shared_db.update_document_status(filename, user_name, "done")
            logger.info("Job fully ready (vectors indexed): %s (user: %s)", filename, user_name)

        except Exception as exc:
            _free_gpu_memory()   # always free VRAM even on failure
            shared_db.mark_failed(filename, str(exc), user_name)
            shared_db.update_document_status(filename, user_name, "failed")
            logger.error("Job failed [%s]: %s", filename, exc, exc_info=True)

        # Small pause before picking the next job
        time.sleep(JOB_PAUSE)


if __name__ == "__main__":
    run_worker()
