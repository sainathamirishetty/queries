import time
import uuid
import tempfile
import shutil
from pathlib import Path

import streamlit as st

from config import SUPPORTED_EXTENSIONS, MAX_FILES, SOFT_LINE_LIMIT
from code_reader import read_code_file, build_code_context
from ollama_connect import (
    build_prompt,
    check_ollama_connection,
    stream_response,
    GenerationStats,
)
from logger import get_logger, activity_log

log = get_logger("app")


# ── page config ───────────────────────────────────────────────

st.set_page_config(
    page_title = "Code Assistant",
    page_icon  = "💻",
    layout     = "wide",
)


# ── Ollama check ──────────────────────────────────────────────

@st.cache_data(ttl=60, show_spinner=False)
def _cached_ollama_check() -> tuple:
    return check_ollama_connection()

_ok, _info = _cached_ollama_check()
log.info(f"Ollama | {'Connected' if _ok else 'NOT reachable'} | {_info}")


# ── client IP ─────────────────────────────────────────────────

def _get_client_ip() -> str:
    try:
        from streamlit import runtime
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        ctx = get_script_run_ctx()
        if ctx is None:
            return "unknown"
        session_info = runtime.get_instance().get_client(ctx.session_id)
        if session_info is None:
            return "unknown"
        return f"{session_info.request.remote_ip}"
    except Exception:
        return "unknown"


# ── session cleanup sentinel ──────────────────────────────────

class _SessionCleanup:
    """
    Deletes all temp files when Streamlit garbage-collects the session
    (browser tab closed / session expired).
    """
    def __init__(self, session_id: str):
        self.session_id = session_id

    def __del__(self):
        try:
            tmp_dirs = st.session_state.get("_tmp_dirs", [])
            for d in tmp_dirs:
                try:
                    p = Path(d)
                    if p.exists():
                        shutil.rmtree(p)
                        log.info(f"Cleaned temp: {p}")
                except Exception:
                    pass
            total_q = st.session_state.get("qa_turn", 0)
            activity_log.log_session_end(self.session_id, total_q)
        except Exception:
            pass


# ── session init ──────────────────────────────────────────────

def _init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = _get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        st.session_state.qa_turn    = 0
        st.session_state._cleanup_sentinel = _SessionCleanup(sid)
        activity_log.log_session_start(sid, ip)
        log.info(f"New session id={sid} ip={ip}")

    defaults = {
        "code_files":    [],      # list of CodeFile objects
        "total_lines":   0,       # running total lines across all files
        "chat_history":  [],      # list of {question, answer}
        "messages":      [],      # list of {role, content} for UI display
        "qa_turn":       0,
        "uploader_key":  0,
        "_tmp_dirs":     [],      # temp dirs to clean on session end
        "_streaming":    False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_session()


# ── helpers ───────────────────────────────────────────────────

def _remove_file(filename: str):
    st.session_state.code_files = [
        f for f in st.session_state.code_files
        if f.filename != filename
    ]
    st.session_state.total_lines = sum(
        f.line_count for f in st.session_state.code_files
    )
    log.info(f"Removed file: {filename}")


def _clear_all_files():
    st.session_state.code_files   = []
    st.session_state.total_lines  = 0
    st.session_state.chat_history = []
    st.session_state.messages     = []
    st.session_state.qa_turn      = 0
    st.session_state["uploader_key"] += 1
    log.info("All files cleared by user")


def _do_upload(uploaded_file):
    """Read one uploaded file and add it to session state."""

    # Max files check
    if len(st.session_state.code_files) >= MAX_FILES:
        st.sidebar.error(
            f"Maximum **{MAX_FILES} files** already loaded. "
            f"Remove a file before adding more."
        )
        st.session_state["uploader_key"] += 1
        return

    # Duplicate check
    existing_names = [f.filename for f in st.session_state.code_files]
    if uploaded_file.name in existing_names:
        st.sidebar.warning(f"**{uploaded_file.name}** is already loaded.")
        st.session_state["uploader_key"] += 1
        return

    # Save to temp file
    suffix = Path(uploaded_file.name).suffix
    tmp    = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(uploaded_file.read())
    tmp.flush()
    tmp.close()
    st.session_state["_tmp_dirs"].append(tmp.name)

    # Progress bar — silent fill
    progress_bar = st.sidebar.progress(0)
    st.sidebar.caption(f"⏳ Processing **{uploaded_file.name}**...")

    progress_bar.progress(0.3)
    code_file = read_code_file(tmp.name, uploaded_file.name)
    progress_bar.progress(1.0)

    if code_file.error:
        progress_bar.empty()
        st.sidebar.error(f"Failed to read **{uploaded_file.name}**: {code_file.error}")
        st.session_state["uploader_key"] += 1
        return

    # Add to session
    st.session_state.code_files.append(code_file)
    st.session_state.total_lines += code_file.line_count
    st.session_state["uploader_key"] += 1

    # Log upload
    activity_log.log_file_upload(
        ip         = st.session_state.client_ip,
        filename   = code_file.filename,
        language   = code_file.language,
        line_count = code_file.line_count,
        read_time  = code_file.read_time,
    )

    progress_bar.empty()

    # Soft line limit warning
    if st.session_state.total_lines > SOFT_LINE_LIMIT:
        st.sidebar.warning(
            f"⚠️ Total lines: **{st.session_state.total_lines:,}** — "
            f"responses may be slower on very large codebases."
        )

    log.info(f"Loaded: {code_file.summary}")


# ══════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════

with st.sidebar:

    st.subheader("📂 Upload Code Files")
    st.caption(f"Max {MAX_FILES} files · any language")

    uploaded_files = st.file_uploader(
        label                = "Choose files",
        type                 = SUPPORTED_EXTENSIONS,
        accept_multiple_files = True,
        label_visibility     = "collapsed",
        key                  = f"uploader_{st.session_state.uploader_key}",
    )

    if uploaded_files:
        for uf in uploaded_files:
            _do_upload(uf)

    # Clear all button
    st.button(
        "🗑️ Clear All Files",
        use_container_width = True,
        disabled            = len(st.session_state.code_files) == 0,
        on_click            = _clear_all_files,
    )

    # Loaded files list
    if st.session_state.code_files and not st.session_state._streaming:
        st.divider()
        st.subheader("📋 Loaded Files")

        for cf in st.session_state.code_files:
            col_info, col_btn = st.columns([5, 1])
            with col_info:
                st.markdown(
                    f"**{cf.filename}**  \n"
                    f"{cf.language} · {cf.line_count:,} lines"
                )
            with col_btn:
                if st.button("✕", key=f"remove_{cf.filename}",
                             help=f"Remove {cf.filename}"):
                    _remove_file(cf.filename)
                    st.rerun()

        st.divider()
        st.caption(
            f"Total: **{st.session_state.total_lines:,} lines** "
            f"across **{len(st.session_state.code_files)} file(s)**"
        )


# ══════════════════════════════════════════════════════════════
# MAIN AREA
# ══════════════════════════════════════════════════════════════

st.title("💻 AI Code Assistant")

with st.container(border=True):
    col_about, col_disclaimer = st.columns(2)

    with col_about:
        st.markdown("**About**")
        st.markdown(
            "Upload your code files from the sidebar and ask anything — "
            "explain, debug, refactor, generate, review. "
            "You can also ask general programming questions without uploading files."
        )
    with col_disclaimer:
        st.markdown("**Disclaimer**")
        st.markdown(
            "Answers are generated by an AI model and may not always be accurate. "
            "Always review generated or modified code before using it in production."
        )

st.divider()

# ── display chat history ──────────────────────────────────────

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# ── chat input ────────────────────────────────────────────────

question = st.chat_input(
    placeholder = "Ask about your code, or any programming question...",
)

if question:
    log.info(f"Q [{st.session_state.client_ip}]: {question[:120]}")

    # Show user message immediately
    with st.chat_message("user"):
        st.markdown(question)
    st.session_state.messages.append({"role": "user", "content": question})

    # Build code context from all loaded files
    code_context = build_code_context(st.session_state.code_files)

    # Build prompt
    prompt = build_prompt(
        question     = question,
        code_context = code_context,
        chat_history = st.session_state.chat_history,
    )

    # Stream answer
    stats       = GenerationStats()
    full_answer = ""

    st.session_state["_streaming"] = True

    t_query_start = time.time()   # ← timer starts here

    with st.chat_message("assistant"):
        with st.spinner(""):
            try:
                full_answer = st.write_stream(
                    stream_response(prompt, stats)
                )
            except Exception as exc:
                full_answer = (
                    f"❌ Ollama error: `{exc}`\n\n"
                    "Check Ollama is running and OLLAMA_HOST in config.py is correct."
                )
                st.error(full_answer)
                log.error(f"Ollama error: {exc}")

    elapsed = time.time() - t_query_start   # ← timer ends here

    st.session_state["_streaming"] = False

    # Update state
    st.session_state.qa_turn += 1
    st.session_state.chat_history.append({
        "question": question,
        "answer":   full_answer,
    })
    st.session_state.messages.append({
        "role":    "assistant",
        "content": full_answer,
    })

    # Activity log — IP, question, answer, time
    activity_log.log_qa(
        ip       = st.session_state.client_ip,
        turn     = st.session_state.qa_turn,
        question = question,
        answer   = full_answer,
        elapsed  = elapsed,
    )

    log.info(
        f"QA done | Turn {st.session_state.qa_turn} | "
        f"IP: {st.session_state.client_ip} | "
        f"Time: {elapsed:.2f}s | Files: {len(st.session_state.code_files)}"
    )


# ── footer ────────────────────────────────────────────────────

footer_html = """
<style>
footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #f8fafc;
    color: #64748b;
    text-align: center;
    font-size: 10px;
    padding: 12px 0;
    z-index: 999;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.1);
}
</style>
<footer>
Designed &amp; Developed by DAIV, RCI Team &nbsp;—&nbsp; For Support Call 040-2430 7192
</footer>
"""
st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)
st.markdown(footer_html, unsafe_allow_html=True)
