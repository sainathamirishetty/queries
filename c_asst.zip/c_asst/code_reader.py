import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from config import LANGUAGE_MAP
from logger import get_logger

log = get_logger("code_reader")


# ── result dataclass ──────────────────────────────────────────

@dataclass
class CodeFile:
    filename:   str
    language:   str
    line_count: int
    content:    str
    read_time:  float
    error:      Optional[str] = None

    @property
    def summary(self) -> str:
        return (
            f"{self.filename} | Language: {self.language} "
            f"| Lines: {self.line_count} | ReadTime: {self.read_time:.2f}s"
        )


# ── language detection ────────────────────────────────────────

def detect_language(filename: str) -> str:
    ext = Path(filename).suffix.lstrip(".").lower()
    return LANGUAGE_MAP.get(ext, "Unknown")


# ── file reader ───────────────────────────────────────────────

def read_code_file(file_path: str, original_filename: str) -> CodeFile:
    """
    Read a code file and return a CodeFile dataclass.
    Tries multiple encodings. Never raises — returns error in CodeFile.error.
    """
    t0       = time.perf_counter()
    language = detect_language(original_filename)

    for enc in ["utf-8", "utf-8-sig", "latin-1", "cp1252"]:
        try:
            content    = Path(file_path).read_text(encoding=enc)
            line_count = len(content.splitlines())
            read_time  = time.perf_counter() - t0

            log.info(
                f"Read '{original_filename}' | {language} "
                f"| {line_count} lines | {read_time:.3f}s"
            )

            return CodeFile(
                filename   = original_filename,
                language   = language,
                line_count = line_count,
                content    = content,
                read_time  = read_time,
            )

        except UnicodeDecodeError:
            continue
        except Exception as exc:
            read_time = time.perf_counter() - t0
            log.error(f"Failed to read '{original_filename}': {exc}")
            return CodeFile(
                filename   = original_filename,
                language   = language,
                line_count = 0,
                content    = "",
                read_time  = read_time,
                error      = str(exc),
            )

    # All encodings failed
    read_time = time.perf_counter() - t0
    log.error(f"Cannot decode '{original_filename}' with any supported encoding")
    return CodeFile(
        filename   = original_filename,
        language   = language,
        line_count = 0,
        content    = "",
        read_time  = read_time,
        error      = "Could not decode file with any supported encoding.",
    )


# ── combined context builder ──────────────────────────────────

def build_code_context(code_files: list) -> str:
    """
    Combine all uploaded code files into one clearly structured
    text block to send to the LLM.

    Format per file:
        ════════════════════════════════════════
        [FILE 1: main.py | Language: Python | Lines: 120]
        ════════════════════════════════════════
        <actual code>
    """
    if not code_files:
        return ""

    parts = []
    for i, cf in enumerate(code_files, 1):
        header = (
            f"\n{'═' * 60}\n"
            f"[FILE {i}: {cf.filename} | Language: {cf.language} | Lines: {cf.line_count}]\n"
            f"{'═' * 60}\n"
        )
        parts.append(header + cf.content)

    return "\n\n".join(parts)
