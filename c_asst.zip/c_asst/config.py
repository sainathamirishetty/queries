# ── Ollama Connection ─────────────────────────────────────────
OLLAMA_HOST    = "http://localhost:11434"
OLLAMA_MODEL   = "gpt-oss:20b"          # change to test other models
OLLAMA_TIMEOUT = 300                    # seconds

# ── File Upload Limits ────────────────────────────────────────
MAX_FILES            = 10              # max number of files per session
SOFT_LINE_LIMIT      = 10000          # warn user if total lines exceed this

# ── Supported Code Extensions ─────────────────────────────────
SUPPORTED_EXTENSIONS = [
    # Python
    "py",
    # C / C++
    "c", "h", "cpp", "cc", "cxx", "hpp",
    # Java
    "java",
    # JavaScript / TypeScript
    "js", "ts", "jsx", "tsx",
    # C#
    "cs",
    # Go
    "go",
    # Rust
    "rs",
    # Ruby
    "rb",
    # PHP
    "php",
    # Shell
    "sh", "bash",
    # MATLAB
    "m",
    # VHDL / Verilog
    "vhd", "vhdl", "v", "sv",
    # SQL
    "sql",
    # Kotlin / Swift / Scala
    "kt", "swift", "scala",
    # Web
    "html", "htm", "css", "scss",
    # Config / data
    "json", "yaml", "yml", "toml", "xml",
    # Plain text / markdown
    "txt", "md",
]

# ── Language map — extension → display name ───────────────────
LANGUAGE_MAP = {
    "py":    "Python",
    "c":     "C",
    "h":     "C Header",
    "cpp":   "C++",
    "cc":    "C++",
    "cxx":   "C++",
    "hpp":   "C++ Header",
    "java":  "Java",
    "js":    "JavaScript",
    "ts":    "TypeScript",
    "jsx":   "React JSX",
    "tsx":   "React TSX",
    "cs":    "C#",
    "go":    "Go",
    "rs":    "Rust",
    "rb":    "Ruby",
    "php":   "PHP",
    "sh":    "Shell",
    "bash":  "Bash",
    "m":     "MATLAB",
    "vhd":   "VHDL",
    "vhdl":  "VHDL",
    "v":     "Verilog",
    "sv":    "SystemVerilog",
    "sql":   "SQL",
    "kt":    "Kotlin",
    "swift": "Swift",
    "scala": "Scala",
    "html":  "HTML",
    "htm":   "HTML",
    "css":   "CSS",
    "scss":  "SCSS",
    "json":  "JSON",
    "yaml":  "YAML",
    "yml":   "YAML",
    "toml":  "TOML",
    "xml":   "XML",
    "txt":   "Plain Text",
    "md":    "Markdown",
}

# ── Chat History ──────────────────────────────────────────────
MAX_HISTORY_TURNS = 20              # number of past Q&A turns kept in prompt

# ── Logging ───────────────────────────────────────────────────
LOG_DIR = "logs"
