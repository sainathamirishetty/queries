
import io
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from config import (
    EXTRACTED_DOCS_DIR,
    MAX_PAGES,
    SCANNED_TEXT_THRESHOLD,
    EXTRACTION_MODE,
    EXTRACTION_API_URL,
    EXTRACTION_API_TIMEOUT,
)
from logger import get_logger

log = get_logger("extractor")


# ── result dataclass ──────────────────────────────────────────

@dataclass
class ExtractionResult:
    full_text:           str              = ""
    image_map:           Dict[int, str]   = field(default_factory=dict)
    table_count:         int              = 0
    page_count:          int              = 0
    is_scanned:          bool             = False
    md_saved_path:       Optional[str]    = None
    out_dir:             Optional[str]    = None
    t_page_check:        float            = 0.0
    t_text_extraction:   float            = 0.0
    t_image_extraction:  float            = 0.0
    t_table_extraction:  float            = 0.0
    t_total:             float            = 0.0

    @property
    def summary(self) -> str:
        return (
            f"Pages: {self.page_count} | Chars: {len(self.full_text):,} | "
            f"Images: {len(self.image_map)} | Tables: {self.table_count} | "
            f"Scanned: {self.is_scanned} | Total: {self.t_total:.2f}s"
        )


# ── shared helpers ────────────────────────────────────────────

def _make_output_dir(original_filename: str) -> Path:
    date_str  = datetime.now().strftime("%Y-%m-%d")
    stem      = Path(original_filename).stem
    safe_stem = re.sub(r"[^\w\-]", "_", stem)[:60]
    out_dir   = Path(EXTRACTED_DOCS_DIR) / date_str / safe_stem
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def _table_to_markdown(table: List[List]) -> str:
    """Convert a list-of-lists table to pipe-formatted markdown."""
    if not table or not table[0]:
        return ""
    rows = []
    for row in table:
        normalised = [str(c).strip() if c is not None else "" for c in row]
        if any(normalised):
            rows.append(normalised)
    if not rows:
        return ""
    col_count = max(len(r) for r in rows)
    rows = [r + [""] * (col_count - len(r)) for r in rows]
    col_widths = [
        max(max(len(rows[i][c]) for i in range(len(rows))), 3)
        for c in range(col_count)
    ]
    def _fmt(row):
        return (
            "| "
            + " | ".join(row[c].ljust(col_widths[c]) for c in range(col_count))
            + " |"
        )
    header    = _fmt(rows[0])
    separator = "| " + " | ".join("-" * w for w in col_widths) + " |"
    body      = [_fmt(r) for r in rows[1:]]
    return "\n".join([header, separator] + body)


def _save_image_bytes(img_bytes: bytes, out_dir: Path,
                      img_num: int, ext: str = "png") -> str:
    img_path = out_dir / f"image_{img_num:03d}.{ext}"
    img_path.write_bytes(img_bytes)
    return str(img_path)


def _pil_to_png_bytes(pil_image) -> bytes:
    buf = io.BytesIO()
    pil_image.save(buf, format="PNG")
    return buf.getvalue()


def _save_markdown(text: str, out_dir: Path, stem: str) -> str:
    md_path = out_dir / f"{stem}.md"
    md_path.write_text(text, encoding="utf-8")
    return str(md_path)


# ── PDF extraction via Docling ### using local system────────────────────────────────

def _extract_pdf_docling(file_path: str, out_dir: Path,
                          progress_cb=None) -> Tuple[
    str, Dict[int, str], int, bool, float, float, float, float
]:

    def _cb(fraction: float, msg: str):
        if progress_cb:
            progress_cb(fraction, msg)

    import fitz  # PyMuPDF — fast page check only
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions, EasyOcrOptions
    from docling_core.types.doc import PictureItem, TableItem, SectionHeaderItem

    # ── Step 1: Page count + scanned detection ────────────────
    _cb(0.05, "Checking pages...")
    t0       = time.perf_counter()
    fitz_doc = fitz.open(file_path)
    total_pages = len(fitz_doc)

    if total_pages > MAX_PAGES:
        fitz_doc.close()
        raise ValueError(
            f"Document has {total_pages} pages — limit is {MAX_PAGES}."
        )

    scanned_pages = 0
    for pg in fitz_doc:
        raw = pg.get_text("text").strip()
        if len(raw) < SCANNED_TEXT_THRESHOLD and pg.get_images(full=True):
            scanned_pages += 1
    is_scanned = scanned_pages > (total_pages // 2)
    fitz_doc.close()
    t_page_check = time.perf_counter() - t0

    log.info(
        f"Docling PDF | {total_pages} pages | "
        f"scanned={is_scanned} ({scanned_pages}/{total_pages}) | "
        f"check={t_page_check:.2f}s"
    )

    # ── Step 2: Run Docling conversion ───────────────────────
    _cb(0.15, f"Loading AI models ({total_pages} pages)...")
    t0 = time.perf_counter()

    pipeline_options = PdfPipelineOptions(
        images_scale            = 2.0,
        generate_page_images    = True,
        generate_picture_images = True,
        ocr_options             = EasyOcrOptions(),
    )
    converter = DocumentConverter(
        format_options={
            InputFormat.PDF: PdfFormatOption(
                pipeline_options=pipeline_options
            )
        }
    )

    log.info("Docling: loading models ...")
    _cb(0.25, "Converting PDF — extracting text & tables...")
    conv_res = converter.convert(file_path)
    log.info("Docling: conversion complete")
    _cb(0.60, "Conversion done — saving images...")

    # ── Step 3: Save images ───────────────────────────────────
    image_map:   Dict[int, str] = {}
    img_counter                 = 0

    for element, _ in conv_res.document.iterate_items():
        if isinstance(element, PictureItem):
            img_counter += 1
            img_path = out_dir / f"image_{img_counter:03d}.png"
            try:
                pil_img = element.get_image(conv_res.document)
                if pil_img:
                    pil_img.save(str(img_path), "PNG")
                    image_map[img_counter] = str(img_path)
                    log.debug(f"Saved image {img_counter}: {img_path.name}")
                else:
                    log.warning(f"Image {img_counter}: get_image() returned None")
            except Exception as exc:
                log.warning(f"Failed to save image {img_counter}: {exc}")

    t_images = time.perf_counter() - t0
    log.info(f"Docling: {img_counter} images saved | {t_images:.2f}s")
    _cb(0.80, f"Images saved ({img_counter}) — building markdown...")

    # ── Step 4: Build markdown with page markers ──────────────
    t0       = time.perf_counter()
    lines    = []
    cur_page = 0
    img_idx  = 0   # counts PictureItems in document iteration order

    for element, _ in conv_res.document.iterate_items():

        # Detect page change and inject marker
        page_no = 0
        if hasattr(element, "prov") and element.prov:
            try:
                page_no = int(element.prov[0].page_no)
            except Exception:
                page_no = cur_page

        if page_no > cur_page:
            cur_page = page_no
            lines.append(f"\n<!-- Page {cur_page} -->\n")

        # ── Image → placeholder ───────────────────────────────
        if isinstance(element, PictureItem):
            img_idx += 1
            if img_idx in image_map:
                lines.append(f"\n[Image {img_idx} appears here]\n")

        # ── Table → pipe markdown ─────────────────────────────
        elif isinstance(element, TableItem):
            try:
                tbl_md = element.export_to_markdown()
                if tbl_md and tbl_md.strip():
                    lines.append(f"\n{tbl_md.strip()}\n")
            except Exception as exc:
                log.warning(f"Table export failed: {exc}")

        # ── Section heading ───────────────────────────────────
        elif isinstance(element, SectionHeaderItem):
            text = (getattr(element, "text", None) or "").strip()
            if text:
                lvl = getattr(element, "level", 1) or 1
                lines.append(f"\n{'#' * min(int(lvl), 6)} {text}\n")

        # ── All other text items ──────────────────────────────
        else:
            try:
                text = (getattr(element, "text", None) or "").strip()
                if text:
                    lines.append(text)
            except Exception:
                pass

    # Safety: if Docling returned no page numbers, add single marker
    if cur_page == 0:
        lines.insert(0, "\n<!-- Page 1 -->\n")

    full_text = "\n".join(lines)
    t_text    = time.perf_counter() - t0

    # ── Step 5: Count tables ──────────────────────────────────
    _cb(0.95, "Finalising...")
    t0          = time.perf_counter()
    table_count = len(re.findall(r"\n\|[-| :]+\|", full_text))
    t_tables    = time.perf_counter() - t0

    log.info(
        f"Docling done | pages={cur_page} | images={img_counter} | "
        f"tables={table_count} | chars={len(full_text):,} | "
        f"text={t_text:.2f}s"
    )

    _cb(1.0, "Done")
    return (
        full_text, image_map, table_count, is_scanned,
        t_page_check, t_text, t_images, t_tables,
    )




# ── PDF extraction via API (GPU system) ────────────────

def _extract_pdf_via_api(file_path: str, out_dir: Path,
                          progress_cb=None) -> Tuple[
    str, Dict[int, str], int, bool, float, float, float, float
]:
    """
    Extract PDF by calling the remote GPU server API.
    Sends PDF file → receives markdown + base64 images + metadata.
    Saves images locally to out_dir and builds image_map.

    Returns same tuple as _extract_pdf_docling()

    """
    def _cb(fraction: float, msg: str):
        if progress_cb:
            progress_cb(fraction, msg)

    import requests as _requests
    import base64 as _base64

    log.info(f"API extraction: POST {EXTRACTION_API_URL}/extract")

    _cb(0.10, "Sending PDF to extraction server...")
    t_wall = time.perf_counter()

    with open(file_path, "rb") as pdf_f:
        try:
            _cb(0.20, "Server processing PDF — extracting text & tables...")
            resp = _requests.post(
                f"{EXTRACTION_API_URL}/extract",
                files={"file": ("document.pdf", pdf_f, "application/pdf")},
                timeout=EXTRACTION_API_TIMEOUT,
            )
        except _requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot reach extraction server at {EXTRACTION_API_URL}. "
                "Check GPU server is running."
            )
        except _requests.exceptions.Timeout:
            raise RuntimeError(
                f"Extraction server timed out after {EXTRACTION_API_TIMEOUT}s."
            )

    if resp.status_code != 200:
        raise RuntimeError(
            f"Extraction API returned {resp.status_code}: {resp.text[:300]}"
        )

    data = resp.json()
    t_api = time.perf_counter() - t_wall

    log.info(
        f"API extraction done | pages={data.get('page_count', '?')} | "
        f"images={len(data.get('images', {}))} | "
        f"tables={data.get('table_count', 0)} | "
        f"api_time={t_api:.2f}s"
    )

    _cb(0.75, "Saving images locally...")
    # ── Save images from base64 → local PNG files ─────────────
    image_map: Dict[int, str] = {}
    t0 = time.perf_counter()

    for num_str, b64_str in data.get("images", {}).items():
        try:
            num      = int(num_str)
            img_bytes = _base64.b64decode(b64_str)
            img_path  = out_dir / f"image_{num:03d}.png"
            img_path.write_bytes(img_bytes)
            image_map[num] = str(img_path)
            log.debug(f"Saved API image {num}: {img_path.name}")
        except Exception as exc:
            log.warning(f"Failed to save API image {num_str}: {exc}")

    t_images = time.perf_counter() - t0

    # ── Pull timings from server response ─────────────────────
    timings = data.get("timings", {})

    _cb(1.0, "Done")
    return (
        data.get("markdown", ""),
        image_map,
        data.get("table_count", 0),
        data.get("is_scanned", False),
        timings.get("page_check", 0.0),
        timings.get("text", t_api),
        t_images,
        timings.get("tables", 0.0),
    )

# ── DOCX extraction ───────────────────────────────────────────

def _extract_docx(file_path: str, out_dir: Path,
                   progress_cb=None) -> Tuple[
    str, Dict[int, str], int, float, float, float
]:
    def _cb(fraction: float, msg: str):
        if progress_cb:
            progress_cb(fraction, msg)

    _cb(0.10, "Reading document structure...")
    from docx import Document

    doc = Document(file_path)
    _cb(0.30, "Extracting text, images & tables...")

    parts:       List[str]      = ["<!-- Page 1 -->\n"]
    image_map:   Dict[int, str] = {}
    img_counter                 = 0
    table_count                 = 0
    saved_rids:  Dict[str, int] = {}

    t_text = t_images = t_tables = 0.0

    tbl_lookup = {t._tbl: t for t in doc.tables}
    NS_REL     = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    def _get_inline_image_rids(para_xml) -> List[str]:
        rids = []
        for elem in para_xml.iter():
            local = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
            if local == "blip":
                rid = elem.get(f"{{{NS_REL}}}embed")
                if rid:
                    rids.append(rid)
        return rids

    for child in doc.element.body:
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag

        if tag == "p":
            t0 = time.perf_counter()
            from docx.text.paragraph import Paragraph as _Para
            para = _Para(child, doc)
            text = para.text.strip()
            if text:
                if para.style.name.startswith("Heading"):
                    lvl = "".join(c for c in para.style.name if c.isdigit()) or "1"
                    parts.append(f"\n{'#' * int(lvl)} {text}\n")
                else:
                    parts.append(text)
            t_text += time.perf_counter() - t0

            t0 = time.perf_counter()
            for rid in _get_inline_image_rids(child):
                if rid not in saved_rids:
                    try:
                        img_bytes = doc.part.related_parts[rid].blob
                        img_counter += 1
                        img_path = _save_image_bytes(
                            img_bytes, out_dir, img_counter
                        )
                        image_map[img_counter] = img_path
                        saved_rids[rid] = img_counter
                        parts.append(f"\n[Image {img_counter} appears here]\n")
                        log.debug(f"Saved DOCX image {img_counter}")
                    except Exception as exc:
                        log.warning(f"DOCX image {rid} failed: {exc}")
            t_images += time.perf_counter() - t0

        elif tag == "tbl":
            t0      = time.perf_counter()
            tbl_obj = tbl_lookup.get(child)
            if tbl_obj:
                rows = [
                    [cell.text.strip() for cell in row.cells]
                    for row in tbl_obj.rows
                ]
                md = _table_to_markdown(rows)
                if md:
                    table_count += 1
                    parts.append(
                        f"\n\n<!-- Table {table_count} -->\n" + md + "\n"
                    )
            t_tables += time.perf_counter() - t0

    _cb(1.0, "Done")
    return "\n".join(parts), image_map, table_count, t_text, t_images, t_tables


# ── TXT extraction ────────────────────────────────────────────

def _extract_txt(file_path: str) -> str:
    for enc in ["utf-8", "utf-8-sig", "latin-1", "cp1252"]:
        try:
            return "<!-- Page 1 -->\n" + Path(file_path).read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    raise ValueError(
        "Could not decode text file with any supported encoding."
    )


# ── public API ────────────────────────────────────────────────

def extract_document(
    file_path:         str,
    file_ext:          str,
    session_id:        str,
    original_filename: str,
    progress_cb=None,
) -> ExtractionResult:

    t_wall   = time.perf_counter()
    file_ext = file_ext.lower().lstrip(".")

    TEXT_EXTENSIONS = {
        "txt", "md", "log", "csv", "tsv",
        "html", "htm", "xml", "json",
        "yaml", "yml", "ini", "cfg", "conf",
        "toml", "env", "rtf",
        "py", "pyw", "c", "h", "cpp", "cc",
        "cxx", "hpp", "cs", "java", "js", "ts",
        "jsx", "tsx", "css", "scss", "vue",
        "sh", "bash", "ps1", "rb", "php",
        "go", "rs", "sql", "r", "lua", "pl",
        "scala", "kt", "swift",
    }

    if file_ext not in ("pdf", "docx") and file_ext not in TEXT_EXTENSIONS:
        raise ValueError(f"Unsupported file type: .{file_ext}")

    out_dir = _make_output_dir(original_filename)
    stem    = Path(original_filename).stem
    res     = ExtractionResult()

    if file_ext == "pdf":
        if EXTRACTION_MODE == "api":
            log.info(f"PDF extraction mode: API → {EXTRACTION_API_URL}")
            _extractor = _extract_pdf_via_api
        else:
            log.info("PDF extraction mode: local Docling")
            _extractor = _extract_pdf_docling
        (
            res.full_text,
            res.image_map,
            res.table_count,
            res.is_scanned,
            res.t_page_check,
            res.t_text_extraction,
            res.t_image_extraction,
            res.t_table_extraction,
        ) = _extractor(file_path, out_dir, progress_cb=progress_cb)
        res.page_count = len(
            re.findall(r"<!-- Page \d+ -->", res.full_text)
        )

    elif file_ext == "docx":
        (
            res.full_text,
            res.image_map,
            res.table_count,
            res.t_text_extraction,
            res.t_image_extraction,
            res.t_table_extraction,
        ) = _extract_docx(file_path, out_dir, progress_cb=progress_cb)
        res.page_count   = 1
        res.t_page_check = 0.0


    elif file_ext in TEXT_EXTENSIONS:
        if progress_cb: progress_cb(0.20, "Reading file...")
        t0 = time.perf_counter()
        res.full_text = _extract_txt(file_path)
        res.t_text_extraction = time.perf_counter() - t0
        res.page_count = 1
        if progress_cb: progress_cb(1.0, "Done")

    if res.page_count > MAX_PAGES:
        raise ValueError(
            f"Document has {res.page_count} pages — limit is {MAX_PAGES}pages."
        )

    res.md_saved_path = _save_markdown(res.full_text, out_dir, stem)
    res.out_dir       = str(out_dir)
    res.t_total       = time.perf_counter() - t_wall

    log.info(f"Extracted '{original_filename}' → {res.summary}")
    return res


def cleanup_session_images(session_id: str, out_dirs: list):
    """Delete all extracted output folders for this session."""
    import shutil
    for dir_path in out_dirs:
        try:
            p = Path(dir_path)
            if p.exists() and p.is_dir():
                shutil.rmtree(p)
                log.info(f"Cleaned up session folder: {p}")
        except Exception as exc:
            log.warning(f"Failed to delete {dir_path}: {exc}")
