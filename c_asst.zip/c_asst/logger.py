import logging
from datetime import datetime
from pathlib import Path

from config import LOG_DIR as _LOG_DIR_STR

LOG_DIR = Path(_LOG_DIR_STR)
LOG_DIR.mkdir(exist_ok=True)

_DATE_FMT   = "%Y-%m-%d %H:%M:%S"
_SYSTEM_FMT = "[%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s"


# ── system logger ─────────────────────────────────────────────

def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(f"system.{name}")
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter(
        "[%(asctime)s] [%(levelname)-8s] %(message)s", datefmt=_DATE_FMT
    ))
    logger.addHandler(console)

    log_file = LOG_DIR / f"code_system_{datetime.now().strftime('%Y-%m-%d')}.log"
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_SYSTEM_FMT, datefmt=_DATE_FMT))
    logger.addHandler(fh)

    return logger


# ── activity logger ───────────────────────────────────────────

class ActivityLogger:
    """
    Logs two things only:
      1. File uploads  — filename, language, line count, read time
      2. Q&A turns     — IP, question, answer, time taken (query → last token)
    """

    def __init__(self):
        self._logger = logging.getLogger("code_activity")
        if self._logger.handlers:
            return

        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        log_file = LOG_DIR / f"code_activity_{datetime.now().strftime('%Y-%m-%d')}.log"
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(logging.INFO)
        fh.setFormatter(logging.Formatter("%(message)s"))
        self._logger.addHandler(fh)

    def _write(self, line: str):
        self._logger.info(line)

    # ── session ───────────────────────────────────────────────

    def log_session_start(self, session_id: str, ip: str):
        self._write(
            f"\n{'═' * 80}\n"
            f"SESSION    | {datetime.now().strftime(_DATE_FMT)} "
            f"| IP: {ip} | Session: {session_id}"
        )

    def log_session_end(self, session_id: str, total_questions: int):
        self._write(
            f"SESSION END| {datetime.now().strftime(_DATE_FMT)} "
            f"| Session: {session_id} | Total Questions: {total_questions}\n"
            f"{'═' * 80}"
        )

    # ── file upload ───────────────────────────────────────────

    def log_file_upload(self, ip: str, filename: str, language: str,
                        line_count: int, read_time: float):
        self._write(
            f"FILE       | {datetime.now().strftime(_DATE_FMT)} "
            f"| IP: {ip} | {filename} "
            f"| Language: {language} | Lines: {line_count} "
            f"| ReadTime: {read_time:.2f}s"
        )

    # ── Q&A ───────────────────────────────────────────────────

    def log_qa(self, ip: str, turn: int,
               question: str, answer: str, elapsed: float):
        question = question.replace("\n", " ").strip()
        answer   = answer.strip()
        self._write(
            f"{'─' * 80}\n"
            f"{datetime.now().strftime(_DATE_FMT)} | IP: {ip} | Turn: {turn}\n"
            f"QUESTION:\n{question}\n"
            f"ANSWER:\n{answer}\n"
            f"TIME: {elapsed:.2f}s"
        )


# ── single shared instance ────────────────────────────────────
activity_log = ActivityLogger()
