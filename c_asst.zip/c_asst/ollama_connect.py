import json
import time
from dataclasses import dataclass
from typing import Generator, List, Tuple

import requests

from config import (
    MAX_HISTORY_TURNS,
    OLLAMA_HOST,
    OLLAMA_MODEL,
    OLLAMA_TIMEOUT,
)
from logger import get_logger

log = get_logger("ollama")


# ── generation stats ──────────────────────────────────────────

@dataclass
class GenerationStats:
    t_start:         float = 0.0
    t_total:         float = 0.0
    chars_generated: int   = 0

    @property
    def chars_per_sec(self) -> float:
        return self.chars_generated / self.t_total if self.t_total > 0 else 0.0


# ── system prompt ─────────────────────────────────────────────

_SYSTEM_PROMPT = """You are an expert code assistant with deep knowledge across all programming languages including C, C++, Python, Java, JavaScript, TypeScript, Go, Rust, C#, Ruby, PHP, Shell, MATLAB, VHDL, Verilog, SQL, Kotlin, Swift, Scala and more.

You have two modes of operation:

1. UPLOADED FILES MODE — When the user has uploaded code files, they will appear below under "UPLOADED CODE FILES". Use these files as your primary context to answer questions about them. You can:
   - Explain what the code does
   - Find bugs or issues
   - Suggest improvements or refactoring
   - Add features or modify existing code
   - Write tests for the code
   - Explain how files relate to each other
   - Answer any other question about the uploaded code

2. GENERAL MODE — When the user asks general programming questions not related to the uploaded files, answer from your own knowledge. Examples: "how does a pointer work", "write me a quicksort in Python", "what is a deadlock".

GUIDELINES:
- Always format code in proper markdown code blocks with the language specified e.g. ```python
- Be precise and accurate — do not guess or hallucinate code behaviour
- When modifying uploaded code, show the complete modified version clearly
- When explaining, be concise but thorough
- If a question is ambiguous, answer based on the most likely intent
- You can handle both uploaded file questions and general questions in the same conversation
"""


# ── prompt builder ────────────────────────────────────────────

def build_prompt(
    question:     str,
    code_context: str,
    chat_history: list,
) -> str:
    """
    Build the full prompt to send to Ollama.

    Structure:
        System prompt
        + Uploaded files (if any)
        + Conversation history (last N turns)
        + Current question
    """

    # 1. Files block
    files_block = ""
    if code_context.strip():
        files_block = (
            "\n\nUPLOADED CODE FILES:\n"
            + "═" * 60 + "\n"
            + code_context
            + "\n" + "═" * 60
        )
    else:
        files_block = "\n\n[No files uploaded — answer from general knowledge]"

    # 2. Conversation history
    history_block = ""
    if chat_history:
        lines = []
        for turn in chat_history[-MAX_HISTORY_TURNS:]:
            lines.append(f"User: {turn['question']}")
            lines.append(f"Assistant: {turn['answer']}")
            lines.append("")
        history_block = (
            "\n\nCONVERSATION HISTORY:\n"
            + "\n".join(lines)
        )

    # 3. Assemble
    prompt = (
        _SYSTEM_PROMPT
        + files_block
        + history_block
        + "\n\nUSER QUESTION:\n"
        + question
        + "\n\nASSISTANT:"
    )

    log.info(f"Prompt built | {len(prompt):,} chars | history={len(chat_history)} turns")
    return prompt


# ── streaming generator ───────────────────────────────────────

def stream_response(
    prompt: str,
    stats:  GenerationStats,
) -> Generator[str, None, None]:
    """
    Stream tokens from Ollama one by one.
    Updates stats.t_total and stats.chars_generated in place.
    """
    payload = {
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": True,
        "options": {
            "num_ctx":     128000,
            "temperature": 0.2,
            "top_p":       0.9,
            "stop":        ["User:", "USER:"],
        },
    }

    stats.t_start = time.perf_counter()

    with requests.post(
        f"{OLLAMA_HOST}/api/generate",
        json    = payload,
        stream  = True,
        timeout = OLLAMA_TIMEOUT,
    ) as resp:
        resp.raise_for_status()

        for raw in resp.iter_lines():
            if not raw:
                continue
            data  = json.loads(raw)
            token = data.get("response", "")

            if token:
                stats.chars_generated += len(token)
                yield token

            if data.get("done", False):
                break

    stats.t_total = time.perf_counter() - stats.t_start
    log.info(
        f"Stream done | {stats.chars_generated} chars "
        f"| {stats.t_total:.2f}s | {stats.chars_per_sec:.1f} chars/s"
    )


# ── connectivity check ────────────────────────────────────────

def check_ollama_connection() -> Tuple[bool, str]:
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=10)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]

        if OLLAMA_MODEL in models:
            log.info(f"Ollama connected | model={OLLAMA_MODEL}")
            return True, f"Connected — {len(models)} model(s) loaded"
        else:
            msg = f"Model '{OLLAMA_MODEL}' not found. Available: {models}"
            log.warning(msg)
            return False, msg

    except requests.exceptions.ConnectionError:
        msg = f"Cannot reach Ollama at {OLLAMA_HOST}"
        log.warning(msg)
        return False, msg
    except Exception as exc:
        return False, str(exc)
