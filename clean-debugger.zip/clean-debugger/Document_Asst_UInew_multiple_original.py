import re
import uuid
import tempfile
from pathlib import Path

import streamlit as st
import random

from config import SUPPORTED_EXTENSIONS, MAX_HISTORY_TURNS, MAX_IMAGES_PER_QUERY, MAX_PAGES
from extractor import extract_document, cleanup_session_images
from ollama_connect import (
    build_prompt,
    check_ollama_connection,
    stream_response,
    GenerationStats,
)
from logger import get_logger, activity_log

log = get_logger("app")


# ── page config ───────────────────────────────────────────────

st.set_page_config(
    page_title = "Document Assistant",
    page_icon  = "📄",
    layout     = "wide",
)


# ── Ollama check — terminal/log only ─────────────────────────

@st.cache_data(ttl=60, show_spinner=False)
def _cached_ollama_check() -> tuple:
    return check_ollama_connection()

_ok, _info = _cached_ollama_check()
log.info(f"Ollama | {'Connected' if _ok else 'NOT reachable'} | {_info}")


# ── client IP detection ───────────────────────────────────────

def _get_client_ip() -> str:
    try:
        from streamlit import runtime
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        ctx = get_script_run_ctx()
        if ctx is None:
            return "unknown"
        session_info = runtime.get_instance().get_client(ctx.session_id)
        if session_info is None:
            return "unknown"
        return f"{session_info.request.remote_ip}"
    except Exception:
        return "unknown"


# ── session init ──────────────────────────────────────────────

def _init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = _get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        st.session_state.qa_turn    = 0
        activity_log.log_session_start(sid, ip)
        log.info(f"New session id={sid} ip={ip}")

    defaults = {
        # Multi-doc state
        "documents":    [],    # list of doc dicts
        "total_pages":  0,     # running total pages across all docs
        # Chat state
        "chat_history": [],
        "messages":     [],
        "qa_turn":      0,
        # UI state
        "uploader_key": 0,
        "_streaming":   False,
        "_extracting": False
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_session()


# ── helpers ───────────────────────────────────────────────────

_IMAGE_REF_RE = re.compile(r"(?:see\s+)?[Ii]mage\s+(\d+)", re.IGNORECASE)


def _render_referenced_images(answer_text: str, image_map: dict):
    """Parse LLM answer for Image N references and render those images."""
    rendered = []
    seen     = set()
    for m in _IMAGE_REF_RE.finditer(answer_text):
        n = int(m.group(1))
        if n not in seen and n in image_map:
            seen.add(n)
            img_path = image_map[n]
            if Path(img_path).exists():
                rendered.append(img_path)
                st.image(img_path, caption=f"Image {n}", width=700)
    return rendered


def _build_combined_context():
    """
    Combine all ready documents into one text block and one image_map.
    Each document clearly marked with its name for LLM citation.
    Images renumbered globally across all documents.
    """
    combined_text      = ""
    combined_image_map = {}
    global_img_counter = 1

    ready_docs = [
        d for d in st.session_state.documents
        if d["status"] == "ready"
    ]

    for i, doc in enumerate(ready_docs, 1):
        # Document header — LLM uses filename for citation
        combined_text += (
            f"\n{'═' * 60}\n"
            f"[DOCUMENT {i}: {doc['name']} | {doc['page_count']} pages]\n"
            f"{'═' * 60}\n"
        )

        # Replace local image tags with global numbers
        doc_text = doc["full_text"]
        for local_num in sorted(doc["image_map"].keys()):
            path    = doc["image_map"][local_num]
            old_tag = f"[Image {local_num} appears here]"
            new_tag = f"[Image {global_img_counter} appears here]"
            doc_text = doc_text.replace(old_tag, new_tag, 1)
            combined_image_map[global_img_counter] = path
            global_img_counter += 1

        combined_text += doc_text + "\n\n"
        
    print(f"{'=' * 80} FRESH CONVERSATION {'=' * 80}")
    print(combined_text)   # In Terminal it will show all appended Documents.this full length is going to OLLAMA
    print(f"{'=' * 80} ENDING OF ALL DOCUMENTS {'=' * 80}")

    return combined_text, combined_image_map


def _remove_document(doc_name: str):
    """Remove a document from the list and update total pages."""
    st.session_state.documents = [
        d for d in st.session_state.documents
        if d["name"] != doc_name
    ]
    st.session_state.total_pages = sum(
        d["page_count"] for d in st.session_state.documents
    )
    log.info(f"Removed document: {doc_name}")


def _do_extraction(uploaded_file):
    """
    Full extraction pipeline for one document:
    1. Quick page count check
    2. Total pages limit check
    3. Extract with Docling
    4. Add to documents list
    """
    # ── Save uploaded file to temp ────────────────────────────
    suffix = Path(uploaded_file.name).suffix
    tmp    = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(uploaded_file.read())
    tmp.flush()
    tmp.close()

    # ── Quick page count for PDF ──────────────────────────────
    new_pages = 1   # default for DOCX / TXT
    if suffix.lower() == ".pdf":
        try:
            import fitz
            fitz_doc  = fitz.open(tmp.name)
            new_pages = len(fitz_doc)
            fitz_doc.close()
        except Exception:
            new_pages = 1   # fallback if fitz fails

    # ── Total pages limit check ───────────────────────────────
    current_total = st.session_state.total_pages
    if current_total + new_pages > MAX_PAGES:
        st.session_state["uploader_key"] += 1
        st.sidebar.error(
            f"**Cannot add {uploaded_file.name}** ({new_pages} pages).\n\n"
            f"Current total: **{current_total} / {MAX_PAGES} pages** used.\n\n"
            f"Adding this would reach **{current_total + new_pages} pages** "
            f"which exceeds the **{MAX_PAGES} page limit**.\n\n"
            f"Please click ✕ next to an uploaded document to delete, "
            f"then try again."
        )
        log.warning(
            f"Page limit exceeded: {uploaded_file.name} ({new_pages}p) "
            f"+ current ({current_total}p) > {MAX_PAGES}"
        )
        return

    # ── Add to documents list with extracting status ──────────
    doc_entry = {
        "name":        uploaded_file.name,
        "full_text":   "",
        "image_map":   {},
        "page_count":  new_pages,
        "table_count": 0,
        "is_scanned":  False,
        "status":      "extracting",
    }
    
    st.session_state.documents.append(doc_entry)
    print(f"{'&'*50}")
    print(doc_entry)
    print(f"{'&'*50}")
    st.session_state.total_pages += new_pages

    # ── Loading bar + status text ─────────────────────────────
    loading_bar = st.sidebar.empty()
    loading_bar.markdown(
        """
        <style>
        .docqa-loading-wrap {
            width: 100%;
            height: 3px;
            background: rgba(124, 58, 237, 0.15);
            border-radius: 2px;
            overflow: hidden;
            margin: 6px 0 12px 0;
        }
        .docqa-loading-line {
            height: 100%;
            width: 40%;
            background: linear-gradient(
                90deg,
                transparent 0%,
                #7c3aed 40%,
                #a78bfa 60%,
                transparent 100%
            );
            border-radius: 2px;
            animation: docqa-slide 1.4s ease-in-out infinite;
        }
        @keyframes docqa-slide {
            0%   { transform: translateX(-100%); }
            100% { transform: translateX(350%);  }
        }
        </style>
        <div class="docqa-loading-wrap">
            <div class="docqa-loading-line"></div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    status_text = st.sidebar.empty()
    status_text.caption(
        f" I'm Working on **{uploaded_file.name}** — Please wait..."
    )

    # ── Run extraction ────────────────────────────────────────
    try:
        res = extract_document(
            file_path         = tmp.name,
            file_ext          = suffix.lstrip("."),
            session_id        = st.session_state.session_id,
            original_filename = uploaded_file.name,
        )

        # Update document entry in list
        for doc in st.session_state.documents:
            if doc["name"] == uploaded_file.name:
                doc["full_text"]   = res.full_text
                doc["image_map"]   = res.image_map
                doc["page_count"]  = res.page_count
                doc["table_count"] = res.table_count
                doc["is_scanned"]  = res.is_scanned
                doc["status"]      = "ready"
                break

        # Recalculate total from actual page counts
        st.session_state.total_pages = sum(
            d["page_count"] for d in st.session_state.documents
        )

        activity_log.log_document(
            filename = uploaded_file.name,
            pages    = res.page_count,
            chars    = len(res.full_text),
            images   = len(res.image_map),
            tables   = res.table_count,
        )
        activity_log.log_extraction_timing(
            t_page_check = res.t_page_check,
            t_text       = res.t_text_extraction,
            t_images     = res.t_image_extraction,
            t_total      = res.t_total,
            t_tables     = res.t_table_extraction,
        )

        log.info(f"Extracted: {uploaded_file.name} | {res.summary}")
        loading_bar.empty()
        status_text.empty()
        st.sidebar.success(f" {uploaded_file.name} ready!")

    except ValueError as exc:
        # Remove failed doc from list
        st.session_state.documents = [
            d for d in st.session_state.documents
            if d["name"] != uploaded_file.name
        ]
        st.session_state.total_pages = sum(
            d["page_count"] for d in st.session_state.documents
        )
        loading_bar.empty()
        status_text.empty()
        st.session_state["uploader_key"] += 1
        st.sidebar.error(str(exc))
        log.warning(str(exc))

    except Exception as exc:
        # Remove failed doc from list
        st.session_state.documents = [
            d for d in st.session_state.documents
            if d["name"] != uploaded_file.name
        ]
        st.session_state.total_pages = sum(
            d["page_count"] for d in st.session_state.documents
        )
        loading_bar.empty()
        status_text.empty()
        st.session_state["uploader_key"] += 1
        st.sidebar.error(f"Extraction error: {exc}")
        log.exception(str(exc))


def _clear_all_documents():
    """Clear all documents and reset chat."""
    for k, v in {
        "documents":    [],
        "total_pages":  0,
        "chat_history": [],
        "messages":     [],
        "qa_turn":      0,
    }.items():
        st.session_state[k] = v
    st.session_state["uploader_key"] += 1
    log.info("All documents cleared by user")


# ── sidebar ───────────────────────────────────────────────────

with st.sidebar:

    # ── Upload section ─────────────────────────────────────────
    st.subheader("📂 Upload Document")
    st.caption(f"PDF · DOCX · TXT — max {MAX_PAGES} pages total")

    uploaded_file = st.file_uploader(
        label            = "Choose a file",
        type             = SUPPORTED_EXTENSIONS,
        label_visibility = "collapsed",
        key              = f"uploader_{st.session_state.uploader_key}",
        accept_multiple_files=True, #this will enable multiple files at a time,false for single selection
        disabled = st.session_state._extracting
    )
    if st.session_state._extracting:
        st.sidebar.warning(" Extraction in progress, please wait...")
    # Duplicate check then extraction
    if uploaded_file is not None:
        existing_names = [d["name"] for d in st.session_state.documents]
        st.session_state["_extracting"] = True

        for file in uploaded_file:
            if file.name in existing_names:
                st.sidebar.warning(
                    f"**{file.name}** is already loaded."
                )
                st.session_state["uploader_key"] += 1
            else:
                _do_extraction(file)
        st.session_state["_extracting"] = False
        st.session_state["uploader_key"] += 1
    # ── Clear All button ───────────────────────────────────────
    st.button(
        " Clear All Documents",
        use_container_width = True,
        disabled            = len(st.session_state.documents) == 0,
        help                = "Remove all documents and reset chat",
        on_click            = _clear_all_documents,
    )

    # ── Documents list with status ─────────────────────────────
    if st.session_state.documents and not st.session_state._streaming:
        st.divider()
        st.subheader("📋 Documents")

        for doc in st.session_state.documents:
            col_info, col_btn = st.columns([5, 1])

            with col_info:
                if doc["status"] == "ready":
                    scanned = " " if doc["is_scanned"] else ""
                    st.markdown(
                        f" **{doc['name']}**  \n"
                        f"{doc['page_count']} pages "
                        #f"{doc['table_count']} tables{scanned} "
                    )
                elif doc["status"] == "extracting":
                    st.markdown(
                        f" **{doc['name']}**  \n"
                        f" Extracting..."
                    )
                else:
                    st.markdown(
                        f" **{doc['name']}**  \n"
                        f" Failed"
                    )

            with col_btn:
                if st.button(
                    "✕",
                    key  = f"remove_{doc['name']}",
                    help = f"Remove {doc['name']}",
                ):
                    _remove_document(doc["name"])
                    st.rerun()

        # ── Total pages usage ──────────────────────────────────
        st.divider()
        total = st.session_state.total_pages
        st.caption(f"Total: **{total} / {MAX_PAGES}** pages used")
        st.progress(min(total / MAX_PAGES, 1.0))


# ══════════════════════════════════════════════════════════════
# MAIN AREA
# ══════════════════════════════════════════════════════════════

st.title("AI Based Document Assistant")


with st.container(border=True):
    col_about, col_disclaimer = st.columns(2)

    with col_about:
        st.markdown("**About**")
        st.markdown(
            "This application allows you to upload multiple documents — "
            "PDF, DOCX, or TXT from the Sidebar. "
            "Ask questions across all uploaded documents. "
            "It understands text, tables, and images."
        )

    with col_disclaimer:
        st.markdown("**Disclaimer**")
        st.markdown(
            "Answers are generated strictly from the uploaded documents. "
            "The system does not use external knowledge. "
            "Always verify critical information from the original source."
        )

st.divider()

# ── Chat messages ─────────────────────────────────────────────

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        for img_path in msg.get("images", []):
            if Path(img_path).exists():
                st.image(img_path, width=700)

# ── Chat input ────────────────────────────────────────────────

# Enable chat when at least one document is ready
any_ready = any(
    d["status"] == "ready" for d in st.session_state.documents
)

question = st.chat_input(
    placeholder = "Ask about text, tables, charts, or images in your document…",
    disabled    = not any_ready,
)

if question:
    log.info(f"Q: {question[:120]}")

    # Show user message immediately
    with st.chat_message("user"):
        st.markdown(question)
    st.session_state.messages.append({
        "role": "user", "content": question, "images": [], "mode": None,
    })

    # ── Build combined context from all ready docs ─────────────
    combined_text, combined_image_map = _build_combined_context()

    # ── Build prompt ───────────────────────────────────────────
    prompt, images_b64, t_prompt, qtype = build_prompt(
        extracted_text = combined_text,
        chat_history   = st.session_state.chat_history,
        question       = question,
        image_map      = combined_image_map,
    )
    stats = GenerationStats(t_prompt_build=t_prompt)

    log.info(
        f"Prompt: {len(prompt):,} chars | mode={qtype.mode} | "
        f"{len(images_b64)} image(s) | build={t_prompt:.3f}s"
    )

    # ── Stream answer ──────────────────────────────────────────
    full_answer       = ""
    referenced_images = []

    THINKING_MESSAGES = [
        "Analyzing your query against the available documents.",
        "Retrieving the most relevant information.",
        "Processing context to ensure an accurate response.",
        "Searching the knowledge base for matching insights.",
        "Reviewing related content to form a precise answer.",
        "Evaluating document sections for relevance.",
        "Synthesizing information from multiple sources.",
        "Aligning your question with stored knowledge.",
        "Identifying key details required for the response.",
        "Cross-checking facts to improve accuracy.",
        "Understanding the intent behind your question.",
        "Filtering unnecessary information.",
        "Assembling a clear and concise answer.",
        "Validating results before responding.",
        "Matching your query with indexed content.",
        "Optimizing the response for clarity.",
        "Finalizing the answer for delivery.",
    ]

    st.session_state["_streaming"] = True

    with st.spinner(random.choice(THINKING_MESSAGES)):
        try:
            full_answer = st.write_stream(
                stream_response(prompt, images_b64, stats)
            )
        except Exception as exc:
            full_answer = (
                f"❌ Ollama error: `{exc}`\n\n"
                "Check Ollama is running and OLLAMA_HOST in config.py is correct."
            )
            st.error(full_answer)
            log.error(f"Ollama error: {exc}")
            with st.chat_message("assistant"):
                st.markdown(full_answer)

        # Render referenced images below answer
        if combined_image_map:
            referenced_images = _render_referenced_images(
                full_answer, combined_image_map
            )

    st.session_state["_streaming"] = False

    # ── Update session state ───────────────────────────────────
    st.session_state.qa_turn += 1
    st.session_state.chat_history.append({
        "question": question,
        "answer":   full_answer,
    })
    if len(st.session_state.chat_history) > MAX_HISTORY_TURNS:
        st.session_state.chat_history = (
            st.session_state.chat_history[-MAX_HISTORY_TURNS:]
        )

    st.session_state.messages.append({
        "role":    "assistant",
        "content": full_answer,
        "images":  referenced_images,
        "mode":    qtype.mode,
    })

    # ── Activity log ───────────────────────────────────────────
    doc_names = [d["name"] for d in st.session_state.documents]
    activity_log.log_qa(
        turn          = st.session_state.qa_turn,
        question      = question,
        answer        = full_answer,
        t_prompt      = stats.t_prompt_build,
        t_ttft        = stats.t_ttft,
        t_total       = stats.t_total,
        chars_per_sec = stats.chars_per_sec,
        question_type = qtype.mode,
        images_sent   = len(images_b64),
        ip            = st.session_state.client_ip,
    )

    log.info(
        f"QA done | Turn {st.session_state.qa_turn} | "
        f"mode={qtype.mode} | docs={doc_names} | {stats.summary}"
    )


# ── Footer ────────────────────────────────────────────────────

footer_html = """
<style>
footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #f8fafc;
    color: #64748b;
    text-align: center;
    font-size: 10px;
    padding: 12px 0;
    z-index: 999;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.1);
}
</style>
<footer>
Designed &amp; Developed by DAIV, RCI Team &nbsp;—&nbsp; For Support Call 040-2430 7192
</footer>
"""
st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)
st.markdown(footer_html, unsafe_allow_html=True)

