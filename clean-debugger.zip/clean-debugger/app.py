# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  app.py  ·  Main Streamlit entry point
# ═══════════════════════════════════════════════════════════════

import os
import json
import logging
import tempfile
import streamlit as st
from datetime import datetime

from config import (
    OLLAMA_HOST, OLLAMA_MODEL, OLLAMA_TIMEOUT,
    APP_TITLE, APP_SUBTITLE, APP_ICON,
    SUPPORTED_LANGUAGES, PRIORITY_LEVELS,
    REPORT_OUTPUT_DIR,
)
from core.extractor     import extract_from_zip, extract_from_folder, cleanup_temp
from core.prompt_builder import build_debug_prompt, build_chat_prompt
from core.ollama_client  import check_connection, generate, generate_stream
from core.parser         import parse_debug_response, build_run_summary
from core.reporter       import generate_html_report, generate_json_report
from core.chat_history   import (
    new_session_id, save_session, load_history,
    list_sessions, load_session, add_turn
)

# ── Logging ───────────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.FileHandler("logs/clean_debugger.log"),
        logging.StreamHandler(),
    ]
)
logger = logging.getLogger(__name__)

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title=f"{APP_TITLE} — {APP_SUBTITLE}",
    page_icon=APP_ICON,
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Session state init ────────────────────────────────────────────────────────
def _init_state():
    defaults = {
        "files":          [],     # extracted file dicts
        "results":        [],     # parsed debug result dicts
        "debug_done":     False,
        "chat_history":   [],
        "session_id":     new_session_id(),
        "ollama_host":    OLLAMA_HOST,
        "ollama_model":   OLLAMA_MODEL,
        "connection_ok":  None,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val

_init_state()

# ── Language icon map ─────────────────────────────────────────────────────────
LANG_ICONS = {
    "Python": "🐍", "C": "⚙️", "C++": "⚙️",
    "Java": "☕", "MATLAB": "📊",
    "JavaScript": "🟨", "TypeScript": "🔷",
}

# ═════════════════════════════════════════════════════════════════════════════
#  SIDEBAR
# ═════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown(f"## {APP_ICON} {APP_TITLE}")
    st.caption(APP_SUBTITLE)
    st.divider()

    # ── Ollama config ──────────────────────────────────────────────────────
    st.markdown("#### Ollama config")

    host = st.text_input(
        "Server URL",
        value=st.session_state.ollama_host,
        placeholder="http://10.144.177.192:12345",
    )
    model = st.text_input(
        "Model name",
        value=st.session_state.ollama_model,
        placeholder="gpt-oss:20b",
    )

    st.session_state.ollama_host  = host
    st.session_state.ollama_model = model

    # Connection test
    if st.button("Test connection", use_container_width=True):
        with st.spinner("Connecting..."):
            result = check_connection(host)
            st.session_state.connection_ok = result["ok"]
            if result["ok"]:
                st.success(f"Connected · {len(result['models'])} model(s) available")
                if result["models"]:
                    st.caption("Available: " + ", ".join(result["models"][:5]))
            else:
                st.error(result["message"])

    st.divider()

    # ── Upload ─────────────────────────────────────────────────────────────
    st.markdown("#### Upload")

    upload_mode = st.radio(
        "Source",
        ["ZIP file", "Folder path"],
        horizontal=True,
        label_visibility="collapsed",
    )

    uploaded_zip    = None
    folder_path_val = None

    if upload_mode == "ZIP file":
        uploaded_zip = st.file_uploader(
            "Upload ZIP",
            type=["zip"],
            label_visibility="collapsed",
        )
    else:
        folder_path_val = st.text_input(
            "Folder path",
            placeholder="/path/to/your/project",
            label_visibility="collapsed",
        )

    # Supported languages info
    exts = ", ".join(sorted(set(
        e for lang in SUPPORTED_LANGUAGES.values() for e in lang["exts"]
    )))
    st.caption(f"Supported: {exts}")

    # ── Load files button ──────────────────────────────────────────────────
    if st.button("Load files", use_container_width=True):
        with st.spinner("Extracting files..."):
            if upload_mode == "ZIP file" and uploaded_zip:
                # Save uploaded file to temp location
                with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
                    tmp.write(uploaded_zip.read())
                    tmp_path = tmp.name
                files = extract_from_zip(tmp_path)
                os.unlink(tmp_path)
            elif upload_mode == "Folder path" and folder_path_val:
                files = extract_from_folder(folder_path_val)
            else:
                st.warning("Please upload a ZIP or enter a folder path.")
                files = []

            if files:
                st.session_state.files      = files
                st.session_state.results    = []
                st.session_state.debug_done = False
                st.session_state.chat_history = []
                st.success(f"Loaded {len(files)} file(s)")
            else:
                st.error("No supported files found.")

    # ── File list ──────────────────────────────────────────────────────────
    if st.session_state.files:
        st.divider()
        st.markdown(f"#### Files ({len(st.session_state.files)})")

        for i, f in enumerate(st.session_state.files):
            icon = LANG_ICONS.get(f["language"], "📄")
            name = f["path"].split("/")[-1]

            # Show status dot if debug has run
            if st.session_state.results and i < len(st.session_state.results):
                r      = st.session_state.results[i]
                status = "✅" if r["status"] == "clean" else "❌"
                st.caption(f"{status} {icon} {name}")
            else:
                st.caption(f"⬜ {icon} {name}")

    # ── Run debugger ───────────────────────────────────────────────────────
    st.divider()
    run_disabled = not bool(st.session_state.files)
    run_clicked  = st.button(
        "▶ Run Debugger",
        use_container_width=True,
        disabled=run_disabled,
        type="primary",
    )

    # ── Past sessions ──────────────────────────────────────────────────────
    st.divider()
    st.markdown("#### Past sessions")
    sessions = list_sessions()
    if sessions:
        for s in sessions[:5]:
            label = f"{s['session_id']} · {s['turn_count']} turns"
            if st.button(label, use_container_width=True, key=f"sess_{s['session_id']}"):
                history = load_history(s["session_id"])
                st.session_state.chat_history = history
                st.session_state.session_id   = s["session_id"]
                st.rerun()
    else:
        st.caption("No saved sessions yet.")


# ═════════════════════════════════════════════════════════════════════════════
#  MAIN AREA
# ═════════════════════════════════════════════════════════════════════════════

st.markdown(f"# {APP_ICON} {APP_TITLE}")
st.caption(f"{APP_SUBTITLE} · {st.session_state.ollama_model} @ {st.session_state.ollama_host}")
st.divider()

# ── Empty state ───────────────────────────────────────────────────────────────
if not st.session_state.files and not st.session_state.debug_done:
    st.info("Upload a ZIP file or enter a folder path in the sidebar, then click **Load files** to get started.")
    st.stop()

# ═════════════════════════════════════════════════════════════════════════════
#  RUN DEBUGGER
# ═════════════════════════════════════════════════════════════════════════════
if run_clicked and st.session_state.files:
    st.session_state.results    = []
    st.session_state.debug_done = False
    st.session_state.session_id = new_session_id()

    files = st.session_state.files
    model = st.session_state.ollama_model
    host  = st.session_state.ollama_host

    st.markdown(f"### Debugging {len(files)} file(s)...")
    progress = st.progress(0, text="Starting...")

    for i, f in enumerate(files):
        icon = LANG_ICONS.get(f["language"], "📄")
        progress.progress((i) / len(files), text=f"Analyzing {icon} {f['path']} ...")

        with st.expander(f"{icon} {f['path']}  —  analyzing...", expanded=True):
            response_placeholder = st.empty()
            raw_text = ""

            try:
                # Stream response live into UI
                prompt = build_debug_prompt(f)
                for token in generate_stream(prompt, model=model, host=host):
                    raw_text += token
                    response_placeholder.markdown(
                        f"```\n{raw_text}\n```", unsafe_allow_html=False
                    )
            except Exception as e:
                raw_text = f"Error calling Ollama: {e}"
                response_placeholder.error(raw_text)

            # Parse the completed response
            parsed = parse_debug_response(raw_text)
            st.session_state.results.append(parsed)

        progress.progress((i + 1) / len(files), text=f"Done: {f['path']}")

    progress.empty()
    st.session_state.debug_done = True
    st.rerun()


# ═════════════════════════════════════════════════════════════════════════════
#  RESULTS DISPLAY
# ═════════════════════════════════════════════════════════════════════════════
if st.session_state.debug_done and st.session_state.results:

    files   = st.session_state.files
    results = st.session_state.results
    summary = build_run_summary(results)

    # ── Summary metrics ────────────────────────────────────────────────────
    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Files analyzed",       summary["total"])
    col2.metric("Files with errors",    summary["error_count"])
    col3.metric("Clean files",          summary["clean_count"])
    col4.metric("Total errors found",   summary["total_errors"])
    col5.metric("Modifications needed", summary["total_mods"])

    st.divider()

    # ── Download buttons ───────────────────────────────────────────────────
    model     = st.session_state.ollama_model
    html_str  = generate_html_report(files, results, model)
    json_data = generate_json_report(files, results, model)

    dl_col1, dl_col2, _ = st.columns([1, 1, 4])
    with dl_col1:
        st.download_button(
            label="⬇ Download HTML report",
            data=html_str,
            file_name=f"clean_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
            mime="text/html",
            use_container_width=True,
        )
    with dl_col2:
        st.download_button(
            label="⬇ Download JSON report",
            data=json.dumps(json_data, indent=2),
            file_name=f"clean_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json",
            use_container_width=True,
        )

    st.divider()
    st.markdown("### Results")

    # ── Per-file result cards ──────────────────────────────────────────────
    for f, r in zip(files, results):
        icon     = LANG_ICONS.get(f["language"], "📄")
        is_clean = r["status"] == "clean"
        status   = "✅ Clean" if is_clean else f"❌ {len(r['errors'])} error(s) · {len(r['modifications'])} modification(s)"
        label    = f"{icon} {f['path']}  —  {status}"

        with st.expander(label, expanded=not is_clean):

            tab_errors, tab_mods, tab_summary, tab_raw = st.tabs([
                f"Errors ({len(r['errors'])})",
                f"Modifications ({len(r['modifications'])})",
                "Summary",
                "Raw output",
            ])

            # ── Errors tab ────────────────────────────────────────────────
            with tab_errors:
                if not r["errors"]:
                    st.success("No errors detected in this file.")
                else:
                    for e in r["errors"]:
                        with st.container(border=True):
                            c1, c2 = st.columns([1, 4])
                            c1.code(f"Line {e['line']}")
                            c2.markdown(f"**{e['type']}**")
                            st.markdown(e["desc"])

            # ── Modifications tab ─────────────────────────────────────────
            with tab_mods:
                if not r["modifications"]:
                    st.success("No modifications needed for this file.")
                else:
                    for m in r["modifications"]:
                        p_cfg = PRIORITY_LEVELS.get(m["priority"], PRIORITY_LEVELS["SUGGESTION"])
                        with st.container(border=True):
                            st.markdown(
                                f"<span style='background:{p_cfg['bg']};color:{p_cfg['color']};"
                                f"padding:2px 10px;border-radius:4px;font-size:12px;font-weight:600;'>"
                                f"{m['priority']}</span>",
                                unsafe_allow_html=True,
                            )
                            if m.get("where"):
                                st.caption(f"📍 {m['where']}")
                            st.markdown(f"**What to change:**  {m['what']}")
                            if m.get("how"):
                                st.info(f"**How to fix:**\n\n{m['how']}")

            # ── Summary tab ───────────────────────────────────────────────
            with tab_summary:
                st.markdown(r.get("summary", "No summary available."))

            # ── Raw output tab ────────────────────────────────────────────
            with tab_raw:
                st.code(r.get("raw", ""), language=None)

    # ═════════════════════════════════════════════════════════════════════
    #  GLOBAL CHAT — talk to all files together
    # ═════════════════════════════════════════════════════════════════════
    st.divider()
    st.markdown("### 💬 Ask about your codebase")
    st.caption(
        "Ask anything about the errors, modifications, or code logic. "
        "The model has full context of all analyzed files."
    )

    # Display existing chat history
    for turn in st.session_state.chat_history:
        role = turn["role"]
        with st.chat_message(role):
            st.markdown(turn["content"])

    # Chat input
    user_input = st.chat_input(
        "e.g. Why does main.py have a memory leak? How do I fix the error in utils.c?"
    )

    if user_input:
        # Show user message
        with st.chat_message("user"):
            st.markdown(user_input)

        # Add to history
        st.session_state.chat_history = add_turn(
            st.session_state.chat_history, "user", user_input
        )

        # Build prompt with full codebase context
        prompt = build_chat_prompt(
            user_question  = user_input,
            all_files      = files,
            debug_results  = results,
            chat_history   = st.session_state.chat_history,
        )

        # Stream response
        with st.chat_message("assistant"):
            response_placeholder = st.empty()
            full_response        = ""

            for token in generate_stream(
                prompt,
                model   = st.session_state.ollama_model,
                host    = st.session_state.ollama_host,
            ):
                full_response += token
                response_placeholder.markdown(full_response + "▌")

            response_placeholder.markdown(full_response)

        # Save assistant response to history
        st.session_state.chat_history = add_turn(
            st.session_state.chat_history, "assistant", full_response
        )

        # Auto-save session to disk
        save_session(
            session_id   = st.session_state.session_id,
            chat_history = st.session_state.chat_history,
            metadata     = {
                "model":          st.session_state.ollama_model,
                "files_analyzed": len(files),
                "file_paths":     [f["path"] for f in files],
            }
        )

        st.rerun()
