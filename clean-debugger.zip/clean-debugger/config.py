# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  config.py  ·  Central configuration for all modules
# ═══════════════════════════════════════════════════════════════

# ── Ollama Connection ────────────────────────────────────────────────────────
OLLAMA_HOST    = "URL"   # your Ollama server IP + port
OLLAMA_MODEL   = "MOdel"                   # model loaded on your GPU
OLLAMA_TIMEOUT = 300                             # seconds before request times out
OLLAMA_STREAM  = True                            # stream tokens live into UI

# ── Supported Languages ──────────────────────────────────────────────────────
# Each entry:
#   key   = language display name
#   exts  = file extensions to scan
#   label = short name sent inside the prompt so model knows the language

SUPPORTED_LANGUAGES = {
    "Python": {
        "exts":  [".py"],
        "label": "Python"
    },
    "C": {
        "exts":  [".c", ".h"],
        "label": "C"
    },
    "C++": {
        "exts":  [".cpp", ".cc", ".cxx", ".hpp"],
        "label": "C++"
    },
    "Java": {
        "exts":  [".java"],
        "label": "Java"
    },
    "MATLAB": {
        "exts":  [".m"],
        "label": "MATLAB"
    },
    "JavaScript": {
        "exts":  [".js", ".mjs"],
        "label": "JavaScript"
    },
    "TypeScript": {
        "exts":  [".ts", ".tsx"],
        "label": "TypeScript"
    },
}

# Flat list of all supported extensions — used by extractor.py for fast lookup
ALL_SUPPORTED_EXTENSIONS = [
    ext
    for lang in SUPPORTED_LANGUAGES.values()
    for ext in lang["exts"]
]

# ── File Extraction ──────────────────────────────────────────────────────────
UPLOAD_TEMP_DIR  = "temp_uploads"    # where ZIP contents are extracted temporarily
MAX_FILE_SIZE_MB = 5                 # skip files larger than this (likely binaries)
MAX_FILES        = 100               # max number of files to debug in one run

# ── Prompt Settings ──────────────────────────────────────────────────────────
MAX_FILE_CHARS = 12000   # truncate file content sent to model if too large
                         # keeps prompt within model context window

# ── Debug Output Parsing ─────────────────────────────────────────────────────
# These section headers must match what prompt_builder.py asks the model to output
SECTION_STATUS        = "STATUS:"
SECTION_ERRORS        = "ERRORS:"
SECTION_MODIFICATIONS = "MODIFICATIONS:"
SECTION_SUMMARY       = "SUMMARY:"

# ── Chat Settings ────────────────────────────────────────────────────────────
# Global chat — user talks to ALL files together after debug run
CHAT_MODE             = "global"          # "global" or "per_file"
MAX_CHAT_HISTORY      = 20                # max turns kept in active context window
CHAT_CONTEXT_FILES    = 3                 # how many most-relevant files to inject per question
CHAT_MAX_CODE_CHARS   = 3000             # max chars of code injected per file into chat context

# ── Chat History (saved to disk) ─────────────────────────────────────────────
CHAT_HISTORY_DIR      = "chat_history"    # folder where sessions are saved
CHAT_HISTORY_FORMAT   = "json"            # saved as JSON — one file per session
# Session filename pattern: chat_history/session_YYYYMMDD_HHMMSS.json

# ── Report Generation ────────────────────────────────────────────────────────
REPORT_OUTPUT_DIR  = "reports"            # folder where generated reports are saved
REPORT_HTML        = True                 # generate HTML report
REPORT_JSON        = True                 # generate JSON report (machine readable)

# ── Logging ──────────────────────────────────────────────────────────────────
LOG_DIR            = "logs"
LOG_LEVEL          = "INFO"               # DEBUG / INFO / WARNING / ERROR
LOG_TO_FILE        = True
LOG_FILENAME       = "clean_debugger.log"

# ── Streamlit UI ─────────────────────────────────────────────────────────────
APP_TITLE          = "Clean"
APP_SUBTITLE       = "Offline Code Debugger"
APP_ICON           = "🧹"
SIDEBAR_WIDTH      = 320                  # pixels — Streamlit default is 300

# ── Priority Levels (used in modifications) ──────────────────────────────────
PRIORITY_LEVELS = {
    "CRITICAL":   {"color": "#A32D2D", "bg": "#FCEBEB", "order": 1},
    "WARNING":    {"color": "#854F0B", "bg": "#FAEEDA", "order": 2},
    "SUGGESTION": {"color": "#3B6D11", "bg": "#EAF3DE", "order": 3},
}
