# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  core/chat_history.py  ·  Save and load chat sessions to disk
# ═══════════════════════════════════════════════════════════════

import os
import json
import logging
from datetime  import datetime
from typing    import List, Dict, Optional

from config import CHAT_HISTORY_DIR, MAX_CHAT_HISTORY

logger = logging.getLogger(__name__)


# ── Session management ────────────────────────────────────────────────────────

def new_session_id() -> str:
    """Generate a session ID based on current timestamp."""
    return datetime.now().strftime("session_%Y%m%d_%H%M%S")


def session_filepath(session_id: str) -> str:
    """Return full path for a session file."""
    os.makedirs(CHAT_HISTORY_DIR, exist_ok=True)
    return os.path.join(CHAT_HISTORY_DIR, f"{session_id}.json")


# ── Save ──────────────────────────────────────────────────────────────────────

def save_session(
    session_id:   str,
    chat_history: List[Dict],
    metadata:     Optional[Dict] = None,
) -> bool:
    """
    Save a chat session to disk as JSON.

    Args:
        session_id   : unique session identifier
        chat_history : list of {role, content, timestamp} dicts
        metadata     : optional extra info (model, files analyzed, etc.)

    Returns:
        True on success, False on failure
    """
    path = session_filepath(session_id)
    payload = {
        "session_id":   session_id,
        "saved_at":     datetime.now().isoformat(),
        "metadata":     metadata or {},
        "chat_history": chat_history,
    }
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        logger.info(f"Chat session saved: {path}")
        return True
    except OSError as e:
        logger.error(f"Failed to save session {session_id}: {e}")
        return False


# ── Load ──────────────────────────────────────────────────────────────────────

def load_session(session_id: str) -> Optional[Dict]:
    """
    Load a chat session from disk.

    Returns:
        Session dict with keys: session_id, saved_at, metadata, chat_history
        or None if not found
    """
    path = session_filepath(session_id)
    if not os.path.exists(path):
        logger.warning(f"Session not found: {path}")
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.error(f"Failed to load session {session_id}: {e}")
        return None


def load_history(session_id: str) -> List[Dict]:
    """
    Load only the chat_history list from a session.
    Returns empty list if session not found.
    """
    session = load_session(session_id)
    if session:
        return session.get("chat_history", [])
    return []


# ── List sessions ─────────────────────────────────────────────────────────────

def list_sessions() -> List[Dict]:
    """
    List all saved sessions sorted by newest first.

    Returns:
        List of { session_id, saved_at, turn_count, files_analyzed }
    """
    os.makedirs(CHAT_HISTORY_DIR, exist_ok=True)
    sessions = []

    for filename in os.listdir(CHAT_HISTORY_DIR):
        if not filename.endswith(".json"):
            continue
        session_id = filename.replace(".json", "")
        session    = load_session(session_id)
        if session:
            meta = session.get("metadata", {})
            sessions.append({
                "session_id":     session_id,
                "saved_at":       session.get("saved_at", ""),
                "turn_count":     len(session.get("chat_history", [])),
                "files_analyzed": meta.get("files_analyzed", 0),
                "model":          meta.get("model", ""),
            })

    sessions.sort(key=lambda s: s["saved_at"], reverse=True)
    return sessions


# ── Add turn ──────────────────────────────────────────────────────────────────

def add_turn(
    chat_history: List[Dict],
    role:         str,
    content:      str,
) -> List[Dict]:
    """
    Append a turn to the chat history list.

    Args:
        chat_history : existing list of turns
        role         : "user" or "assistant"
        content      : message text

    Returns:
        Updated chat history list (trimmed to MAX_CHAT_HISTORY)
    """
    chat_history.append({
        "role":      role,
        "content":   content,
        "timestamp": datetime.now().isoformat(),
    })

    # Keep only the most recent turns to avoid context overflow
    if len(chat_history) > MAX_CHAT_HISTORY * 2:
        chat_history = chat_history[-(MAX_CHAT_HISTORY * 2):]

    return chat_history


# ── Delete session ────────────────────────────────────────────────────────────

def delete_session(session_id: str) -> bool:
    """Delete a saved session file."""
    path = session_filepath(session_id)
    try:
        if os.path.exists(path):
            os.remove(path)
            logger.info(f"Session deleted: {session_id}")
            return True
        return False
    except OSError as e:
        logger.error(f"Failed to delete session {session_id}: {e}")
        return False
