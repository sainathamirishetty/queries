# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  core/extractor.py  ·  Extracts files from ZIP or folder
# ═══════════════════════════════════════════════════════════════

import os
import zipfile
import shutil
import logging
from pathlib import Path
from typing  import List, Dict

from config import (
    ALL_SUPPORTED_EXTENSIONS,
    UPLOAD_TEMP_DIR,
    MAX_FILE_SIZE_MB,
    MAX_FILES,
    SUPPORTED_LANGUAGES,
)

logger = logging.getLogger(__name__)


# ── helpers ───────────────────────────────────────────────────────────────────

def get_language(file_path: str) -> str:
    """Return the language display name for a given file path, or 'Unknown'."""
    ext = Path(file_path).suffix.lower()
    for lang_name, lang_info in SUPPORTED_LANGUAGES.items():
        if ext in lang_info["exts"]:
            return lang_name
    return "Unknown"


def get_language_label(file_path: str) -> str:
    """Return the short label (e.g. 'Python', 'C++') used inside prompts."""
    ext = Path(file_path).suffix.lower()
    for lang_info in SUPPORTED_LANGUAGES.values():
        if ext in lang_info["exts"]:
            return lang_info["label"]
    return "code"


def is_supported(file_path: str) -> bool:
    """Check if a file extension is in the supported list."""
    return Path(file_path).suffix.lower() in ALL_SUPPORTED_EXTENSIONS


def is_within_size_limit(file_path: str) -> bool:
    """Check if file is within MAX_FILE_SIZE_MB."""
    try:
        size_mb = os.path.getsize(file_path) / (1024 * 1024)
        return size_mb <= MAX_FILE_SIZE_MB
    except OSError:
        return False


def read_file_safe(file_path: str) -> str:
    """Read file content with multiple encoding fallbacks."""
    for encoding in ["utf-8", "latin-1", "cp1252"]:
        try:
            with open(file_path, "r", encoding=encoding) as f:
                return f.read()
        except (UnicodeDecodeError, OSError):
            continue
    logger.warning(f"Could not read file: {file_path}")
    return ""


# ── main functions ────────────────────────────────────────────────────────────

def extract_from_zip(zip_path: str) -> List[Dict]:
    """
    Extract a ZIP file to a temp folder and return list of file dicts.

    Returns:
        List of dicts:
        {
            path     : str  — relative path inside ZIP
            abs_path : str  — absolute path on disk after extraction
            content  : str  — file content as string
            language : str  — display name e.g. 'Python'
            label    : str  — prompt label e.g. 'Python'
            lines    : int  — line count
            size_kb  : float
        }
    """
    # Clean and recreate temp dir
    temp_dir = os.path.abspath(UPLOAD_TEMP_DIR)
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir, exist_ok=True)

    files = []

    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(temp_dir)
    except zipfile.BadZipFile as e:
        logger.error(f"Bad ZIP file: {e}")
        return []

    # Walk extracted folder
    for root, dirs, filenames in os.walk(temp_dir):
        # Skip hidden folders like __pycache__, .git
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]

        for filename in sorted(filenames):
            abs_path = os.path.join(root, filename)
            rel_path = os.path.relpath(abs_path, temp_dir)

            if not is_supported(abs_path):
                continue
            if not is_within_size_limit(abs_path):
                logger.warning(f"Skipping large file: {rel_path}")
                continue

            content = read_file_safe(abs_path)
            if not content.strip():
                continue

            files.append(_build_file_dict(rel_path, abs_path, content))

            if len(files) >= MAX_FILES:
                logger.warning(f"Reached MAX_FILES limit ({MAX_FILES}), stopping scan.")
                break

    logger.info(f"Extracted {len(files)} supported files from ZIP.")
    return files


def extract_from_folder(folder_path: str) -> List[Dict]:
    """
    Walk a local folder and return list of file dicts.
    Same return format as extract_from_zip.
    """
    files = []
    folder_path = os.path.abspath(folder_path)

    if not os.path.isdir(folder_path):
        logger.error(f"Folder not found: {folder_path}")
        return []

    for root, dirs, filenames in os.walk(folder_path):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]

        for filename in sorted(filenames):
            abs_path = os.path.join(root, filename)
            rel_path = os.path.relpath(abs_path, folder_path)

            if not is_supported(abs_path):
                continue
            if not is_within_size_limit(abs_path):
                logger.warning(f"Skipping large file: {rel_path}")
                continue

            content = read_file_safe(abs_path)
            if not content.strip():
                continue

            files.append(_build_file_dict(rel_path, abs_path, content))

            if len(files) >= MAX_FILES:
                logger.warning(f"Reached MAX_FILES limit ({MAX_FILES}), stopping scan.")
                break

    logger.info(f"Found {len(files)} supported files in folder.")
    return files


def _build_file_dict(rel_path: str, abs_path: str, content: str) -> Dict:
    """Build the standard file info dictionary."""
    return {
        "path":     rel_path,
        "abs_path": abs_path,
        "content":  content,
        "language": get_language(rel_path),
        "label":    get_language_label(rel_path),
        "lines":    len(content.splitlines()),
        "size_kb":  round(os.path.getsize(abs_path) / 1024, 2),
    }


def cleanup_temp():
    """Remove the temp extraction folder after the session."""
    temp_dir = os.path.abspath(UPLOAD_TEMP_DIR)
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
        logger.info("Temp extraction folder cleaned up.")
