# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  core/ollama_client.py  ·  Ollama API calls + streaming
# ═══════════════════════════════════════════════════════════════

import json
import logging
import requests
from typing import Generator, Optional

from config import (
    OLLAMA_HOST,
    OLLAMA_MODEL,
    OLLAMA_TIMEOUT,
    OLLAMA_STREAM,
)

logger = logging.getLogger(__name__)


# ── Connection check ──────────────────────────────────────────────────────────

def check_connection(host: str = OLLAMA_HOST) -> dict:
    """
    Ping the Ollama server to verify it is reachable.

    Returns:
        { "ok": True/False, "message": str, "models": list }
    """
    try:
        resp = requests.get(f"{host}/api/tags", timeout=10)
        if resp.status_code == 200:
            data   = resp.json()
            models = [m["name"] for m in data.get("models", [])]
            return {"ok": True, "message": "Connected", "models": models}
        return {"ok": False, "message": f"HTTP {resp.status_code}", "models": []}
    except requests.exceptions.ConnectionError:
        return {"ok": False, "message": f"Cannot reach {host} — is Ollama running?", "models": []}
    except requests.exceptions.Timeout:
        return {"ok": False, "message": "Connection timed out", "models": []}
    except Exception as e:
        return {"ok": False, "message": str(e), "models": []}


def check_model(model: str = OLLAMA_MODEL, host: str = OLLAMA_HOST) -> bool:
    """Check if a specific model is available on the Ollama server."""
    result = check_connection(host)
    if not result["ok"]:
        return False
    return any(model in m for m in result["models"])


# ── Non-streaming call ────────────────────────────────────────────────────────

def generate(
    prompt:  str,
    model:   str  = OLLAMA_MODEL,
    host:    str  = OLLAMA_HOST,
    timeout: int  = OLLAMA_TIMEOUT,
) -> Optional[str]:
    """
    Send a prompt to Ollama and return the full response as a string.
    Used when streaming is disabled.

    Returns:
        Response text string, or None on failure.
    """
    url     = f"{host}/api/generate"
    payload = {
        "model":  model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.1,   # low temp = more deterministic debug output
            "num_predict": 4096,  # max tokens in response
        }
    }

    try:
        resp = requests.post(url, json=payload, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        return data.get("response", "")
    except requests.exceptions.Timeout:
        logger.error(f"Ollama request timed out after {timeout}s for model {model}")
        return None
    except requests.exceptions.ConnectionError as e:
        logger.error(f"Ollama connection error: {e}")
        return None
    except requests.exceptions.HTTPError as e:
        logger.error(f"Ollama HTTP error: {e}")
        return None
    except Exception as e:
        logger.error(f"Ollama unexpected error: {e}")
        return None


# ── Streaming call ────────────────────────────────────────────────────────────

def generate_stream(
    prompt:  str,
    model:   str = OLLAMA_MODEL,
    host:    str = OLLAMA_HOST,
    timeout: int = OLLAMA_TIMEOUT,
) -> Generator[str, None, None]:
    """
    Send a prompt to Ollama and yield response tokens one by one.
    Used for live streaming into the Streamlit UI.

    Yields:
        str — each token/chunk as it arrives
    """
    url     = f"{host}/api/generate"
    payload = {
        "model":  model,
        "prompt": prompt,
        "stream": True,
        "options": {
            "temperature": 0.1,
            "num_predict": 4096,
        }
    }

    try:
        with requests.post(url, json=payload, timeout=timeout, stream=True) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line.decode("utf-8"))
                        token = chunk.get("response", "")
                        if token:
                            yield token
                        if chunk.get("done", False):
                            break
                    except json.JSONDecodeError:
                        continue

    except requests.exceptions.Timeout:
        logger.error("Ollama streaming request timed out")
        yield "\n\n[Error: Request timed out]"
    except requests.exceptions.ConnectionError as e:
        logger.error(f"Ollama streaming connection error: {e}")
        yield f"\n\n[Error: Cannot connect to Ollama — {e}]"
    except Exception as e:
        logger.error(f"Ollama streaming error: {e}")
        yield f"\n\n[Error: {e}]"


# ── Unified call (respects config) ───────────────────────────────────────────

def call_ollama(
    prompt:  str,
    model:   str  = OLLAMA_MODEL,
    host:    str  = OLLAMA_HOST,
    timeout: int  = OLLAMA_TIMEOUT,
    stream:  bool = OLLAMA_STREAM,
):
    """
    Unified call — returns a generator if stream=True, string if stream=False.
    Use this in app.py so you don't have to pick manually.
    """
    if stream:
        return generate_stream(prompt, model, host, timeout)
    else:
        return generate(prompt, model, host, timeout)
