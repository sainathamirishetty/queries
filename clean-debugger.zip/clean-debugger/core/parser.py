# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  core/parser.py  ·  Parses raw Ollama response into sections
# ═══════════════════════════════════════════════════════════════

import re
import logging
from typing import Dict, List

logger = logging.getLogger(__name__)


# ── Main parser ───────────────────────────────────────────────────────────────

def parse_debug_response(raw: str) -> Dict:
    """
    Parse the raw model response into a clean structured dict.

    Input  : raw text from Ollama matching the prompt_builder format
    Output : {
        status        : "clean" | "errors" | "unknown"
        errors        : [ {line, type, desc} ]
        modifications : [ {priority, where, what, how} ]
        summary       : str
        raw           : str  — original full response
    }
    """
    result = {
        "status":        "unknown",
        "errors":        [],
        "modifications": [],
        "summary":       "",
        "raw":           raw,
    }

    if not raw or not raw.strip():
        logger.warning("Empty response from model")
        return result

    # ── Status ────────────────────────────────────────────────
    if "STATUS: CLEAN" in raw:
        result["status"] = "clean"
    elif "STATUS: ERRORS_FOUND" in raw:
        result["status"] = "errors"
    else:
        # fallback — infer from content
        result["status"] = "errors" if re.search(r"ERROR_\d+", raw) else "clean"

    # ── Extract ERRORS block ──────────────────────────────────
    errors_block = _extract_block(raw, "ERRORS:", ["MODIFICATIONS:", "SUMMARY:"])
    if errors_block:
        result["errors"] = _parse_errors(errors_block)

    # ── Extract MODIFICATIONS block ───────────────────────────
    mods_block = _extract_block(raw, "MODIFICATIONS:", ["SUMMARY:"])
    if mods_block:
        result["modifications"] = _parse_modifications(mods_block)

    # ── Extract SUMMARY block ─────────────────────────────────
    summary_block = _extract_block(raw, "SUMMARY:", [])
    if summary_block:
        result["summary"] = summary_block.strip()

    logger.debug(
        f"Parsed: status={result['status']} "
        f"errors={len(result['errors'])} "
        f"mods={len(result['modifications'])}"
    )
    return result


# ── Block extractor ───────────────────────────────────────────────────────────

def _extract_block(text: str, start_marker: str, end_markers: List[str]) -> str:
    """
    Extract text between start_marker and the first of end_markers found.
    Returns empty string if start_marker not found.
    """
    idx = text.find(start_marker)
    if idx == -1:
        return ""

    block_start = idx + len(start_marker)
    block_end   = len(text)

    for end in end_markers:
        end_idx = text.find(end, block_start)
        if end_idx != -1 and end_idx < block_end:
            block_end = end_idx

    return text[block_start:block_end].strip()


# ── Errors parser ─────────────────────────────────────────────────────────────

def _parse_errors(block: str) -> List[Dict]:
    """
    Parse the ERRORS block into a list of error dicts.
    Each entry: { line, type, desc }
    """
    errors = []

    # Split on ERROR_N: pattern
    chunks = re.split(r"ERROR_\d+\s*:", block, flags=re.IGNORECASE)

    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue

        line  = _field(chunk, "LINE")
        etype = _field(chunk, "TYPE")
        desc  = _field_multiline(chunk, "DESCRIPTION")

        if desc or etype:
            errors.append({
                "line": line or "?",
                "type": etype or "Error",
                "desc": desc or chunk[:200],
            })

    return errors


# ── Modifications parser ──────────────────────────────────────────────────────

def _parse_modifications(block: str) -> List[Dict]:
    """
    Parse the MODIFICATIONS block into a list of mod dicts.
    Each entry: { priority, where, what, how }
    """
    mods = []

    # Split on MOD_N: pattern
    chunks = re.split(r"MOD_\d+\s*:", block, flags=re.IGNORECASE)

    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue

        priority = _field(chunk, "PRIORITY")
        where    = _field(chunk, "WHERE")
        what     = _field_multiline(chunk, "WHAT", next_fields=["HOW", "WHERE", "PRIORITY"])
        how      = _field_multiline(chunk, "HOW",  next_fields=["WHERE", "PRIORITY", "MOD_"])

        # Normalise priority
        priority = priority.upper() if priority else "SUGGESTION"
        if priority not in ("CRITICAL", "WARNING", "SUGGESTION"):
            priority = "SUGGESTION"

        if what or how:
            mods.append({
                "priority": priority,
                "where":    where or "",
                "what":     what  or "",
                "how":      how   or "",
            })

    # Sort by priority order: CRITICAL → WARNING → SUGGESTION
    order = {"CRITICAL": 0, "WARNING": 1, "SUGGESTION": 2}
    mods.sort(key=lambda m: order.get(m["priority"], 3))

    return mods


# ── Field extractors ──────────────────────────────────────────────────────────

def _field(text: str, key: str) -> str:
    """Extract a single-line field value like 'LINE: 42'."""
    match = re.search(rf"{key}\s*:\s*(.+)", text, re.IGNORECASE)
    return match.group(1).strip() if match else ""


def _field_multiline(text: str, key: str, next_fields: List[str] = None) -> str:
    """
    Extract a potentially multi-line field value.
    Stops at the next known field or end of chunk.
    """
    pattern = rf"{key}\s*:\s*([\s\S]*?)(?={'|'.join(next_fields) + r'|\Z' if next_fields else r'\Z'})"
    if next_fields:
        stop = "|".join([rf"(?={f}\s*:)" for f in next_fields])
        pattern = rf"(?i){key}\s*:([\s\S]*?)(?:{stop}|$)"
    else:
        pattern = rf"(?i){key}\s*:([\s\S]*?)$"

    match = re.search(pattern, text)
    return match.group(1).strip() if match else ""


# ── Summary builder for UI ───────────────────────────────────────────────────

def build_run_summary(results: List[Dict]) -> Dict:
    """
    Build a high-level summary across all file results.

    Returns:
        {
            total         : int
            error_count   : int
            clean_count   : int
            total_errors  : int
            total_mods    : int
            critical_count: int
        }
    """
    error_files   = [r for r in results if r["status"] == "errors"]
    clean_files   = [r for r in results if r["status"] == "clean"]
    all_errors    = [e for r in results for e in r.get("errors", [])]
    all_mods      = [m for r in results for m in r.get("modifications", [])]
    critical_mods = [m for m in all_mods if m["priority"] == "CRITICAL"]

    return {
        "total":          len(results),
        "error_count":    len(error_files),
        "clean_count":    len(clean_files),
        "total_errors":   len(all_errors),
        "total_mods":     len(all_mods),
        "critical_count": len(critical_mods),
    }
