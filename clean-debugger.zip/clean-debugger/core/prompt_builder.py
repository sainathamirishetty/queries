# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  core/prompt_builder.py  ·  Builds all prompts sent to Ollama
# ═══════════════════════════════════════════════════════════════

from typing import List, Dict
from config import MAX_FILE_CHARS, MAX_CHAT_HISTORY, CHAT_MAX_CODE_CHARS


# ── Debug Prompt ──────────────────────────────────────────────────────────────

def build_debug_prompt(file: Dict) -> str:
    """
    Build a structured debug + modification suggestion prompt for one file.

    The model is asked to:
      1. Understand the full script
      2. Find ALL errors with line numbers and types
      3. Suggest modifications the user should make themselves (not rewrite)
      4. Give a priority-ordered modification list
      5. Write an overall summary

    Args:
        file: dict from extractor.py with keys: path, content, label, lines
    """
    content = file["content"]

    # Truncate if file is very large to stay within context window
    if len(content) > MAX_FILE_CHARS:
        content = content[:MAX_FILE_CHARS] + f"\n\n... [truncated at {MAX_FILE_CHARS} chars]"

    label = file["label"]   # e.g. "Python", "C++", "Java"
    path  = file["path"]

    return f"""You are a senior {label} developer and expert code reviewer.

Your job is to:
1. Carefully read and fully understand this {label} source file
2. Find ALL errors — syntax errors, logic errors, runtime errors, memory issues, security issues, bad practices
3. For each error — suggest the exact modification the developer should make themselves. Do NOT rewrite the file.
4. Order modifications by priority: CRITICAL first, then WARNING, then SUGGESTION
5. Write an overall code quality summary

File: {path}
Language: {label}
Lines: {file['lines']}

```{label.lower()}
{content}
```

Respond in EXACTLY this structured format. Do not add any text outside this format:

STATUS: ERRORS_FOUND
(write STATUS: CLEAN only if there are truly zero issues)

ERRORS:
ERROR_1:
  LINE: <line number or range>
  TYPE: <Syntax Error | Logic Error | Runtime Error | Memory Leak | Null Pointer | Security Issue | Bad Practice | Warning>
  DESCRIPTION: <clear explanation of what is wrong and why it is a problem>

ERROR_2:
  LINE: <line number>
  TYPE: <type>
  DESCRIPTION: <description>

(list every error found, numbered ERROR_1, ERROR_2, ...)

MODIFICATIONS:
MOD_1:
  PRIORITY: CRITICAL
  WHERE: <exact location — file name, function name, line number>
  WHAT: <clearly describe what the developer needs to change>
  HOW: <step by step instructions on how to make this change — no full rewrites, guide the developer>

MOD_2:
  PRIORITY: WARNING
  WHERE: <location>
  WHAT: <what to change>
  HOW: <how to change it>

MOD_3:
  PRIORITY: SUGGESTION
  WHERE: <location>
  WHAT: <what to improve>
  HOW: <how to improve it>

(list every modification numbered MOD_1, MOD_2, ...)

SUMMARY:
<Write 3-5 sentences covering: overall code quality, main problems found, which modifications are most urgent, what the developer should fix first, and estimated effort level>"""


# ── Global Chat Prompt ────────────────────────────────────────────────────────

def build_chat_prompt(
    user_question:  str,
    all_files:      List[Dict],
    debug_results:  List[Dict],
    chat_history:   List[Dict],
) -> str:
    """
    Build a global chat prompt so the user can ask questions
    about ALL files and their debug results together.

    Args:
        user_question : the user's latest question
        all_files     : list of file dicts from extractor
        debug_results : list of parsed debug result dicts
        chat_history  : list of {role, content} dicts — recent turns only
    """

    # Build a compact code + result context for each file
    file_contexts = []
    for i, (f, r) in enumerate(zip(all_files, debug_results)):
        code_snippet = f["content"][:CHAT_MAX_CODE_CHARS]
        if len(f["content"]) > CHAT_MAX_CODE_CHARS:
            code_snippet += "\n... [truncated]"

        errors_text = ""
        if r.get("errors"):
            errors_text = "Errors found:\n" + "\n".join([
                f"  - Line {e['line']} [{e['type']}]: {e['desc']}"
                for e in r["errors"]
            ])
        else:
            errors_text = "No errors found."

        mods_text = ""
        if r.get("modifications"):
            mods_text = "Modifications suggested:\n" + "\n".join([
                f"  [{m['priority']}] {m['where']}: {m['what']}"
                for m in r["modifications"]
            ])

        file_contexts.append(f"""--- File {i+1}: {f['path']} ({f['label']}, {f['lines']} lines) ---
{errors_text}
{mods_text}

Source code:
```{f['label'].lower()}
{code_snippet}
```""")

    context_block = "\n\n".join(file_contexts)

    # Build recent chat history block
    history_block = ""
    if chat_history:
        recent = chat_history[-MAX_CHAT_HISTORY:]
        history_lines = []
        for turn in recent:
            role    = "User"    if turn["role"] == "user"      else "Assistant"
            history_lines.append(f"{role}: {turn['content']}")
        history_block = "Previous conversation:\n" + "\n".join(history_lines)

    return f"""You are an expert code reviewer and debugging assistant.

You have already analyzed the following source files and found errors and modification suggestions for each.
The developer is now asking you questions to understand the issues more deeply and learn how to fix them.

Answer clearly, specifically, and reference exact file names and line numbers where relevant.
If the developer asks about a specific file, focus on that file.
If the developer asks a general question, consider all files together.
Never rewrite the entire file — guide the developer on what to change and how.

=== ANALYZED CODEBASE ===
{context_block}

=== CONVERSATION HISTORY ===
{history_block}

=== DEVELOPER QUESTION ===
{user_question}

=== YOUR ANSWER ==="""


# ── System message for chat ───────────────────────────────────────────────────

CHAT_SYSTEM_MESSAGE = """You are a senior software engineer and debugging assistant.
You have deep knowledge of Python, C, C++, Java, MATLAB, JavaScript, and TypeScript.
You explain errors clearly, suggest targeted fixes, and help developers understand root causes.
You never rewrite entire files — you guide the developer step by step."""
