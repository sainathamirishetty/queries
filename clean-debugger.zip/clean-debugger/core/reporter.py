# ═══════════════════════════════════════════════════════════════
#  Clean — Offline Code Debugger
#  core/reporter.py  ·  Generates HTML and JSON reports
# ═══════════════════════════════════════════════════════════════

import os
import json
import logging
from datetime import datetime
from typing   import List, Dict

from config import REPORT_OUTPUT_DIR, OLLAMA_MODEL

logger = logging.getLogger(__name__)

os.makedirs(REPORT_OUTPUT_DIR, exist_ok=True)


# ── HTML Report ───────────────────────────────────────────────────────────────

def generate_html_report(
    files:   List[Dict],
    results: List[Dict],
    model:   str = OLLAMA_MODEL,
) -> str:
    """
    Generate a full standalone HTML report.

    Args:
        files   : list of file dicts from extractor
        results : list of parsed result dicts from parser
        model   : model name used

    Returns:
        HTML string
    """
    now        = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    err_files  = [r for r in results if r["status"] == "errors"]
    ok_files   = [r for r in results if r["status"] == "clean"]
    total_mods = sum(len(r.get("modifications", [])) for r in results)

    cards_html = ""
    for f, r in zip(files, results):
        is_clean   = r["status"] == "clean"
        err_count  = len(r.get("errors", []))
        mod_count  = len(r.get("modifications", []))
        border_clr = "#9FE1CB" if is_clean else "#F09595"
        badge_clr  = "#3B6D11" if is_clean else "#A32D2D"
        badge_bg   = "#EAF3DE" if is_clean else "#FCEBEB"
        badge_txt  = "Clean"   if is_clean else f"{err_count} errors · {mod_count} modifications"

        errors_html = ""
        if r.get("errors"):
            err_rows = "".join([f"""
            <div style="border:1px solid #F7C1C1;border-radius:6px;margin-bottom:8px;overflow:hidden;">
              <div style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:#FCEBEB;">
                <span style="font-family:monospace;font-size:11px;background:#F7C1C1;color:#A32D2D;padding:2px 7px;border-radius:4px;">Line {_esc(e['line'])}</span>
                <span style="font-size:12px;font-weight:600;color:#A32D2D;">{_esc(e['type'])}</span>
              </div>
              <div style="padding:8px 10px;font-size:13px;color:#555;line-height:1.5;">{_esc(e['desc'])}</div>
            </div>""" for e in r["errors"]])
            errors_html = f"""
            <div style="padding:12px 14px;border-bottom:1px solid #f0f0f0;">
              <div style="font-size:11px;font-weight:600;color:#aaa;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px;">Errors</div>
              {err_rows}
            </div>"""

        mods_html = ""
        if r.get("modifications"):
            p_colors = {"CRITICAL": "#A32D2D", "WARNING": "#854F0B", "SUGGESTION": "#3B6D11"}
            p_bgs    = {"CRITICAL": "#FCEBEB", "WARNING": "#FAEEDA", "SUGGESTION": "#EAF3DE"}
            mod_rows = "".join([f"""
            <div style="border:1px solid #e0e0e0;border-radius:6px;margin-bottom:10px;overflow:hidden;">
              <div style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:#f9f9f9;border-bottom:1px solid #f0f0f0;">
                <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;background:{p_bgs.get(m['priority'],'#eee')};color:{p_colors.get(m['priority'],'#666')};">{_esc(m['priority'])}</span>
                <span style="font-size:13px;font-weight:500;">{_esc(m['what'][:80])}</span>
              </div>
              <div style="padding:10px 12px;">
                {f'<div style="font-size:11px;color:#888;font-family:monospace;margin-bottom:6px;">📍 {_esc(m["where"])}</div>' if m.get("where") else ""}
                <div style="font-size:13px;color:#333;margin-bottom:8px;">{_esc(m['what'])}</div>
                {f'<div style="font-size:12px;color:#555;padding:8px 10px;background:#f5f5f5;border-radius:4px;border-left:3px solid #1D9E75;line-height:1.6;"><strong>How to fix:</strong><br/>{_esc(m["how"])}</div>' if m.get("how") else ""}
              </div>
            </div>""" for m in r["modifications"]])
            mods_html = f"""
            <div style="padding:12px 14px;border-bottom:1px solid #f0f0f0;">
              <div style="font-size:11px;font-weight:600;color:#aaa;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px;">Modifications to make</div>
              {mod_rows}
            </div>"""

        summary_html = f"""
        <div style="padding:12px 14px;border-bottom:1px solid #f0f0f0;">
          <div style="font-size:11px;font-weight:600;color:#aaa;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Summary</div>
          <div style="font-size:13px;color:#444;line-height:1.65;background:#fafafa;padding:10px;border-radius:6px;">{_esc(r.get('summary','No summary.'))}</div>
        </div>"""

        raw_html = f"""
        <details style="padding:12px 14px;">
          <summary style="font-size:11px;font-weight:600;color:#aaa;text-transform:uppercase;letter-spacing:0.5px;cursor:pointer;">Raw model output</summary>
          <pre style="font-family:monospace;font-size:11px;white-space:pre-wrap;word-break:break-word;color:#555;line-height:1.6;margin-top:8px;background:#f5f5f5;padding:10px;border-radius:6px;">{_esc(r.get('raw',''))}</pre>
        </details>"""

        lang_icon = {"Python": "🐍", "C": "⚙️", "C++": "⚙️", "Java": "☕", "MATLAB": "📊", "JavaScript": "🟨", "TypeScript": "🔷"}.get(f["language"], "📄")

        cards_html += f"""
        <div style="background:#fff;border:1px solid {border_clr};border-radius:10px;margin-bottom:20px;overflow:hidden;">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#fafafa;border-bottom:1px solid #f0f0f0;">
            <span style="font-family:monospace;font-size:13px;font-weight:500;">{lang_icon} {_esc(f['path'])} &nbsp;<span style="color:#aaa;font-weight:400;">({f['language']} · {f['lines']} lines)</span></span>
            <span style="font-size:11px;padding:3px 10px;border-radius:20px;background:{badge_bg};color:{badge_clr};">{badge_txt}</span>
          </div>
          {errors_html}
          {mods_html}
          {summary_html}
          {raw_html}
        </div>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>Clean — Debug Report</title>
<style>
  body{{font-family:system-ui,sans-serif;max-width:900px;margin:40px auto;padding:0 24px 60px;color:#1a1a1a;background:#f9f9f7;}}
  h1{{font-size:24px;font-weight:500;margin-bottom:4px;}}
  .meta{{font-size:13px;color:#888;margin-bottom:20px;}}
  .chips{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:32px;}}
  .chip{{font-size:12px;padding:5px 12px;border-radius:20px;border:1px solid #ddd;background:#fff;color:#666;}}
  .chip.err{{background:#FCEBEB;color:#A32D2D;border-color:#F7C1C1;}}
  .chip.ok{{background:#EAF3DE;color:#3B6D11;border-color:#C0DD97;}}
  .chip.warn{{background:#FAEEDA;color:#854F0B;border-color:#FAC775;}}
</style>
</head>
<body>
<h1>🧹 Clean — Debug Report</h1>
<div class="meta">Generated: {now} &nbsp;·&nbsp; Model: {model}</div>
<div class="chips">
  <span class="chip">📁 {len(files)} files analyzed</span>
  {"<span class='chip err'>⚠ " + str(len(err_files)) + " files with errors</span>" if err_files else ""}
  {"<span class='chip ok'>✓ " + str(len(ok_files)) + " clean files</span>" if ok_files else ""}
  <span class="chip warn">🔧 {total_mods} modifications suggested</span>
</div>
{cards_html}
</body>
</html>"""

    return html


# ── JSON Report ───────────────────────────────────────────────────────────────

def generate_json_report(
    files:   List[Dict],
    results: List[Dict],
    model:   str = OLLAMA_MODEL,
) -> dict:
    """Generate a machine-readable JSON report dict."""
    return {
        "generated_at": datetime.now().isoformat(),
        "model":        model,
        "summary": {
            "total_files":   len(files),
            "error_files":   len([r for r in results if r["status"] == "errors"]),
            "clean_files":   len([r for r in results if r["status"] == "clean"]),
            "total_errors":  sum(len(r.get("errors", [])) for r in results),
            "total_mods":    sum(len(r.get("modifications", [])) for r in results),
        },
        "files": [
            {
                "path":          f["path"],
                "language":      f["language"],
                "lines":         f["lines"],
                "status":        r["status"],
                "errors":        r.get("errors", []),
                "modifications": r.get("modifications", []),
                "summary":       r.get("summary", ""),
            }
            for f, r in zip(files, results)
        ]
    }


# ── Save to disk ──────────────────────────────────────────────────────────────

def save_reports(
    files:   List[Dict],
    results: List[Dict],
    model:   str = OLLAMA_MODEL,
) -> Dict[str, str]:
    """
    Save both HTML and JSON reports to REPORT_OUTPUT_DIR.

    Returns:
        { "html": <path>, "json": <path> }
    """
    ts        = datetime.now().strftime("%Y%m%d_%H%M%S")
    html_path = os.path.join(REPORT_OUTPUT_DIR, f"report_{ts}.html")
    json_path = os.path.join(REPORT_OUTPUT_DIR, f"report_{ts}.json")

    html_str  = generate_html_report(files, results, model)
    json_data = generate_json_report(files, results, model)

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_str)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(json_data, f, indent=2, ensure_ascii=False)

    logger.info(f"Reports saved: {html_path}, {json_path}")
    return {"html": html_path, "json": json_path}


# ── Utility ───────────────────────────────────────────────────────────────────

def _esc(s: str) -> str:
    """Escape HTML special characters."""
    if not s:
        return ""
    return (str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))
