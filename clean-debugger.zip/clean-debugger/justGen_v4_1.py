import io
import json
import sqlite3
import hashlib
import requests
import streamlit as st
import pandas as pd
from datetime import datetime
from docx import Document
import re
import logging

# login imports
from ldap3 import Server, Connection, ALL, SIMPLE, SUBTREE
from ldap3.core.exceptions import LDAPBindError, LDAPException

# Rich-text editor (pip install streamlit-quill)
try:
    from streamlit_quill import st_quill
    QUILL_OK = True
except ImportError:
    QUILL_OK = False

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════
#  AD AUTH
# ══════════════════════════════════════════════════════════
def ad_auth(username: str, password: str, client_ip: str):
    """Return (True, display_name) on success, (False, error_msg) on failure."""
    domain     = 'hastinapur'
    server_ip  = '172.30.1.136'
    user_principal = f"{domain}\\{username}"
    ldap_server    = f"ldap://{server_ip}"
    server = Server(ldap_server, get_info=ALL, use_ssl=False)

    try:
        conn = Connection(
            server,
            user=user_principal,
            password=password,
            authentication=SIMPLE,
            auto_bind="NO_TLS",
        )

        if not conn.bind():
            logger.warning(f"AD Auth Failed: {username} from {client_ip}")
            return False, "Invalid credentials"

        search_base   = f"DC={domain},DC=res"
        search_filter = f"(&(objectClass=user)(sAMAccountName={username}))"
        conn.search(
            search_base=search_base,
            search_filter=search_filter,
            search_scope=SUBTREE,
            attributes=['displayName'],
        )
        if conn.entries:
            dn       = conn.entries[0].entry_dn
            cn_match = re.search(r'CN=([^,]+)', dn)
            display_name = cn_match.group(1) if cn_match else username
            logger.info(f"AD Auth Success: {username} ({display_name}) from {client_ip}")
            return True, display_name

        logger.info(f"AD Auth Success: {username} from {client_ip}")
        return True, username

    except LDAPBindError as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {e}")
        return False, "Invalid credentials"
    except LDAPException as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {e}")
        return False, "Invalid credentials"
    except Exception as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {e}")
        return False, "Invalid credentials"


# ══════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════
OLLAMA_URL = "http://10.144.177.192:12345/api/generate"
MODEL_NAME = "gpt-oss:20b"
DB_PATH    = "procurement.db"

# ══════════════════════════════════════════════════════════
#  PAGE CONFIG
# ══════════════════════════════════════════════════════════
st.set_page_config(page_title="Procurement Justification Generator", layout="wide")

# ══════════════════════════════════════════════════════════
#  COOKIE MANAGER
# ══════════════════════════════════════════════════════════
try:
    import extra_streamlit_components as stx

    @st.cache_resource
    def _get_cm():
        return stx.CookieManager()

    _cm        = _get_cm()
    COOKIES_OK = True
except Exception:
    _cm        = None
    COOKIES_OK = False


def _set_cookie(key, value):
    if COOKIES_OK:
        _cm.set(key, str(value))


def _get_cookie(key):
    if COOKIES_OK:
        return _cm.get(key)
    return None


def _del_cookie(key):
    if COOKIES_OK:
        try:
            _cm.delete(key)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════
#  DATABASE
# ══════════════════════════════════════════════════════════
def _conn():
    return sqlite3.connect(DB_PATH, check_same_thread=False)


def init_db():
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER,
                title         TEXT    NOT NULL,
                form_data     TEXT,
                conversation  TEXT,
                answers       TEXT,
                justification TEXT,
                created_at    TEXT DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')),
                ad_username   TEXT
            )
        """)
        c.commit()


def db_verify(username, password):
    pw = hashlib.sha256(password.encode()).hexdigest()
    with _conn() as c:
        row = c.execute(
            "SELECT id FROM users WHERE username=? AND password=?",
            (username, pw),
        ).fetchone()
    return row[0] if row else None


def db_get_sessions(user_id):
    with _conn() as c:
        if user_id == 0:   # AD login
            ad_user = st.session_state.username
            return c.execute(
                "SELECT id, title, created_at FROM sessions "
                "WHERE ad_username=? ORDER BY created_at DESC",
                (ad_user,),
            ).fetchall()
        else:
            return c.execute(
                "SELECT id, title, created_at FROM sessions "
                "WHERE user_id=? ORDER BY created_at DESC",
                (user_id,),
            ).fetchall()


def db_save_session(user_id, title, form_data, conversation, answers, justification):
    user_id = user_id or 0
    ad_user = st.session_state.username if user_id == 0 else None
    with _conn() as c:
        cur = c.execute(
            """
            INSERT INTO sessions
            (user_id, title, form_data, conversation, answers,
             justification, ad_username)
            VALUES (?,?,?,?,?,?,?)
            """,
            (
                user_id,
                title,
                json.dumps(form_data),
                json.dumps(conversation),
                json.dumps(answers),
                justification,
                ad_user,
            ),
        )
        c.commit()
        return cur.lastrowid


def db_rename(session_id, new_title):
    with _conn() as c:
        c.execute(
            "UPDATE sessions SET title=? WHERE id=?", (new_title, session_id)
        )
        c.commit()


def db_delete(session_id):
    with _conn() as c:
        c.execute("DELETE FROM sessions WHERE id=?", (session_id,))
        c.commit()


def db_load(session_id):
    with _conn() as c:
        row = c.execute(
            "SELECT form_data, conversation, answers, justification "
            "FROM sessions WHERE id=?",
            (session_id,),
        ).fetchone()
    if not row:
        return None
    return {
        "form_data":     json.loads(row[0]) if row[0] else {},
        "conversation":  json.loads(row[1]) if row[1] else [],
        "answers":       json.loads(row[2]) if row[2] else {},
        "justification": row[3] or "",
    }


# ══════════════════════════════════════════════════════════
#  SESSION STATE DEFAULTS
# ══════════════════════════════════════════════════════════
_DEFAULTS = dict(
    logged_in=False, user_id=None, username=None,
    form_submitted=False, conversation=[], answers={},
    current_question=None, justification_generated=False,
    final_justification="", question_count=0,
    form_data={}, current_session_id=None,
    unsaved_work=False, sessions_list=[],
    show_save_dialog=False,
    rename_id=None, rename_title="",
    delete_id=None,
    pending_new_session=False,
)
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

init_db()


# ══════════════════════════════════════════════════════════
#  RICH-TEXT HELPER  +  TABLE BUILDER
#  Uses st_quill when available; falls back to st.text_area.
#  Each rich_text field gets a collapsible "Insert Table" expander
#  powered by st.data_editor — the table is converted to HTML and
#  appended to the field content when the user clicks "Add Table".
# ══════════════════════════════════════════════════════════

# Full Quill toolbar — bold, italic, underline, strike, alignment,
# lists, headings, font size, color, background, link, image, clean.
# Tables are handled separately via the data_editor builder below.
_QUILL_TOOLBAR = [
    # Text style
    ["bold", "italic", "underline", "strike"],
    # Colour + background
    [{"color": []}, {"background": []}],
    # Font size
    [{"size": ["small", False, "large", "huge"]}],
    # Headings
    [{"header": [1, 2, 3, 4, 5, 6, False]}],
    # Alignment
    [{"align": []}],
    # Lists and indent
    [{"list": "ordered"}, {"list": "bullet"},
     {"indent": "-1"}, {"indent": "+1"}],
    # Extras
    ["blockquote", "code-block"],
    ["link", "image"],
    # Subscript / superscript
    [{"script": "sub"}, {"script": "super"}],
    # Clear
    ["clean"],
]


def _dataframe_to_html(df: pd.DataFrame) -> str:
    """Convert a pandas DataFrame to a plain HTML table string."""
    rows_html = ""
    # Header row
    header_cells = "".join(
        f"<th style='border:1px solid #aaa;padding:6px 10px;"
        f"background:#f0f0f0;font-weight:bold'>{col}</th>"
        for col in df.columns
    )
    rows_html += f"<tr>{header_cells}</tr>"
    # Data rows
    for _, row in df.iterrows():
        cells = "".join(
            f"<td style='border:1px solid #aaa;padding:6px 10px'>{val}</td>"
            for val in row
        )
        rows_html += f"<tr>{cells}</tr>"
    return (
        "<table style='border-collapse:collapse;width:100%;"
        "margin:8px 0'>" + rows_html + "</table><p></p>"
    )


def _table_builder(field_key: str):
    """
    Render a collapsible table-builder expander.
    When the user clicks 'Add Table to Field', the HTML table is
    appended to session_state[field_key].
    """
    tkey   = f"_tbl_{field_key}"   # key for table editor state
    rkey   = f"_tbl_rows_{field_key}"
    ckey   = f"_tbl_cols_{field_key}"

    with st.expander("📊 Insert Table", expanded=False):
        col_r, col_c = st.columns(2)
        with col_r:
            n_rows = st.number_input(
                "Rows", min_value=1, max_value=30, value=st.session_state.get(rkey, 3),
                key=f"_nr_{field_key}",
            )
        with col_c:
            n_cols = st.number_input(
                "Columns", min_value=1, max_value=10, value=st.session_state.get(ckey, 3),
                key=f"_nc_{field_key}",
            )

        st.session_state[rkey] = int(n_rows)
        st.session_state[ckey] = int(n_cols)

        # Build a blank dataframe with editable header names
        col_names = [f"Column {i+1}" for i in range(int(n_cols))]

        # Header row — user renames columns here
        header_df = pd.DataFrame([col_names], columns=col_names)
        st.caption("✏️ Edit column headers in the first row, then fill data below.")
        edited_headers = st.data_editor(
            header_df,
            hide_index=True,
            use_container_width=True,
            key=f"_hdr_{field_key}",
        )
        final_cols = list(edited_headers.iloc[0].values)

        # Data rows
        blank_data = {c: [""] * int(n_rows) for c in final_cols}
        data_df = pd.DataFrame(blank_data)

        # Restore previously edited data if available
        prev = st.session_state.get(tkey)
        if prev is not None and list(prev.columns) == final_cols:
            data_df = prev

        edited_df = st.data_editor(
            data_df,
            hide_index=False,
            use_container_width=True,
            num_rows="dynamic",
            key=f"_dat_{field_key}",
        )
        st.session_state[tkey] = edited_df

        if st.button("➕ Add Table to Field", key=f"_add_{field_key}", type="primary"):
            html_table = _dataframe_to_html(edited_df)
            current = st.session_state.get(field_key, "") or ""
            st.session_state[field_key] = current + html_table
            # Reset editor state
            st.session_state.pop(tkey, None)
            st.rerun()


def rich_text(label: str, key: str, height: int = 150, placeholder: str = ""):
    """
    Render a rich-text editor + table builder for the given session_state key.
    Returns the current HTML value stored in session_state[key].
    """
    st.caption(f"**{label}**")
    if QUILL_OK:
        current_val = st.session_state.get(key, "")
        new_val = st_quill(
            value=current_val,
            html=True,
            toolbar=_QUILL_TOOLBAR,
            key=f"_quill_{key}",
            placeholder=placeholder,
        )
        if new_val is not None:
            st.session_state[key] = new_val
    else:
        # Graceful fallback — plain text area
        st.text_area(
            label, key=key, height=height,
            placeholder=placeholder, label_visibility="collapsed",
        )

    # Table builder always available regardless of Quill
    _table_builder(key)
    return st.session_state.get(key, "")


# ══════════════════════════════════════════════════════════
#  FORM FIELD KEYS  (all prefixed "f_")
# ══════════════════════════════════════════════════════════


def collect_form_data():
    ss = st.session_state
    return {
        # 0. Project/Directorate Name
        "project_name":                   ss.get("f_project_name", ""),
        # 1. Nature of Item
        "nature_of_item":                 ss.get("f_nature_of_item", ""),
        # 2. Item Nomenclature
        "item_nomenclature":              ss.get("f_item_nomenclature", ""),
        # 3. Technical Parameters  (HTML from rich editor)
        "technical_parameters":           ss.get("f_technical_parameters", ""),
        # 4. Committee recommendation
        "any_committee_recommendation":   ss.get("f_any_committee_recommendation", "No"),
        "doc_no":                         ss.get("f_doc_no", ""),
        "date":                           ss.get("f_date").strftime("%Y-%m-%d")
                                          if ss.get("f_date") else None,
        # FIX #1 — MOM suggestions now collected
        "mom_committee_suggestions":      ss.get("f_mom_committee_suggestions", ""),
        # 5. Fresh purchase
        "fresh_purchase":                 ss.get("f_fresh_purchase", "No"),
        # FIX #5 — always store both; UI controls which is editable
        "fresh_purchase_purpose_served":  ss.get("f_fresh_purchase_purpose_served", ""),
        "fresh_purchase_reason":          ss.get("f_fresh_purchase_reason", ""),
        "previous_supply_order_no":       ss.get("f_previous_supply_order_no", ""),
        "previous_supply_order_date":     ss.get("f_previous_supply_order_date").strftime("%Y-%m-%d")
                                          if ss.get("f_previous_supply_order_date") else None,
        # 6. Sensitive items
        "are_items_sensitive":            ss.get("f_are_items_sensitive", "No"),
        "sensitive_items_details":        ss.get("f_sensitive_items_details", ""),
        # 7. SBC
        "sbc_applicable":                 ss.get("f_sbc_applicable", "No"),
        "sbc_doc_no":                     ss.get("f_sbc_doc_no", ""),
        "sbc_doc_date":                   ss.get("f_sbc_doc_date").strftime("%Y-%m-%d")
                                          if ss.get("f_sbc_doc_date") else None,
        "sbc_reason":                     ss.get("f_sbc_reason", ""),
        # 8. Quantity
        "item_quantity":                  ss.get("f_item_quantity", 0),
        # 9. Base of quantity
        "base_of_quantity":               ss.get("f_base_of_quantity", ""),
        # 10. Proposed distribution  (HTML from rich editor)
        "proposed_distribution":          ss.get("f_proposed_distribution", ""),
        # 11. Tender type
        "tender_type":                    ss.get("f_tender_type", ""),
        # FIX #2 — tdoc_no and tdoc_date now collected
        "tdoc_no":                        ss.get("f_tdoc_no", ""),
        "tdoc_date":                      ss.get("f_tdoc_date").strftime("%Y-%m-%d")
                                          if ss.get("f_tdoc_date") else None,
        "tender_type_reason":             ss.get("f_tender_type_reason", ""),
        # 12. Tender mode
        "tender_mode":                    ss.get("f_tender_mode", ""),
        "tender_mode_reason":             ss.get("f_tender_mode_reason", ""),
        # 13. Bid type
        "bid_type":                       ss.get("f_bid_type", ""),
        "bid_type_reason":                ss.get("f_bid_type_reason", ""),
        # 14. Total demand value
        "total_demand_value":             ss.get("f_total_demand_value", 0.0),
        # 15. PAC
        "pac_applicable":                 ss.get("f_pac_applicable", "No"),
        "pac_doc_no":                     ss.get("f_pac_doc_no", ""),
        "pac_reason":                     ss.get("f_pac_reason", ""),
        "pac_doc_date":                   ss.get("f_pac_doc_date").strftime("%Y-%m-%d")
                                          if ss.get("f_pac_doc_date") else None,
    }


def populate_form_fields(form_data):
    ss = st.session_state

    def _date(val):
        """Convert stored string back to date object, or None."""
        if isinstance(val, str) and val:
            try:
                return datetime.strptime(val, "%Y-%m-%d").date()
            except ValueError:
                return None
        return None

    # 0. Project/Directorate Name
    ss["f_project_name"]                  = form_data.get("project_name", "")
    # 1. Nature of Item
    ss["f_nature_of_item"]                = form_data.get("nature_of_item", "ACCESSORIES")
    # 2. Item Nomenclature
    ss["f_item_nomenclature"]             = form_data.get("item_nomenclature", "")
    # 3. Technical Parameters
    ss["f_technical_parameters"]          = form_data.get("technical_parameters", "")
    # 4. Committee recommendation
    ss["f_any_committee_recommendation"]  = form_data.get("any_committee_recommendation", "No")
    ss["f_doc_no"]                        = form_data.get("doc_no", "")
    ss["f_date"]                          = _date(form_data.get("date"))
    # FIX #1 — restore MOM suggestions
    ss["f_mom_committee_suggestions"]     = form_data.get("mom_committee_suggestions", "")
    # 5. Fresh purchase
    ss["f_fresh_purchase"]                = form_data.get("fresh_purchase", "No")
    ss["f_fresh_purchase_purpose_served"] = form_data.get("fresh_purchase_purpose_served", "")
    ss["f_fresh_purchase_reason"]         = form_data.get("fresh_purchase_reason", "")
    ss["f_previous_supply_order_no"]      = form_data.get("previous_supply_order_no", "")
    ss["f_previous_supply_order_date"]    = _date(form_data.get("previous_supply_order_date"))
    # 6. Sensitive items
    ss["f_are_items_sensitive"]           = form_data.get("are_items_sensitive", "No")
    ss["f_sensitive_items_details"]       = form_data.get("sensitive_items_details", "")
    # 7. SBC
    ss["f_sbc_applicable"]                = form_data.get("sbc_applicable", "No")
    ss["f_sbc_doc_no"]                    = form_data.get("sbc_doc_no", "")
    ss["f_sbc_doc_date"]                  = _date(form_data.get("sbc_doc_date"))
    ss["f_sbc_reason"]                    = form_data.get("sbc_reason", "")
    # 8. Quantity
    ss["f_item_quantity"]                 = form_data.get("item_quantity", 0)
    # 9. Base of quantity
    ss["f_base_of_quantity"]              = form_data.get("base_of_quantity", "")
    # 10. Proposed distribution
    ss["f_proposed_distribution"]         = form_data.get("proposed_distribution", "")
    # 11. Tender type
    ss["f_tender_type"]                   = form_data.get("tender_type", "GeM")
    # FIX #2 — restore tdoc fields
    ss["f_tdoc_no"]                       = form_data.get("tdoc_no", "")
    ss["f_tdoc_date"]                     = _date(form_data.get("tdoc_date"))
    ss["f_tender_type_reason"]            = form_data.get("tender_type_reason", "")
    # 12. Tender mode
    ss["f_tender_mode"]                   = form_data.get("tender_mode", "Open")
    ss["f_tender_mode_reason"]            = form_data.get("tender_mode_reason", "")
    # 13. Bid type
    ss["f_bid_type"]                      = form_data.get("bid_type", "Two")
    ss["f_bid_type_reason"]               = form_data.get("bid_type_reason", "")
    # 14. Total demand value
    ss["f_total_demand_value"]            = form_data.get("total_demand_value", 0.0)
    # 15. PAC
    ss["f_pac_applicable"]                = form_data.get("pac_applicable", "No")
    ss["f_pac_doc_no"]                    = form_data.get("pac_doc_no", "")
    ss["f_pac_reason"]                    = form_data.get("pac_reason", "")
    ss["f_pac_doc_date"]                  = _date(form_data.get("pac_doc_date"))


# ══════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════
def refresh_sessions():
    uid = st.session_state.user_id or 0
    st.session_state.sessions_list = db_get_sessions(uid)


def reset_work():
    st.session_state.update(
        form_submitted=False, conversation=[], answers={},
        current_question=None, justification_generated=False,
        final_justification="", question_count=0,
        form_data={}, current_session_id=None, unsaved_work=False,
    )
    populate_form_fields({})


def group_by_date(sessions):
    grouped = {}
    for sid, title, created_at in sessions:
        dt  = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
        key = dt.strftime("%d %b %Y")
        grouped.setdefault(key, []).append((sid, title, dt.strftime("%H:%M")))
    return grouped


def has_active_work():
    any_field = any(
        bool(st.session_state.get(k, ""))
        for k in ("f_initiator_name", "f_item_nomenclature", "f_nature_of_item")
    )
    return any_field or bool(st.session_state.form_data) or bool(st.session_state.conversation)


# ══════════════════════════════════════════════════════════
#  OLLAMA  — FIX #7: UI-level error handling
# ══════════════════════════════════════════════════════════
def call_ollama(prompt):
    try:
        r = requests.post(
            OLLAMA_URL,
            json={"model": MODEL_NAME, "prompt": prompt, "stream": False},
            timeout=120,
        )
        if r.status_code != 200:
            raise Exception(f"Server returned {r.status_code}: {r.text}")
        return r.json()["response"]
    except requests.exceptions.ConnectionError:
        st.error("⚠️ Cannot reach the LLM service. Please check that the Ollama server is running.")
        st.stop()
    except requests.exceptions.Timeout:
        st.error("⚠️ LLM request timed out. The server may be busy — try again.")
        st.stop()
    except Exception as e:
        st.error(f"⚠️ LLM error: {e}")
        st.stop()


# ══════════════════════════════════════════════════════════
#  PROMPTS  — FIX #4: consistent formatting instructions
# ══════════════════════════════════════════════════════════
def build_question_prompt(form_data, conversation, answers):
    return f"""
    You are an enterprise procurement assistant with technical knowledge of the given product.
    Your goal is to collect enough information to generate a detailed procurement justification note.

Rules:
1. Ask only ONE simple question at a time.
2. Questions must dynamically depend on previous answers.
3. Ask questions only regarding:
    - Any additional information the user wants to provide.
    - Why these specific technical specifications were needed and how they were determined.
4. Do not ask duplicate or repeated questions. Return ONLY your single question — no preamble or thinking.
5. After asking exactly 3 questions, respond ONLY with: JUSTIFICATION_COMPLETE

    FORM DATA:
    {json.dumps(form_data, indent=2)}

    ANSWERS SO FAR:
    {json.dumps(answers, indent=2)}

    CONVERSATION HISTORY:
    {conversation}
    """


def build_justification_prompt(form_data, answers):
    # FIX #4 — unified, non-contradictory instructions
    prompt = f"""
You are an enterprise procurement assistant specialised in drafting official justification notes
for government and public-sector purchases.

TONE AND STYLE:
- Neutral, objective, third-person only. Avoid "we", "I", or first-person references.
- No promotional adjectives (e.g., "excellent", "state-of-the-art", "critical", "urgent").
- State facts exactly as supplied. Do not add opinions or recommendations not in the data.
- Use formal, corporate language appropriate for official documentation.
- Do not refer to this form or these instructions in the output.

STRUCTURE:
Produce a single continuous justification note of exactly THREE paragraphs:

1. Technical Justification — Explain how the need for the product arose, referencing relevant
   project details, operational requirements, or regulatory drivers from the form data and answers.

2. Quantity and Distribution Justification — Detail the required quantity, any proposed allocation
   across departments or locations, and why this amount is appropriate.

3. Tender and Bid Explanation — The default procurement settings are:
   Tender type: GeM | Tender mode: Open | Bid type: Two
   Include this paragraph ONLY if any of these defaults differ in the input data, and state the
   officer-supplied reason. If all defaults match, omit this paragraph entirely.

FORMATTING:
- Three plain paragraphs separated by a single blank line. No headings, no bullet points,
  no numbered lists within the paragraphs.
- Where a comparison or allocation table would materially aid clarity, insert one HTML table
  inline using standard <table> tags. Keep all other content as paragraphs.
- Use digits for numbers (e.g., 66.6 kVA, 12 units).
- Elaborate each paragraph fully using the data supplied.

INPUT DATA:

FORM DATA:
{json.dumps(form_data, indent=2)}

QUESTION ANSWERS:
{json.dumps(answers, indent=2)}
    """
    return prompt


# ══════════════════════════════════════════════════════════
#  DOCX EXPORT  (preserves HTML formatting from rich editor)
# ══════════════════════════════════════════════════════════
def _html_to_plain(html_text: str) -> str:
    """Strip HTML tags for plain-text contexts (e.g., DOCX paragraphs)."""
    if not html_text:
        return ""
    clean = re.sub(r'<[^>]+>', ' ', html_text)
    clean = re.sub(r'&nbsp;', ' ', clean)
    clean = re.sub(r'&amp;',  '&', clean)
    clean = re.sub(r'&lt;',   '<', clean)
    clean = re.sub(r'&gt;',   '>', clean)
    return re.sub(r'\s+', ' ', clean).strip()


def generate_docx(item_name, justification_text):
    doc = Document()
    doc.add_heading("Procurement Justification Note", level=1)
    doc.add_paragraph(f"Item: {item_name}")
    doc.add_paragraph(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    doc.add_paragraph("")

    # Split on double newlines or paragraph tags
    paragraphs = re.split(r'\n\n|<br\s*/?>|</p>', justification_text)
    for para in paragraphs:
        para = _html_to_plain(para).strip()
        if para:
            doc.add_paragraph(para)

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf


# ══════════════════════════════════════════════════════════
#  DIALOGS
# ══════════════════════════════════════════════════════════
@st.dialog(" Save Session")
def save_dialog():
    title = st.text_input("Enter a title for this session", placeholder="")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Save", use_container_width=True):
            if title.strip():
                current_fd = collect_form_data()
                st.session_state.form_data = current_fd
                sid = db_save_session(
                    st.session_state.user_id,
                    title.strip(),
                    current_fd,
                    st.session_state.conversation,
                    st.session_state.answers,
                    st.session_state.final_justification,
                )
                st.session_state.current_session_id = sid
                st.session_state.unsaved_work        = False
                st.session_state.show_save_dialog    = False
                refresh_sessions()
                st.rerun()
            else:
                st.warning("Please enter a title.")
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.show_save_dialog = False
            st.rerun()


@st.dialog(" Rename Session")
def rename_dialog():
    new = st.text_input("Session title", value=st.session_state.rename_title)
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Update", use_container_width=True):
            if new.strip():
                db_rename(st.session_state.rename_id, new.strip())
                st.session_state.rename_id    = None
                st.session_state.rename_title = ""
                refresh_sessions()
                st.rerun()
            else:
                st.warning("Title cannot be empty.")
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.rename_id = None
            st.rerun()


@st.dialog(" Delete Session")
def delete_dialog():
    st.warning("Are you sure you want to delete this session? This cannot be undone.")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Yes, Delete", use_container_width=True):
            sid = st.session_state.delete_id
            if st.session_state.current_session_id == sid:
                reset_work()
            db_delete(sid)
            st.session_state.delete_id = None
            refresh_sessions()
            st.rerun()
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.delete_id = None
            st.rerun()


@st.dialog(" ")
def unsaved_dialog():
    st.warning("You have unsaved work. What would you like to do?")
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button(" Save", use_container_width=True):
            st.session_state.pending_new_session = False
            st.session_state.show_save_dialog    = True
            st.rerun()
    with c2:
        if st.button("Continue to create New session", use_container_width=True):
            st.session_state.pending_new_session = False
            reset_work()
            st.rerun()
    with c3:
        if st.button("Cancel", use_container_width=True):
            st.session_state.pending_new_session = False
            st.rerun()


# ══════════════════════════════════════════════════════════
#  SIDEBAR
# ══════════════════════════════════════════════════════════
def show_sidebar():
    with st.sidebar:
        st.markdown(f"###  Welcome, **{st.session_state.username}**")
        st.divider()

        c1, c2 = st.columns(2)
        with c1:
            if st.button("➕ New Session", use_container_width=True):
                if has_active_work():
                    st.session_state.pending_new_session = True
                else:
                    reset_work()
                st.rerun()
        with c2:
            if st.button(" Logout", use_container_width=True):
                _del_cookie("username")
                _del_cookie("user_id")
                for k in list(st.session_state.keys()):
                    del st.session_state[k]
                st.rerun()

        if has_active_work():
            if st.button(" Save", use_container_width=True):
                st.session_state.show_save_dialog = True
                st.rerun()

        st.divider()

        if not st.session_state.sessions_list:
            st.caption("No saved sessions yet.")
        else:
            grouped = group_by_date(st.session_state.sessions_list)
            for date_str, items in grouped.items():
                st.markdown(f"**{date_str}**")
                for sid, title, time_str in items:
                    is_active    = (sid == st.session_state.current_session_id)
                    col_t, col_m = st.columns([5, 1])
                    with col_t:
                        if st.button(
                            f"{time_str} - {title}",
                            key=f"sess_{sid}",
                            use_container_width=True,
                            type="primary" if is_active else "secondary",
                        ):
                            data = db_load(sid)
                            if data:
                                populate_form_fields(data["form_data"])
                                st.session_state.form_data               = data["form_data"]
                                st.session_state.conversation            = data["conversation"]
                                st.session_state.answers                 = data["answers"]
                                st.session_state.final_justification     = data["justification"]
                                st.session_state.justification_generated = bool(data["justification"])
                                st.session_state.form_submitted          = (
                                    bool(data["conversation"]) or bool(data["justification"])
                                )
                                st.session_state.current_session_id = sid
                                st.session_state.unsaved_work        = False
                            st.rerun()
                    with col_m:
                        with st.popover("⋮"):
                            if st.button(" Rename", key=f"ren_{sid}", use_container_width=True):
                                st.session_state.rename_id    = sid
                                st.session_state.rename_title = title
                                st.rerun()
                            if st.button(" Delete", key=f"del_{sid}", use_container_width=True):
                                st.session_state.delete_id = sid
                                st.rerun()


# ══════════════════════════════════════════════════════════
#  LOGIN PAGE
# ══════════════════════════════════════════════════════════
def show_login():
    st.markdown(
        "<h1 style='text-align: center;'>Login with RCNET/PIS Details</h1>",
        unsafe_allow_html=True,
    )
    _, col, _ = st.columns([1, 1, 1])
    with col:
        st.subheader("Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login", use_container_width=True):
            client_ip = st.session_state.get("client_ip") or "unknown"
            success, info = ad_auth(username, password, client_ip)

            if success:
                st.session_state.logged_in = True
                st.session_state.username  = info
                st.session_state.user_id   = None   # AD users: no local DB row
                _set_cookie("username", info)
                _set_cookie("user_id", "ad")        # FIX #3 — explicit "ad" marker
                refresh_sessions()
                st.rerun()
            else:
                st.error(info)


# ══════════════════════════════════════════════════════════
#  MAIN APP
# ══════════════════════════════════════════════════════════
def show_main_app():
    st.title("AI BASED PROCUREMENT JUSTIFICATION GENERATOR")

    # ── PHASE 1 : FORM ──────────────────────────────────────
    if not st.session_state.form_submitted:

        # 0. Project/Directorate Name
        st.text_input("Project/Directorate Name", key="f_project_name")

        # 1. Nature of Item  — FIX #8: corrected typos in dropdown
        col1, col2 = st.columns([1, 2])
        with col1:
            st.selectbox(
                "Nature of Item",
                [
                    "ACCESSORIES",
                    "AMMUNITION",
                    "ARBORICULTURE (special services)",
                    "BUILDUP ITEMS",
                    "CAPITAL",
                    "CONSERVANCY (SPECIAL SERVICES)",
                    "CONSUMABLES",
                    "COTS",
                    "DEVELOPMENT",            # was "DEVELOPMENTM"
                    "EQUIPMENTS",
                    "EXPLOSIVE",
                    "FABRICATION",
                    "FIREFIGHTING (SPECIAL SERVICES)",
                    "HARDWARE",
                    "HYGIENE AND MAINTENANCE (special services)",
                    "IT HARDWARE",
                    "IT SOFTWARE",
                    "MISCELLANEOUS",          # was "MISCELLEANEOUS"
                    "RAW MATERIAL",
                    "REPLACEMENT (Repair/Maintenance Contracts)",
                    "SECURITY SERVICES DGR (Special services)",
                    "SERVICES",
                    "SPACES",
                    "SUPPORT SERVICES TO DSC (special services)",  # was "SUPPORT ERVICES"
                    "TRANSPORTATION",
                    "WET CANTEEN SERVICES (special services)",
                ],
                key="f_nature_of_item",
            )

        with col2:
            # 2. Item Nomenclature
            st.text_input("Item Nomenclature", key="f_item_nomenclature")

        # 3. Technical Parameters — rich text
        rich_text(
            "Technical Parameters Calculation",
            key="f_technical_parameters",
            height=150,
            placeholder="Enter technical specs. Use bold, lists, or tables as needed.",
        )

        # 4. Committee Recommendation
        st.radio(
            "Any Committee Recommendation?",
            ["Yes", "No"],
            key="f_any_committee_recommendation",
        )
        disabled = st.session_state.f_any_committee_recommendation == "No"

        col_docno, col_docdate = st.columns([2, 1])
        with col_docno:
            st.text_input("Document No", key="f_doc_no", disabled=disabled)
        with col_docdate:
            st.date_input("Document Date", key="f_date", disabled=disabled)

        # FIX #1 — MOM field rendered AND collected
        rich_text(
            "MOM / Committee Suggestions",
            key="f_mom_committee_suggestions",
            height=120,
            placeholder="Summarise committee recommendations here…",
        )
        # Visually disable the editor when recommendation is "No"
        if disabled:
            st.caption("ℹ️ Committee Recommendation is set to 'No' — field above is informational only.")

        # 5. Fresh Purchase
        st.radio("Fresh Purchase?", ["Yes", "No"], key="f_fresh_purchase")

        disable_prev_supply = st.session_state.f_fresh_purchase == "Yes"

        # FIX #5 — both fields always rendered; only the relevant one is editable;
        #           the other is disabled so stale data cannot bleed into the LLM.
        if st.session_state.f_fresh_purchase == "Yes":
            rich_text(
                "How was the purpose served till now?",
                key="f_fresh_purchase_purpose_served",
                height=80,
            )
            # Clear the alternate field so stale data does not reach the LLM
            st.session_state["f_fresh_purchase_reason"] = ""
        else:
            rich_text(
                "Why is upgradation of existing equipment not sufficient?",
                key="f_fresh_purchase_reason",
                height=80,
            )
            # Clear the alternate field
            st.session_state["f_fresh_purchase_purpose_served"] = ""

        col_order_no, col_order_date = st.columns([2, 1])
        with col_order_no:
            st.text_input(
                "Previous Supply Order No",
                key="f_previous_supply_order_no",
                disabled=disable_prev_supply,
            )
        with col_order_date:
            st.date_input(
                "Previous Supply Order Date",
                key="f_previous_supply_order_date",
                disabled=disable_prev_supply,
            )

        # 6. Sensitive Items
        st.radio(
            "Are Items Sensitive in Nature?",
            ["Yes", "No"],
            key="f_are_items_sensitive",
            index=0,
        )
        disabled = st.session_state.f_are_items_sensitive == "No"
        rich_text(
            "Explain how and if FIM will be issued?",
            key="f_sensitive_items_details",
            height=80,
        )
        if disabled:
            st.caption("ℹ️ Items are not sensitive — field above is informational only.")

        # 7. SBC
        st.radio(
            "Is SBC (Specific Brand Certificate) applied?",
            ["Yes", "No"],
            key="f_sbc_applicable",
        )
        disabled = st.session_state.f_sbc_applicable == "No"

        col_docno, col_docdate = st.columns([2, 1])
        with col_docno:
            st.text_input("SBC Doc No",  key="f_sbc_doc_no",  disabled=disabled)
            st.text_input("SBC Reason",  key="f_sbc_reason",  disabled=disabled)
        with col_docdate:
            st.date_input("SBC Doc Date", key="f_sbc_doc_date", disabled=disabled)

        # 8. Quantity
        st.number_input(
            "Quantity",
            min_value=0,
            step=1,
            key="f_item_quantity",
        )

        # 9. Base of Quantity
        st.text_input("Basis of Quantity", key="f_base_of_quantity")

        # 10. Proposed Distribution — rich text
        rich_text(
            "Proposed Distribution of Items",
            key="f_proposed_distribution",
            height=120,
            placeholder="Describe how items will be distributed across departments/locations.",
        )

        # 11. Tender Type
        # Clear hidden fields when user switches back to GeM
        if st.session_state.get("f_tender_type") == "GeM":
            st.session_state.f_tdoc_no            = ""
            st.session_state.f_tdoc_date          = None
            st.session_state.f_tender_type_reason = ""

        st.selectbox(
            "Tender Type",
            [
                "GeM",
                "Annual Maint. Cont",
                "Cash Purchase Scientific Equipment",
                "CARS for Research Services",
                "Cash Purchase",
                "Development Contract",
                "Fabrication Order",
                "Imports",
                "CAPSI",
                "Rate Contracts",
                "Supply Order",
            ],
            key="f_tender_type",
        )

        disabled = st.session_state.f_tender_type == "GeM"
        col_docno, col_docdate = st.columns([2, 1])
        with col_docno:
            # FIX #2 — tdoc_no widget mapped to correct key
            st.text_input("Document No", key="f_tdoc_no", disabled=disabled)
            rich_text(
                "Tender Type Reason",
                key="f_tender_type_reason",
                height=120,
            )
            if disabled:
                st.caption("ℹ️ Tender type is GeM — document fields are not required.")
        with col_docdate:
            # FIX #2 — tdoc_date widget mapped to correct key
            st.date_input("Document Date", key="f_tdoc_date", disabled=disabled)

        # 12. Tender Mode
        st.radio(
            "Tender Mode",
            ["Single", "Limited", "Open"],
            key="f_tender_mode",
        )
        disabled = st.session_state.f_tender_mode == "Open"
        st.text_input(
            "Tender Mode Reason",
            key="f_tender_mode_reason",
            disabled=disabled,
        )

        # 13. Bid Type
        st.radio(
            "Bid Type",
            ["Single", "Two"],
            key="f_bid_type",
        )
        disabled = st.session_state.f_bid_type == "Two"
        st.text_input(
            "Bid Type Reason",
            key="f_bid_type_reason",
            disabled=disabled,
        )

        # 14. Total Demand Value
        st.number_input(
            "Total Demand Value (Rupees)",
            min_value=0.0,
            step=1.0,
            key="f_total_demand_value",
        )

        # 15. PAC
        st.radio(
            "Is PAC (Proprietary Article Certificate) Applicable?",
            ["Yes", "No"],
            key="f_pac_applicable",
        )
        pac_disabled = st.session_state.f_pac_applicable == "No"

        col_pac_docno, col_pac_docdate = st.columns([2, 1])
        with col_pac_docno:
            st.text_input("PAC Doc No",  key="f_pac_doc_no",  disabled=pac_disabled)
            st.text_input("PAC Reason",  key="f_pac_reason",  disabled=pac_disabled)
        with col_pac_docdate:
            st.date_input("PAC Doc Date", key="f_pac_doc_date", disabled=pac_disabled)

        # Submit
        st.write("")
        if st.button("Start", type="primary"):
            form_data = collect_form_data()
            st.session_state.form_data     = form_data
            st.session_state.form_submitted = True
            st.session_state.unsaved_work   = True

            print("=== filled data sent to LLM ===")
            print(json.dumps(form_data, indent=2))

            with st.spinner("Thinking…"):
                first_q = call_ollama(build_question_prompt(form_data, [], {}))

            st.session_state.current_question = first_q
            st.rerun()

    # ── PHASE 2 : CHAT ──────────────────────────────────────
    else:
        for msg in st.session_state.conversation:
            with st.chat_message(msg["role"]):
                st.write(msg["content"])

        if st.session_state.justification_generated:
            st.subheader("Generated Justification")
            st.write(st.session_state.final_justification)

            buf   = generate_docx(
                st.session_state.form_data.get("item_nomenclature", ""),
                st.session_state.final_justification,
            )
            fname = (
                f"{st.session_state.form_data.get('item_nomenclature', 'item').replace(' ', '_')}.docx"
            )
            st.download_button(
                "Download DOCX",
                data=buf,
                file_name=fname,
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            )

        else:
            with st.chat_message("assistant"):
                st.write(st.session_state.current_question)

            user_answer = st.chat_input("Enter your answer")

            if user_answer:
                st.session_state.conversation.append(
                    {"role": "assistant", "content": st.session_state.current_question}
                )
                st.session_state.conversation.append(
                    {"role": "user", "content": user_answer}
                )
                qkey = f"question_{st.session_state.question_count + 1}"
                st.session_state.answers[qkey] = {
                    "question": st.session_state.current_question,
                    "answer":   user_answer,
                }
                st.session_state.question_count += 1
                st.session_state.unsaved_work    = True

                with st.spinner("Thinking..."):
                    next_q = call_ollama(build_question_prompt(
                        st.session_state.form_data,
                        st.session_state.conversation,
                        st.session_state.answers,
                    ))

                if "JUSTIFICATION_COMPLETE" in next_q:
                    with st.spinner("Generating justification..."):
                        final = call_ollama(build_justification_prompt(
                            st.session_state.form_data,
                            st.session_state.answers,
                        ))
                    st.session_state.final_justification     = final
                    st.session_state.justification_generated = True
                    st.session_state.unsaved_work            = True
                else:
                    st.session_state.current_question = next_q

                st.rerun()


# ══════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════

# FIX #3 — robust cookie restore: handle "ad" marker safely
if not st.session_state.logged_in and COOKIES_OK:
    _u = _get_cookie("username")
    _i = _get_cookie("user_id")
    if _u and _i:
        st.session_state.logged_in = True
        st.session_state.username  = _u
        # "ad" cookie means AD user (user_id=None); digit string means local DB id
        st.session_state.user_id   = int(_i) if _i.isdigit() else None
        refresh_sessions()

if not st.session_state.logged_in:
    show_login()
else:
    show_sidebar()
    show_main_app()

    if st.session_state.show_save_dialog:
        save_dialog()

    if st.session_state.rename_id is not None:
        rename_dialog()

    if st.session_state.delete_id is not None:
        delete_dialog()

    if st.session_state.pending_new_session:
        unsaved_dialog()
