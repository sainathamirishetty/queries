"""
extractor.py
─────────────────────────────────────────────────────────────
Document extraction pipeline for DocQA.

Supports:
  • PDF  — digital text via pdfplumber  (tables → markdown)
           scanned pages → EasyOCR fallback
  • DOCX — python-docx  (paragraphs + tables → markdown)
  • TXT  — plain read

Output:
  ExtractionResult
    .full_text       — complete markdown text with page markers,
                       <<IMAGE_N>> tags, and pipe-formatted tables
    .image_map       — {image_number: saved_image_path}
    .table_count     — how many tables were extracted
    .page_count
    .is_scanned
    .md_saved_path   — where the markdown was persisted
    .t_page_check / .t_text_extraction / .t_image_extraction
    .t_table_extraction / .t_total
    .summary         — one-line human summary
─────────────────────────────────────────────────────────────
"""

import io
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from config import (
    EXTRACTED_DOCS_DIR,
    MAX_PAGES,
    SCANNED_TEXT_THRESHOLD,
    TABLE_MIN_CELL_CHARS,
)
from logger import get_logger

log = get_logger("extractor")


# ── result dataclass ──────────────────────────────────────────

@dataclass
class ExtractionResult:
    full_text:           str         = ""
    image_map:           Dict[int, str] = field(default_factory=dict)
    table_count:         int         = 0
    page_count:          int         = 0
    is_scanned:          bool        = False
    md_saved_path:       Optional[str] = None
    t_page_check:        float       = 0.0
    t_text_extraction:   float       = 0.0
    t_image_extraction:  float       = 0.0
    t_table_extraction:  float       = 0.0
    t_total:             float       = 0.0

    @property
    def summary(self) -> str:
        return (
            f"Pages: {self.page_count} | "
            f"Chars: {len(self.full_text):,} | "
            f"Images: {len(self.image_map)} | "
            f"Tables: {self.table_count} | "
            f"Scanned: {self.is_scanned} | "
            f"Total: {self.t_total:.2f}s"
        )


# ── helpers ───────────────────────────────────────────────────

def _make_output_dir(original_filename: str) -> Path:
    """Create and return dated output directory for this document."""
    date_str  = datetime.now().strftime("%Y-%m-%d")
    stem      = Path(original_filename).stem
    safe_stem = re.sub(r"[^\w\-]", "_", stem)[:60]
    out_dir   = Path(EXTRACTED_DOCS_DIR) / date_str / safe_stem
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def _table_to_markdown(table: List[List]) -> str:
    """
    Convert a pdfplumber / python-docx table (list of rows, each a list of
    cell strings) to GitHub-Flavoured Markdown pipe format.

    Example output:
        | Name   | Score | Grade |
        |--------|-------|-------|
        | Alice  | 95    | A     |
        | Bob    | 82    | B     |
    """
    if not table or not table[0]:
        return ""

    # normalise cells — replace None with ""
    rows = [
        [str(cell).strip() if cell is not None else "" for cell in row]
        for row in table
        if any(cell for cell in row)  # skip fully-empty rows
    ]
    if not rows:
        return ""

    # determine column widths for alignment
    col_count = max(len(r) for r in rows)
    # pad short rows
    rows = [r + [""] * (col_count - len(r)) for r in rows]
    col_widths = [
        max(len(rows[i][c]) for i in range(len(rows)))
        for c in range(col_count)
    ]
    col_widths = [max(w, 3) for w in col_widths]  # minimum 3 for separator

    def fmt_row(row):
        cells = [row[c].ljust(col_widths[c]) for c in range(col_count)]
        return "| " + " | ".join(cells) + " |"

    header    = fmt_row(rows[0])
    separator = "| " + " | ".join("-" * w for w in col_widths) + " |"
    data_rows = [fmt_row(r) for r in rows[1:]]

    return "\n".join([header, separator] + data_rows)


def _save_image(img_bytes: bytes, out_dir: Path, img_num: int, ext: str = "png") -> str:
    """Save raw image bytes and return the file path string."""
    img_path = out_dir / f"image_{img_num:03d}.{ext}"
    with open(img_path, "wb") as f:
        f.write(img_bytes)
    return str(img_path)


def _save_markdown(text: str, out_dir: Path, stem: str) -> str:
    """Persist extracted markdown and return path string."""
    md_path = out_dir / f"{stem}.md"
    md_path.write_text(text, encoding="utf-8")
    return str(md_path)


# ── PDF extraction ────────────────────────────────────────────

def _is_page_scanned(page_text: str) -> bool:
    return len(page_text.strip()) < SCANNED_TEXT_THRESHOLD


def _ocr_page_image(pil_image) -> str:
    """
    Run EasyOCR on a PIL image and return the recognised text.
    Lazy-imports easyocr so the app still runs without it if no scanned pages.
    """
    try:
        import easyocr
        import numpy as np
        reader = easyocr.Reader(["en"], gpu=False, verbose=False)
        result = reader.readtext(np.array(pil_image), detail=0, paragraph=True)
        return "\n".join(result)
    except ImportError:
        log.warning("easyocr not installed — scanned page will be empty")
        return "[scanned page — install easyocr for OCR support]"
    except Exception as exc:
        log.warning(f"OCR failed: {exc}")
        return "[OCR error]"


def extract_pdf(
    file_path:  str,
    session_id: str,
    out_dir:    Path,
) -> Tuple[str, Dict[int, str], int, bool, float, float, float, float]:
    """
    Extract text, tables, and images from a PDF.

    Returns:
        full_text, image_map, table_count,
        is_scanned, t_page_check, t_text, t_images, t_tables
    """
    import pdfplumber
    from PIL import Image as PILImage

    pages_text   : List[str]       = []
    image_map    : Dict[int, str]  = {}
    img_counter                    = 0
    table_count                    = 0
    is_scanned                     = False

    t_page_check = t_text = t_images = t_tables = 0.0

    with pdfplumber.open(file_path) as pdf:
        total_pages = min(len(pdf.pages), MAX_PAGES)

        for page_num, page in enumerate(pdf.pages[:total_pages], start=1):
            log.debug(f"Processing PDF page {page_num}/{total_pages}")
            page_parts: List[str] = [f"\n<!-- Page {page_num} -->\n"]

            # ── page-check timing ──
            t0 = time.perf_counter()
            raw_text = page.extract_text() or ""
            t_page_check += time.perf_counter() - t0

            # ── text extraction ──
            t0 = time.perf_counter()
            if _is_page_scanned(raw_text):
                is_scanned = True
                log.info(f"Page {page_num}: scanned — running OCR")
                pil_img  = page.to_image(resolution=150).original
                raw_text = _ocr_page_image(pil_img)
            page_parts.append(raw_text)
            t_text += time.perf_counter() - t0

            # ── table extraction ──
            t0 = time.perf_counter()
            try:
                tables = page.extract_tables()
                for table in tables:
                    if table:
                        md_table = _table_to_markdown(table)
                        if md_table:
                            table_count += 1
                            page_parts.append(
                                f"\n\n<!-- Table {table_count} on Page {page_num} -->\n"
                                + md_table
                                + "\n"
                            )
            except Exception as exc:
                log.warning(f"Table extraction failed on page {page_num}: {exc}")
            t_tables += time.perf_counter() - t0

            # ── image extraction ──
            t0 = time.perf_counter()
            try:
                for img_obj in page.images:
                    try:
                        # pdfplumber gives us the raw image dict
                        x0, y0 = img_obj["x0"], img_obj["y0"]
                        x1, y1 = img_obj["x1"], img_obj["y1"]
                        # crop to bounding box and save
                        cropped = page.within_bbox((x0, y0, x1, y1)).to_image(
                            resolution=150
                        ).original
                        img_counter += 1
                        img_path = _save_image(
                            _pil_to_png_bytes(cropped),
                            out_dir,
                            img_counter,
                        )
                        image_map[img_counter] = img_path
                        page_parts.append(f"\n<<IMAGE_{img_counter}>>\n")
                        log.debug(f"Saved image {img_counter} from page {page_num}")
                    except Exception as exc:
                        log.warning(f"Failed to extract image on page {page_num}: {exc}")
            except Exception as exc:
                log.warning(f"Image iteration failed on page {page_num}: {exc}")
            t_images += time.perf_counter() - t0

            pages_text.append("\n".join(page_parts))

    full_text = "\n".join(pages_text)
    return (
        full_text, image_map, table_count,
        is_scanned, t_page_check, t_text, t_images, t_tables,
    )


def _pil_to_png_bytes(pil_image) -> bytes:
    buf = io.BytesIO()
    pil_image.save(buf, format="PNG")
    return buf.getvalue()


# ── DOCX extraction ───────────────────────────────────────────

def extract_docx(
    file_path:  str,
    session_id: str,
    out_dir:    Path,
) -> Tuple[str, Dict[int, str], int, float, float, float]:
    """
    Extract text, tables, and images from a DOCX file.

    Returns:
        full_text, image_map, table_count, t_text, t_images, t_tables
    """
    from docx import Document
    from docx.oxml.ns import qn

    doc         = Document(file_path)
    parts       : List[str]      = ["<!-- Page 1 -->\n"]
    image_map   : Dict[int, str] = {}
    img_counter                  = 0
    table_count                  = 0

    t_text = t_images = t_tables = 0.0

    # We iterate the document's XML body children in order so that paragraphs
    # and tables appear in their original reading sequence.
    body = doc.element.body

    from docx.oxml import OxmlElement
    from docx.text.paragraph import Paragraph as DocxParagraph
    from docx.table import Table as DocxTable

    # Build a lookup of table XML elements → Table objects
    docx_tables = {t._tbl: t for t in doc.tables}

    # Track inline images via relationship IDs we've already saved
    saved_rids: Dict[str, int] = {}

    for child in body:
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag

        # ── paragraph ──
        if tag == "p":
            t0   = time.perf_counter()
            para = DocxParagraph(child, doc)
            text = para.text.strip()
            if text:
                # Heading formatting
                if para.style.name.startswith("Heading"):
                    level = "".join(filter(str.isdigit, para.style.name)) or "1"
                    parts.append(f"\n{'#' * int(level)} {text}\n")
                else:
                    parts.append(text)
            t_text += time.perf_counter() - t0

            # ── inline images inside paragraph ──
            t0 = time.perf_counter()
            for rel in _find_image_rels_in_para(child, doc):
                if rel not in saved_rids:
                    try:
                        img_bytes = doc.part.related_parts[rel].blob
                        img_counter += 1
                        img_path = _save_image(img_bytes, out_dir, img_counter)
                        image_map[img_counter] = img_path
                        saved_rids[rel] = img_counter
                        parts.append(f"\n<<IMAGE_{img_counter}>>\n")
                        log.debug(f"Saved DOCX inline image {img_counter}")
                    except Exception as exc:
                        log.warning(f"DOCX image extraction failed: {exc}")
            t_images += time.perf_counter() - t0

        # ── table ──
        elif tag == "tbl":
            t0     = time.perf_counter()
            tbl_obj = docx_tables.get(child)
            if tbl_obj:
                rows = []
                for row in tbl_obj.rows:
                    rows.append([cell.text.strip() for cell in row.cells])
                md_table = _table_to_markdown(rows)
                if md_table:
                    table_count += 1
                    parts.append(
                        f"\n\n<!-- Table {table_count} -->\n"
                        + md_table
                        + "\n"
                    )
            t_tables += time.perf_counter() - t0

    full_text = "\n".join(parts)
    return full_text, image_map, table_count, t_text, t_images, t_tables


def _find_image_rels_in_para(para_xml, doc) -> List[str]:
    """Return relationship IDs of all images embedded in a paragraph's XML."""
    from lxml import etree
    rids = []
    ns   = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
    for elem in para_xml.iter():
        local = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        if local == "blip":
            rid = elem.get(
                "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed"
            )
            if rid:
                rids.append(rid)
    return rids


# ── TXT extraction ────────────────────────────────────────────

def extract_txt(file_path: str) -> str:
    """Read plain text file, add a single page marker."""
    encodings = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]
    for enc in encodings:
        try:
            text = Path(file_path).read_text(encoding=enc)
            return "<!-- Page 1 -->\n" + text
        except UnicodeDecodeError:
            continue
    raise ValueError("Could not decode text file with any supported encoding.")


# ── public API ────────────────────────────────────────────────

def extract_document(
    file_path:         str,
    file_ext:          str,
    session_id:        str,
    original_filename: str,
) -> ExtractionResult:
    """
    Main entry point.  Dispatches to the right extractor, saves outputs,
    and returns a fully populated ExtractionResult.

    Raises ValueError for unsupported extensions or page limit exceeded.
    """
    t_wall_start = time.perf_counter()
    file_ext     = file_ext.lower().lstrip(".")

    if file_ext not in ("pdf", "docx", "txt"):
        raise ValueError(f"Unsupported file type: .{file_ext}")

    out_dir  = _make_output_dir(original_filename)
    stem     = Path(original_filename).stem
    result   = ExtractionResult()

    # ── dispatch ──────────────────────────────────────────────
    if file_ext == "pdf":
        (
            result.full_text,
            result.image_map,
            result.table_count,
            result.is_scanned,
            result.t_page_check,
            result.t_text_extraction,
            result.t_image_extraction,
            t_table,
        ) = extract_pdf(file_path, session_id, out_dir)
        result.t_table_extraction = t_table

        # count pages from markers
        result.page_count = len(
            re.findall(r"<!-- Page \d+ -->", result.full_text)
        )

    elif file_ext == "docx":
        (
            result.full_text,
            result.image_map,
            result.table_count,
            result.t_text_extraction,
            result.t_image_extraction,
            result.t_table_extraction,
        ) = extract_docx(file_path, session_id, out_dir)
        result.page_count = 1   # DOCX has no native page boundaries
        result.t_page_check = 0.0

    elif file_ext == "txt":
        t0               = time.perf_counter()
        result.full_text = extract_txt(file_path)
        result.t_text_extraction = time.perf_counter() - t0
        result.page_count        = 1
        result.table_count       = 0

    # ── page cap check ────────────────────────────────────────
    if result.page_count > MAX_PAGES:
        raise ValueError(
            f"Document has {result.page_count} pages — "
            f"limit is {MAX_PAGES}. Please upload a shorter document."
        )

    # ── save markdown ─────────────────────────────────────────
    result.md_saved_path = _save_markdown(result.full_text, out_dir, stem)

    result.t_total = time.perf_counter() - t_wall_start

    log.info(
        f"Extracted '{original_filename}' → {result.summary}"
    )
    return result


def cleanup_session_images(session_id: str):
    """
    Placeholder — images are stored permanently under extracted_docs/.
    If you want to clean up tmp files, do it here.
    """
    log.debug(f"cleanup_session_images called for session {session_id} (no-op)")
