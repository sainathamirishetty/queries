"""
ollama_client_sync.py
─────────────────────────────────────────────────────────────
Synchronous streaming client for Gemma 4 E4B (vision model).

Capabilities:
  • Classifies every question as  image / table / text
  • Image questions  → sends relevant base64 images (6-strategy selector)
  • Table questions  → injects structured table-reading instructions
  • Text questions   → standard text mode
  • Citation support via <!-- Page N --> markers in prompt
─────────────────────────────────────────────────────────────
"""

import base64
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Generator, List, Optional, Tuple

import requests

from config import (
    IMAGE_CONTEXT_WINDOW,
    IMAGE_MIN_SCORE,
    MAX_HISTORY_TURNS,
    MAX_IMAGES_PER_QUERY,
    OLLAMA_HOST,
    OLLAMA_MODEL,
    OLLAMA_TIMEOUT,
)
from logger import get_logger

log = get_logger("ollama")


# ─────────────────────────────────────────────────────────────
# Timing / stats
# ─────────────────────────────────────────────────────────────

@dataclass
class GenerationStats:
    t_prompt_build:  float = 0.0
    t_ttft:          float = 0.0
    t_total:         float = 0.0
    chars_generated: int   = 0

    @property
    def chars_per_sec(self) -> float:
        return self.chars_generated / self.t_total if self.t_total > 0 else 0.0

    @property
    def summary(self) -> str:
        return (
            f"Prompt build: {self.t_prompt_build:.3f}s | "
            f"TTFT: {self.t_ttft:.2f}s | "
            f"Total: {self.t_total:.2f}s | "
            f"Chars: {self.chars_generated} | "
            f"Speed: {self.chars_per_sec:.1f} chars/s"
        )


# ─────────────────────────────────────────────────────────────
# Question classifier
# ─────────────────────────────────────────────────────────────

@dataclass
class QuestionType:
    mode:        str  = "text"    # "image" | "table" | "text"
    extra_instr: str  = ""        # injected into the prompt verbatim

    @property
    def is_image(self) -> bool:
        return self.mode == "image"

    @property
    def is_table(self) -> bool:
        return self.mode == "table"

    @property
    def is_text(self) -> bool:
        return self.mode == "text"


@dataclass
class VerificationResult:
    grounded: bool
    corrected_answer: str
    issues: List[str]


# Keywords that signal image-related intent
_IMAGE_TRIGGERS = frozenset([
    "chart", "graph", "diagram", "plot", "figure", "image",
    "picture", "visual", "bar", "pie", "trend", "growth",
    "comparison", "show me", "what does", "describe the",
    "color", "colour", "shape", "icon", "logo", "photo",
    "screenshot", "illustration", "look like", "depicted",
    "drawn", "plotted", "displayed", "shown",
])

# Keywords that signal table / structured-data intent
_TABLE_TRIGGERS = frozenset([
    "table", "row", "column", "cell", "header",
    "list", "entry", "entries", "record", "records",
    "tabular", "grid",
    # data-question words that tables typically answer
    "how many", "which", "compare", "total", "average",
    "maximum", "minimum", "highest", "lowest", "sum",
    "breakdown", "per", "each", "count", "rank",
    "sorted", "ordered", "top", "bottom",
])

# Explicit figure reference pattern
_EXPLICIT_FIG_RE = re.compile(
    r"(?:image|figure|fig|graph|chart)\s*\.?\s*(\d+)",
    re.IGNORECASE,
)


def classify_question_type(
    question:  str,
    image_map: Dict[int, str],
) -> QuestionType:
    """
    Classify the user's question as image / table / text.

    Priority: explicit figure reference → image triggers → table triggers → text.

    Returns a QuestionType with:
      .mode         — "image" | "table" | "text"
      .extra_instr  — additional instructions injected into the prompt
    """
    q_lower = question.lower()

    # ── 1. Explicit figure reference ("figure 2", "fig.3") ──
    has_explicit_fig  = bool(_EXPLICIT_FIG_RE.search(q_lower))
    has_image_trigger = any(kw in q_lower for kw in _IMAGE_TRIGGERS)
    has_images_in_doc = bool(image_map)

    if has_images_in_doc and (has_explicit_fig or has_image_trigger):
        log.info(
            "[Classifier] → IMAGE "
            f"(explicit_fig={has_explicit_fig}, trigger={has_image_trigger})"
        )
        return QuestionType(
            mode="image",
            extra_instr=(
                "VISUAL QUESTION INSTRUCTIONS:\n"
                "- You have been provided with image(s) extracted from the document.\n"
                "- Examine every image carefully: read all axis labels, legends,\n"
                "  titles, data labels, and any text visible in the image.\n"
                "- Quote specific numeric values or labels directly from the image.\n"
                "- Describe trends, patterns, highs, lows as you see them.\n"
                "- Reference each image you use: <<IMAGE_N>>\n"
                "- If a figure is not relevant to the question, say so.\n"
                "- Do NOT guess values — only state what is clearly visible.\n"
            ),
        )

    # ── 2. Table / structured-data triggers ──
    has_table_trigger = any(kw in q_lower for kw in _TABLE_TRIGGERS)

    if has_table_trigger:
        log.info(f"[Classifier] → TABLE (trigger={has_table_trigger})")
        return QuestionType(
            mode="table",
            extra_instr=(
                "TABLE QUESTION INSTRUCTIONS:\n"
                "- Tables in this document are formatted with pipe characters (|).\n"
                "- Locate the relevant table by its column headers.\n"
                "- Read every row carefully — do not skip rows.\n"
                "- Quote exact cell values — never round or paraphrase numbers.\n"
                "- If multiple rows match the question, list each one.\n"
                "- If a cell is empty or missing, say 'not available'.\n"
                "- Reproduce the relevant table rows in your answer for clarity.\n"
                "- Cite the table: 📌 Source: Page <N>, Table <M>\n"
            ),
        )

    # ── 3. Default: plain text ──
    log.info("[Classifier] → TEXT (default)")
    return QuestionType(mode="text", extra_instr="")


# ─────────────────────────────────────────────────────────────
# Image encoding
# ─────────────────────────────────────────────────────────────

def encode_image_to_base64(image_path: str) -> str:
    """Read an image file and return its base64-encoded string."""
    try:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    except Exception as exc:
        log.error(f"Failed to encode image {image_path}: {exc}")
        return ""


# ─────────────────────────────────────────────────────────────
# 6-Strategy image selector  (your friend's improved version)
# ─────────────────────────────────────────────────────────────

def find_referenced_images(
    question:       str,
    extracted_text: str,
    image_map:      Dict[int, str],
) -> List[str]:
    """
    Decide which images are relevant to this question and return their
    base64-encoded data, ready to pass to the Ollama vision API.

    Strategy priority (stops as soon as one strategy produces results):
      1. Explicit reference  — "figure 2", "fig.3", "image 4"
      2. Context matching    — keyword overlap near <<IMAGE_N>> tags  (scored)
      3. Visual-intent fallback   — visual keywords + ≤ MAX_IMAGES images
      4. Data-question fallback   — numeric/stats keywords + ≤ MAX_IMAGES images
      5. Final safety net         — ≤ 2 images in doc → send them all

    Returns: list of base64 strings (len ≤ MAX_IMAGES_PER_QUERY)
    """
    if not image_map:
        return []

    q_lower     = question.lower()
    result_b64  : List[str]  = []
    used_nums   : set        = set()

    # ── stop-words for keyword extraction ──
    _STOP_WORDS = frozenset([
        "the", "a", "an", "in", "on", "at", "what", "how", "is", "are",
        "was", "were", "does", "did", "can", "could", "would", "from",
        "with", "about", "this", "that", "for", "to", "of", "and", "or",
    ])

    def _load(img_num: int) -> Optional[str]:
        """Encode image and mark as used. Returns b64 or None."""
        if img_num in used_nums:
            return None
        path = image_map.get(img_num, "")
        if not path or not Path(path).exists():
            return None
        b64 = encode_image_to_base64(path)
        if b64:
            used_nums.add(img_num)
            return b64
        return None

    # ─────────────────────────────────────────────────────────
    # Strategy 1 — Explicit figure reference
    # ─────────────────────────────────────────────────────────
    explicit_nums = _EXPLICIT_FIG_RE.findall(q_lower)
    for num_str in explicit_nums:
        num = int(num_str)
        if num in image_map:
            b64 = _load(num)
            if b64:
                result_b64.append(b64)
                log.info(f"[IMG] Strategy 1 → image {num} (explicit reference)")

    if result_b64:
        return result_b64[:MAX_IMAGES_PER_QUERY]

    # ─────────────────────────────────────────────────────────
    # Prepare question keywords (used by strategies 2-4)
    # ─────────────────────────────────────────────────────────
    keywords = [
        w.strip(".,?!") for w in q_lower.split()
        if len(w) > 3 and w not in _STOP_WORDS
    ]

    # ─────────────────────────────────────────────────────────
    # Strategy 2 — Scored context matching
    # Scan every occurrence of <<IMAGE_N>> in the document text.
    # Score each image by how many question keywords appear in
    # the ±IMAGE_CONTEXT_WINDOW chars around the tag.
    # Pick top-3 by score.
    # ─────────────────────────────────────────────────────────
    scored: List[Tuple[int, int]] = []   # (score, img_num)

    for img_num in sorted(image_map.keys()):
        tag        = f"<<IMAGE_{img_num}>>"
        best_score = 0

        for match in re.finditer(re.escape(tag), extracted_text):
            pos     = match.start()
            ctx_s   = max(0, pos - IMAGE_CONTEXT_WINDOW)
            ctx_e   = min(len(extracted_text), pos + IMAGE_CONTEXT_WINDOW)
            context = extracted_text[ctx_s:ctx_e].lower()
            ctx_words = set(context.split())
            score   = sum(1 for kw in keywords if kw in ctx_words)
            best_score = max(best_score, score)

        if best_score >= IMAGE_MIN_SCORE:
            scored.append((best_score, img_num))

    scored.sort(reverse=True)

    for _, img_num in scored[:3]:
        b64 = _load(img_num)
        if b64:
            result_b64.append(b64)
            log.info(
                f"[IMG] Strategy 2 → image {img_num} "
                f"(score={next(s for s,n in scored if n==img_num)})"
            )

    if result_b64:
        return result_b64[:MAX_IMAGES_PER_QUERY]

    # ─────────────────────────────────────────────────────────
    # Strategy 3 — Visual-intent fallback
    # Question has visual keywords but no context match found.
    # Send all images if there are not too many.
    # ─────────────────────────────────────────────────────────
    _VISUAL_KW = frozenset([
        "chart", "graph", "diagram", "plot", "figure",
        "image", "visual", "trend", "growth", "comparison",
        "color", "colour", "shape", "shown", "displayed",
    ])
    has_visual_intent = any(vk in q_lower for vk in _VISUAL_KW)

    if has_visual_intent and len(image_map) <= MAX_IMAGES_PER_QUERY:
        log.info("[IMG] Strategy 3 → visual-intent fallback (sending all images)")
        for img_num in sorted(image_map.keys()):
            b64 = _load(img_num)
            if b64:
                result_b64.append(b64)
        if result_b64:
            return result_b64

    # ─────────────────────────────────────────────────────────
    # Strategy 4 — Data-question fallback
    # Questions about numbers / stats that charts often answer.
    # ─────────────────────────────────────────────────────────
    _DATA_KW = frozenset([
        "value", "number", "percentage", "amount", "total",
        "revenue", "profit", "sales", "cost", "price", "rate",
        "increase", "decrease", "compare", "difference",
        "average", "maximum", "minimum", "highest", "lowest",
    ])
    asks_for_data = any(dk in q_lower for dk in _DATA_KW)

    if asks_for_data and len(image_map) <= MAX_IMAGES_PER_QUERY:
        log.info("[IMG] Strategy 4 → data-question fallback (sending all images)")
        for img_num in sorted(image_map.keys()):
            b64 = _load(img_num)
            if b64:
                result_b64.append(b64)
        if result_b64:
            return result_b64

    # ─────────────────────────────────────────────────────────
    # Strategy 5 — Final safety net
    # Very few images in doc → just send them all.
    # ─────────────────────────────────────────────────────────
    if len(image_map) <= 2:
        log.info("[IMG] Strategy 5 → final safety net (≤2 images, sending all)")
        for img_num in sorted(image_map.keys())[:2]:
            b64 = _load(img_num)
            if b64:
                result_b64.append(b64)

    return result_b64[:MAX_IMAGES_PER_QUERY]


# ─────────────────────────────────────────────────────────────
# Prompt builder
# ─────────────────────────────────────────────────────────────

def build_prompt(
    extracted_text: str,
    chat_history:   list,
    question:       str,
    image_map:      Dict[int, str],
) -> Tuple[str, List[str], float, QuestionType]:
    """
    Classify the question, select images if needed, and assemble the full
    prompt string.

    Returns:
        prompt_string  — text prompt for Ollama
        images_base64  — list of base64 images to send  ([] for table/text)
        build_time     — seconds taken
        qtype          — QuestionType (mode, extra_instr)
    """
    t0 = time.perf_counter()

    # ── classify ──────────────────────────────────────────────
    qtype = classify_question_type(question, image_map)

    # ── select images (only for image questions) ──────────────
    images_to_send: List[str] = []
    if qtype.is_image:
        images_to_send = find_referenced_images(question, extracted_text, image_map)

    # ── conversation history block ────────────────────────────
    history_block = ""
    if chat_history:
        lines = []
        for turn in chat_history[-MAX_HISTORY_TURNS:]:
            lines.append(f"User: {turn['question']}")
            lines.append(f"Assistant: {turn['answer']}")
            lines.append("")
        history_block = (
            "\n\nCONVERSATION HISTORY (most recent last):\n"
            + "\n".join(lines)
        )

    # ── vision note (only when images are attached) ───────────
    vision_note = ""
    if images_to_send:
        vision_note = (
            f"\n• You have been provided with {len(images_to_send)} "
            "image(s) from the document."
        )

    # ── type-specific instruction block ──────────────────────
    extra_block = f"\n{qtype.extra_instr}\n" if qtype.extra_instr else ""

    # ── assemble full prompt ──────────────────────────────────
    prompt = f"""You are a helpful, precise document assistant with vision capabilities.

GENERAL INSTRUCTIONS:
- Answer only from the document content below.
- Page markers are: <!-- Page 1 -->, <!-- Page 2 --> etc.
- Always end your answer with a citation: 📌 Source: Page <number>, <Section>{vision_note}
- If a figure/chart is relevant, reference it as: <<IMAGE_N>>
- If the answer is not in the document: reply exactly "I couldn't find this information in the uploaded document."
- Do NOT make up, infer, or guess information.
- Every factual claim must be supported by explicit evidence from the provided document.
- If evidence is partial or ambiguous, say so clearly and avoid definitive claims.
- Never use outside knowledge.

RESPONSE FORMAT (STRICT):
1) EVIDENCE:
   - Bullet list of exact supporting facts from the document with page references.
   - Format each bullet as: - <fact> (Page <N>)
2) ANSWER:
   - Final user-facing answer based only on the evidence above.
3) CITATION:
   - End with exactly one line: 📌 Source: Page <number>, <Section/Figure/Table>
{extra_block}
{'═' * 60}
DOCUMENT CONTENT:
{'═' * 60}
{extracted_text}
{'═' * 60}
{history_block}
CURRENT QUESTION:
{question}

ANSWER:"""

    build_time = time.perf_counter() - t0

    log.info(
        f"[Prompt] mode={qtype.mode} | "
        f"{len(prompt):,} chars | "
        f"{len(images_to_send)} image(s) | "
        f"build={build_time:.3f}s"
    )

    return prompt, images_to_send, build_time, qtype


# ─────────────────────────────────────────────────────────────
# Streaming generator
# ─────────────────────────────────────────────────────────────

def stream_response(
    prompt: str,
    images: List[str],
    stats:  GenerationStats,
) -> Generator[str, None, None]:
    """
    Stream tokens from Gemma 4 E4B.

    Ollama /api/generate payload:
      { "model": ..., "prompt": ..., "images": [...], "stream": true }

    Yields individual token strings as they arrive.
    """
    url     = f"{OLLAMA_HOST}/api/generate"
    payload = {
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": True,
        "options": {
            "num_ctx":     128000,  # full 128k context
            "temperature": 0.1,     # factual — low randomness
            "top_p":       0.9,
        },
    }

    if images:
        payload["images"] = images
        log.info(f"[Vision] Sending {len(images)} image(s) to {OLLAMA_MODEL}")
    else:
        log.info("[Text] No images attached")

    t_start     = time.perf_counter()
    first_token = True

    with requests.post(
        url,
        json    = payload,
        stream  = True,
        timeout = OLLAMA_TIMEOUT,
    ) as response:
        response.raise_for_status()

        for raw_line in response.iter_lines():
            if not raw_line:
                continue

            data  = json.loads(raw_line)
            token = data.get("response", "")

            if token:
                if first_token:
                    stats.t_ttft = time.perf_counter() - t_start
                    log.info(f"[QA] TTFT = {stats.t_ttft:.2f}s")
                    first_token  = False

                stats.chars_generated += len(token)
                yield token

            if data.get("done", False):
                break

    stats.t_total = time.perf_counter() - t_start


def _generate_once(prompt: str, images: List[str]) -> str:
    """
    Non-streaming generation helper used for post-answer verification/correction.
    """
    url = f"{OLLAMA_HOST}/api/generate"
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "num_ctx": 128000,
            "temperature": 0.0,
            "top_p": 0.9,
        },
    }
    if images:
        payload["images"] = images

    response = requests.post(url, json=payload, timeout=OLLAMA_TIMEOUT)
    response.raise_for_status()
    data = response.json()
    return data.get("response", "").strip()


def _has_valid_citation(answer: str) -> bool:
    return bool(
        re.search(r"📌\s*Source:\s*Page\s+\d+\s*,\s*.+", answer, flags=re.IGNORECASE)
    )


def _extract_cited_pages(answer: str) -> List[int]:
    """
    Extract all cited page numbers from citation lines.
    """
    nums = re.findall(r"📌\s*Source:\s*Page\s+(\d+)\s*,", answer, flags=re.IGNORECASE)
    return [int(n) for n in nums]


def _extract_available_pages(extracted_text: str) -> List[int]:
    """
    Extract available page numbers from <!-- Page N --> markers.
    """
    nums = re.findall(r"<!--\s*Page\s+(\d+)\s*-->", extracted_text, flags=re.IGNORECASE)
    pages = sorted({int(n) for n in nums})
    if not pages:
        return [1]
    return pages


def _citation_pages_exist(answer: str, extracted_text: str) -> bool:
    """
    Ensure every cited page number exists in extracted document markers.
    """
    cited = _extract_cited_pages(answer)
    if not cited:
        return False
    available = set(_extract_available_pages(extracted_text))
    return all(p in available for p in cited)


def _best_fallback_page(extracted_text: str) -> int:
    pages = _extract_available_pages(extracted_text)
    return pages[0] if pages else 1


def verify_and_correct_answer(
    question: str,
    extracted_text: str,
    draft_answer: str,
    images: List[str],
) -> VerificationResult:
    """
    Run a second-pass grounding verifier and, if needed, return a corrected answer.
    This favors factual accuracy over speed.
    """
    verifier_prompt = f"""You are a strict answer-grounding verifier.

TASK:
- Check whether the DRAFT ANSWER is fully supported by the DOCUMENT.
- If unsupported, rewrite it conservatively using only supported facts.
- Never add facts not explicitly present in DOCUMENT.

RETURN FORMAT (STRICT JSON ONLY):
{{
  "grounded": true/false,
  "issues": ["..."],
  "corrected_answer": "..."
}}

RULES FOR corrected_answer:
- Must answer the question directly.
- Must include a concise EVIDENCE section and an ANSWER section.
- Must end with citation line:
  📌 Source: Page <number>, <Section/Figure/Table>
- If information is absent, write exactly:
  "I couldn't find this information in the uploaded document."
  then still include citation with best available page context.

QUESTION:
{question}

DOCUMENT:
{extracted_text}

DRAFT ANSWER:
{draft_answer}
"""
    raw = _generate_once(verifier_prompt, images)
    try:
        parsed = json.loads(raw)
        grounded = bool(parsed.get("grounded", False))
        issues = parsed.get("issues", [])
        if not isinstance(issues, list):
            issues = [str(issues)]
        corrected = str(parsed.get("corrected_answer", "")).strip()
    except Exception:
        grounded = False
        issues = ["Verifier returned non-JSON output"]
        corrected = ""

    draft_is_valid = _has_valid_citation(draft_answer) and _citation_pages_exist(
        draft_answer, extracted_text
    )

    final_answer = draft_answer
    if not grounded or not draft_is_valid:
        if corrected:
            final_answer = corrected
        else:
            page = _best_fallback_page(extracted_text)
            final_answer = (
                "I couldn't find this information in the uploaded document.\n\n"
                f"📌 Source: Page {page}, Document"
            )

    # Guard corrected answer as well; patch citation if still invalid.
    if not (_has_valid_citation(final_answer) and _citation_pages_exist(final_answer, extracted_text)):
        page = _best_fallback_page(extracted_text)
        if _has_valid_citation(final_answer):
            final_answer = re.sub(
                r"📌\s*Source:\s*Page\s+\d+\s*,\s*.+",
                f"📌 Source: Page {page}, Document",
                final_answer,
                flags=re.IGNORECASE,
            )
        else:
            final_answer = final_answer.rstrip() + f"\n\n📌 Source: Page {page}, Document"

    return VerificationResult(
        grounded=grounded and draft_is_valid,
        corrected_answer=final_answer,
        issues=issues,
    )


# ─────────────────────────────────────────────────────────────
# Connectivity check
# ─────────────────────────────────────────────────────────────

def check_ollama_connection() -> Tuple[bool, object]:
    """Ping Ollama and verify that the configured vision model is loaded."""
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=10)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]

        if OLLAMA_MODEL in models:
            log.info(f"Vision model {OLLAMA_MODEL} found ✅")
            return True, models
        else:
            msg = (
                f"Model '{OLLAMA_MODEL}' not found in Ollama. "
                f"Available: {models}"
            )
            log.warning(msg)
            return False, msg

    except Exception as exc:
        return False, str(exc)
