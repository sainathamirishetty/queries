"""
streamlit_app.py  —  DocQA
─────────────────────────────────────────────────────────────
Run with:
  streamlit run streamlit_app.py --server.address 0.0.0.0 --server.port 8000
─────────────────────────────────────────────────────────────
"""

import re
import uuid
import tempfile
from pathlib import Path

import streamlit as st

from config import SUPPORTED_EXTENSIONS, MAX_HISTORY_TURNS
from extractor import extract_document, cleanup_session_images
from ollama_client_sync import (
    build_prompt,
    stream_response,
    check_ollama_connection,
    GenerationStats,
    verify_and_correct_answer,
)
from logger import get_logger, activity_log

log = get_logger("app")


# ── page config ───────────────────────────────────────────────

st.set_page_config(
    page_title = "DocQA",
    page_icon  = "📄",
    layout     = "wide",
)


# ── client IP ─────────────────────────────────────────────────

def get_client_ip() -> str:
    """
    Try to detect real client IP from request headers.
    Falls back gracefully through multiple sources.
    """
    try:
        headers = getattr(st.context, "headers", None)
        if headers:
            for key in ("x-forwarded-for", "x-real-ip", "remote-addr"):
                val = headers.get(key, "").split(",")[0].strip()
                if val:
                    return val
        import os
        return os.getenv("REMOTE_ADDR", "unknown")
    except Exception as exc:
        log.debug(f"IP detection error: {exc}")
        return "unknown"


# ── session state ─────────────────────────────────────────────

def init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        st.session_state.qa_turn    = 0
        activity_log.log_session_start(sid, ip)
        log.info(f"New session  id={sid}  ip={ip}")

    defaults = {
        "extracted_text": None,
        "image_map":      {},
        "table_count":    0,
        "chat_history":   [],
        "messages":       [],
        "doc_name":       None,
        "doc_pages":      None,
        "doc_chars":      None,
        "doc_images":     0,
        "doc_tables":     0,
        "doc_scanned":    False,
        "md_saved_path":  None,
        "qa_turn":        0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_session()


# ── question-type badge helper ────────────────────────────────

_MODE_BADGE = {
    "image": "🖼️ Image question",
    "table": "📊 Table question",
    "text":  "📝 Text question",
}


# ── sidebar ───────────────────────────────────────────────────

with st.sidebar:
    st.title("📄 DocQA")
    st.caption("Document Question Answering")
    st.divider()

    # Ollama status
    ok, info = check_ollama_connection()
    if ok:
        st.success("Ollama connected ✅")
    else:
        st.error("Ollama not reachable ❌")
        st.caption(str(info))

    st.divider()

    # ── file uploader ──────────────────────────────────────────
    st.subheader("📂 Upload Document")
    st.caption("PDF · DOCX · TXT  |  Max 50 pages")

    uploaded_file = st.file_uploader(
        label            = "Choose a file",
        type             = SUPPORTED_EXTENSIONS,
        label_visibility = "collapsed",
    )

    if uploaded_file is not None:
        if uploaded_file.name != st.session_state.doc_name:

            with st.spinner(f"Extracting {uploaded_file.name}…"):
                try:
                    suffix = Path(uploaded_file.name).suffix
                    tmp    = tempfile.NamedTemporaryFile(
                        delete=False, suffix=suffix
                    )
                    tmp.write(uploaded_file.read())
                    tmp.flush()
                    tmp.close()

                    res = extract_document(
                        file_path          = tmp.name,
                        file_ext           = suffix.lstrip("."),
                        session_id         = st.session_state.session_id,
                        original_filename  = uploaded_file.name,
                    )

                    # store extraction results
                    st.session_state.extracted_text = res.full_text
                    st.session_state.image_map      = res.image_map
                    st.session_state.table_count    = res.table_count
                    st.session_state.doc_name       = uploaded_file.name
                    st.session_state.doc_pages      = res.page_count
                    st.session_state.doc_chars      = len(res.full_text)
                    st.session_state.doc_images     = len(res.image_map)
                    st.session_state.doc_tables     = res.table_count
                    st.session_state.doc_scanned    = res.is_scanned
                    st.session_state.md_saved_path  = res.md_saved_path
                    st.session_state.chat_history   = []
                    st.session_state.messages       = []
                    st.session_state.qa_turn        = 0

                    # activity log
                    activity_log.log_document(
                        filename = uploaded_file.name,
                        pages    = res.page_count,
                        chars    = len(res.full_text),
                        images   = len(res.image_map),
                        tables   = res.table_count,
                    )
                    activity_log.log_extraction_timing(
                        t_page_check = res.t_page_check,
                        t_text       = res.t_text_extraction,
                        t_images     = res.t_image_extraction,
                        t_tables     = res.t_table_extraction,
                        t_total      = res.t_total,
                    )

                    log.info(f"Extracted: {uploaded_file.name} | {res.summary}")
                    st.success("✅ Ready!")

                except ValueError as exc:
                    st.error(str(exc))
                    log.warning(str(exc))
                except Exception as exc:
                    st.error(f"Extraction error: {exc}")
                    log.exception(str(exc))

    st.divider()

    # ── document info ──────────────────────────────────────────
    if st.session_state.doc_name:
        st.subheader("📋 Document Info")
        st.markdown(f"**File:** {st.session_state.doc_name}")
        st.markdown(f"**Pages:** {st.session_state.doc_pages}")
        st.markdown(f"**Characters:** {st.session_state.doc_chars:,}")

        # images
        img_count = st.session_state.doc_images
        st.markdown(
            f"**Images found:** {img_count} "
            + ("✅" if img_count > 0 else "—")
        )

        # tables
        tbl_count = st.session_state.doc_tables
        st.markdown(
            f"**Tables found:** {tbl_count} "
            + ("✅" if tbl_count > 0 else "—")
        )

        if st.session_state.doc_scanned:
            st.caption("🔍 Scanned PDF detected — EasyOCR was used")
        else:
            st.caption("📝 Digital document")

        if st.session_state.md_saved_path:
            st.caption(f"💾 Saved: `{st.session_state.md_saved_path}`")

        st.divider()

        if st.button("🗑️ Clear Document", use_container_width=True):
            keys_to_reset = {
                "extracted_text": None,
                "image_map":      {},
                "table_count":    0,
                "doc_name":       None,
                "doc_pages":      None,
                "doc_chars":      None,
                "doc_images":     0,
                "doc_tables":     0,
                "doc_scanned":    False,
                "md_saved_path":  None,
                "chat_history":   [],
                "messages":       [],
                "qa_turn":        0,
            }
            for k, v in keys_to_reset.items():
                st.session_state[k] = v
            log.info("Document cleared by user")
            st.rerun()


# ── main chat area ────────────────────────────────────────────

st.title("💬 Ask Your Document")

if not st.session_state.extracted_text:
    st.info(
        "👈 Upload a **PDF**, **DOCX**, or **TXT** file from the sidebar.\n\n"
        "Once uploaded, ask any question — including questions about "
        "**images, charts, graphs, or tables** inside the document."
    )

# render previous messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        # show question-type badge on assistant messages
        if msg["role"] == "assistant" and msg.get("mode"):
            st.caption(_MODE_BADGE.get(msg["mode"], ""))
        st.markdown(msg["content"])
        # render images that the answer referenced
        for img_path in msg.get("images", []):
            if Path(img_path).exists():
                st.image(img_path, width=700)


# ── chat input ────────────────────────────────────────────────

question = st.chat_input(
    placeholder = "Ask a question — text, table, or image…",
    disabled    = not st.session_state.extracted_text,
)

if question:
    log.info(f"Q: {question[:120]}")

    # show user message
    with st.chat_message("user"):
        st.markdown(question)
    st.session_state.messages.append({
        "role": "user", "content": question, "images": [], "mode": None,
    })

    # ── build prompt (classify + select images inside) ────────
    prompt, images_base64, t_prompt, qtype = build_prompt(
        extracted_text = st.session_state.extracted_text,
        chat_history   = st.session_state.chat_history,
        question       = question,
        image_map      = st.session_state.image_map,
    )
    stats = GenerationStats(t_prompt_build=t_prompt)

    log.info(
        f"Prompt: {len(prompt):,} chars | "
        f"mode={qtype.mode} | "
        f"{len(images_base64)} images | "
        f"build={t_prompt:.3f}s"
    )

    # ── stream answer ─────────────────────────────────────────
    full_answer       = ""
    referenced_images = []

    with st.chat_message("assistant"):
        # show question type badge
        st.caption(_MODE_BADGE.get(qtype.mode, ""))

        try:
            full_answer = st.write_stream(
                stream_response(prompt, images_base64, stats)
            )
        except Exception as exc:
            full_answer = (
                f"❌ Ollama error: `{exc}`\n\n"
                "Check that Ollama is running and OLLAMA_HOST in config.py is correct."
            )
            st.error(full_answer)
            log.error(f"Ollama error: {exc}")

        # ── second-pass verifier for higher factual grounding ──
        try:
            vr = verify_and_correct_answer(
                question      = question,
                extracted_text= st.session_state.extracted_text,
                draft_answer  = full_answer,
                images        = images_base64,
            )
            if vr.corrected_answer != full_answer:
                full_answer = vr.corrected_answer
                st.caption("✅ Answer refined by grounding verifier")
                st.markdown(full_answer)
                if vr.issues:
                    log.info(f"Verifier corrected answer | issues={vr.issues}")
            else:
                log.info("Verifier accepted draft answer")
        except Exception as exc:
            log.warning(f"Verifier pass failed (using draft answer): {exc}")

        # ── render images the model referenced in its answer ──
        if st.session_state.image_map:
            nums = re.findall(r"<<IMAGE_(\d+)>>", full_answer)
            seen = set()
            for n in nums:
                if n not in seen:
                    seen.add(n)
                    img_path = st.session_state.image_map.get(int(n))
                    if img_path and Path(img_path).exists():
                        referenced_images.append(img_path)
                        st.image(
                            img_path,
                            caption = f"Figure {n}",
                            width   = 700,
                        )

    # ── update history ─────────────────────────────────────────
    st.session_state.qa_turn += 1
    st.session_state.chat_history.append({
        "question": question,
        "answer":   full_answer,
    })
    if len(st.session_state.chat_history) > MAX_HISTORY_TURNS:
        st.session_state.chat_history = (
            st.session_state.chat_history[-MAX_HISTORY_TURNS:]
        )

    # save for re-render
    st.session_state.messages.append({
        "role":    "assistant",
        "content": full_answer,
        "images":  referenced_images,
        "mode":    qtype.mode,
    })

    # ── activity log ───────────────────────────────────────────
    activity_log.log_qa(
        turn          = st.session_state.qa_turn,
        question      = question,
        answer        = full_answer,
        question_type = qtype.mode,
        t_prompt      = stats.t_prompt_build,
        t_ttft        = stats.t_ttft,
        t_total       = stats.t_total,
        chars_per_sec = stats.chars_per_sec,
        images_sent   = len(images_base64),
    )

    log.info(
        f"QA done | Turn {st.session_state.qa_turn} | "
        f"mode={qtype.mode} | {stats.summary}"
    )
