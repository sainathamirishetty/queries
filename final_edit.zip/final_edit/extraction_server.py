"""
extraction_server.py
────────────────────────────────────────────────────────────────
FastAPI server that runs on the HIGH-END GPU machine.
Receives PDF file → runs Docling extraction → returns JSON.

Run on GPU server:
    conda activate docling2_env
    pip install fastapi uvicorn python-multipart
    python extraction_server.py

Endpoints:
    GET  /health   → server status check
    POST /extract  → PDF extraction (main endpoint)

Your Streamlit PC calls this API when EXTRACTION_MODE = "api"
in config.py. Everything else in the pipeline stays unchanged.
"""

import base64
import re
import tempfile
import time
import traceback
from pathlib import Path
from typing import Dict, Any

import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException, Query
from fastapi.responses import JSONResponse

# ── Server config — edit these ────────────────────────────────
SERVER_HOST            = "0.0.0.0"   # listen on all interfaces
SERVER_PORT            = 8001        # port your Streamlit PC will call
MAX_PAGES              = 50          # reject PDFs with more pages
SCANNED_TEXT_THRESHOLD = 50          # chars threshold for scanned detection
IMAGE_RESOLUTION_SCALE = 2.0         # Docling image resolution (2x)
LOG_REQUESTS           = True        # print extraction logs to console

# ─────────────────────────────────────────────────────────────

app = FastAPI(
    title        = "DocQA Extraction Server",
    description  = "Docling-based PDF extraction API for AI-Powered Document Assistant",
    version      = "1.0.0",
)


def _log(msg: str):
    if LOG_REQUESTS:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{ts}] {msg}")


# ── Health check ──────────────────────────────────────────────

@app.get("/health")
def health():
    """Quick health check — Streamlit app calls this to verify server is up."""
    return {
        "status":   "ok",
        "server":   "DocQA Extraction Server",
        "version":  "1.0.0",
        "max_pages": MAX_PAGES,
    }


# ── Main extraction endpoint ──────────────────────────────────

@app.post("/extract")
async def extract(
    file: UploadFile = File(..., description="PDF file to extract"),
):
    """
    Extract PDF using Docling.

    Accepts:  multipart PDF upload
    Returns:  JSON with markdown text, base64 images, metadata, timings
    """
    t_wall = time.perf_counter()

    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=400,
            detail="Only PDF files are supported by this endpoint."
        )

    _log(f"Received: {file.filename}")

    # ── Save uploaded PDF to temp file ────────────────────────
    pdf_bytes = await file.read()
    tmp_pdf   = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    tmp_pdf.write(pdf_bytes)
    tmp_pdf.flush()
    tmp_pdf.close()
    tmp_path = Path(tmp_pdf.name)

    try:
        result = _run_extraction(tmp_path)
        result["total_time"] = round(time.perf_counter() - t_wall, 3)
        _log(
            f"Done: {file.filename} | "
            f"pages={result['page_count']} | "
            f"images={len(result['images'])} | "
            f"tables={result['table_count']} | "
            f"time={result['total_time']}s"
        )
        return JSONResponse(content=result)

    except ValueError as exc:
        _log(f"Rejected: {exc}")
        raise HTTPException(status_code=422, detail=str(exc))

    except Exception as exc:
        _log(f"Error: {exc}")
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail=f"Extraction failed: {str(exc)}"
        )

    finally:
        tmp_path.unlink(missing_ok=True)


# ── Core extraction logic ─────────────────────────────────────

def _run_extraction(pdf_path: Path) -> Dict[str, Any]:
    """
    Run complete Docling extraction pipeline.
    Returns dict ready to JSON-serialize and send back.
    """
    import fitz
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions, EasyOcrOptions
    from docling_core.types.doc import PictureItem, TableItem, SectionHeaderItem

    # ── Step 1: Page count + scanned detection ────────────────
    t0       = time.perf_counter()
    fitz_doc = fitz.open(str(pdf_path))
    total_pages = len(fitz_doc)

    if total_pages > MAX_PAGES:
        fitz_doc.close()
        raise ValueError(
            f"Document has {total_pages} pages — server limit is {MAX_PAGES}."
        )

    scanned_pages = 0
    for pg in fitz_doc:
        raw = pg.get_text("text").strip()
        if len(raw) < SCANNED_TEXT_THRESHOLD and pg.get_images(full=True):
            scanned_pages += 1
    is_scanned = scanned_pages > (total_pages // 2)
    fitz_doc.close()
    t_page_check = round(time.perf_counter() - t0, 3)

    _log(
        f"Page check done | {total_pages} pages | "
        f"scanned={is_scanned} ({scanned_pages}/{total_pages}) | "
        f"{t_page_check}s"
    )

    # ── Step 2: Docling conversion ────────────────────────────
    t0 = time.perf_counter()

    pipeline_options = PdfPipelineOptions(
        images_scale            = IMAGE_RESOLUTION_SCALE,
        generate_page_images    = True,
        generate_picture_images = True,
        ocr_options             = EasyOcrOptions(),
    )
    converter = DocumentConverter(
        format_options={
            InputFormat.PDF: PdfFormatOption(
                pipeline_options=pipeline_options
            )
        }
    )

    _log("Docling: starting conversion...")
    conv_res = converter.convert(str(pdf_path))
    _log("Docling: conversion complete")

    # ── Step 3: Extract images → base64 ──────────────────────
    images_b64:  Dict[str, str] = {}
    img_counter                  = 0

    for element, _ in conv_res.document.iterate_items():
        if isinstance(element, PictureItem):
            img_counter += 1
            try:
                pil_img = element.get_image(conv_res.document)
                if pil_img:
                    import io
                    buf = io.BytesIO()
                    pil_img.save(buf, format="PNG")
                    b64_str = base64.b64encode(buf.getvalue()).decode("utf-8")
                    images_b64[str(img_counter)] = b64_str
                    _log(f"Image {img_counter} encoded ({len(b64_str)//1024}KB)")
            except Exception as exc:
                _log(f"Warning: image {img_counter} failed: {exc}")

    t_images = round(time.perf_counter() - t0, 3)
    _log(f"Images done | {img_counter} images | {t_images}s")

    # ── Step 4: Build markdown with page markers ──────────────
    t0       = time.perf_counter()
    lines    = []
    cur_page = 0
    img_idx  = 0

    for element, _ in conv_res.document.iterate_items():

        # Page marker injection
        page_no = 0
        if hasattr(element, "prov") and element.prov:
            try:
                page_no = int(element.prov[0].page_no)
            except Exception:
                page_no = cur_page

        if page_no > cur_page:
            cur_page = page_no
            lines.append(f"\n<!-- Page {cur_page} -->\n")

        # Image placeholder
        if isinstance(element, PictureItem):
            img_idx += 1
            if str(img_idx) in images_b64:
                lines.append(f"\n[Image {img_idx} appears here]\n")

        # Table → pipe markdown
        elif isinstance(element, TableItem):
            try:
                tbl_md = element.export_to_markdown()
                if tbl_md and tbl_md.strip():
                    lines.append(f"\n{tbl_md.strip()}\n")
            except Exception as exc:
                _log(f"Warning: table export failed: {exc}")

        # Section heading
        elif isinstance(element, SectionHeaderItem):
            text = (getattr(element, "text", None) or "").strip()
            if text:
                lvl = getattr(element, "level", 1) or 1
                lines.append(f"\n{'#' * min(int(lvl), 6)} {text}\n")

        # All other text
        else:
            try:
                text = (getattr(element, "text", None) or "").strip()
                if text:
                    lines.append(text)
            except Exception:
                pass

    if cur_page == 0:
        lines.insert(0, "\n<!-- Page 1 -->\n")

    markdown    = "\n".join(lines)
    t_text      = round(time.perf_counter() - t0, 3)

    # ── Step 5: Count tables ──────────────────────────────────
    t0          = time.perf_counter()
    table_count = len(re.findall(r"\n\|[-| :]+\|", markdown))
    t_tables    = round(time.perf_counter() - t0, 3)

    page_count  = len(re.findall(r"<!-- Page \d+ -->", markdown))

    _log(
        f"Markdown built | chars={len(markdown):,} | "
        f"pages={page_count} | tables={table_count} | {t_text}s"
    )

    return {
        "markdown":    markdown,
        "images":      images_b64,       # {str(num): base64_string}
        "table_count": table_count,
        "page_count":  page_count,
        "is_scanned":  is_scanned,
        "timings": {
            "page_check": t_page_check,
            "text":       t_text,
            "images":     t_images,
            "tables":     t_tables,
        },
    }


# ── Run server ────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("  DocQA Extraction Server")
    print(f"  Host : {SERVER_HOST}")
    print(f"  Port : {SERVER_PORT}")
    print(f"  Max pages  : {MAX_PAGES}")
    print(f"  Image scale: {IMAGE_RESOLUTION_SCALE}x")
    print("=" * 60)
    print(f"  Streamlit PC should set in config.py:")
    print(f"  EXTRACTION_MODE    = 'api'")
    print(f"  EXTRACTION_API_URL = 'http://<THIS_SERVER_IP>:{SERVER_PORT}'")
    print("=" * 60)
    uvicorn.run(app, host=SERVER_HOST, port=SERVER_PORT, log_level="info")
