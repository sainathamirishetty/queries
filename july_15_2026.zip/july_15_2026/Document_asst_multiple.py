import re
import uuid
import tempfile
import shutil
from pathlib import Path

import streamlit as st
import random

from config import SUPPORTED_EXTENSIONS, MAX_HISTORY_TURNS, MAX_IMAGES_PER_QUERY, MAX_PAGES
from extractor import extract_document, cleanup_session_images
from ollama_connect import (
    build_prompt,
    check_ollama_connection,
    stream_response,
    GenerationStats,
)
from logger import get_logger, activity_log

log = get_logger("app")


# ── page config ───────────────────────────────────────────────

st.set_page_config(
    page_title = "Document Assistant",
    page_icon  = "📄",
    layout     = "wide",
)


# ══════════════════════════════════════════════════════════════
# THEME  —  injected once, styling only (no logic touched)
# ══════════════════════════════════════════════════════════════

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700&family=Inter:wght@400;500;600&display=swap');

:root {
    --bg:        #F4F6FB;
    --surface:   #FFFFFF;
    --ink:       #0F172A;
    --muted:     #64748B;
    --line:      #E2E8F0;
    --primary:   #4F46E5;
    --primary-d: #4338CA;
    --accent:    #06B6D4;
    --ok:        #16A34A;
    --warn:      #D97706;
    --err:       #DC2626;
}

/* ---- base ---- */
.stApp { background: var(--bg); }
html, body, [class*="css"], .stMarkdown, p, span, div, label, input, textarea {
    font-family: 'Inter', system-ui, sans-serif;
    color: var(--ink);
}
#MainMenu, header[data-testid="stHeader"] { background: transparent; }
.block-container { padding-top: 1.4rem; max-width: 1180px; }

/* ---- hero header ---- */
.hero {
    background: linear-gradient(135deg, #1E293B 0%, #334155 55%, #4F46E5 135%);
    border-radius: 18px;
    padding: 30px 34px;
    color: #fff;
    box-shadow: 0 10px 30px rgba(30,41,59,.18);
    margin-bottom: 20px;
}
.hero .eyebrow {
    font-size: 12px; letter-spacing: .18em; text-transform: uppercase;
    color: #C7D2FE; font-weight: 600; margin-bottom: 8px;
}
.hero h1 {
    font-family: 'Sora', sans-serif; font-weight: 700;
    font-size: 34px; line-height: 1.1; margin: 0; color: #fff;
}
.hero p { margin: 10px 0 0; color: #CBD5E1; font-size: 15px; max-width: 640px; }
.hero .badge {
    display:inline-block; margin-top:16px; padding:5px 12px;
    background: rgba(255,255,255,.12); border:1px solid rgba(255,255,255,.22);
    border-radius:999px; font-size:12px; font-weight:600; color:#E0E7FF;
}

/* ---- info cards ---- */
.info-grid { display:flex; gap:16px; margin-bottom: 4px; }
.info-card {
    flex:1; background: var(--surface); border:1px solid var(--line);
    border-radius:14px; padding:18px 20px; position:relative;
    box-shadow: 0 2px 6px rgba(15,23,42,.04);
}
.info-card::before {
    content:""; position:absolute; left:0; top:16px; bottom:16px; width:4px;
    border-radius:4px; background: var(--primary);
}
.info-card.warn::before { background: var(--accent); }
.info-card h4 {
    font-family:'Sora',sans-serif; font-size:14px; font-weight:600;
    margin:0 0 8px 14px; color:var(--ink);
}
.info-card p { font-size:13.5px; line-height:1.55; color:var(--muted); margin:0 0 0 14px; }

/* ---- sidebar ---- */
[data-testid="stSidebar"] {
    background: var(--surface); border-right:1px solid var(--line);
}
[data-testid="stSidebar"] .block-container { padding-top: 1.2rem; }
.side-brand {
    display:flex; align-items:center; gap:10px; padding:4px 2px 14px;
    border-bottom:1px solid var(--line); margin-bottom:14px;
}
.side-brand .logo {
    width:36px; height:36px; border-radius:10px;
    background:linear-gradient(135deg,var(--primary),var(--accent));
    display:flex; align-items:center; justify-content:center; font-size:18px;
}
.side-brand .t1 { font-family:'Sora',sans-serif; font-weight:600; font-size:15px; }
.side-brand .t2 { font-size:11px; color:var(--muted); letter-spacing:.04em; }
[data-testid="stSidebar"] h3, [data-testid="stSidebar"] .stSubheader {
    font-family:'Sora',sans-serif !important;
}

/* ---- file uploader ---- */
[data-testid="stFileUploaderDropzone"] {
    background:#F8FAFC; border:1.5px dashed #CBD5E1; border-radius:12px;
    transition: all .15s ease;
}
[data-testid="stFileUploaderDropzone"]:hover {
    border-color: var(--primary); background:#F5F3FF;
}

/* ---- document chips ---- */
.doc-chip {
    display:flex; align-items:center; gap:10px;
    background:#F8FAFC; border:1px solid var(--line); border-radius:11px;
    padding:10px 12px;
}
.doc-chip .dot { width:9px; height:9px; border-radius:50%; flex-shrink:0; }
.doc-chip .dot.ready { background:var(--ok);   box-shadow:0 0 0 3px rgba(22,163,74,.15); }
.doc-chip .dot.work  { background:var(--warn); box-shadow:0 0 0 3px rgba(217,119,6,.15); }
.doc-chip .dot.fail  { background:var(--err);  box-shadow:0 0 0 3px rgba(220,38,38,.15); }
.doc-chip .doc-name { font-size:13px; font-weight:600; word-break:break-word; }
.doc-chip .doc-meta { font-size:11.5px; color:var(--muted); }

/* ---- buttons ---- */
.stButton > button {
    border-radius:10px; border:1px solid var(--line); font-weight:600;
    font-family:'Inter',sans-serif; transition: all .15s ease;
    background: var(--surface); color: var(--ink);
}
.stButton > button:hover {
    border-color: var(--primary); color: var(--primary);
    background:#F5F3FF;
}

/* ---- chat messages ---- */
[data-testid="stChatMessage"] {
    background: var(--surface); border:1px solid var(--line);
    border-radius:14px; padding:14px 16px; box-shadow:0 2px 6px rgba(15,23,42,.04);
    margin-bottom: 6px;
}
[data-testid="stChatMessage"]:has([data-testid="stChatMessageAvatarUser"]) {
    background:#F5F3FF; border-color:#E0E7FF;
}

/* ---- chat input ---- */
[data-testid="stChatInput"] {
    border-radius:14px; border:1px solid var(--line);
    box-shadow:0 4px 14px rgba(15,23,42,.06);
}
[data-testid="stChatInput"]:focus-within { border-color: var(--primary); }

/* ---- divider tighten ---- */
hr { margin: 14px 0; border-color: var(--line); }
</style>
""", unsafe_allow_html=True)


# ── Ollama check — terminal/log only ─────────────────────────

@st.cache_data(ttl=60, show_spinner=False)
def _cached_ollama_check() -> tuple:
    return check_ollama_connection()

_ok, _info = _cached_ollama_check()
log.info(f"Ollama | {'Connected' if _ok else 'NOT reachable'} | {_info}")


# ── client IP detection ───────────────────────────────────────

def _get_client_ip() -> str:
    try:
        from streamlit import runtime
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        ctx = get_script_run_ctx()
        if ctx is None:
            return "unknown"
        session_info = runtime.get_instance().get_client(ctx.session_id)
        if session_info is None:
            return "unknown"
        return f"{session_info.request.remote_ip}"
    except Exception:
        return "unknown"


# ── session cleanup sentinel ─────────────────────────────────

class _SessionCleanup:
    """
    Stored in session_state so Python calls __del__ when Streamlit
    garbage-collects the session (browser tab closed / session expired).
    Deletes all extracted folders created during this session.
    """
    def __init__(self, session_id: str):
        self.session_id = session_id

    def __del__(self):
        try:
            out_dirs = [
                d.get("out_dir")
                for d in st.session_state.get("documents", [])
                if d.get("out_dir")
            ]
            if out_dirs:
                cleanup_session_images(self.session_id, out_dirs)
                log.info(
                    f"Session {self.session_id} ended — "
                    f"deleted {len(out_dirs)} folder(s)"
                )
        except Exception:
            pass  # session_state may already be gone — silently skip


# ── session init ──────────────────────────────────────────────

def _init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = _get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        st.session_state.qa_turn    = 0
        activity_log.log_session_start(sid, ip)
        log.info(f"New session id={sid} ip={ip}")
        st.session_state._cleanup_sentinel = _SessionCleanup(sid)

    defaults = {
        # Multi-doc state
        "documents":    [],    # list of doc dicts
        "total_pages":  0,     # running total pages across all docs
        # Chat state
        "chat_history": [],
        "messages":     [],
        "qa_turn":      0,
        # UI state
        "uploader_key": 0,
        "_streaming":   False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_session()


# ── helpers ───────────────────────────────────────────────────

_IMAGE_REF_RE = re.compile(r"(?:see\s+)?[Ii]mage\s+(\d+)", re.IGNORECASE)


def _render_referenced_images(answer_text: str, image_map: dict):
    """Parse LLM answer for Image N references and render those images."""
    rendered = []
    seen     = set()
    for m in _IMAGE_REF_RE.finditer(answer_text):
        n = int(m.group(1))
        if n not in seen and n in image_map:
            seen.add(n)
            img_path = image_map[n]
            if Path(img_path).exists():
                rendered.append(img_path)
                st.image(img_path, caption=f"Image {n}", width=700)
    return rendered


def _build_combined_context():
    """
    Combine all ready documents into one text block and one image_map.
    Each document clearly marked with its name for LLM citation.
    Images renumbered globally across all documents.
    """
    combined_text      = ""
    combined_image_map = {}
    global_img_counter = 1

    ready_docs = [
        d for d in st.session_state.documents
        if d["status"] == "ready"
    ]

    for i, doc in enumerate(ready_docs, 1):
        # Document header — LLM uses filename for citation
        combined_text += (
            f"\n{'═' * 60}\n"
            f"[DOCUMENT {i}: {doc['name']} | {doc['page_count']} pages]\n"
            f"{'═' * 60}\n"
        )

        # Replace local image tags with global numbers
        doc_text = doc["full_text"]
        for local_num in sorted(doc["image_map"].keys()):
            path    = doc["image_map"][local_num]
            old_tag = f"[Image {local_num} appears here]"
            new_tag = f"[Image {global_img_counter} appears here]"
            doc_text = doc_text.replace(old_tag, new_tag, 1)
            combined_image_map[global_img_counter] = path
            global_img_counter += 1

        combined_text += doc_text + "\n\n"

    print(f"{'=' * 80} FRESH CONVERSATION {'=' * 80}")
    print(combined_text)   # In Terminal it will show all appended Documents.this full length is going to OLLAMA
    print(f"{'=' * 80} ENDING OF ALL DOCUMENTS {'=' * 80}")

    return combined_text, combined_image_map


def _remove_document(doc_name: str):
    """Remove a document from the list and update total pages."""
    st.session_state.documents = [
        d for d in st.session_state.documents
        if d["name"] != doc_name
    ]
    st.session_state.total_pages = sum(
        d["page_count"] for d in st.session_state.documents
    )
    log.info(f"Removed document: {doc_name}")


def _do_extraction(uploaded_file):
    """
    Full extraction pipeline for one document:
    1. Quick page count check
    2. Total pages limit check
    3. Extract with Docling
    4. Add to documents list
    """
    # ── Save uploaded file to temp ────────────────────────────
    suffix = Path(uploaded_file.name).suffix
    tmp    = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(uploaded_file.read())
    tmp.flush()
    tmp.close()

    # ── Quick page count for PDF ──────────────────────────────
    new_pages = 1   # default for DOCX / TXT
    if suffix.lower() == ".pdf":
        try:
            import fitz
            fitz_doc  = fitz.open(tmp.name)
            new_pages = len(fitz_doc)
            fitz_doc.close()
        except Exception:
            new_pages = 1   # fallback if fitz fails

    # ── Total pages limit check ───────────────────────────────
    current_total = st.session_state.total_pages
    if current_total + new_pages > MAX_PAGES:
        st.session_state["uploader_key"] += 1
        st.sidebar.error(
            f"**Cannot add {uploaded_file.name}** ({new_pages} pages).\n\n"
            f"Current total: **{current_total} / {MAX_PAGES} pages** used.\n\n"
            f"Adding this would reach **{current_total + new_pages} pages** "
            f"which exceeds the **{MAX_PAGES} page limit**.\n\n"
            f"Please click ✕ next to an uploaded document to delete, "
            f"then try again."
        )
        log.warning(
            f"Page limit exceeded: {uploaded_file.name} ({new_pages}p) "
            f"+ current ({current_total}p) > {MAX_PAGES}"
        )
        return

    # ── Add to documents list with extracting status ──────────
    doc_entry = {
        "name":        uploaded_file.name,
        "full_text":   "",
        "image_map":   {},
        "page_count":  new_pages,
        "table_count": 0,
        "is_scanned":  False,
        "status":      "extracting",
    }

    st.session_state.documents.append(doc_entry)
    print(f"{'&'*50}")
    print(doc_entry)
    print(f"{'&'*50}")
    st.session_state.total_pages += new_pages

    # ── Progress bar ──────────────────────────────────────────
    progress_bar = st.sidebar.progress(0)
    caption_widget=st.sidebar.caption(f" I'm Working on **{uploaded_file.name}** — Please wait...")

    def _on_progress(fraction: float, msg: str):
        progress_bar.progress(min(fraction, 1.0))

    # ── Run extraction ────────────────────────────────────────
    try:
        res = extract_document(
            file_path         = tmp.name,
            file_ext          = suffix.lstrip("."),
            session_id        = st.session_state.session_id,
            original_filename = uploaded_file.name,
            progress_cb       = _on_progress,
        )

        # Update document entry in list
        for doc in st.session_state.documents:
            if doc["name"] == uploaded_file.name:
                doc["full_text"]   = res.full_text
                doc["image_map"]   = res.image_map
                doc["page_count"]  = res.page_count
                doc["table_count"] = res.table_count
                doc["is_scanned"]  = res.is_scanned
                doc["out_dir"]     = res.out_dir
                doc["status"]      = "ready"
                break

        # Recalculate total from actual page counts
        st.session_state.total_pages = sum(
            d["page_count"] for d in st.session_state.documents
        )

        activity_log.log_document(
            filename = uploaded_file.name,
            pages    = res.page_count,
            chars    = len(res.full_text),
            images   = len(res.image_map),
            tables   = res.table_count,
        )
        activity_log.log_extraction_timing(
            t_page_check = res.t_page_check,
            t_text       = res.t_text_extraction,
            t_images     = res.t_image_extraction,
            t_total      = res.t_total,
            t_tables     = res.t_table_extraction,
        )

        log.info(f"Extracted: {uploaded_file.name} | {res.summary}")
        progress_bar.empty()
        caption_widget.empty()
        st.sidebar.success(f" {uploaded_file.name} ready!")
        st.session_state["uploader_key"] += 1

    except ValueError as exc:
        # Remove failed doc from list
        st.session_state.documents = [
            d for d in st.session_state.documents
            if d["name"] != uploaded_file.name
        ]
        st.session_state.total_pages = sum(
            d["page_count"] for d in st.session_state.documents
        )
        progress_bar.empty()
        st.session_state["uploader_key"] += 1
        st.sidebar.error(str(exc))
        log.warning(str(exc))

    except Exception as exc:
        # Remove failed doc from list
        st.session_state.documents = [
            d for d in st.session_state.documents
            if d["name"] != uploaded_file.name
        ]
        st.session_state.total_pages = sum(
            d["page_count"] for d in st.session_state.documents
        )
        progress_bar.empty()
        st.session_state["uploader_key"] += 1
        st.sidebar.error(f"Extraction error: {exc}")
        log.exception(str(exc))


def _clear_all_documents():
    """Clear all documents and reset chat."""
    for k, v in {
        "documents":    [],
        "total_pages":  0,
        "chat_history": [],
        "messages":     [],
        "qa_turn":      0,
    }.items():
        st.session_state[k] = v
    st.session_state["uploader_key"] += 1
    log.info("All documents cleared by user")


# ── sidebar ───────────────────────────────────────────────────

with st.sidebar:

    # ── Brand block ────────────────────────────────────────────
    st.markdown(
        """
        <div class="side-brand">
            <div class="logo">📄</div>
            <div>
                <div class="t1">Document Assistant</div>
                <div class="t2">DAIV · RCI</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ── Upload section ─────────────────────────────────────────
    st.subheader("📂 Submit Document")
    st.caption(f"PDF · DOCX · TXT · Code — max {MAX_PAGES} pages total")

    uploaded_file = st.file_uploader(
        label            = "Choose a file",
        type             = SUPPORTED_EXTENSIONS,
        label_visibility = "collapsed",
        key              = f"uploader_{st.session_state.uploader_key}",
        accept_multiple_files=True #this will enable multiple files at a time,false for single selection
    )

    # Duplicate check then extraction
    if uploaded_file is not None:
        existing_names = [d["name"] for d in st.session_state.documents]
        duplicates_found = False

        # Handle both single file and multiple files cases
        if isinstance(uploaded_file, list):
            for file in uploaded_file:
                if file.name in existing_names:
                    st.sidebar.warning(
                        f"**{file.name}** is already loaded."
                    )
                    duplicates_found = True
                else:
                    _do_extraction(file)
        else:
            if uploaded_file.name in existing_names:
                st.sidebar.warning(
                    f"**{uploaded_file.name}** is already loaded."
                )
                duplicates_found = True
            else:
                _do_extraction(uploaded_file)

        # Clear uploader widget if duplicates were found
        if duplicates_found:
            st.session_state["uploader_key"] += 1

    # ── Clear All button ───────────────────────────────────────
    st.button(
        " Clear All Documents",
        use_container_width = True,
        disabled            = len(st.session_state.documents) == 0,
        help                = "Remove all documents and reset chat",
        on_click            = _clear_all_documents,
    )

    # ── Documents list with status ─────────────────────────────
    if st.session_state.documents and not st.session_state._streaming:
        st.divider()
        st.subheader("📋 Documents")

        for doc in st.session_state.documents:
            col_info, col_btn = st.columns([5, 1])

            with col_info:
                if doc["status"] == "ready":
                    st.markdown(
                        f'<div class="doc-chip"><span class="dot ready"></span>'
                        f'<div><div class="doc-name">{doc["name"]}</div>'
                        f'<div class="doc-meta">{doc["page_count"]} pages</div>'
                        f'</div></div>',
                        unsafe_allow_html=True,
                    )
                elif doc["status"] == "extracting":
                    st.markdown(
                        f'<div class="doc-chip"><span class="dot work"></span>'
                        f'<div><div class="doc-name">{doc["name"]}</div>'
                        f'<div class="doc-meta">Extracting…</div>'
                        f'</div></div>',
                        unsafe_allow_html=True,
                    )
                else:
                    st.markdown(
                        f'<div class="doc-chip"><span class="dot fail"></span>'
                        f'<div><div class="doc-name">{doc["name"]}</div>'
                        f'<div class="doc-meta">Failed</div>'
                        f'</div></div>',
                        unsafe_allow_html=True,
                    )

            with col_btn:
                if st.button(
                    "✕",
                    key  = f"remove_{doc['name']}",
                    help = f"Remove {doc['name']}",
                ):
                    _remove_document(doc["name"])
                    st.rerun()

        # ── Total pages usage ──────────────────────────────────
        total = st.session_state.total_pages


# ══════════════════════════════════════════════════════════════
# MAIN AREA
# ══════════════════════════════════════════════════════════════

# ── Hero header ───────────────────────────────────────────────
st.markdown(
    """
    <div class="hero">
        <div class="eyebrow">AI Document Intelligence</div>
        <h1>Document Assistant</h1>
        <p>Ask questions, retrieve facts, and refine content — grounded entirely
        in the documents you upload. Text, tables and images, all in one place.</p>
        <span class="badge">Answers sourced only from your files</span>
    </div>
    """,
    unsafe_allow_html=True,
)

# ── About / Disclaimer cards ──────────────────────────────────
st.markdown(
    """
    <div class="info-grid">
        <div class="info-card">
            <h4>What it does</h4>
            <p>Upload one or more PDF, DOCX, TXT or code files from the sidebar,
            then ask questions across everything you've added. The assistant reads
            text, tables and images — and can also rewrite, improve or summarize
            content when you ask.</p>
        </div>
        <div class="info-card warn">
            <h4>Good to know</h4>
            <p>Answers come only from the documents you upload; no outside
            knowledge is used for retrieval. Scanned PDFs are partially supported.
            Always verify critical details against the original source.</p>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

st.divider()

# ── Chat messages ─────────────────────────────────────────────

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        for img_path in msg.get("images", []):
            if Path(img_path).exists():
                st.image(img_path, width=700)

# ── Chat input ────────────────────────────────────────────────

# Enable chat when at least one document is ready
any_ready = any(
    d["status"] == "ready" for d in st.session_state.documents
)

question = st.chat_input(
    placeholder = "Ask about text, tables, images — or ask to improve/summarize…",
    disabled    = not any_ready,
)

if question:
    log.info(f"Q: {question[:120]}")

    # Show user message immediately
    with st.chat_message("user"):
        st.markdown(question)
    st.session_state.messages.append({
        "role": "user", "content": question, "images": [], "mode": None,
    })

    # ── Build combined context from all ready docs ─────────────
    combined_text, combined_image_map = _build_combined_context()

    # ── Build prompt ───────────────────────────────────────────
    prompt, images_b64, t_prompt, qtype = build_prompt(
        extracted_text = combined_text,
        chat_history   = st.session_state.chat_history,
        question       = question,
        image_map      = combined_image_map,
    )
    stats = GenerationStats(t_prompt_build=t_prompt)

    log.info(
        f"Prompt: {len(prompt):,} chars | mode={qtype.mode} | "
        f"{len(images_b64)} image(s) | build={t_prompt:.3f}s"
    )

    # ── Stream answer ──────────────────────────────────────────
    full_answer       = ""
    referenced_images = []

    THINKING_MESSAGES = [
        "Analyzing your query against the available documents.",
        "Retrieving the most relevant information.",
        "Processing context to ensure an accurate response.",
        "Searching the knowledge base for matching insights.",
        "Reviewing related content to form a precise answer.",
        "Evaluating document sections for relevance.",
        "Synthesizing information from multiple sources.",
        "Aligning your question with stored knowledge.",
        "Identifying key details required for the response.",
        "Cross-checking facts to improve accuracy.",
        "Understanding the intent behind your question.",
        "Filtering unnecessary information.",
        "Assembling a clear and concise answer.",
        "Validating results before responding.",
        "Matching your query with indexed content.",
        "Optimizing the response for clarity.",
        "Finalizing the answer for delivery.",
    ]

    st.session_state["_streaming"] = True

    with st.spinner(random.choice(THINKING_MESSAGES)):
        try:
            # NOTE: to enable per-mode temperature (optional steps 7-8 in
            # ollama_connect.py), replace the call below with:
            #   temp = 0.5 if (qtype.mode == "text" and qtype.intent == "edit") else 0.2
            #   full_answer = st.write_stream(
            #       stream_response(prompt, images_b64, stats, temperature=temp)
            #   )
            full_answer = st.write_stream(
                stream_response(prompt, images_b64, stats)
            )
        except Exception as exc:
            full_answer = (
                f"❌ Ollama error: `{exc}`\n\n"
                "Check Ollama is running and OLLAMA_HOST in config.py is correct."
            )
            st.error(full_answer)
            log.error(f"Ollama error: {exc}")
            with st.chat_message("assistant"):
                st.markdown(full_answer)

        # Render referenced images below answer
        if combined_image_map:
            referenced_images = _render_referenced_images(
                full_answer, combined_image_map
            )

    st.session_state["_streaming"] = False

    # ── Update session state ───────────────────────────────────
    st.session_state.qa_turn += 1
    st.session_state.chat_history.append({
        "question": question,
        "answer":   full_answer,
    })
    if len(st.session_state.chat_history) > MAX_HISTORY_TURNS:
        st.session_state.chat_history = (
            st.session_state.chat_history[-MAX_HISTORY_TURNS:]
        )

    st.session_state.messages.append({
        "role":    "assistant",
        "content": full_answer,
        "images":  referenced_images,
        "mode":    qtype.mode,
    })

    # ── Activity log ───────────────────────────────────────────
    doc_names = [d["name"] for d in st.session_state.documents]
    activity_log.log_qa(
        turn          = st.session_state.qa_turn,
        question      = question,
        answer        = full_answer,
        t_prompt      = stats.t_prompt_build,
        t_ttft        = stats.t_ttft,
        t_total       = stats.t_total,
        chars_per_sec = stats.chars_per_sec,
        question_type = qtype.mode,
        images_sent   = len(images_b64),
        ip            = st.session_state.client_ip,
    )

    log.info(
        f"QA done | Turn {st.session_state.qa_turn} | "
        f"mode={qtype.mode} | docs={doc_names} | {stats.summary}"
    )


# ── Footer ────────────────────────────────────────────────────

footer_html = """
<style>
footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #0F172A;
    color: #94A3B8;
    text-align: center;
    font-size: 11px;
    padding: 10px 0;
    z-index: 999;
    letter-spacing: .02em;
}
footer b { color:#CBD5E1; }
</style>
<footer>
Designed &amp; Developed by <b>DAIV, RCI Team</b> &nbsp;—&nbsp; For Support Call 040-2430 7192
</footer>
"""
st.markdown("<div style='height: 40px;'></div>", unsafe_allow_html=True)
st.markdown(footer_html, unsafe_allow_html=True)
