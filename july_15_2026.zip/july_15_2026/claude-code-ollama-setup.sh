#!/usr/bin/env bash
#
# claude-code-ollama-setup.sh
# ---------------------------------------------------------------------------
# Sets up Claude Code to run FULLY OFFLINE against a local Ollama model.
#
# You run this ONE file on BOTH machines, with a different argument each time:
#
#   1) On the INTERNET pc (downloads the claude binary):
#          ./claude-code-ollama-setup.sh internet
#      -> produces a file called  claude-binary  next to this script.
#      -> copy BOTH this script and claude-binary to the offline pc.
#
#   2) On the OFFLINE pc (installs + wires it to Ollama):
#          ./claude-code-ollama-setup.sh offline
#      (optionally: ./claude-code-ollama-setup.sh offline /path/to/claude-binary)
#
# Requirements: both machines are Ubuntu and the SAME cpu architecture
# (run `uname -m` on each; they must match, normally x86_64).
# ---------------------------------------------------------------------------

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_OUT="${SCRIPT_DIR}/claude-binary"      # where 'internet' mode saves the binary
LOCAL_BIN="${HOME}/.local/bin"
CLAUDE_LINK="${HOME}/.local/bin/claude"

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
info() { printf '    %s\n' "$*"; }
warn() { printf '\n\033[33m[!] %s\033[0m\n' "$*"; }
die()  { printf '\n\033[31m[x] %s\033[0m\n' "$*" >&2; exit 1; }

# ===========================================================================
# MODE 1: INTERNET PC  — download the self-contained claude binary
# ===========================================================================
do_internet() {
    say "MODE: internet  (preparing the claude binary for transfer)"

    command -v curl >/dev/null 2>&1 || die "curl is not installed. Run: sudo apt install curl"

    say "Step 1/3  Running the official Claude Code native installer"
    curl -fsSL https://claude.ai/install.sh | bash \
        || die "Installer failed. Check your internet connection and try again."

    # The launcher may not be on PATH in this shell yet; use it directly.
    local claude_cmd="${CLAUDE_LINK}"
    [ -e "${claude_cmd}" ] || claude_cmd="$(command -v claude || true)"
    [ -n "${claude_cmd}" ] && [ -e "${claude_cmd}" ] \
        || die "Install finished but the claude launcher was not found at ${CLAUDE_LINK}"

    say "Step 2/3  Verifying the install"
    "${claude_cmd}" --version || die "claude --version failed."

    say "Step 3/3  Extracting the real (self-contained) binary"
    # ~/.local/bin/claude is a symlink into ~/.local/share/claude/versions/<ver>.
    local real_bin
    real_bin="$(readlink -f "${claude_cmd}")" \
        || die "Could not resolve the real binary behind the launcher."
    cp -f "${real_bin}" "${BIN_OUT}" || die "Could not copy the binary to ${BIN_OUT}"
    chmod +x "${BIN_OUT}"

    local arch size sum
    arch="$(uname -m)"
    size="$(du -h "${BIN_OUT}" | cut -f1)"
    sum="$(sha256sum "${BIN_OUT}" 2>/dev/null | cut -d' ' -f1)"

    say "DONE (internet pc)"
    info "Binary saved to : ${BIN_OUT}   (${size})"
    info "Architecture    : ${arch}   <-- the offline pc MUST match this"
    info "SHA256          : ${sum}"
    printf '\n'
    info "Next: copy these TWO files to the offline pc (USB / intranet):"
    info "    1) $(basename "${BASH_SOURCE[0]}")   (this script)"
    info "    2) claude-binary"
    info "Then on the offline pc run:   ./$(basename "${BASH_SOURCE[0]}") offline"
}

# ===========================================================================
# MODE 2: OFFLINE PC  — install the binary and wire Claude Code to Ollama
# ===========================================================================
do_offline() {
    say "MODE: offline  (installing Claude Code and wiring it to local Ollama)"

    # ---- locate the binary --------------------------------------------------
    local src="${1:-}"
    [ -z "${src}" ] && src="${BIN_OUT}"
    [ -f "${src}" ] || die "Binary not found at '${src}'. Copy claude-binary next to this script, or pass its path: ./$(basename "${BASH_SOURCE[0]}") offline /path/to/claude-binary"

    info "Offline pc architecture: $(uname -m)  (must match the internet pc)"

    # ---- install into PATH --------------------------------------------------
    say "Step 1/5  Installing the binary to ${CLAUDE_LINK}"
    mkdir -p "${LOCAL_BIN}"
    # remove any old symlink/file from a previous native install so we own it
    rm -f "${CLAUDE_LINK}"
    cp -f "${src}" "${CLAUDE_LINK}"
    chmod +x "${CLAUDE_LINK}"

    # ensure ~/.local/bin is on PATH for future shells
    case ":${PATH}:" in
        *":${LOCAL_BIN}:"*) : ;;  # already there
        *)
            if ! grep -qs 'HOME/.local/bin' "${HOME}/.bashrc" 2>/dev/null; then
                echo 'export PATH=$HOME/.local/bin:$PATH' >> "${HOME}/.bashrc"
                info "Added ~/.local/bin to PATH in ~/.bashrc (open a new terminal, or run: source ~/.bashrc)"
            fi
            export PATH="${LOCAL_BIN}:${PATH}"
            ;;
    esac

    "${CLAUDE_LINK}" --version >/dev/null 2>&1 \
        || die "The binary was installed but won't run. Most likely the architecture doesn't match the internet pc, or the file was corrupted in transfer."
    info "claude version: $("${CLAUDE_LINK}" --version)"

    # ---- check Ollama -------------------------------------------------------
    say "Step 2/5  Checking Ollama"
    command -v ollama >/dev/null 2>&1 || die "ollama not found on this machine. Install/start Ollama first."
    if ! ollama list >/dev/null 2>&1; then
        warn "Ollama does not appear to be running. Start it (e.g. 'ollama serve' or 'sudo systemctl start ollama'), then re-run this script."
    fi
    info "Ollama version: $(ollama --version 2>/dev/null | head -n1)"

    # ---- context window advice (server-side, the #1 gotcha) ----------------
    say "Step 3/5  Context window (the most common cause of a broken setup)"
    info "Ollama's DEFAULT serving context is only 4096 tokens, which breaks Claude Code."
    info "It must be raised on the OLLAMA SERVER side via OLLAMA_CONTEXT_LENGTH=64000."
    if systemctl list-units --type=service 2>/dev/null | grep -q '\bollama\.service\b'; then
        info "Detected Ollama running as a systemd service."
        printf '    Set it permanently now via a systemd drop-in? (needs sudo) [y/N] '
        read -r ans
        if [ "${ans:-N}" = "y" ] || [ "${ans:-N}" = "Y" ]; then
            sudo mkdir -p /etc/systemd/system/ollama.service.d
            printf '[Service]\nEnvironment="OLLAMA_CONTEXT_LENGTH=64000"\n' \
                | sudo tee /etc/systemd/system/ollama.service.d/context.conf >/dev/null
            sudo systemctl daemon-reload
            sudo systemctl restart ollama
            info "Done. Ollama restarted with a 64000-token context."
        else
            info "Skipped. To do it later:"
            info "  sudo mkdir -p /etc/systemd/system/ollama.service.d"
            info '  echo -e "[Service]\\nEnvironment=\\"OLLAMA_CONTEXT_LENGTH=64000\\"" | sudo tee /etc/systemd/system/ollama.service.d/context.conf'
            info "  sudo systemctl daemon-reload && sudo systemctl restart ollama"
        fi
    else
        info "If you start Ollama manually, launch it like this:"
        info "    export OLLAMA_CONTEXT_LENGTH=64000"
        info "    ollama serve"
    fi

    # ---- pick the model -----------------------------------------------------
    say "Step 4/5  Selecting the Ollama model"
    local model=""
    if ollama list >/dev/null 2>&1; then
        # prefer a qwen coder model, else fall back to the first model listed
        model="$(ollama list 2>/dev/null | awk 'NR>1{print $1}' | grep -i 'qwen.*coder' | head -n1)"
        [ -z "${model}" ] && model="$(ollama list 2>/dev/null | awk 'NR>1{print $1}' | head -n1)"
    fi
    if [ -n "${model}" ]; then
        info "Detected model: ${model}"
        printf '    Press Enter to use it, or type a different exact model name: '
        read -r override
        [ -n "${override}" ] && model="${override}"
    else
        printf '    Could not auto-detect a model. Type the exact name from `ollama list`: '
        read -r model
        [ -z "${model}" ] && die "No model name given."
    fi

    # ---- write Claude Code config ------------------------------------------
    say "Step 5/5  Writing ~/.claude/settings.json"
    mkdir -p "${HOME}/.claude"
    if [ -f "${HOME}/.claude/settings.json" ]; then
        cp "${HOME}/.claude/settings.json" "${HOME}/.claude/settings.json.bak.$(date +%s)"
        info "Existing settings.json backed up."
    fi
    cat > "${HOME}/.claude/settings.json" <<EOF
{
  "model": "${model}",
  "env": {
    "ANTHROPIC_BASE_URL": "http://localhost:11434",
    "ANTHROPIC_AUTH_TOKEN": "ollama",
    "ANTHROPIC_API_KEY": "",
    "DISABLE_UPDATES": "1",
    "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1"
  }
}
EOF
    info "Config written. Claude Code will talk to Ollama on localhost:11434 and never phone home."

    # ---- done ---------------------------------------------------------------
    say "DONE (offline pc)"
    info "Run it from any project folder:"
    info "    cd ~/your-project"
    info "    claude"
    printf '\n'
    info "Health check:   claude doctor"
    info "Proof of offline: disconnect the network entirely, then give claude a real"
    info "task. If it still works, everything is running through your local model."
    printf '\n'
    warn "Reality check: a 32B local model is great for everyday coding/RAG work, but"
    warn "won't match cloud Claude on the hardest long multi-step tasks."
}

# ===========================================================================
# entry point
# ===========================================================================
MODE="${1:-}"
case "${MODE}" in
    internet) do_internet ;;
    offline)  shift; do_offline "${1:-}" ;;
    *)
        cat <<EOF
Usage:
  On the INTERNET pc:   ./$(basename "${BASH_SOURCE[0]}") internet
  On the OFFLINE  pc:   ./$(basename "${BASH_SOURCE[0]}") offline [optional /path/to/claude-binary]

Run 'internet' first; it produces a file 'claude-binary'. Copy this script and
that file to the offline pc, then run 'offline' there.
EOF
        exit 1 ;;
esac
