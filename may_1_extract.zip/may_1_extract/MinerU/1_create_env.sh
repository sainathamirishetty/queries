#!/bin/bash
# ─────────────────────────────────────────────────────────────
# 1_create_env.sh
# Creates the conda environment and installs ALL dependencies.
# Run this on the INTERNET-CONNECTED PC only.
#
# Usage:
#   chmod +x 1_create_env.sh
#   ./1_create_env.sh
# ─────────────────────────────────────────────────────────────

set -e  # stop on any error

ENV_NAME="docqa"
PYTHON_VERSION="3.10"

echo "=============================================="
echo " DocQA Environment Setup"
echo " Environment : $ENV_NAME"
echo " Python      : $PYTHON_VERSION"
echo "=============================================="

# ── Step 1: Create conda environment ─────────────────────────
echo ""
echo "[1/6] Creating conda environment '$ENV_NAME'..."
conda create -y -n "$ENV_NAME" python="$PYTHON_VERSION"

# Activate the environment for the rest of this script
# shellcheck disable=SC1090
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$ENV_NAME"

echo "      Python location: $(which python)"
echo "      Python version : $(python --version)"

# ── Step 2: Install PyTorch with CUDA ─────────────────────────
# Using CUDA 11.8 — stable and widely compatible with Ubuntu + NVIDIA
# If your GPU needs CUDA 12.x change cu118 → cu121 below
echo ""
echo "[2/6] Installing PyTorch with CUDA 11.8 support..."
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# ── Step 3: Install MinerU (magic-pdf) stable version ────────
echo ""
echo "[3/6] Installing MinerU 0.9.3 (stable)..."
pip install magic-pdf==0.9.3

# MinerU needs these backends explicitly
pip install paddlepaddle-gpu==2.6.1.post120 -f https://www.paddlepaddle.org.cn/whl/linux/mkl/avx/stable.html
pip install paddleocr==2.7.3

# ── Step 4: Install all other DocQA dependencies ──────────────
echo ""
echo "[4/6] Installing DocQA application dependencies..."
pip install \
    streamlit==1.35.0 \
    python-docx==1.1.2 \
    requests==2.32.3 \
    Pillow==10.3.0 \
    easyocr==1.7.1

# ── Step 5: Install conda-pack (needed to pack env for offline) ─
echo ""
echo "[5/6] Installing conda-pack..."
conda install -y -c conda-forge conda-pack

# ── Step 6: Verify key imports ────────────────────────────────
echo ""
echo "[6/6] Verifying installations..."
python - <<'EOF'
import sys

checks = [
    ("torch",          "PyTorch"),
    ("magic_pdf",      "MinerU"),
    ("paddleocr",      "PaddleOCR"),
    ("streamlit",      "Streamlit"),
    ("docx",           "python-docx"),
    ("requests",       "Requests"),
    ("PIL",            "Pillow"),
    ("easyocr",        "EasyOCR"),
]

all_ok = True
for module, name in checks:
    try:
        __import__(module)
        print(f"  ✅  {name}")
    except ImportError as e:
        print(f"  ❌  {name} — {e}")
        all_ok = False

import torch
print(f"\n  PyTorch CUDA available : {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU                    : {torch.cuda.get_device_name(0)}")

if all_ok:
    print("\n✅  All dependencies installed successfully.")
else:
    print("\n❌  Some dependencies failed. Check errors above.")
    sys.exit(1)
EOF

echo ""
echo "=============================================="
echo " Step 1 complete."
echo " Next: run ./2_download_models.sh"
echo "=============================================="
