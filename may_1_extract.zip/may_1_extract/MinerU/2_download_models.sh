#!/bin/bash
# ─────────────────────────────────────────────────────────────
# 2_download_models.sh
# Downloads ALL MinerU models to a local folder inside your
# project directory. After this, MinerU runs fully offline.
#
# Models downloaded:
#   - Layout detection model  (DocLayout-YOLO)
#   - OCR model               (PaddleOCR)
#   - Table structure model   (TableMaster)
#   - Formula detection model (UniMERNet)
#   - Reading order model     (LayoutReader)
#
# Usage:
#   chmod +x 2_download_models.sh
#   ./2_download_models.sh
# ─────────────────────────────────────────────────────────────

set -e

ENV_NAME="docqa"
# Models will be downloaded here — inside your project folder
# This makes it easy to copy everything to the hard disk together
MODELS_DIR="$(pwd)/mineru_models"

echo "=============================================="
echo " MinerU Model Download"
echo " Models will be saved to:"
echo " $MODELS_DIR"
echo "=============================================="

# Activate environment
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$ENV_NAME"

# ── Create model directories ──────────────────────────────────
mkdir -p "$MODELS_DIR"

# ── Write MinerU config pointing to local model folder ────────
# MinerU reads this config file to know where models are stored.
# By pointing it to our local folder, it never needs internet at runtime.
MINERU_CONFIG_DIR="$HOME/.mineru"
mkdir -p "$MINERU_CONFIG_DIR"

cat > "$MINERU_CONFIG_DIR/magic-pdf.json" <<EOF
{
    "bucket_info":{
        "bucket-name-1":["ak", "sk", "endpoint"],
        "bucket-name-2":["ak", "sk", "endpoint"]
    },
    "models-dir": "$MODELS_DIR",
    "layoutreader-model-dir": "$MODELS_DIR/layoutreader",
    "device-mode": "cuda",
    "layout-config": {
        "model": "doclayout_yolo"
    },
    "formula-config": {
        "mfd_model": "yolo_v8_mfd",
        "mfr_model": "unimernet_small",
        "enable": true
    },
    "table-config": {
        "model": "rapid_table",
        "enable": true,
        "max_time": 400
    }
}
EOF

echo ""
echo "MinerU config written to: $MINERU_CONFIG_DIR/magic-pdf.json"

# ── Download models via Python ────────────────────────────────
echo ""
echo "Downloading MinerU models (this may take 10-30 minutes)..."
echo "Models are large — please wait..."
echo ""

python - <<EOF
import os
import sys

models_dir = "$MODELS_DIR"

# MinerU provides a utility to download all required models
# This pulls from HuggingFace once — after this, fully offline
try:
    from magic_pdf.model.doc_analyze_by_custom_model import ModelSingleton
    print("MinerU model manager found.")
except ImportError as e:
    print(f"Import error: {e}")
    sys.exit(1)

# Download via huggingface_hub
# All models go into our local models_dir
try:
    from huggingface_hub import snapshot_download
    import json

    print("[1/5] Downloading DocLayout-YOLO (layout detection)...")
    snapshot_download(
        repo_id   = "opendatalab/PDF-Extract-Kit-1.0",
        local_dir = os.path.join(models_dir, "PDF-Extract-Kit-1.0"),
        ignore_patterns = ["*.git*", "README*"],
    )
    print("      ✅ DocLayout-YOLO downloaded")

    print("[2/5] Downloading LayoutReader (reading order)...")
    snapshot_download(
        repo_id   = "hantian/layoutreader",
        local_dir = os.path.join(models_dir, "layoutreader"),
        ignore_patterns = ["*.git*", "README*"],
    )
    print("      ✅ LayoutReader downloaded")

    print("[3/5] PaddleOCR models (downloaded automatically on first use)...")
    # PaddleOCR downloads its models to ~/.paddleocr on first inference
    # We trigger that download now so it's cached before we pack
    from paddleocr import PaddleOCR
    ocr = PaddleOCR(
        use_angle_cls = True,
        lang          = "en",
        use_gpu       = True,
        show_log      = False,
    )
    print("      ✅ PaddleOCR models ready")

    print("[4/5] Verifying model paths exist...")
    expected = [
        os.path.join(models_dir, "PDF-Extract-Kit-1.0"),
        os.path.join(models_dir, "layoutreader"),
    ]
    all_exist = True
    for p in expected:
        if os.path.exists(p):
            print(f"      ✅ {p}")
        else:
            print(f"      ❌ MISSING: {p}")
            all_exist = False

    if not all_exist:
        print("\n❌ Some models missing. Re-run this script.")
        sys.exit(1)

    print("[5/5] All models downloaded successfully.")
    print(f"\nModels location: {models_dir}")
    print("MinerU will use this folder — no internet needed at runtime.")

except Exception as e:
    print(f"\n❌ Download failed: {e}")
    print("Check your internet connection and try again.")
    sys.exit(1)
EOF

echo ""
echo "=============================================="
echo " Step 2 complete."
echo " Models saved to: $MODELS_DIR"
echo " Next: run ./3_verify.sh"
echo "=============================================="
