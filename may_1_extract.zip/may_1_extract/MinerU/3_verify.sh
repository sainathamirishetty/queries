#!/bin/bash
# ─────────────────────────────────────────────────────────────
# 3_verify.sh
# Verifies the full pipeline works end-to-end before you pack
# and move to the offline PC.
#
# What it checks:
#   1. All Python imports work
#   2. MinerU can process a real PDF (creates a tiny test PDF)
#   3. Ollama is reachable at the configured port
#   4. GPU is visible to PyTorch and PaddlePaddle
#   5. All model files are present locally
#
# Usage:
#   chmod +x 3_verify.sh
#   ./3_verify.sh
# ─────────────────────────────────────────────────────────────

set -e

ENV_NAME="docqa"

echo "=============================================="
echo " DocQA Full Verification"
echo "=============================================="

source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$ENV_NAME"

python - <<'EOF'
import sys
import os
import tempfile

print("\n── 1. Import checks ──────────────────────────────────")
imports_ok = True
checks = [
    ("torch",          "PyTorch"),
    ("magic_pdf",      "MinerU (magic-pdf)"),
    ("paddleocr",      "PaddleOCR"),
    ("streamlit",      "Streamlit"),
    ("docx",           "python-docx"),
    ("requests",       "Requests"),
    ("PIL",            "Pillow"),
    ("easyocr",        "EasyOCR (fallback)"),
]
for module, name in checks:
    try:
        __import__(module)
        print(f"  ✅  {name}")
    except ImportError as e:
        print(f"  ❌  {name}: {e}")
        imports_ok = False

print("\n── 2. GPU checks ─────────────────────────────────────")
import torch
cuda_ok = torch.cuda.is_available()
print(f"  PyTorch CUDA : {'✅ ' + torch.cuda.get_device_name(0) if cuda_ok else '❌ Not available'}")

try:
    import paddle
    paddle_gpu = paddle.device.get_device()
    print(f"  PaddlePaddle : ✅ device={paddle_gpu}")
except Exception as e:
    print(f"  PaddlePaddle : ❌ {e}")

print("\n── 3. MinerU model files check ───────────────────────")
import json
config_path = os.path.expanduser("~/.mineru/magic-pdf.json")
if os.path.exists(config_path):
    with open(config_path) as f:
        cfg = json.load(f)
    models_dir = cfg.get("models-dir", "")
    print(f"  Config found : ✅ {config_path}")
    print(f"  Models dir   : {models_dir}")

    required_dirs = [
        os.path.join(models_dir, "PDF-Extract-Kit-1.0"),
        os.path.join(models_dir, "layoutreader"),
    ]
    for d in required_dirs:
        exists = os.path.isdir(d)
        print(f"  {'✅' if exists else '❌'}  {d}")
else:
    print(f"  ❌ Config not found at {config_path}")
    print("     Run 2_download_models.sh first.")

print("\n── 4. MinerU PDF extraction test ─────────────────────")
try:
    # Create a minimal valid PDF for testing
    import struct, zlib

    def make_test_pdf(path):
        # Minimal single-page PDF with one line of text
        content = b"BT /F1 12 Tf 100 700 Td (DocQA MinerU test page.) Tj ET"
        stream  = zlib.compress(content)
        pdf = (
            b"%PDF-1.4\n"
            b"1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
            b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
            b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]"
            b"/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n"
            b"4 0 obj<</Filter/FlateDecode/Length " + str(len(stream)).encode() + b">>\n"
            b"stream\n" + stream + b"\nendstream\nendobj\n"
            b"5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n"
            b"xref\n0 6\n"
            b"0000000000 65535 f \n"
            b"trailer<</Size 6/Root 1 0 R>>\n"
            b"startxref\n9\n%%EOF"
        )
        with open(path, "wb") as f:
            f.write(pdf)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_pdf  = os.path.join(tmpdir, "test.pdf")
        test_out  = os.path.join(tmpdir, "output")
        os.makedirs(test_out, exist_ok=True)
        make_test_pdf(test_pdf)

        from magic_pdf.data.data_reader_writer import FileBasedDataWriter, FileBasedDataReader
        from magic_pdf.data.dataset import PymuPDFDataset
        from magic_pdf.model.doc_analyze_by_custom_model import doc_analyze
        from magic_pdf.config.make_content_config import DropMode, MakeMode
        from magic_pdf.pipe.UNIPipe import UNIPipe

        reader     = FileBasedDataReader("")
        pdf_bytes  = reader.read(test_pdf)
        ds         = PymuPDFDataset(pdf_bytes)
        writer_img = FileBasedDataWriter(os.path.join(test_out, "images"))
        writer_md  = FileBasedDataWriter(test_out)

        pipe = UNIPipe(
            pdf_bytes,
            {"_pdf_type": "", "model_list": []},
            writer_img,
        )
        pipe.pipe_classify()
        pipe.pipe_analyze()
        pipe.pipe_parse()
        md = pipe.pipe_mk_markdown(writer_img, drop_mode=DropMode.NONE)

        print(f"  ✅ MinerU extraction worked")
        print(f"     Output chars: {len(md)}")

except Exception as e:
    print(f"  ❌ MinerU test failed: {e}")
    print("     This may be a model path issue. Check 2_download_models.sh ran correctly.")

print("\n── 5. Ollama connectivity check ──────────────────────")
import requests, json as _json
# Read host from your config
sys.path.insert(0, os.getcwd())
try:
    from config import OLLAMA_HOST, OLLAMA_MODEL
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=5)
        models = [m["name"] for m in r.json().get("models", [])]
        if OLLAMA_MODEL in models:
            print(f"  ✅ Ollama reachable at {OLLAMA_HOST}")
            print(f"  ✅ Model '{OLLAMA_MODEL}' is loaded")
        else:
            print(f"  ✅ Ollama reachable but model '{OLLAMA_MODEL}' not found")
            print(f"     Available: {models}")
    except Exception as e:
        print(f"  ❌ Ollama not reachable at {OLLAMA_HOST}: {e}")
        print("     Make sure Ollama is running before starting the app.")
except ImportError:
    print("  ⚠️  config.py not found in current directory — skipping Ollama check")

print("\n══════════════════════════════════════════════════════")
if imports_ok:
    print("  ✅ Verification complete — ready to pack.")
    print("     Next: run ./4_pack_for_offline.sh")
else:
    print("  ❌ Some checks failed. Fix errors before packing.")
print("══════════════════════════════════════════════════════\n")
EOF
