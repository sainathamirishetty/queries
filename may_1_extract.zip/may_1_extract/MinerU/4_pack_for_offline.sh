#!/bin/bash
# ─────────────────────────────────────────────────────────────
# 4_pack_for_offline.sh
# Packs the conda environment + models + scripts into one
# folder. Copy this folder to your hard disk and move to
# the offline PC.
#
# What gets packed:
#   docqa_offline/
#   ├── env/                  ← conda environment (conda-pack)
#   ├── mineru_models/        ← all MinerU model weights
#   ├── paddleocr_models/     ← PaddleOCR cached models
#   ├── mineru_config/        ← MinerU config file
#   ├── scripts/              ← all your Python scripts
#   └── install_on_offline.sh ← run this on the offline PC
#
# Usage:
#   chmod +x 4_pack_for_offline.sh
#   ./4_pack_for_offline.sh
# ─────────────────────────────────────────────────────────────

set -e

ENV_NAME="docqa"
PACK_DIR="$(pwd)/docqa_offline"
MODELS_DIR="$(pwd)/mineru_models"
SCRIPTS_DIR="$(pwd)"   # assumes you run from your project folder

echo "=============================================="
echo " Packing DocQA for Offline Transfer"
echo " Output folder: $PACK_DIR"
echo "=============================================="

source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$ENV_NAME"

# ── Create output structure ───────────────────────────────────
echo ""
echo "[1/5] Creating folder structure..."
rm -rf "$PACK_DIR"
mkdir -p "$PACK_DIR/env"
mkdir -p "$PACK_DIR/mineru_models"
mkdir -p "$PACK_DIR/paddleocr_models"
mkdir -p "$PACK_DIR/mineru_config"
mkdir -p "$PACK_DIR/scripts"
echo "      ✅ Done"

# ── Pack conda environment ────────────────────────────────────
echo ""
echo "[2/5] Packing conda environment with conda-pack..."
echo "      This may take 5-10 minutes..."
conda pack \
    -n "$ENV_NAME" \
    -o "$PACK_DIR/env/docqa_env.tar.gz" \
    --ignore-editable-packages \
    --ignore-missing-files
echo "      ✅ Environment packed: $(du -sh $PACK_DIR/env/docqa_env.tar.gz | cut -f1)"

# ── Copy MinerU models ────────────────────────────────────────
echo ""
echo "[3/5] Copying MinerU models..."
if [ -d "$MODELS_DIR" ]; then
    cp -r "$MODELS_DIR/." "$PACK_DIR/mineru_models/"
    echo "      ✅ MinerU models copied: $(du -sh $PACK_DIR/mineru_models | cut -f1)"
else
    echo "      ❌ Models not found at $MODELS_DIR"
    echo "         Run 2_download_models.sh first."
    exit 1
fi

# ── Copy PaddleOCR cached models ─────────────────────────────
echo ""
echo "[4/5] Copying PaddleOCR models..."
PADDLE_CACHE="$HOME/.paddleocr"
if [ -d "$PADDLE_CACHE" ]; then
    cp -r "$PADDLE_CACHE/." "$PACK_DIR/paddleocr_models/"
    echo "      ✅ PaddleOCR models copied: $(du -sh $PACK_DIR/paddleocr_models | cut -f1)"
else
    echo "      ⚠️  PaddleOCR cache not found at $PADDLE_CACHE"
    echo "         Models will be missing — run 2_download_models.sh again."
fi

# ── Copy MinerU config ────────────────────────────────────────
MINERU_CONFIG="$HOME/.mineru/magic-pdf.json"
if [ -f "$MINERU_CONFIG" ]; then
    cp "$MINERU_CONFIG" "$PACK_DIR/mineru_config/magic-pdf.json"
    echo "      ✅ MinerU config copied"
fi

# ── Copy project scripts ──────────────────────────────────────
echo ""
echo "[5/5] Copying project scripts..."
SCRIPT_FILES=(
    "config.py"
    "logger.py"
    "extractor.py"
    "ollama_client_sync.py"
    "streamlit_app.py"
)
for f in "${SCRIPT_FILES[@]}"; do
    if [ -f "$SCRIPTS_DIR/$f" ]; then
        cp "$SCRIPTS_DIR/$f" "$PACK_DIR/scripts/"
        echo "      ✅ $f"
    else
        echo "      ❌ Missing: $f — copy manually"
    fi
done

# ── Write the installer script for the offline PC ─────────────
cat > "$PACK_DIR/install_on_offline_pc.sh" <<'INSTALLER'
#!/bin/bash
# ─────────────────────────────────────────────────────────────
# install_on_offline_pc.sh
# Run this on the OFFLINE PC after copying the hard disk.
#
# Usage:
#   cd /path/to/docqa_offline
#   chmod +x install_on_offline_pc.sh
#   ./install_on_offline_pc.sh
# ─────────────────────────────────────────────────────────────

set -e

INSTALL_DIR="$(pwd)"
APP_DIR="$HOME/docqa_app"

echo "=============================================="
echo " DocQA Offline Installation"
echo " Installing to: $APP_DIR"
echo "=============================================="

# ── 1. Unpack conda environment ───────────────────────────────
echo ""
echo "[1/5] Unpacking conda environment..."
mkdir -p "$APP_DIR/env"
tar -xzf "$INSTALL_DIR/env/docqa_env.tar.gz" -C "$APP_DIR/env"

# Fix conda paths inside the unpacked environment
source "$APP_DIR/env/bin/activate"
conda-unpack
echo "      ✅ Environment ready at $APP_DIR/env"

# ── 2. Copy models ────────────────────────────────────────────
echo ""
echo "[2/5] Installing MinerU models..."
mkdir -p "$APP_DIR/mineru_models"
cp -r "$INSTALL_DIR/mineru_models/." "$APP_DIR/mineru_models/"
echo "      ✅ MinerU models installed"

echo ""
echo "[3/5] Installing PaddleOCR models..."
mkdir -p "$HOME/.paddleocr"
cp -r "$INSTALL_DIR/paddleocr_models/." "$HOME/.paddleocr/"
echo "      ✅ PaddleOCR models installed"

# ── 3. Write MinerU config pointing to local paths ───────────
echo ""
echo "[4/5] Writing MinerU config..."
mkdir -p "$HOME/.mineru"
cat > "$HOME/.mineru/magic-pdf.json" <<CONFIG
{
    "bucket_info":{
        "bucket-name-1":["ak", "sk", "endpoint"]
    },
    "models-dir": "$APP_DIR/mineru_models",
    "layoutreader-model-dir": "$APP_DIR/mineru_models/layoutreader",
    "device-mode": "cuda",
    "layout-config": {
        "model": "doclayout_yolo"
    },
    "formula-config": {
        "mfd_model": "yolo_v8_mfd",
        "mfr_model": "unimernet_small",
        "enable": true
    },
    "table-config": {
        "model": "rapid_table",
        "enable": true,
        "max_time": 400
    }
}
CONFIG
echo "      ✅ MinerU config written"

# ── 4. Copy application scripts ───────────────────────────────
echo ""
echo "[5/5] Copying application scripts..."
mkdir -p "$APP_DIR/app"
cp -r "$INSTALL_DIR/scripts/." "$APP_DIR/app/"

# Write the run script
cat > "$APP_DIR/run_docqa.sh" <<RUN
#!/bin/bash
# ── Activate the packed conda environment ──
source "$APP_DIR/env/bin/activate"

# ── Move to app directory ──
cd "$APP_DIR/app"

# ── Create runtime directories ──
mkdir -p extracted_docs logs

# ── Launch Streamlit ──
echo "Starting DocQA..."
echo "Open your browser at: http://localhost:8000"
streamlit run streamlit_app.py \
    --server.address 0.0.0.0 \
    --server.port 8000 \
    --server.headless true
RUN
chmod +x "$APP_DIR/run_docqa.sh"

echo ""
echo "=============================================="
echo " Installation complete!"
echo ""
echo " To start the app:"
echo "   $APP_DIR/run_docqa.sh"
echo ""
echo " Then open browser at:"
echo "   http://localhost:8000"
echo "=============================================="
INSTALLER

chmod +x "$PACK_DIR/install_on_offline_pc.sh"

# ── Final summary ─────────────────────────────────────────────
echo ""
echo "=============================================="
echo " Packing complete!"
echo ""
echo " Output folder : $PACK_DIR"
echo " Total size    : $(du -sh $PACK_DIR | cut -f1)"
echo ""
echo " Contents:"
echo "   env/              → conda environment"
echo "   mineru_models/    → MinerU model weights"
echo "   paddleocr_models/ → PaddleOCR models"
echo "   mineru_config/    → MinerU config"
echo "   scripts/          → your Python scripts"
echo "   install_on_offline_pc.sh → run on offline PC"
echo ""
echo " Next steps:"
echo "   1. Copy the entire 'docqa_offline' folder to hard disk"
echo "   2. On offline PC: cd docqa_offline"
echo "   3. On offline PC: chmod +x install_on_offline_pc.sh"
echo "   4. On offline PC: ./install_on_offline_pc.sh"
echo "   5. On offline PC: ~/docqa_app/run_docqa.sh"
echo "=============================================="
