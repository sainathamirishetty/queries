# config.py
# ─────────────────────────────────────────────────────────────
#  Single place to change all settings
# ─────────────────────────────────────────────────────────────

# ── Ollama ────────────────────────────────────────────────────
OLLAMA_HOST    = "http://localhost:12345"   # ← change to your server
OLLAMA_MODEL   = "gemma4:e4b"              # ← Vision-enabled multimodal model
OLLAMA_TIMEOUT = 300                        # seconds

# ── Document limits ───────────────────────────────────────────
MAX_PAGES            = 50     # hard page cap — documents above this are rejected
MAX_HISTORY_TURNS    = 10     # how many past Q&A turns to keep in LLM context
WORDS_PER_PAGE       = 500    # used to estimate DOCX page count from word count
SUPPORTED_EXTENSIONS = ["pdf", "docx", "txt"]

# ── Storage paths ─────────────────────────────────────────────
# Permanent storage — markdown + images saved here forever
# Structure: extracted_docs/YYYY-MM-DD/document_name/
EXTRACTED_DOCS_DIR = "extracted_docs"

# ── OCR settings ─────────────────────────────────────────────
# Minimum characters per page to consider PDF as digital (not scanned)
# If a page has fewer than this → treated as scanned → OCR applied
SCANNED_TEXT_THRESHOLD = 50

# ── Image / Table QA settings ────────────────────────────────
# Max images sent to vision model per question (keeps payload manageable)
MAX_IMAGES_PER_QUERY = 5

# Context window around each [Image N appears here] tag when scoring relevance (chars)
IMAGE_CONTEXT_WINDOW = 500

# Minimum keyword score for a context-matched image to be included
IMAGE_MIN_SCORE = 1

# pdfplumber table extraction settings
# Any cell with fewer chars than this is treated as empty
TABLE_MIN_CELL_CHARS = 0

# ── Logging ───────────────────────────────────────────────────
LOG_DIR = "logs"
