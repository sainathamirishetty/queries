
import io
import json
import sqlite3
import hashlib
import requests
import streamlit as st
from datetime import datetime
from docx import Document
import re
import logging

#login imports
from ldap3 import Server, Connection, ALL, SIMPLE, SUBTREE
from ldap3.core.exceptions import LDAPBindError,LDAPException

logger = logging.getLogger(__name__)

def ad_auth(username: str, password: str, client_ip: str):
    """Return (True, display_name) on success, (False, error_msg) on failure."""
    domain = 'hastinapur'
    server_ip = '172.30.1.136'
    user_principal = f"{domain}\\{username}"
    ldap_server = f"ldap://{server_ip}"
    server = Server(ldap_server, get_info=ALL, use_ssl=False)

    try:
        conn = Connection(
            server,
            user=user_principal,
            password=password,
            authentication=SIMPLE,
            auto_bind="NO_TLS"
        )

        if not conn.bind():
            logger.warning(f"AD Auth Failed: {username} from {client_ip}")
            return False, "Invalid credentials"

        # Pull display name (CN) – optional but handy for UI
        search_base = f"DC={domain},DC=res"
        search_filter = f"(&(objectClass=user)(sAMAccountName={username}))"
        conn.search(
            search_base=search_base,
            search_filter=search_filter,
            search_scope=SUBTREE,
            attributes=['displayName']
        )
        if conn.entries:
            dn = conn.entries[0].entry_dn
            cn_match = re.search(r'CN=([^,]+)', dn)
            display_name = cn_match.group(1) if cn_match else username
            logger.info(f"AD Auth Success: {username} ({display_name}) from {client_ip}")
            return True, display_name

        # Fallback – user exists but no CN found
        logger.info(f"AD Auth Success: {username} from {client_ip}")
        return True, username

    except LDAPBindError as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {str(e)}")
        return False, "Invalid credentials"
    except LDAPException as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {str(e)}")
        return False, "Invalid credentials"
    except Exception as e:
        logger.warning(f"AD Auth Failed: {username} from {client_ip} - {str(e)}")
        return False, "Invalid credentials"

# ══════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════
OLLAMA_URL = "http://10.144.177.192:12345/api/generate"
MODEL_NAME = "gpt-oss:20b"
DB_PATH    = "procurement.db"

# ══════════════════════════════════════════════════════════
#  PAGE CONFIG
# ══════════════════════════════════════════════════════════
st.set_page_config(page_title="Procurement Justification Generator", layout="wide")

# ══════════════════════════════════════════════════════════
#  COOKIE MANAGER
# ══════════════════════════════════════════════════════════
try:
    import extra_streamlit_components as stx

    @st.cache_resource
    def _get_cm():
        return stx.CookieManager()

    _cm        = _get_cm()
    COOKIES_OK = True
except Exception:
    _cm        = None
    COOKIES_OK = False


def _set_cookie(key, value):
    if COOKIES_OK:
        _cm.set(key, str(value))


def _get_cookie(key):
    if COOKIES_OK:
        return _cm.get(key)
    return None


def _del_cookie(key):
    if COOKIES_OK:
        try:
            _cm.delete(key)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════
#  DATABASE
# ══════════════════════════════════════════════════════════
def _conn():
    return sqlite3.connect(DB_PATH, check_same_thread=False)


def init_db():
    with _conn() as c:
        # ---- users table (kept for possible future use) ----
        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """)

        # ---- sessions table -------------------------------------------------
        # If you **do not** need per‑AD‑user isolation, drop the ad_username column.
        c.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER,                     -- 0 for AD users
                title         TEXT    NOT NULL,
                form_data     TEXT,
                conversation  TEXT,
                answers       TEXT,
                justification TEXT,
                created_at    TEXT DEFAULT (strftime('%Y-%m-%d %H:%M:%S','now','localtime')),
                ad_username   TEXT                         -- optional, can be NULL
            )
        """)
        c.commit()


def db_verify(username, password):
    pw = hashlib.sha256(password.encode()).hexdigest()
    with _conn() as c:
        row = c.execute(
            "SELECT id FROM users WHERE username=? AND password=?",
            (username, pw),
        ).fetchone()
    return row[0] if row else None


def db_get_sessions(user_id):
    with _conn() as c:
        if user_id == 0:   # AD login
            ad_user = st.session_state.username
            return c.execute(
                "SELECT id, title, created_at FROM sessions "
                "WHERE ad_username=? ORDER BY created_at DESC",
                (ad_user,),
            ).fetchall()
        else:
            return c.execute(
                "SELECT id, title, created_at FROM sessions "
                "WHERE user_id=? ORDER BY created_at DESC",
                (user_id,),
            ).fetchall()


def db_save_session(user_id, title, form_data, conversation, answers, justification):
    user_id = user_id or 0
    ad_user = st.session_state.username if user_id == 0 else None
    with _conn() as c:
        cur = c.execute(
            """
            INSERT INTO sessions
            (user_id, title, form_data, conversation, answers,
             justification, ad_username)
            VALUES (?,?,?,?,?,?,?)
            """,
            (
                user_id,
                title,
                json.dumps(form_data),
                json.dumps(conversation),
                json.dumps(answers),
                justification,
                ad_user,
            ),
        )
        c.commit()
        return cur.lastrowid
    
    
def db_rename(session_id, new_title):
    with _conn() as c:
        c.execute(
            "UPDATE sessions SET title=? WHERE id=?", (new_title, session_id)
        )
        c.commit()


def db_delete(session_id):
    with _conn() as c:
        c.execute("DELETE FROM sessions WHERE id=?", (session_id,))
        c.commit()


def db_load(session_id):
    with _conn() as c:
        row = c.execute(
            "SELECT form_data, conversation, answers, justification "
            "FROM sessions WHERE id=?",
            (session_id,),
        ).fetchone()
    if not row:
        return None
    return {
        "form_data":     json.loads(row[0]) if row[0] else {},
        "conversation":  json.loads(row[1]) if row[1] else [],
        "answers":       json.loads(row[2]) if row[2] else {},
        "justification": row[3] or "",
    }


# ══════════════════════════════════════════════════════════
#  SESSION STATE DEFAULTS
# ══════════════════════════════════════════════════════════
_DEFAULTS = dict(
    logged_in=False, user_id=None, username=None,
    form_submitted=False, conversation=[], answers={},
    current_question=None, justification_generated=False,
    final_justification="", question_count=0,
    form_data={}, current_session_id=None,
    unsaved_work=False, sessions_list=[],
    # dialog flags
    show_save_dialog=False,
    rename_id=None, rename_title="",
    delete_id=None,
    pending_new_session=False,
)
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

init_db()


# ══════════════════════════════════════════════════════════
#  FORM FIELD KEYS
#  All widget keys are prefixed with "f_" so they live in
#  session_state and survive reruns without st.form.
# ══════════════════════════════════════════════════════════
# Selectbox option lists (needed by populate_form_fields)
_DESIGNATIONS  = ["Scientist B","Scientist C","Scientist D",
                  "Scientist E","Scientist F","Scientist G"]
_PROC_METHODS  = ["GeM", "Non-GeM"]
_YES_NO        = ["Yes", "No"]
_BID_TYPES     = ["Single Bid", "Two Bid"]
_FIN_POWERS    = ["2.2", "2.7", "2.3", "2.4"]

_SOC_LABELS = [
    ("unit",                  "Unit/Directorate/Office initiating the SOC"),
    ("item_name",             "Name of the item(s)/services being procured"),
    ("justification",         "Justification for procurement"),
    ("authority",             "Authority under which the proposal is being initiated (Financial Power)"),
    ("previous_item",         "Which item was serving the purpose till date"),
    ("current_proposal",      "How the present proposal will serve the purpose"),
    ("broad_purpose",         "Broad purpose of items being procured"),
    ("purchase_category",     "Category of purchase"),
    ("fresh_purchase_purpose","Fresh purchase – how was the purpose being served till date"),
    ("fresh_purchase_reason", "Fresh purchase – why it cannot be served with upgradation of existing items"),
    ("quantity_basis",        "Basis for working out the quantity against each item"),
    ("holding_details",       "Details like authorized holdings, existing holding"),
    ("calc_sheets",           "Calculation sheets/PR documents"),
    ("distribution",          "Proposed distribution of items"),
    ("last_purchase_date",    "Last purchase date"),
    ("budget_quotes",         "Budgetary quotes"),
    ("market_intelligence",   "Market intelligence"),
    ("rates_other_orgs",      "Rates obtained from other organisations"),
    ("professional_eval",     "Professional officers evaluation"),
    ("other_method",          "Any other method"),
    ("is_new_item",           "Is new item"),
    ("major_head",            "Major head, sub head and detailed head"),
    ("fund_certificate",      "Fund availability certificate"),
    ("paying_agency",         "Name of paying agency"),
    ("tender_mode",           "Mode of tendering"),
    ("tender_justification",  "Justification for tendering mode other than OBM"),
    ("draft_rfp",             "Draft RFP – original sentences"),
]


def collect_form_data():
    """
    Read every form field from st.session_state (via widget keys).
    Safe to call at any time — even before Start is clicked.
    Returns a form_data dict identical to what v2 produced.
    """
    ss = st.session_state
    oi = {
        "tender_type":                     ss.get("f_oi_tender_type", ""),
        "basis_for_cost":                  ss.get("f_oi_basis_for_cost", ""),
        "single_bid_two_bid":              ss.get("f_oi_single_bid_two_bid", "Single Bid"),
        "expected_delivery":               ss.get("f_oi_expected_delivery", ""),
        "delivery_term":                   ss.get("f_oi_delivery_term", ""),
        "price_bid_evaluation":            ss.get("f_oi_price_bid_evaluation", ""),
        "appointment_of_quantity":         ss.get("f_oi_appointment_of_quantity", ""),
        "quality_tolerance_clause":        ss.get("f_oi_quality_tolerance_clause", ""),
        "part_supply_prorata_payment":     ss.get("f_oi_part_supply_prorata_payment", "Yes"),
        "previous_order_contract_details": ss.get("f_oi_previous_order_contract_details", ""),
        "warranty_period":                 ss.get("f_oi_warranty_period", 0),
        "training":                        ss.get("f_oi_training", ""),
        "insurance_cover":                 ss.get("f_oi_insurance_cover", ""),
        "inspection_agency":               ss.get("f_oi_inspection_agency", ""),
        "product_support":                 ss.get("f_oi_product_support", ""),
        "post_warranty_amc":               ss.get("f_oi_post_warranty_amc", "Yes"),
        "requirement_sample":              ss.get("f_oi_requirement_sample", ""),
        "validity_of_bids":                ss.get("f_oi_validity_of_bids", ""),
        "repeat_order_possible":           ss.get("f_oi_repeat_order_possible", "Yes"),
        "option_clause_invoked":           ss.get("f_oi_option_clause_invoked", ""),
        "pre_bid_conference_required":     ss.get("f_oi_pre_bid_conference_required", "Yes"),
        "testing_facilities_free_of_cost": ss.get("f_oi_testing_facilities_free_of_cost", "Yes"),
        "sensitive_items":                 ss.get("f_oi_sensitive_items", "Yes"),
        "nda_applicable":                  ss.get("f_oi_nda_applicable", "Yes"),
        "ipr_property":                    ss.get("f_oi_ipr_property", ""),
        "gem_non_availability_id":         ss.get("f_oi_gem_non_availability_id", ""),
    }
    soc = {k: ss.get(f"f_soc_{k}", "") for k, _ in _SOC_LABELS}

    return {
        "initiator_name":           ss.get("f_initiator_name", ""),
        "designation":              ss.get("f_designation", _DESIGNATIONS[0]),
        "nature_of_item":           ss.get("f_nature_of_item", ""),
        "financial_year":           ss.get("f_financial_year", ""),
        "fund":                     ss.get("f_fund", ""),
        "budget_head":              ss.get("f_budget_head", ""),
        "budget_code":              ss.get("f_budget_code", ""),
        "unit_code":                ss.get("f_unit_code", ""),
        "budget_serial_number":     ss.get("f_budget_serial_number", ""),
        "forecasted_item":          ss.get("f_forecasted_item", ""),
        "procurement_method":       ss.get("f_procurement_method", _PROC_METHODS[0]),
        "item_serial_number":       ss.get("f_item_serial_number", ""),
        "item_code":                ss.get("f_item_code", ""),
        "item_type":                ss.get("f_item_type", ""),
        "item_nomenclature":        ss.get("f_item_nomenclature", ""),
        "item_quantity":            ss.get("f_item_quantity", 0),
        "item_rate":                ss.get("f_item_rate", 0.0),
        "item_estimated_cost":      ss.get("f_item_estimated_cost", 0.0),
        "other_inputs":             oi,
        "vendor_serial_number":     ss.get("f_vendor_serial_number", ""),
        "vendor_code":              ss.get("f_vendor_code", ""),
        "vendor_name":              ss.get("f_vendor_name", ""),
        "vendor_address":           ss.get("f_vendor_address", ""),
        "lab_registration_details": ss.get("f_lab_registration_details", ""),
        "rfp_term_1":               ss.get("f_rfp_term_1", ""),
        "rfp_term_2":               ss.get("f_rfp_term_2", ""),
        "rfp_term_3":               ss.get("f_rfp_term_3", ""),
        "pac_accorded":             ss.get("f_pac_accorded", "Yes"),
        "statement_of_case":        soc,
        "financial_power":          ss.get("f_financial_power", _FIN_POWERS[0]),
    }


def populate_form_fields(form_data):
    """
    Push saved form_data back into session_state widget keys
    so fields render with loaded values.
    """
    fd  = form_data
    oi  = fd.get("other_inputs", {})
    soc = fd.get("statement_of_case", {})
    ss  = st.session_state

    # Initiator
    ss["f_initiator_name"]  = fd.get("initiator_name", "")
    ss["f_designation"]     = fd.get("designation", _DESIGNATIONS[0])
    ss["f_nature_of_item"]  = fd.get("nature_of_item", "")
    # Budget
    ss["f_financial_year"]      = fd.get("financial_year", "")
    ss["f_fund"]                = fd.get("fund", "")
    ss["f_budget_head"]         = fd.get("budget_head", "")
    ss["f_budget_code"]         = fd.get("budget_code", "")
    ss["f_unit_code"]           = fd.get("unit_code", "")
    ss["f_budget_serial_number"]= fd.get("budget_serial_number", "")
    ss["f_forecasted_item"]     = fd.get("forecasted_item", "")
    # Procurement
    ss["f_procurement_method"]  = fd.get("procurement_method", _PROC_METHODS[0])
    # Item
    ss["f_item_serial_number"]  = fd.get("item_serial_number", "")
    ss["f_item_code"]           = fd.get("item_code", "")
    ss["f_item_type"]           = fd.get("item_type", "")
    ss["f_item_nomenclature"]   = fd.get("item_nomenclature", "")
    ss["f_item_quantity"]       = fd.get("item_quantity", 0)
    ss["f_item_rate"]           = fd.get("item_rate", 0.0)
    ss["f_item_estimated_cost"] = fd.get("item_estimated_cost", 0.0)
    # Other Inputs
    ss["f_oi_tender_type"]                     = oi.get("tender_type", "")
    ss["f_oi_basis_for_cost"]                  = oi.get("basis_for_cost", "")
    ss["f_oi_single_bid_two_bid"]              = oi.get("single_bid_two_bid", "Single Bid")
    ss["f_oi_expected_delivery"]               = oi.get("expected_delivery", "")
    ss["f_oi_delivery_term"]                   = oi.get("delivery_term", "")
    ss["f_oi_price_bid_evaluation"]            = oi.get("price_bid_evaluation", "")
    ss["f_oi_appointment_of_quantity"]         = oi.get("appointment_of_quantity", "")
    ss["f_oi_quality_tolerance_clause"]        = oi.get("quality_tolerance_clause", "")
    ss["f_oi_part_supply_prorata_payment"]     = oi.get("part_supply_prorata_payment", "Yes")
    ss["f_oi_previous_order_contract_details"] = oi.get("previous_order_contract_details", "")
    ss["f_oi_warranty_period"]                 = oi.get("warranty_period", 0)
    ss["f_oi_training"]                        = oi.get("training", "")
    ss["f_oi_insurance_cover"]                 = oi.get("insurance_cover", "")
    ss["f_oi_inspection_agency"]               = oi.get("inspection_agency", "")
    ss["f_oi_product_support"]                 = oi.get("product_support", "")
    ss["f_oi_post_warranty_amc"]               = oi.get("post_warranty_amc", "Yes")
    ss["f_oi_requirement_sample"]              = oi.get("requirement_sample", "")
    ss["f_oi_validity_of_bids"]                = oi.get("validity_of_bids", "")
    ss["f_oi_repeat_order_possible"]           = oi.get("repeat_order_possible", "Yes")
    ss["f_oi_option_clause_invoked"]           = oi.get("option_clause_invoked", "")
    ss["f_oi_pre_bid_conference_required"]     = oi.get("pre_bid_conference_required", "Yes")
    ss["f_oi_testing_facilities_free_of_cost"] = oi.get("testing_facilities_free_of_cost", "Yes")
    ss["f_oi_sensitive_items"]                 = oi.get("sensitive_items", "Yes")
    ss["f_oi_nda_applicable"]                  = oi.get("nda_applicable", "Yes")
    ss["f_oi_ipr_property"]                    = oi.get("ipr_property", "")
    ss["f_oi_gem_non_availability_id"]         = oi.get("gem_non_availability_id", "")
    # Vendors
    ss["f_vendor_serial_number"]     = fd.get("vendor_serial_number", "")
    ss["f_vendor_code"]              = fd.get("vendor_code", "")
    ss["f_vendor_name"]              = fd.get("vendor_name", "")
    ss["f_vendor_address"]           = fd.get("vendor_address", "")
    ss["f_lab_registration_details"] = fd.get("lab_registration_details", "")
    # RFP
    ss["f_rfp_term_1"] = fd.get("rfp_term_1", "")
    ss["f_rfp_term_2"] = fd.get("rfp_term_2", "")
    ss["f_rfp_term_3"] = fd.get("rfp_term_3", "")
    # PAC
    ss["f_pac_accorded"] = fd.get("pac_accorded", "Yes")
    # SOC
    for k, _ in _SOC_LABELS:
        ss[f"f_soc_{k}"] = soc.get(k, "")
    # Financial Power
    ss["f_financial_power"] = fd.get("financial_power", _FIN_POWERS[0])


# ══════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════
def refresh_sessions():
    """
    Load the list of sessions for the current user.
    AD users (user_id is None) use the sentinel 0.
    """
    uid = st.session_state.user_id or 0
    st.session_state.sessions_list = db_get_sessions(uid)


def reset_work():
    """Clear active-work state and wipe all form field keys."""
    st.session_state.update(
        form_submitted=False, conversation=[], answers={},
        current_question=None, justification_generated=False,
        final_justification="", question_count=0,
        form_data={}, current_session_id=None, unsaved_work=False,
    )
    populate_form_fields({})   # blank out all fields


def group_by_date(sessions):
    grouped = {}
    for sid, title, created_at in sessions:
        dt  = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
        key = dt.strftime("%d %b %Y")
        grouped.setdefault(key, []).append((sid, title, dt.strftime("%H:%M")))
    return grouped


def has_active_work():
    """True if user has filled any field OR started a conversation."""
    any_field = any(
        bool(st.session_state.get(k, ""))
        for k in ("f_initiator_name", "f_item_nomenclature", "f_nature_of_item")
    )
    return any_field or bool(st.session_state.form_data) or bool(st.session_state.conversation)


# ══════════════════════════════════════════════════════════
#  OLLAMA
# ══════════════════════════════════════════════════════════
def call_ollama(prompt):
    r = requests.post(
        OLLAMA_URL,
        json={"model": MODEL_NAME, "prompt": prompt, "stream": False},
        timeout=120,
    )
    if r.status_code != 200:
        raise Exception(r.text)
    return r.json()["response"]


# ══════════════════════════════════════════════════════════
#  PROMPTS
# ══════════════════════════════════════════════════════════
def build_question_prompt(form_data, conversation, answers):
    return f"""
You are an enterprise procurement assistant.
Your goal is to collect enough information to generate a detailed procurement justification note.

Rules:
1. Ask only ONE simple question at a time.
2. Questions must dynamically depend on previous answers.
3. Ask questions regarding (reframe naturally based on context):
   - Is this a new requirement and if not then how was it handled earlier?
   - How many items are needed and how did the user arrive at that number (calculations required)?
   - Why were the alternatives not considered (provide those alternatives)?
   - What are the technical calculations required for the item?
   - Price breakdown for each sub-component must be provided.
   - Did any committee recommend the current item?
   - Why did the user select the specific mode of tender?
   - If procurement method is Non-GeM then ask the reason.
   - If PAC is yes, then what is the reason?
   - What is the broad technical requirement of this item?
   - Why were these specific technical specs needed?
   - What performance expectations exist (throughput, latency, scalability)?
   - Which systems or components must it integrate with?
   - Where will it be deployed (cloud, on-prem, edge, field)?
   - Are there any hardware or software constraints?
   - What are the maintenance, support, and lifecycle expectations?
4. Do not ask duplicate or repeated questions. Only ONE question (not your thinking).
5. Ask only 3 questions then respond ONLY with: JUSTIFICATION_COMPLETE

FORM DATA:
{json.dumps(form_data, indent=2)}

ANSWERS SO FAR:
{json.dumps(answers, indent=2)}

CONVERSATION:
{conversation}
"""


def build_justification_prompt(form_data, answers):
    return f"""
You are an enterprise procurement documentation specialist.
Generate a detailed procurement justification note.
Do NOT include the person's name. Base the justification on technical aspects only.

Requirements:
1. Output only continuous professional paragraphs.
2. No headings, no bullet points, no numbered lists.
3. The output must span multiple detailed paragraphs.
4. Use formal corporate language.
5. Naturally include: technical justification, technical calculations,
   alternatives considered, existing situation and solutions, number of items.

FORM DATA:
{json.dumps(form_data, indent=2)}

QUESTION ANSWERS:
{json.dumps(answers, indent=2)}
"""


# ══════════════════════════════════════════════════════════
#  DOCX  (fixed — uses params, returns in-memory buffer)
# ══════════════════════════════════════════════════════════
def generate_docx(employee_name, item_name, justification_text):
    doc = Document()
    doc.add_heading("Procurement Justification Note", level=1)
    doc.add_paragraph(f"Initiator: {employee_name}")
    doc.add_paragraph(f"Item: {item_name}")
    doc.add_paragraph(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    for para in justification_text.split("\n\n"):
        para = para.strip()
        if para:
            doc.add_paragraph(para)
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf


# ══════════════════════════════════════════════════════════
#  DIALOGS
# ══════════════════════════════════════════════════════════
@st.dialog(" Save Session")
def save_dialog():
    title = st.text_input(
        "Enter a title for this session",
        placeholder="",
    )
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Save", use_container_width=True):
            if title.strip():
                # Always collect freshest form state before saving
                current_fd = collect_form_data()
                st.session_state.form_data = current_fd
                sid = db_save_session(
                    st.session_state.user_id,
                    title.strip(),
                    current_fd,
                    st.session_state.conversation,
                    st.session_state.answers,
                    st.session_state.final_justification,
                )
                st.session_state.current_session_id = sid
                st.session_state.unsaved_work       = False
                st.session_state.show_save_dialog   = False
                refresh_sessions()
                st.rerun()
            else:
                st.warning("Please enter a title.")
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.show_save_dialog = False
            st.rerun()


@st.dialog(" Rename Session")
def rename_dialog():
    new = st.text_input("Session title", value=st.session_state.rename_title)
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Update", use_container_width=True):
            if new.strip():
                db_rename(st.session_state.rename_id, new.strip())
                st.session_state.rename_id    = None
                st.session_state.rename_title = ""
                refresh_sessions()
                st.rerun()
            else:
                st.warning("Title cannot be empty.")
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.rename_id = None
            st.rerun()


@st.dialog(" Delete Session")
def delete_dialog():
    st.warning("Are you sure you want to delete this session? This cannot be undone.")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Yes, Delete", use_container_width=True):
            sid = st.session_state.delete_id
            if st.session_state.current_session_id == sid:
                reset_work()
            db_delete(sid)
            st.session_state.delete_id = None
            refresh_sessions()
            st.rerun()
    with c2:
        if st.button("Cancel", use_container_width=True):
            st.session_state.delete_id = None
            st.rerun()


@st.dialog(" ")
def unsaved_dialog():
    st.warning("You have unsaved work. What would you like to do?")
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button(" Save", use_container_width=True):
            st.session_state.pending_new_session = False
            st.session_state.show_save_dialog    = True
            st.rerun()
    with c2:
        if st.button("Discard", use_container_width=True):
            st.session_state.pending_new_session = False
            reset_work()
            st.rerun()
    with c3:
        if st.button("Cancel", use_container_width=True):
            st.session_state.pending_new_session = False
            st.rerun()


# ══════════════════════════════════════════════════════════
#  SIDEBAR
# ══════════════════════════════════════════════════════════
def show_sidebar():
    with st.sidebar:

        st.markdown(f"###  Welcome, **{st.session_state.username}**")
        st.divider()

        # New Session | Logout
        c1, c2 = st.columns(2)
        with c1:
            if st.button("➕ New Session", use_container_width=True):
                if has_active_work():
                    st.session_state.pending_new_session = True
                else:
                    reset_work()
                st.rerun()
        with c2:
            if st.button(" Logout", use_container_width=True):
                _del_cookie("username")
                _del_cookie("user_id")
                for k in list(st.session_state.keys()):
                    del st.session_state[k]
                st.rerun()

        # Save — always visible when any work exists
        if has_active_work():
            if st.button(" Save", use_container_width=True):
                st.session_state.show_save_dialog = True
                st.rerun()

        st.divider()

        # Chat history
        if not st.session_state.sessions_list:
            st.caption("No saved sessions yet.")
        else:
            grouped = group_by_date(st.session_state.sessions_list)
            for date_str, items in grouped.items():
                st.markdown(f"**{date_str}**")
                for sid, title, time_str in items:
                    is_active     = (sid == st.session_state.current_session_id)
                    col_t, col_m  = st.columns([5, 1])
                    with col_t:
                        if st.button(
                            f"{time_str} - {title}",
                            key=f"sess_{sid}",
                            use_container_width=True,
                            type="primary" if is_active else "secondary",
                        ):
                            data = db_load(sid)
                            if data:
                                populate_form_fields(data["form_data"])
                                st.session_state.form_data               = data["form_data"]
                                st.session_state.conversation            = data["conversation"]
                                st.session_state.answers                 = data["answers"]
                                st.session_state.final_justification     = data["justification"]
                                st.session_state.justification_generated = bool(data["justification"])
                                st.session_state.form_submitted          = (
                                    bool(data["conversation"]) or bool(data["justification"])
                                )
                                st.session_state.current_session_id = sid
                                st.session_state.unsaved_work        = False
                            st.rerun()
                    with col_m:
                        with st.popover("⋮"):
                            if st.button(" Rename", key=f"ren_{sid}", use_container_width=True):
                                st.session_state.rename_id    = sid
                                st.session_state.rename_title = title
                                st.rerun()
                            if st.button(" Delete", key=f"del_{sid}", use_container_width=True):
                                st.session_state.delete_id = sid
                                st.rerun()


# ══════════════════════════════════════════════════════════
#  LOGIN PAGE
# ══════════════════════════════════════════════════════════
def show_login():
    st.markdown(
        "<h1 style='text-align: center;'>Login with RCNET/PIS Details</h1>",
        unsafe_allow_html=True
    )
    _, col, _ = st.columns([1, 1, 1])
    with col:
        st.subheader("Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login", use_container_width=True):
            client_ip = st.session_state.get("client_ip") or "unknown"
            success, info = ad_auth(username, password, client_ip)

            if success:
                # Store a *virtual* user record in the session (no DB row needed)
                st.session_state.logged_in = True
                st.session_state.username  = info          # display name or username
                st.session_state.user_id   = None          # AD users have no local ID
                _set_cookie("username", info)
                _set_cookie("user_id", "ad")               # marker that we used AD
                refresh_sessions()                         # loads any saved sessions
                st.rerun()
            else:
                st.error(info)   # `info` contains the error message


# ══════════════════════════════════════════════════════════
#  MAIN APP
# ══════════════════════════════════════════════════════════
def show_main_app():
    st.title("AI BASED PROCUREMENT JUSTIFICATION GENERATOR")

    # ── PHASE 1 : Form (no st.form wrapper — fields are individually keyed) ──
    if not st.session_state.form_submitted:

        with st.expander("1. Initiator Details"):
            st.text_input("Initiating Officer Name",  key="f_initiator_name")
            st.selectbox("Designation",               _DESIGNATIONS, key="f_designation")
            st.text_input("Nature of Item",           key="f_nature_of_item")

        with st.expander("2. Budget Details"):
            st.text_input("Financial Year",           key="f_financial_year")
            st.text_input("Fund",                     key="f_fund")
            st.text_input("Budget Head",              key="f_budget_head")
            st.text_input("Budget Code",              key="f_budget_code")
            st.text_input("Unit Code",                key="f_unit_code")
            st.text_input("Budget Serial Number",     key="f_budget_serial_number")
            st.text_input("Forecasted Item",          key="f_forecasted_item")

        with st.expander("3. Procurement Method Details"):
            st.selectbox("Procurement Method",        _PROC_METHODS, key="f_procurement_method")

        with st.expander("4. Item Details"):
            st.text_input("Serial Number",            key="f_item_serial_number")
            st.text_input("Item Code",                key="f_item_code")
            st.text_input("Item Type",                key="f_item_type")
            st.text_input("Item Nomenclature",        key="f_item_nomenclature")
            st.number_input("Quantity",               min_value=0, step=1,   key="f_item_quantity")
            st.number_input("Rate per Unit",          min_value=0.0, step=1.0, key="f_item_rate")
            st.number_input("Estimated Cost",         min_value=0.0, step=1.0, key="f_item_estimated_cost")

        with st.expander("5. Other Inputs"):
            st.text_input("Tender Type",                                                key="f_oi_tender_type")
            st.text_input("Basis for working out the estimated cost",                   key="f_oi_basis_for_cost")
            st.selectbox("Single Bid/Two Bid",              _BID_TYPES,                key="f_oi_single_bid_two_bid")
            st.text_input("Expected Delivery",                                          key="f_oi_expected_delivery")
            st.text_input("Delivery Term",                                              key="f_oi_delivery_term")
            st.text_input("Price Bid Evaluation",                                       key="f_oi_price_bid_evaluation")
            st.text_input("Appointment of Quantity",                                    key="f_oi_appointment_of_quantity")
            st.text_input("Quality Tolerance Clause",                                   key="f_oi_quality_tolerance_clause")
            st.selectbox("Part Supply and Prorata Payment",  _YES_NO,                  key="f_oi_part_supply_prorata_payment")
            st.text_input("Details of Previous Order/Contract",                         key="f_oi_previous_order_contract_details")
            st.number_input("Warranty Period (months)",     min_value=0, step=1,        key="f_oi_warranty_period")
            st.text_input("Training",                                                   key="f_oi_training")
            st.text_input("Insurance Cover",                                            key="f_oi_insurance_cover")
            st.text_input("Inspection Agency",                                          key="f_oi_inspection_agency")
            st.text_input("Product Support",                                            key="f_oi_product_support")
            st.selectbox("Post Warranty AMC requirement",    _YES_NO,                  key="f_oi_post_warranty_amc")
            st.text_input("Requirement Sample",                                         key="f_oi_requirement_sample")
            st.text_input("Validity of Bids",                                           key="f_oi_validity_of_bids")
            st.selectbox("Can a Repeat order be placed",     _YES_NO,                  key="f_oi_repeat_order_possible")
            st.text_input("Can an option clause be invoked",                            key="f_oi_option_clause_invoked")
            st.selectbox("Pre-bid conference Required",      _YES_NO,                  key="f_oi_pre_bid_conference_required")
            st.selectbox("Testing/infrastructure facilities free of cost", _YES_NO,    key="f_oi_testing_facilities_free_of_cost")
            st.selectbox("Are items sensitive in Nature",    _YES_NO,                  key="f_oi_sensitive_items")
            st.selectbox("Is NDA with vendor applicable",    _YES_NO,                  key="f_oi_nda_applicable")
            st.text_input("IPR is the property of",                                     key="f_oi_ipr_property")
            st.text_input("GeM Non-availability ID",                                    key="f_oi_gem_non_availability_id")

        with st.expander("6. Vendors"):
            st.text_input("Serial Number",            key="f_vendor_serial_number")
            st.text_input("Vendor Code",              key="f_vendor_code")
            st.text_input("Vendor Name",              key="f_vendor_name")
            st.text_area("Address", height=80,        key="f_vendor_address")
            st.text_input("Lab Registration Details", key="f_lab_registration_details")

        with st.expander("7. RFP Terms"):
            st.text_input("Payment Term for Indigenous Seller", key="f_rfp_term_1")
            st.text_input("Payment Term for Foreign Seller",    key="f_rfp_term_2")
            st.text_input("Advance Payment",                    key="f_rfp_term_3")

        with st.expander("8. Is Proprietary Article Certificate(PAC) Accorded for Item?"):
            st.selectbox("PAC Accorded", _YES_NO, key="f_pac_accorded")

        with st.expander("9. Statement of Case"):
            for k, label in _SOC_LABELS:
                st.text_input(label, key=f"f_soc_{k}")

        with st.expander("10. Financial Power"):
            st.selectbox("Financial Power", _FIN_POWERS, key="f_financial_power")

        st.write("")   # breathing room before button
        if st.button(" Start", type="primary"):
            form_data = collect_form_data()
            st.session_state.form_data      = form_data
            st.session_state.form_submitted = True
            st.session_state.unsaved_work   = True

            with st.spinner("Thinking..."):
                first_q = call_ollama(build_question_prompt(form_data, [], {}))

            st.session_state.current_question = first_q
            st.rerun()

    # ── PHASE 2 : Chat ────────────────────────────────────────────────────────
    else:
        for msg in st.session_state.conversation:
            with st.chat_message(msg["role"]):
                st.write(msg["content"])

        if st.session_state.justification_generated:
            st.subheader("Generated Justification")
            st.write(st.session_state.final_justification)

            buf   = generate_docx(
                st.session_state.form_data.get("initiator_name", ""),
                st.session_state.form_data.get("item_nomenclature", ""),
                st.session_state.final_justification,
            )
            fname = (
                f"{st.session_state.form_data.get('initiator_name','unknown').replace(' ','_')}_"
                f"{st.session_state.form_data.get('item_nomenclature','item').replace(' ','_')}.docx"
            )
            st.download_button(
                " Download DOCX",
                data=buf,
                file_name=fname,
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            )

        else:
            with st.chat_message("assistant"):
                st.write(st.session_state.current_question)

            user_answer = st.chat_input("Enter your answer")

            if user_answer:
                st.session_state.conversation.append(
                    {"role": "assistant", "content": st.session_state.current_question}
                )
                st.session_state.conversation.append(
                    {"role": "user", "content": user_answer}
                )
                qkey = f"question_{st.session_state.question_count + 1}"
                st.session_state.answers[qkey] = {
                    "question": st.session_state.current_question,
                    "answer":   user_answer,
                }
                st.session_state.question_count += 1
                st.session_state.unsaved_work   = True

                with st.spinner("Thinking..."):
                    next_q = call_ollama(build_question_prompt(
                        st.session_state.form_data,
                        st.session_state.conversation,
                        st.session_state.answers,
                    ))

                if "JUSTIFICATION_COMPLETE" in next_q:
                    with st.spinner("Generating justification..."):
                        final = call_ollama(build_justification_prompt(
                            st.session_state.form_data,
                            st.session_state.answers,
                        ))
                    st.session_state.final_justification     = final
                    st.session_state.justification_generated = True
                    st.session_state.unsaved_work            = True
                else:
                    st.session_state.current_question = next_q

                st.rerun()


# ══════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════

# Restore login from cookie
if not st.session_state.logged_in and COOKIES_OK:
    _u = _get_cookie("username")
    _i = _get_cookie("user_id")
    if _u and _i:
        st.session_state.logged_in = True
        st.session_state.username  = _u
        st.session_state.user_id = int(_i) if _i.isdigit() else None
        refresh_sessions()

if not st.session_state.logged_in:
    show_login()

else:
    show_sidebar()
    show_main_app()

    # Modal dialogs — rendered as overlays on top of the page
    if st.session_state.show_save_dialog:
        save_dialog()

    if st.session_state.rename_id is not None:
        rename_dialog()

    if st.session_state.delete_id is not None:
        delete_dialog()

    if st.session_state.pending_new_session:
        unsaved_dialog()
