
import base64
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Generator, List, Optional, Tuple

import requests

from config import (
    IMAGE_CONTEXT_WINDOW,
    IMAGE_MIN_SCORE,
    MAX_HISTORY_TURNS,
    MAX_IMAGES_PER_QUERY,
    OLLAMA_HOST,
    OLLAMA_MODEL,
    OLLAMA_TIMEOUT,
)
from logger import get_logger

log = get_logger("ollama")


# ─────────────────────────────────────────────────────────────
# Generation stats
# ─────────────────────────────────────────────────────────────

@dataclass
class GenerationStats:
    t_prompt_build:  float = 0.0
    t_ttft:          float = 0.0
    t_total:         float = 0.0
    chars_generated: int   = 0

    @property
    def chars_per_sec(self) -> float:
        return self.chars_generated / self.t_total if self.t_total > 0 else 0.0

    @property
    def summary(self) -> str:
        return (
            f"Prompt build: {self.t_prompt_build:.3f}s | "
            f"TTFT: {self.t_ttft:.2f}s | "
            f"Total: {self.t_total:.2f}s | "
            f"Chars: {self.chars_generated} | "
            f"Speed: {self.chars_per_sec:.1f} chars/s"
        )


# ─────────────────────────────────────────────────────────────
# Question classifier
# ─────────────────────────────────────────────────────────────

@dataclass
class QuestionType:
    mode:        str = "text"   # "image" | "table" | "text"
    extra_instr: str = ""

    @property
    def is_image(self) -> bool:
        return self.mode == "image"

    @property
    def is_table(self) -> bool:
        return self.mode == "table"

    @property
    def is_text(self) -> bool:
        return self.mode == "text"


# Keywords that signal the user wants to look at a visual element
_IMAGE_TRIGGERS = frozenset([
    "chart", "graph", "diagram", "plot", "figure", "image",
    "picture", "visual", "bar", "pie", "trend", "growth",
    "comparison", "show me", "what does", "describe the",
    "color", "colour", "shape", "icon", "logo", "photo",
    "screenshot", "illustration", "look like", "depicted",
    "drawn", "plotted", "displayed", "shown",
])

# Keywords that signal structured / tabular data questions
_TABLE_TRIGGERS = frozenset([
    "table", "row", "column", "cell", "header",
    "list", "entry", "entries", "record", "records",
    "tabular", "grid",
    "how many", "which", "compare", "total", "average",
    "maximum", "minimum", "highest", "lowest", "sum",
    "breakdown", "per", "each", "count", "rank",
    "sorted", "ordered", "top", "bottom",
])

# Explicit reference: "figure 2", "fig.3", "image 4", "chart 1"
_EXPLICIT_REF_RE = re.compile(
    r"(?:image|figure|fig|graph|chart)\s*\.?\s*(\d+)",
    re.IGNORECASE,
)


def classify_question_type(
    question:  str,
    image_map: Dict[int, str],
) -> QuestionType:
    """
    Classify question as image / table / text.

    Priority: explicit figure reference → image keywords → table keywords → text.
    """
    q = question.lower()

    has_explicit = bool(_EXPLICIT_REF_RE.search(q))
    has_img_kw   = any(kw in q for kw in _IMAGE_TRIGGERS)
    has_images   = bool(image_map)

    if has_images and (has_explicit or has_img_kw):
        log.info(f"[Classifier] IMAGE  explicit={has_explicit} kw={has_img_kw}")
        return QuestionType(
            mode="image",
            extra_instr=(
                "VISUAL QUESTION INSTRUCTIONS:\n"
                "- You have been given image(s) from this document as attachments.\n"
                "- Study every image carefully: read axis labels, legends, titles,\n"
                "  data labels, and all visible text inside the image.\n"
                "- Quote specific numbers or labels you can actually see.\n"
                "- Describe trends, highs, lows, and patterns clearly.\n"
                "- When you refer to an image write: See Image N\n"
                "  (where N is the image number).\n"
                "- Only report what is clearly visible — do NOT guess.\n"
            ),
        )

    has_tbl_kw = any(kw in q for kw in _TABLE_TRIGGERS)
    if has_tbl_kw:
        log.info(f"[Classifier] TABLE  kw={has_tbl_kw}")
        return QuestionType(
            mode="table",
            extra_instr=(
                "TABLE QUESTION INSTRUCTIONS:\n"
                "- Tables in this document are formatted with pipe characters (|).\n"
                "- Locate the correct table by its column headers.\n"
                "- Read every row carefully — do not skip rows.\n"
                "- Quote exact cell values — never round or paraphrase numbers.\n"
                "- If multiple rows match, list each one.\n"
                "- If a cell is empty, say 'not available'.\n"
                "- Reproduce the relevant rows in your answer for clarity.\n"
            ),
        )

    log.info("[Classifier] TEXT  (default)")
    return QuestionType(mode="text", extra_instr="")


# ─────────────────────────────────────────────────────────────
# Image encoding
# ─────────────────────────────────────────────────────────────

def encode_image_to_base64(image_path: str) -> str:
    try:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    except Exception as exc:
        log.error(f"Failed to encode image {image_path}: {exc}")
        return ""


# ─────────────────────────────────────────────────────────────
# 6-Strategy image selector
# ─────────────────────────────────────────────────────────────

_STOP_WORDS = frozenset([
    "the", "a", "an", "in", "on", "at", "what", "how", "is", "are",
    "was", "were", "does", "did", "can", "could", "would", "from",
    "with", "about", "this", "that", "for", "to", "of", "and", "or",
])

_VISUAL_KW = frozenset([
    "chart", "graph", "diagram", "plot", "figure", "image",
    "visual", "trend", "growth", "comparison", "color", "colour",
    "shape", "shown", "displayed", "drawn",
])

_DATA_KW = frozenset([
    "value", "number", "percentage", "amount", "total",
    "revenue", "profit", "sales", "cost", "price", "rate",
    "increase", "decrease", "compare", "difference",
    "average", "maximum", "minimum", "highest", "lowest",
])


def find_referenced_images(
    question:       str,
    extracted_text: str,
    image_map:      Dict[int, str],
) -> List[str]:
    """
    Select the most relevant images for this question.
    Returns a list of base64-encoded image strings.

    IMPORTANT: The document text uses "[Image N appears here]" markers
    (not <<IMAGE_N>> tags). Strategy 2 searches for these markers.

    Strategy order (stops at first non-empty result):
      1. Explicit reference  — "figure 2", "image 3"
      2. Context matching    — keyword scoring around [Image N] markers
      3. Visual-intent fallback  — visual keywords + small image set
      4. Data-question fallback  — numeric/stats keywords + small image set
      5. Final safety net        — ≤2 images in doc → send all
    """
    if not image_map:
        return []

    q_lower    = question.lower()
    result_b64 : List[str] = []
    used_nums  : set       = set()

    def _load(num: int) -> Optional[str]:
        if num in used_nums:
            return None
        path = image_map.get(num, "")
        if not path or not Path(path).exists():
            return None
        b64 = encode_image_to_base64(path)
        if b64:
            used_nums.add(num)
            return b64
        return None

    # ── Strategy 1: Explicit reference ───────────────────────
    for num_str in _EXPLICIT_REF_RE.findall(q_lower):
        num = int(num_str)
        b64 = _load(num)
        if b64:
            result_b64.append(b64)
            log.info(f"[IMG] S1 explicit → image {num}")

    if result_b64:
        return result_b64[:MAX_IMAGES_PER_QUERY]

    # ── Prepare keywords for strategies 2-4 ──────────────────
    keywords = [
        w.strip(".,?!") for w in q_lower.split()
        if len(w) > 3 and w not in _STOP_WORDS
    ]

    # ── Strategy 2: Scored context matching ──────────────────
    # Marker format in extracted text: "[Image N appears here]"
    scored: List[Tuple[int, int]] = []   # (score, img_num)

    for img_num in sorted(image_map.keys()):
        # Match both old <<IMAGE_N>> style (legacy) and new "[Image N appears here]"
        patterns = [
            rf"\[Image {img_num} appears here\]",
            rf"<<IMAGE_{img_num}>>",
        ]
        best_score = 0
        for pat in patterns:
            for match in re.finditer(pat, extracted_text, re.IGNORECASE):
                pos   = match.start()
                ctx_s = max(0, pos - IMAGE_CONTEXT_WINDOW)
                ctx_e = min(len(extracted_text), pos + IMAGE_CONTEXT_WINDOW)
                ctx   = extracted_text[ctx_s:ctx_e].lower()
                score = sum(1 for kw in keywords if kw in ctx.split())
                best_score = max(best_score, score)

        if best_score >= IMAGE_MIN_SCORE:
            scored.append((best_score, img_num))

    scored.sort(reverse=True)
    for _, img_num in scored[:3]:
        b64 = _load(img_num)
        if b64:
            result_b64.append(b64)
            log.info(f"[IMG] S2 context → image {img_num}")

    if result_b64:
        return result_b64[:MAX_IMAGES_PER_QUERY]

    # ── Strategy 3: Visual-intent fallback ───────────────────
    if any(vk in q_lower for vk in _VISUAL_KW) and len(image_map) <= MAX_IMAGES_PER_QUERY:
        log.info("[IMG] S3 visual fallback → all images")
        for num in sorted(image_map.keys()):
            b64 = _load(num)
            if b64:
                result_b64.append(b64)
        if result_b64:
            return result_b64

    # ── Strategy 4: Data-question fallback ───────────────────
    if any(dk in q_lower for dk in _DATA_KW) and len(image_map) <= MAX_IMAGES_PER_QUERY:
        log.info("[IMG] S4 data fallback → all images")
        for num in sorted(image_map.keys()):
            b64 = _load(num)
            if b64:
                result_b64.append(b64)
        if result_b64:
            return result_b64

    # ── Strategy 5: Final safety net ─────────────────────────
    if len(image_map) <= 2:
        log.info("[IMG] S5 safety net → ≤2 images")
        for num in sorted(image_map.keys())[:2]:
            b64 = _load(num)
            if b64:
                result_b64.append(b64)

    return result_b64[:MAX_IMAGES_PER_QUERY]


# ─────────────────────────────────────────────────────────────
# Prompt builder
# ─────────────────────────────────────────────────────────────

def build_prompt(
    extracted_text: str,
    chat_history:   list,
    question:       str,
    image_map:      Dict[int, str],
) -> Tuple[str, List[str], float, QuestionType]:
    """
    Classify the question, select images if needed, build the full prompt.

    Returns:
        prompt        (str)          — complete prompt text for Ollama
        images_b64    (List[str])    — base64 images to attach (empty for text/table)
        build_time    (float)        — seconds taken to build
        qtype         (QuestionType) — mode + extra instructions used
    """
    t0 = time.perf_counter()

    # 1. Classify
    qtype = classify_question_type(question, image_map)

    # 2. Select images
    images_b64: List[str] = []

    if qtype.is_image:
        # Image/table question → full keyword-based selector
        images_b64 = find_referenced_images(question, extracted_text, image_map)

    elif qtype.is_text and image_map and extracted_text:
        # Text question → ONLY send image if [Image N appears here] tag
        # literally exists inside the most relevant answer passage.
        # No guessing — exact tag match only prevents garbage images.
        q_words = set(question.lower().split()) - {
            "what", "how", "why", "when", "where", "is", "are",
            "the", "a", "an", "does", "do", "did", "was", "were",
            "in", "of", "for", "to", "and", "or", "it", "this",
        }
        # Find most relevant passage by keyword density
        best_pos, best_score = 0, 0
        window = 600
        for i in range(0, max(1, len(extracted_text) - window), 100):
            chunk = extracted_text[i:i + window].lower()
            score = sum(1 for w in q_words if w in chunk)
            if score > best_score:
                best_score, best_pos = score, i

        # Only proceed if we found a relevant passage
        if best_score > 0:
            passage = extracted_text[max(0, best_pos - 200): best_pos + 800]
            for m in re.finditer(r"\[Image (\d+) appears here\]", passage):
                n = int(m.group(1))
                if n in image_map:
                    b64 = encode_image_to_base64(image_map[n])
                    if b64:
                        images_b64.append(b64)
                        log.info(
                            f"[IMG] Text question → literal Image {n} "
                            f"found in answer passage"
                        )
            images_b64 = images_b64[:MAX_IMAGES_PER_QUERY]

    # 3. Conversation history
    history_block = ""
    if chat_history:
        lines = []
        for turn in chat_history[-MAX_HISTORY_TURNS:]:
            lines.append(f"User: {turn['question']}")
            lines.append(f"Assistant: {turn['answer']}")
            lines.append("")
        history_block = (
            "\n\nCONVERSATION HISTORY (most recent last):\n"
            + "\n".join(lines)
        )

    # 4. Vision note (only when images are attached)
    vision_note = ""
    if images_b64:
        vision_note = (
            f"\n• You have been given {len(images_b64)} image(s) from this document."
            "\n• Study the image(s) carefully before answering."
            "\n• Refer to images as: See Image N"
        )

    # 5. Type-specific instruction block
    extra_block = f"\n{qtype.extra_instr}\n" if qtype.extra_instr else ""

    # 6. Assemble
    prompt = (
        "You are a helpful, precise document assistant with vision capabilities.\n\n"
        "GENERAL INSTRUCTIONS:\n"
        "- Answer only from the document content provided below.\n"
        "- Page markers in the document: <!-- Page 1 -->, <!-- Page 2 --> etc.\n"
        "- Always end your answer with: **Source: <document filename> | — Page <N> | Section: <name>\n"
        "  Example: ** Source: report.pdf | — Page 8 | Section: Results\n"
        "- If the answer is not in the document: say exactly "
        "'I could not find this information in the document.'\n"
        "- Do NOT make up or guess any information."
        + vision_note + "\n"
        + extra_block
        + "═" * 60 + "\n"
        "DOCUMENT CONTENT:\n"
        + "═" * 60 + "\n"
        + extracted_text + "\n"
        + "═" * 60 + "\n"
        + history_block
        + "\nCURRENT QUESTION:\n"
        + question
        + "\n\nANSWER:"
    )

    build_time = time.perf_counter() - t0
    log.info(
        f"[Prompt] mode={qtype.mode} | {len(prompt):,} chars | "
        f"{len(images_b64)} image(s) | build={build_time:.3f}s"
    )

    return prompt, images_b64, build_time, qtype


# ─────────────────────────────────────────────────────────────
# Streaming generator
# ─────────────────────────────────────────────────────────────

def stream_response(
    prompt: str,
    images: List[str],
    stats:  GenerationStats,
) -> Generator[str, None, None]:
    
    payload = {
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": True,
        "options": {
            "num_ctx":     128000,
            "temperature": 0.1,
            "top_p":       0.9,
        },
    }
    if images:
        payload["images"] = images
        log.info(f"[Vision] {len(images)} image(s) → {OLLAMA_MODEL}")
    else:
        log.info("[Text] No images attached")

    t_start     = time.perf_counter()
    first_token = True

    with requests.post(
        f"{OLLAMA_HOST}/api/generate",
        json    = payload,
        stream  = True,
        timeout = OLLAMA_TIMEOUT,
    ) as resp:
        resp.raise_for_status()

        for raw in resp.iter_lines():
            if not raw:
                continue
            data  = json.loads(raw)
            token = data.get("response", "")

            if token:
                if first_token:
                    stats.t_ttft = time.perf_counter() - t_start
                    log.info(f"[QA] TTFT = {stats.t_ttft:.2f}s")
                    first_token  = False
                stats.chars_generated += len(token)
                yield token

            if data.get("done", False):
                break

    stats.t_total = time.perf_counter() - t_start


# ─────────────────────────────────────────────────────────────
# Connectivity check( @st.cache_data in the main app)
# ─────────────────────────────────────────────────────────────

def check_ollama_connection() -> Tuple[bool, str]:
   
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=10)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]

        if OLLAMA_MODEL in models:
            log.info(f"Ollama   model={OLLAMA_MODEL}")
            return True, f"Connected — {len(models)} model(s) loaded"
        else:
            msg = f"Model '{OLLAMA_MODEL}' not found. Available: {models}"
            log.warning(msg)
            return False, msg

    except requests.exceptions.ConnectionError:
        msg = f"Cannot reach Ollama at {OLLAMA_HOST}"
        log.warning(msg)
        return False, msg
    except Exception as exc:
        return False, str(exc)
