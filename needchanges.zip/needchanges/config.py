# config.py
# ─────────────────────────────────────────────────────────────
#  Single place to change all settings
# ─────────────────────────────────────────────────────────────

# ── Ollama ────────────────────────────────────────────────────
OLLAMA_HOST    = "http://localhost:12345"   # ← change to your server
OLLAMA_MODEL   = "gemma4:e4b"              # ← Vision-enabled multimodal model
OLLAMA_TIMEOUT = 300                        # seconds

# ── Document limits ───────────────────────────────────────────
MAX_PAGES            = 50
MAX_HISTORY_TURNS    = 10
WORDS_PER_PAGE       = 500
SUPPORTED_EXTENSIONS = ["pdf", "docx", "txt"]

# ── Storage paths ─────────────────────────────────────────────
# Permanent storage — markdown + images saved here forever
# Structure: extracted_docs/YYYY-MM-DD/document_name/
EXTRACTED_DOCS_DIR = "extracted_docs"

# ── OCR settings ─────────────────────────────────────────────
# Minimum characters per page to consider PDF as digital (not scanned)
# If a page has less than this → treated as scanned → OCR applied
SCANNED_TEXT_THRESHOLD = 50
