"""
logger.py
─────────────────────────────────────────────────────────────
Two separate log files:

1. logs/system_YYYY-MM-DD.log
   → Technical logs (errors, debug, extraction steps)
   → Only developers need to read this

2. logs/activity_YYYY-MM-DD.log
   → Structured activity tracking
   → Who accessed, which doc, extraction time,
      every question + answer + timing row by row
─────────────────────────────────────────────────────────────
"""

import logging
from datetime import datetime
from pathlib import Path

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

_DATE_FMT    = "%Y-%m-%d %H:%M:%S"
_SYSTEM_FMT  = "[%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s"


# ── system logger (technical logs) ───────────────────────────

def get_logger(name: str) -> logging.Logger:
    """Return a named system logger."""
    logger = logging.getLogger(f"system.{name}")

    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # console — INFO only
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter(
        "[%(asctime)s] [%(levelname)-8s] %(message)s",
        datefmt=_DATE_FMT
    ))
    logger.addHandler(console)

    # file — DEBUG full detail
    log_file = LOG_DIR / f"system_{datetime.now().strftime('%Y-%m-%d')}.log"
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_SYSTEM_FMT, datefmt=_DATE_FMT))
    logger.addHandler(fh)

    return logger


# ── activity logger (structured tracking) ────────────────────

class ActivityLogger:
    """
    Structured row-wise activity logger.
    Tracks: session, IP, document, extraction timing,
            every question + answer + generation timing.
    """

    def __init__(self):
        self._logger = logging.getLogger("activity")

        if self._logger.handlers:
            return

        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        log_file = LOG_DIR / f"activity_{datetime.now().strftime('%Y-%m-%d')}.log"
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(logging.INFO)
        # raw format — we build our own structured lines
        fh.setFormatter(logging.Formatter("%(message)s"))
        self._logger.addHandler(fh)

    def _write(self, line: str):
        self._logger.info(line)

    def log_session_start(self, session_id: str, ip: str):
        self._write(
            f"\n{'═' * 80}\n"
            f"SESSION    | {datetime.now().strftime(_DATE_FMT)} "
            f"| IP: {ip} "
            f"| Session: {session_id}"
        )

    def log_document(
        self,
        filename:   str,
        pages:      int,
        chars:      int,
        images:     int,
    ):
        self._write(
            f"DOCUMENT   | {filename} "
            f"| Pages: {pages} "
            f"| Chars: {chars:,} "
            f"| Images: {images}"
        )

    def log_extraction_timing(
        self,
        t_page_check:  float,
        t_text:        float,
        t_images:      float,
        t_total:       float,
    ):
        self._write(
            f"EXTRACTION | "
            f"Page check: {t_page_check:.2f}s | "
            f"Text: {t_text:.2f}s | "
            f"Images: {t_images:.2f}s | "
            f"Total: {t_total:.2f}s"
        )

    def log_qa(
        self,
        turn:          int,
        question:      str,
        answer:        str,
        t_prompt:      float,
        t_ttft:        float,
        t_total:       float,
        chars_per_sec: float,
    ):
        # truncate very long answers in log (keep first 500 chars)
        answer_log = answer[:500] + "..." if len(answer) > 500 else answer
        # clean newlines for clean log rows
        answer_log = answer_log.replace("\n", " ").strip()
        question   = question.replace("\n", " ").strip()

        self._write(
            f"{'─' * 80}\n"
            f"Q&A ROW {turn:>3} |\n"
            f"QUESTION   | {question}\n"
            f"ANSWER     | {answer_log}\n"
            f"TIMING     | "
            f"Prompt: {t_prompt:.3f}s | "
            f"TTFT: {t_ttft:.2f}s | "
            f"Total: {t_total:.2f}s | "
            f"Speed: {chars_per_sec:.1f} chars/s"
        )

    def log_session_end(self, session_id: str, total_questions: int):
        self._write(
            f"SESSION END| {datetime.now().strftime(_DATE_FMT)} "
            f"| Session: {session_id} "
            f"| Total Questions: {total_questions}\n"
            f"{'═' * 80}"
        )


# single shared instance
activity_log = ActivityLogger()
