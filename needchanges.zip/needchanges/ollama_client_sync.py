"""
ollama_client_sync.py
─────────────────────────────────────────────────────────────
Synchronous streaming client for Gemma 4 E4B (vision model).

Capabilities:
  • Text-only questions → standard text mode
  • Questions with images → vision mode (sends base64 images)
  • Automatically detects which images are relevant
  • Citation support via page markers in prompt
─────────────────────────────────────────────────────────────
"""

import base64
import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Generator, Tuple, Dict, List

import requests

from config import OLLAMA_HOST, OLLAMA_MODEL, OLLAMA_TIMEOUT, MAX_HISTORY_TURNS
from logger import get_logger

log = get_logger("ollama")


# ── timing ────────────────────────────────────────────────────

@dataclass
class GenerationStats:
    t_prompt_build:  float = 0.0
    t_ttft:          float = 0.0
    t_total:         float = 0.0
    chars_generated: int   = 0

    @property
    def chars_per_sec(self) -> float:
        return self.chars_generated / self.t_total if self.t_total > 0 else 0.0

    @property
    def summary(self) -> str:
        return (
            f"Prompt build: {self.t_prompt_build:.3f}s | "
            f"TTFT: {self.t_ttft:.2f}s | "
            f"Total: {self.t_total:.2f}s | "
            f"Chars: {self.chars_generated} | "
            f"Speed: {self.chars_per_sec:.1f} chars/s"
        )


# ── image encoding ────────────────────────────────────────────

def encode_image_to_base64(image_path: str) -> str:
    """
    Read image file and convert to base64 string for Ollama vision API.
    Returns base64-encoded string.
    """
    try:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    except Exception as e:
        log.error(f"Failed to encode image {image_path}: {e}")
        return ""


def find_referenced_images(
    question: str,
    extracted_text: str,
    image_map: Dict[int, str],
) -> List[str]:
    """
    Smart detection: which images are relevant to this question?
    
    Strategy:
      1. Look for image numbers explicitly in question: "show me image 2"
      2. Look for visual keywords: "chart", "graph", "diagram"
      3. Context matching: search for question keywords near image tags
      4. FALLBACK: If asking for data/numbers and has few images → send all
    
    Returns list of base64-encoded images to send to LLM.
    """
    if not image_map:
        return []
    
    question_lower = question.lower()
    referenced_images = []
    
    # ── Strategy 1: Explicit image number in question ──
    # "show me image 2", "what does figure 3 show"
    explicit_nums = re.findall(r'(?:image|figure)\s*(\d+)', question_lower)
    for num_str in explicit_nums:
        num = int(num_str)
        if num in image_map:
            img_path = image_map[num]
            if Path(img_path).exists():
                b64 = encode_image_to_base64(img_path)
                if b64:
                    referenced_images.append(b64)
                    log.info(f"Including image {num} (explicit reference)")
    
    if referenced_images:
        return referenced_images  # found explicit references, done
    
    # ── Strategy 2: Visual keywords in question ──
    visual_keywords = [
        "chart", "graph", "diagram", "plot", "figure", 
        "image", "picture", "visual", "bar", "pie", 
        "trend", "growth", "comparison", "show me"
    ]
    
    has_visual_intent = any(kw in question_lower for kw in visual_keywords)
    
    if has_visual_intent:
        # Question is asking about visual content
        # Strategy: find which images are most relevant by searching document context
        
        # Extract keywords from question (skip common words)
        stop_words = {"the", "a", "an", "in", "on", "at", "what", "how", "is", "are"}
        keywords = [
            word.strip(".,?!") 
            for word in question_lower.split() 
            if len(word) > 3 and word not in stop_words
        ]
        
        # For each image tag in document, check if nearby text contains question keywords
        for img_num in sorted(image_map.keys()):
            tag = f"<<IMAGE_{img_num}>>"
            if tag in extracted_text:
                # Get 500 chars before and after image tag
                pos = extracted_text.find(tag)
                context_start = max(0, pos - 500)
                context_end = min(len(extracted_text), pos + 500)
                context = extracted_text[context_start:context_end].lower()
                
                # Check if any question keywords appear near this image
                keyword_matches = sum(1 for kw in keywords if kw in context)
                
                if keyword_matches > 0:
                    img_path = image_map[img_num]
                    if Path(img_path).exists():
                        b64 = encode_image_to_base64(img_path)
                        if b64:
                            referenced_images.append(b64)
                            log.info(
                                f"Including image {img_num} "
                                f"({keyword_matches} keyword matches)"
                            )
        
        # If visual question but no context matches, include all images as fallback
        if not referenced_images and len(image_map) <= 5:
            log.info("Visual question — including all images as fallback")
            for img_num, img_path in image_map.items():
                if Path(img_path).exists():
                    b64 = encode_image_to_base64(img_path)
                    if b64:
                        referenced_images.append(b64)
    
    # ── Strategy 3: Context matching (no visual keywords, but might need images) ──
    if not referenced_images:
        # Extract keywords from question
        stop_words = {"the", "a", "an", "in", "on", "at", "what", "how", "is", "are", 
                     "was", "were", "does", "did", "can", "could", "would"}
        keywords = [
            word.strip(".,?!") 
            for word in question_lower.split() 
            if len(word) > 3 and word not in stop_words
        ]
        
        if keywords:
            # Search for these keywords near image tags
            for img_num in sorted(image_map.keys()):
                tag = f"<<IMAGE_{img_num}>>"
                if tag in extracted_text:
                    # Get 500 chars before and after image tag
                    pos = extracted_text.find(tag)
                    context_start = max(0, pos - 500)
                    context_end = min(len(extracted_text), pos + 500)
                    context = extracted_text[context_start:context_end].lower()
                    
                    # Check if any question keywords appear near this image
                    keyword_matches = sum(1 for kw in keywords if kw in context)
                    
                    if keyword_matches > 0:
                        img_path = image_map[img_num]
                        if Path(img_path).exists():
                            b64 = encode_image_to_base64(img_path)
                            if b64:
                                referenced_images.append(b64)
                                log.info(
                                    f"Including image {img_num} "
                                    f"(context match: {keyword_matches} keywords)"
                                )
    
    # ── Strategy 4: SAFETY FALLBACK for data questions ──
    # If question asks for data/numbers/values but no images sent yet,
    # and document has few images (≤3), send all images.
    # Let Gemma 4 E4B's vision decide which is relevant.
    if not referenced_images:
        data_keywords = [
            "how much", "how many", "what was", "what is", "what are",
            "value", "number", "percentage", "%", "amount", "total",
            "revenue", "profit", "sales", "cost", "price", "rate",
            "compare", "difference", "increase", "decrease"
        ]
        
        asks_for_data = any(kw in question_lower for kw in data_keywords)
        
        if asks_for_data and len(image_map) <= 3:
            # Send all images — vision model will figure out which is relevant
            log.info(
                f"Data question detected with {len(image_map)} image(s) "
                "— sending all as safety fallback"
            )
            for img_num in sorted(image_map.keys()):
                img_path = image_map[img_num]
                if Path(img_path).exists():
                    b64 = encode_image_to_base64(img_path)
                    if b64:
                        referenced_images.append(b64)
    
    return referenced_images


# ── prompt builder ────────────────────────────────────────────

def build_prompt(
    extracted_text: str,
    chat_history:   list,
    question:       str,
    image_map:      Dict[int, str],
) -> Tuple[str, List[str], float]:
    """
    Build the full prompt for Gemma 4 E4B.
    
    Returns:
        prompt_string     – text prompt with instructions
        images_base64     – list of base64-encoded images to send
        build_time        – seconds taken to build
    """
    t0 = time.perf_counter()
    
    # ── detect which images to send ──
    images_to_send = find_referenced_images(question, extracted_text, image_map)
    
    # ── build history block ──
    history_block = ""
    if chat_history:
        lines = []
        for turn in chat_history[-MAX_HISTORY_TURNS:]:
            lines.append(f"User: {turn['question']}")
            lines.append(f"Assistant: {turn['answer']}")
            lines.append("")
        history_block = (
            "\n\nCONVERSATION HISTORY (most recent last):\n"
            + "\n".join(lines)
        )
    
    # ── build prompt ──
    vision_note = ""
    if images_to_send:
        vision_note = (
            f"\n• You have been provided with {len(images_to_send)} image(s) "
            "from the document. Use them to answer visual questions about "
            "charts, graphs, diagrams, or any visual content."
        )
    
    prompt = f"""You are a helpful, precise document assistant with vision capabilities.

INSTRUCTIONS:
- Answer based on the document content provided below.
- The document has page markers like <!-- Page 1 -->, <!-- Page 2 --> etc.
- Always end your answer with a citation: 📌 Source: Page <number>, <Section>
- If multiple pages, cite all relevant pages.{vision_note}
- If a figure/chart/graph is relevant, reference it: <<IMAGE_N>>
- If answer not in document: "I couldn't find this information in the document."
- Do NOT make up information.

{'═' * 60}
DOCUMENT CONTENT:
{'═' * 60}
{extracted_text}
{'═' * 60}
{history_block}
CURRENT QUESTION:
{question}

ANSWER:"""
    
    build_time = time.perf_counter() - t0
    
    log.info(
        f"Prompt built | {len(prompt):,} chars | "
        f"{len(images_to_send)} image(s) attached | {build_time:.3f}s"
    )
    
    return prompt, images_to_send, build_time


# ── streaming generator ───────────────────────────────────────

def stream_response(
    prompt:  str,
    images:  List[str],  # list of base64-encoded images
    stats:   GenerationStats,
) -> Generator[str, None, None]:
    """
    Stream tokens from Gemma 4 E4B with optional vision input.
    
    Ollama API format for vision:
    {
      "model": "gemma4:e4b",
      "prompt": "question text",
      "images": ["base64_img1", "base64_img2"],  ← vision capability
      "stream": true
    }
    """
    url     = f"{OLLAMA_HOST}/api/generate"
    payload = {
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": True,
        "options": {
            "num_ctx":     128000,  # full 128k context
            "temperature": 0.1,     # factual answers
            "top_p":       0.9,
        },
    }
    
    # ── add images if provided (vision mode) ──
    if images:
        payload["images"] = images
        log.info(f"[Vision mode] Sending {len(images)} image(s) to Gemma 4 E4B")
    else:
        log.info("[Text mode] No images sent")
    
    t_start     = time.perf_counter()
    first_token = True

    with requests.post(
        url,
        json    = payload,
        stream  = True,
        timeout = OLLAMA_TIMEOUT,
    ) as response:
        response.raise_for_status()

        for raw_line in response.iter_lines():
            if not raw_line:
                continue

            data  = json.loads(raw_line)
            token = data.get("response", "")

            if token:
                if first_token:
                    stats.t_ttft = time.perf_counter() - t_start
                    log.info(f"[QA] TTFT = {stats.t_ttft:.2f}s")
                    first_token  = False

                stats.chars_generated += len(token)
                yield token

            if data.get("done", False):
                break

    stats.t_total = time.perf_counter() - t_start


# ── connectivity check ────────────────────────────────────────

def check_ollama_connection() -> Tuple[bool, object]:
    """Ping Ollama and check if gemma4:e4b is available."""
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=10)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]
        
        # Check if our vision model is present
        if OLLAMA_MODEL in models:
            log.info(f"Vision model {OLLAMA_MODEL} found ✅")
            return True, models
        else:
            log.warning(
                f"Vision model {OLLAMA_MODEL} NOT found in Ollama. "
                f"Available: {models}"
            )
            return False, f"Model {OLLAMA_MODEL} not found. Available: {models}"
            
    except Exception as exc:
        return False, str(exc)
