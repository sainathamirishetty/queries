"""
streamlit_app.py  —  DocQA
─────────────────────────────────────────────────────────────
Run with:
  streamlit run streamlit_app.py --server.address 0.0.0.0 --server.port 8000
─────────────────────────────────────────────────────────────
"""

import re
import uuid
import tempfile
from pathlib import Path

import streamlit as st

from config import SUPPORTED_EXTENSIONS, MAX_HISTORY_TURNS
from extractor import extract_document, cleanup_session_images
from ollama_client_sync import (
    build_prompt,
    stream_response,
    check_ollama_connection,
    GenerationStats,
)
from logger import get_logger, activity_log

log = get_logger("app")


# ── page config ───────────────────────────────────────────────

st.set_page_config(
    page_title = "DocQA",
    page_icon  = "📄",
    layout     = "wide",
)


# ── get client IP ─────────────────────────────────────────────

def get_client_ip() -> str:
    """
    Try to get real client IP from multiple sources.
    Streamlit context headers can be None, so try multiple fallbacks.
    """
    try:
        # Try st.context.headers first (modern API)
        headers = getattr(st.context, 'headers', None)
        if headers:
            # x-forwarded-for can have multiple IPs, take first
            forwarded = headers.get("x-forwarded-for", "").split(",")[0].strip()
            if forwarded:
                return forwarded
            
            real_ip = headers.get("x-real-ip", "")
            if real_ip:
                return real_ip
                
            remote = headers.get("remote-addr", "")
            if remote:
                return remote
        
        # Fallback — use environment or return unknown
        import os
        return os.getenv("REMOTE_ADDR", "unknown")
        
    except Exception as e:
        log.debug(f"IP detection error: {e}")
        return "unknown"


# ── session state init ────────────────────────────────────────

def init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        st.session_state.qa_turn    = 0
        activity_log.log_session_start(sid, ip)
        log.info(f"New session  id={sid}  ip={ip}")

    defaults = {
        "extracted_text":  None,
        "image_map":       {},
        "chat_history":    [],
        "messages":        [],
        "doc_name":        None,
        "doc_pages":       None,
        "doc_chars":       None,
        "doc_images":      0,
        "doc_scanned":     False,
        "md_saved_path":   None,
        "qa_turn":         0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_session()


# ── sidebar ───────────────────────────────────────────────────

with st.sidebar:
    st.title("📄 DocQA")
    st.caption("Document Question Answering")
    st.divider()

    # Ollama status
    ok, info = check_ollama_connection()
    if ok:
        st.success("Ollama connected ✅")
    else:
        st.error("Ollama not reachable ❌")
        st.caption(str(info))

    st.divider()

    # file uploader
    st.subheader("📂 Upload Document")
    st.caption("PDF · DOCX · TXT  |  Max 50 pages")

    uploaded_file = st.file_uploader(
        label            = "Choose a file",
        type             = SUPPORTED_EXTENSIONS,
        label_visibility = "collapsed",
    )

    # process new file
    if uploaded_file is not None:
        if uploaded_file.name != st.session_state.doc_name:

            with st.spinner(f"Extracting {uploaded_file.name}…"):
                try:
                    suffix   = Path(uploaded_file.name).suffix
                    tmp      = tempfile.NamedTemporaryFile(
                        delete=False, suffix=suffix
                    )
                    tmp.write(uploaded_file.read())
                    tmp.flush()
                    tmp.close()

                    res = extract_document(
                        file_path  = tmp.name,
                        file_ext   = suffix.lstrip("."),
                        session_id = st.session_state.session_id,
                        original_filename=uploaded_file.name,
                    )

                    # store in session
                    st.session_state.extracted_text = res.full_text
                    st.session_state.image_map      = res.image_map
                    st.session_state.doc_name       = uploaded_file.name
                    st.session_state.doc_pages      = res.page_count
                    st.session_state.doc_chars      = len(res.full_text)
                    st.session_state.doc_images     = len(res.image_map)
                    st.session_state.doc_scanned    = res.is_scanned
                    st.session_state.md_saved_path  = res.md_saved_path
                    st.session_state.chat_history   = []
                    st.session_state.messages       = []
                    st.session_state.qa_turn        = 0

                    # activity log
                    activity_log.log_document(
                        filename = uploaded_file.name,
                        pages    = res.page_count,
                        chars    = len(res.full_text),
                        images   = len(res.image_map),
                    )
                    activity_log.log_extraction_timing(
                        t_page_check = res.t_page_check,
                        t_text       = res.t_text_extraction,
                        t_images     = res.t_image_extraction,
                        t_total      = res.t_total,
                    )

                    log.info(f"Extracted: {uploaded_file.name} | {res.summary}")
                    st.success("✅ Ready!")

                except ValueError as exc:
                    st.error(str(exc))
                    log.warning(str(exc))
                except Exception as exc:
                    st.error(f"Error: {exc}")
                    log.exception(str(exc))

    st.divider()

    # document info — clean, no timing
    if st.session_state.doc_name:
        st.subheader("📋 Document Info")
        st.markdown(f"**File:** {st.session_state.doc_name}")
        st.markdown(f"**Pages:** {st.session_state.doc_pages}")
        st.markdown(f"**Characters:** {st.session_state.doc_chars:,}")
        st.markdown(f"**Images found:** {st.session_state.doc_images}")

        # show if scanned PDF was detected
        if st.session_state.doc_scanned:
            st.caption("🔍 Scanned PDF detected — EasyOCR was used")
        else:
            st.caption("📝 Digital document")

        # show where markdown was saved
        if st.session_state.md_saved_path:
            st.caption(f"💾 Saved: `{st.session_state.md_saved_path}`")

        st.divider()

        if st.button("🗑️ Clear Document", use_container_width=True):
            for k in [
                "extracted_text", "image_map", "doc_name",
                "doc_pages", "doc_chars", "doc_images",
                "doc_scanned", "md_saved_path",
                "chat_history", "messages", "qa_turn",
            ]:
                st.session_state[k] = (
                    None  if k in ("extracted_text", "doc_name", "doc_pages",
                                   "doc_chars", "md_saved_path")
                    else {} if k == "image_map"
                    else [] if k in ("chat_history", "messages")
                    else False if k == "doc_scanned"
                    else 0
                )
            log.info("Document cleared by user")
            st.rerun()


# ── main chat area ────────────────────────────────────────────

st.title("💬 Ask Your Document")

if not st.session_state.extracted_text:
    st.info(
        "👈 Upload a **PDF**, **DOCX**, or **TXT** file from the sidebar.\n\n"
        "Once uploaded, ask any question about the document here."
    )

# render previous messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        for img_path in msg.get("images", []):
            if Path(img_path).exists():
                st.image(img_path, width=700)


# ── chat input + QA ───────────────────────────────────────────

question = st.chat_input(
    placeholder = "Ask a question about your document…",
    disabled    = not st.session_state.extracted_text,
)

if question:
    log.info(f"Q: {question[:120]}")

    # user message
    with st.chat_message("user"):
        st.markdown(question)
    st.session_state.messages.append({
        "role": "user", "content": question, "images": []
    })

    # build prompt
    prompt, images_base64, t_prompt = build_prompt(
        extracted_text = st.session_state.extracted_text,
        chat_history   = st.session_state.chat_history,
        question       = question,
        image_map      = st.session_state.image_map,  # ← pass image map for vision
    )
    stats = GenerationStats(t_prompt_build=t_prompt)

    log.info(f"Prompt: {len(prompt):,} chars | {len(images_base64)} images | build: {t_prompt:.3f}s")

    # stream answer
    full_answer       = ""
    referenced_images = []

    with st.chat_message("assistant"):
        try:
            full_answer = st.write_stream(
                stream_response(prompt, images_base64, stats)  # ← pass images
            )
        except Exception as exc:
            full_answer = (
                f"❌ Ollama error: `{exc}`\n\n"
                "Check Ollama is running and OLLAMA_HOST in config.py is correct."
            )
            st.error(full_answer)
            log.error(f"Ollama error: {exc}")

        # render referenced images
        if st.session_state.image_map:
            nums = re.findall(r"<<IMAGE_(\d+)>>", full_answer)
            seen = set()
            for n in nums:
                if n not in seen:
                    seen.add(n)
                    img_path = st.session_state.image_map.get(int(n))
                    if img_path and Path(img_path).exists():
                        referenced_images.append(img_path)
                        st.image(
                            img_path,
                            caption = f"Figure {n}",
                            width   = 700,
                        )

    # update chat history for LLM
    st.session_state.qa_turn += 1
    st.session_state.chat_history.append({
        "question": question,
        "answer":   full_answer,
    })
    if len(st.session_state.chat_history) > MAX_HISTORY_TURNS:
        st.session_state.chat_history = (
            st.session_state.chat_history[-MAX_HISTORY_TURNS:]
        )

    # save to display messages
    st.session_state.messages.append({
        "role":    "assistant",
        "content": full_answer,
        "images":  referenced_images,
    })

    # activity log — Q&A row
    activity_log.log_qa(
        turn          = st.session_state.qa_turn,
        question      = question,
        answer        = full_answer,
        t_prompt      = stats.t_prompt_build,
        t_ttft        = stats.t_ttft,
        t_total       = stats.t_total,
        chars_per_sec = stats.chars_per_sec,
    )

    log.info(f"QA done | Turn {st.session_state.qa_turn} | {stats.summary}")
