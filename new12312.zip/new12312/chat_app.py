# ==================================================================
# Simple Qwen3.8-27B chat app (vLLM backend).
#   - No login, no database, no session saving. Opens straight to chat.
#   - Sampling settings are HARD-CODED below (not shown in the sidebar).
#   - Sidebar shows only: server status, Thinking toggle, Clear button.
#   - Accepts attachments:
#       * images / screenshots (png, jpg, ...) -> sent to the model as images
#       * code / text files (.py, .cpp, .txt, ...) -> pasted into the prompt
#   - Thinking (if on) goes into a collapsed expander; answer shows directly.
#
# Reach vLLM from your local machine via SSH tunnel, then run:
#   streamlit run chat_app.py
# ==================================================================
import json
from datetime import datetime
import base64
import requests
import streamlit as st

# ---- Connection (edit if needed) ---------------------------------
VLLM_HOST   = "localhost"       # keep "localhost" when using the SSH tunnel
VLLM_PORT   = 8000
MODEL_NAME  = "qwen38"          # must match --served-model-name on the server
BASE_URL    = f"http://{VLLM_HOST}:{VLLM_PORT}"
CHAT_URL    = f"{BASE_URL}/v1/chat/completions"
MODELS_URL  = f"{BASE_URL}/v1/models"

# ---- HARD-CODED sampling settings (change here, not in the UI) ---
MAX_TOKENS        = 4096        # max length of each reply
TEMP_THINKING     = 1.0         # temperature when Thinking is ON  (Qwen recommends ~1.0)
TEMP_DIRECT       = 0.7         # temperature when Thinking is OFF (Qwen recommends ~0.7)
TOP_P             = 0.95
TOP_K             = 20
SYSTEM_PROMPT = """You are an AI coding and technical assistant, finetuned by RCI (Research Centre Imarat). Your primary focus is providing coding assistance and technical information. The current date is {date}.

Key Guidelines:
1. Specialize in C++, C, Python, MATLAB, VHDL, Verilog, C-sharp, Java, Qt and more, with C++ as the default language.
2. You cannot execute code, access external resources, or modify files on a user's system.
3. When discussing language features or best practices, clarify which version or standard you're referring to (e.g., C++17, Python 3.8).
4. Strictly avoid engaging in general, non-technical discussions or topics outside your programming expertise.
5. If asked about non-technical topics, politely redirect the conversation back to programming, or suggest using the RCI general chatbot.

Code Generation and Explanation:
1. Use Markdown for formatting code snippets.
2. Provide complete, runnable code snippets when possible, avoiding pseudo-code unless specifically requested.
3. After generating code, offer to explain the code's functionality and design choices.
4. For complex algorithms or data structures, provide step-by-step explanations.
5. When applicable, mention potential optimizations or alternative approaches.

Language-Specific Guidelines:
1. C++: Use modern C++ features and idioms by default (C++11 and later). Prefer standard library components when appropriate.
2. C: Follow ANSI C standards unless otherwise specified. Emphasize memory management and pointer safety.
3. Python: Use Python 3.x syntax and features. Adhere to PEP 8 style guidelines.
4. MATLAB: Focus on vectorization and efficient matrix operations.
5. VHDL: Follow IEEE standard syntax. Emphasize synthesizable constructs.
6. Verilog: Use IEEE 1364 standard syntax. Focus on synthesizable code.

Response Style:
1. Provide concise, to-the-point answers for straightforward questions.
2. For complex problems, offer detailed explanations and multiple approaches when relevant.
3. Proactively suggest best practices, potential pitfalls, and performance considerations.
4. Ask clarifying questions when the user's intent or requirements are ambiguous.
""".format(date=datetime.now().strftime("%d %B, %Y"))
# ------------------------------------------------------------------

# File types the uploader accepts
IMAGE_EXTS = {"png", "jpg", "jpeg", "gif", "webp", "bmp"}
CODE_EXTS  = {"py", "txt", "md", "json", "csv", "c", "cpp", "h", "hpp", "cc",
              "java", "js", "ts", "html", "css", "xml", "yaml", "yml", "sh",
              "sql", "m", "vhd", "v", "go", "rs", "rb", "php", "ini", "cfg", "log"}
ALL_EXTS = sorted(IMAGE_EXTS | CODE_EXTS)

st.set_page_config(page_title="Qwen3.8 Chat", page_icon="\U0001F916", layout="wide")


# ---- Helpers ------------------------------------------------------
def server_online() -> bool:
    try:
        return requests.get(MODELS_URL, timeout=3).status_code == 200
    except Exception:
        return False


def split_thinking(reasoning_field: str, content_field: str):
    """Return (thinking, answer). Works whether the server splits reasoning into
    its own field, or glues it inside the answer as <think>...</think>."""
    thinking = reasoning_field or ""
    answer   = content_field or ""
    if "<think>" in answer or "</think>" in answer:
        if "</think>" in answer:
            before, after = answer.split("</think>", 1)
            thinking = (thinking + before.replace("<think>", "")).strip()
            answer   = after.strip()
        else:
            thinking = (thinking + answer.replace("<think>", "")).strip()
            answer   = ""
    return thinking, answer


def ext_of(filename: str) -> str:
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def build_user_content(text: str, attachments):
    """
    Build the OpenAI 'content' for a user turn.
    - code/text files are appended to the text as fenced code blocks
    - images become image_url parts (base64 data URLs, offline-safe)
    Returns (api_content, images_for_history, code_names).
    api_content is a plain string if there are no images, else a list of parts.
    """
    code_names, image_data_urls = [], []
    full_text = text or ""

    for f in attachments or []:
        ext = ext_of(f.name)
        raw = f.getvalue()
        if ext in IMAGE_EXTS:
            mime = f.type or f"image/{'jpeg' if ext in ('jpg','jpeg') else ext}"
            b64  = base64.b64encode(raw).decode("utf-8")
            image_data_urls.append(f"data:{mime};base64,{b64}")
        else:  # treat everything else as text/code
            try:
                code = raw.decode("utf-8", errors="replace")
            except Exception:
                code = "<could not decode file as text>"
            code_names.append(f.name)
            full_text += f"\n\n--- File: {f.name} ---\n```{ext}\n{code}\n```"

    if image_data_urls:
        parts = [{"type": "text", "text": full_text}]
        for du in image_data_urls:
            parts.append({"type": "image_url", "image_url": {"url": du}})
        return parts, image_data_urls, code_names
    return full_text, image_data_urls, code_names


def history_to_api(messages):
    """Convert stored history into OpenAI messages (re-attaching images)."""
    api = [{"role": "system", "content": SYSTEM_PROMPT}]
    for m in messages:
        if m["role"] == "user" and m.get("images"):
            parts = [{"type": "text", "text": m["content"]}]
            for du in m["images"]:
                parts.append({"type": "image_url", "image_url": {"url": du}})
            api.append({"role": "user", "content": parts})
        else:
            api.append({"role": m["role"], "content": m["content"]})
    return api


def stream_reply(api_messages, temperature):
    payload = {
        "model": MODEL_NAME, "messages": api_messages,
        "max_tokens": MAX_TOKENS, "temperature": temperature,
        "top_p": TOP_P, "top_k": TOP_K, "stream": True,
        "chat_template_kwargs": {"enable_thinking": st.session_state.enable_thinking},
    }
    with requests.post(
        CHAT_URL,
        headers={"Content-Type": "application/json", "Authorization": "Bearer EMPTY"},
        data=json.dumps(payload), stream=True, timeout=600,
    ) as resp:
        resp.raise_for_status()
        for raw in resp.iter_lines():
            if not raw:
                continue
            line = raw.decode("utf-8")
            if not line.startswith("data: "):
                continue
            data = line[len("data: "):]
            if data.strip() == "[DONE]":
                break
            try:
                delta = json.loads(data)["choices"][0]["delta"]
            except Exception:
                continue
            yield delta.get("reasoning_content") or "", delta.get("content") or ""


# ---- Session state ------------------------------------------------
if "messages" not in st.session_state:
    st.session_state.messages = []           # {role, content, images?, reasoning?}
if "enable_thinking" not in st.session_state:
    st.session_state.enable_thinking = True
if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0        # bumped to clear the uploader after send

# ---- Sidebar ------------------------------------------------------
with st.sidebar:
    st.header("Settings")
    st.caption(f"Server: {BASE_URL}")
    if server_online():
        st.success("vLLM server: online")
    else:
        st.error("vLLM server: unreachable")

    st.session_state.enable_thinking = st.toggle(
        "Thinking mode", value=st.session_state.enable_thinking,
        help="Off = faster, direct answers. On = model reasons first.")

    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.session_state.uploader_key += 1
        st.rerun()

# ---- Main ---------------------------------------------------------
st.title("\U0001F916 Qwen3.8-27B Chat")

# attachments (images + code/text files); key bumps to clear after each send
attachments = st.file_uploader(
    "Attach images or code files (optional)",
    type=ALL_EXTS, accept_multiple_files=True,
    key=f"uploader_{st.session_state.uploader_key}",
)

# render history
for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        if m.get("reasoning"):
            with st.expander("Thinking"):           # collapsed by default
                st.markdown(m["reasoning"])
        st.markdown(m["content"])
        for du in m.get("images", []):
            st.image(du, width=280)

user_input = st.chat_input("Type your message...")

if user_input is not None and (user_input.strip() or attachments):
    api_content, imgs, code_names = build_user_content(user_input, attachments)

    # what we show in the chat for the user's turn
    shown = user_input or ""
    if code_names:
        shown += ("\n\n" if shown else "") + "📎 " + ", ".join(code_names)
    st.session_state.messages.append(
        {"role": "user", "content": shown or "📎 (attachment)", "images": imgs})

    with st.chat_message("user"):
        st.markdown(shown or "*(attachment only)*")
        for du in imgs:
            st.image(du, width=280)

    # build the API request from full history (last user turn carries attachments)
    api_messages = history_to_api(st.session_state.messages[:-1])
    api_messages.append({"role": "user", "content": api_content})

    temperature = TEMP_THINKING if st.session_state.enable_thinking else TEMP_DIRECT

    with st.chat_message("assistant"):
        think_holder = st.empty()
        answer_slot  = st.empty()
        reasoning_field, content_field = "", ""
        thinking, answer = "", ""

        def render_thinking(text, open_):
            """Show reasoning in the expander. open_=True while generating
            (watch it think live); open_=False collapses it once done."""
            if text:
                with think_holder.container():
                    with st.expander("Thinking", expanded=open_):
                        st.markdown(text)

        try:
            for r_delta, c_delta in stream_reply(api_messages, temperature):
                reasoning_field += r_delta
                content_field   += c_delta
                thinking, answer = split_thinking(reasoning_field, content_field)
                render_thinking(thinking, True)          # LIVE: stream reasoning, expanded
                if answer:
                    answer_slot.markdown(answer + "▌")
            answer_slot.markdown(answer if answer else "*(no answer returned)*")
            render_thinking(thinking, False)             # collapse once the answer is done
        except requests.exceptions.ConnectionError:
            answer = "Cannot reach the vLLM server. Is the job running and the tunnel open?"
            answer_slot.markdown(answer)
        except requests.exceptions.Timeout:
            answer = "Request timed out. The model may still be loading."
            answer_slot.markdown(answer)
        except Exception as e:
            answer = f"Error: {e}"
            answer_slot.markdown(answer)

    st.session_state.messages.append(
        {"role": "assistant", "content": answer, "reasoning": thinking})

    # clear the uploader for the next message
    st.session_state.uploader_key += 1
    st.rerun()
