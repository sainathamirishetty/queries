"""
ollama_client_sync.py
─────────────────────────────────────────────────────────────
Synchronous streaming client for Gemma 4 E4B (vision model).

Changes in this version:

1. TOKEN COUNTING in build_prompt()
   - Prompt token count is estimated before sending to Ollama.
   - If the prompt exceeds the safe token budget, conversation
     history is trimmed first (safest thing to drop — document
     text is never trimmed).
   - A warning is logged and shown if the prompt is dangerously large.

2. PROXIMITY-AWARE CLASSIFICATION in classify_question_type()
   - Before deciding image/table/text mode, the classifier now
     finds where in the document the answer likely lives, then
     checks what's physically present near that region.
   - A question with no image keywords will still trigger image
     mode if an [Image N appears here] marker sits near the
     relevant document section.
   - A question with no table keywords will still trigger table
     mode if a pipe-table exists near the relevant section.
   - Keyword-only classification is kept as a first pass;
     proximity is a second pass that can upgrade the mode.

3. EasyOCR singleton note
   - EasyOCR singleton fix is in extractor.py (not here).
   - This file is unchanged regarding OCR.
─────────────────────────────────────────────────────────────
"""

import base64
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Generator, List, Optional, Tuple

import requests

from config import (
    IMAGE_CONTEXT_WINDOW,
    IMAGE_MIN_SCORE,
    MAX_HISTORY_TURNS,
    MAX_IMAGES_PER_QUERY,
    OLLAMA_HOST,
    OLLAMA_MODEL,
    OLLAMA_TIMEOUT,
)
from logger import get_logger

log = get_logger("ollama")


# ─────────────────────────────────────────────────────────────
# Token budget constants
# ─────────────────────────────────────────────────────────────

# Gemma4 E4B context window set in stream_response payload
_CTX_WINDOW = 128_000

# Reserve this many tokens for the model's answer
_ANSWER_RESERVE = 2_000

# Maximum tokens the prompt is allowed to consume
_MAX_PROMPT_TOKENS = _CTX_WINDOW - _ANSWER_RESERVE  # 126,000

# Warn (but still proceed) if prompt exceeds this fraction of budget
_WARN_THRESHOLD = 0.85  # warn at 85% = ~107,100 tokens


# ─────────────────────────────────────────────────────────────
# Token estimation
# ─────────────────────────────────────────────────────────────

def _estimate_tokens(text: str) -> int:
    """
    Fast token count estimate without a tokenizer.

    Rule of thumb for English text: ~4 characters per token.
    This is consistent with GPT/Gemma tokeniser empirical averages.
    We use characters / 3.5 to be slightly conservative (safer).

    For exact counting you'd use the model's actual tokeniser, but
    that requires loading a heavy dependency. This estimate is
    accurate enough for budget management — within ~10-15% of true
    token count, which is sufficient for our guard.
    """
    return max(1, int(len(text) / 3.5))


# ─────────────────────────────────────────────────────────────
# Generation stats
# ─────────────────────────────────────────────────────────────

@dataclass
class GenerationStats:
    t_prompt_build:  float = 0.0
    t_ttft:          float = 0.0
    t_total:         float = 0.0
    chars_generated: int   = 0
    prompt_tokens:   int   = 0   # estimated token count of the prompt

    @property
    def chars_per_sec(self) -> float:
        return self.chars_generated / self.t_total if self.t_total > 0 else 0.0

    @property
    def summary(self) -> str:
        return (
            f"Prompt build: {self.t_prompt_build:.3f}s | "
            f"TTFT: {self.t_ttft:.2f}s | "
            f"Total: {self.t_total:.2f}s | "
            f"Chars: {self.chars_generated} | "
            f"Speed: {self.chars_per_sec:.1f} chars/s | "
            f"Est. prompt tokens: {self.prompt_tokens:,}"
        )


# ─────────────────────────────────────────────────────────────
# Question classifier
# ─────────────────────────────────────────────────────────────

@dataclass
class QuestionType:
    mode:        str = "text"   # "image" | "table" | "text"
    extra_instr: str = ""

    @property
    def is_image(self) -> bool:
        return self.mode == "image"

    @property
    def is_table(self) -> bool:
        return self.mode == "table"

    @property
    def is_text(self) -> bool:
        return self.mode == "text"


# Keywords that signal the user wants to look at a visual element
_IMAGE_TRIGGERS = frozenset([
    "chart", "graph", "diagram", "plot", "figure", "image",
    "picture", "visual", "bar", "pie", "trend", "growth",
    "comparison", "show me", "what does", "describe the",
    "color", "colour", "shape", "icon", "logo", "photo",
    "screenshot", "illustration", "look like", "depicted",
    "drawn", "plotted", "displayed", "shown",
])

# Keywords that signal structured / tabular data questions
_TABLE_TRIGGERS = frozenset([
    "table", "row", "column", "cell", "header",
    "list", "entry", "entries", "record", "records",
    "tabular", "grid",
    "how many", "which", "compare", "total", "average",
    "maximum", "minimum", "highest", "lowest", "sum",
    "breakdown", "per", "each", "count", "rank",
    "sorted", "ordered", "top", "bottom",
])

# Explicit reference: "figure 2", "fig.3", "image 4", "chart 1"
_EXPLICIT_REF_RE = re.compile(
    r"(?:image|figure|fig|graph|chart)\s*\.?\s*(\d+)",
    re.IGNORECASE,
)

# Stop words for keyword extraction
_STOP_WORDS = frozenset([
    "the", "a", "an", "in", "on", "at", "what", "how", "is", "are",
    "was", "were", "does", "did", "can", "could", "would", "from",
    "with", "about", "this", "that", "for", "to", "of", "and", "or",
    "me", "my", "your", "its", "show", "tell", "give", "find", "get",
])


# ─────────────────────────────────────────────────────────────
# Proximity helpers
# ─────────────────────────────────────────────────────────────

# How many characters around the best-matching region to inspect
_PROXIMITY_WINDOW = 1500


def _extract_keywords(question: str) -> List[str]:
    """Extract meaningful keywords from the question for region search."""
    return [
        w.strip(".,?!:;\"'")
        for w in question.lower().split()
        if len(w) > 3 and w.strip(".,?!:;\"'") not in _STOP_WORDS
    ]


def _find_answer_region(question: str, extracted_text: str) -> Tuple[int, int]:
    """
    Slide a window over the document and find the region with the highest
    keyword overlap with the question.

    Returns (start, end) character positions of the best-matching region.
    Falls back to (0, min(len, PROXIMITY_WINDOW)) if no keywords match.
    """
    keywords = _extract_keywords(question)
    if not keywords or not extracted_text:
        end = min(len(extracted_text), _PROXIMITY_WINDOW)
        return 0, end

    text_lower  = extracted_text.lower()
    text_len    = len(text_lower)
    step        = 300   # slide step in chars
    window      = _PROXIMITY_WINDOW

    best_pos   = 0
    best_score = 0

    for i in range(0, max(1, text_len - window), step):
        chunk = text_lower[i : i + window]
        score = sum(1 for kw in keywords if kw in chunk)
        if score > best_score:
            best_score = score
            best_pos   = i

    # Expand slightly around best position
    start = max(0, best_pos - 200)
    end   = min(text_len, best_pos + window + 200)

    log.debug(
        f"[Proximity] best_score={best_score} region=[{start}:{end}] "
        f"keywords={keywords[:5]}"
    )
    return start, end


def _nearby_image_numbers(extracted_text: str, start: int, end: int) -> List[int]:
    """
    Return image numbers whose [Image N appears here] markers fall
    within the character region [start:end] of the document.
    """
    region = extracted_text[start:end]
    return [
        int(m.group(1))
        for m in re.finditer(r"\[Image (\d+) appears here\]", region, re.IGNORECASE)
    ]


def _nearby_has_table(extracted_text: str, start: int, end: int) -> bool:
    """
    Return True if a pipe-format markdown table exists within [start:end].
    A table separator row (|---|---|) is the definitive signal.
    """
    region = extracted_text[start:end]
    return bool(re.search(r"^\|[-| :]+\|$", region, re.MULTILINE))


# ─────────────────────────────────────────────────────────────
# Classifier (keyword-first + proximity upgrade)
# ─────────────────────────────────────────────────────────────

def classify_question_type(
    question:       str,
    image_map:      Dict[int, str],
    extracted_text: str = "",        # NEW — needed for proximity check
) -> QuestionType:
    """
    Classify question as image / table / text.

    Two-pass strategy:
      Pass 1 — keyword + explicit reference (fast, handles obvious cases)
      Pass 2 — proximity check in document (catches cases where the question
                has no visual keywords but the answer region contains an
                image marker or a table)

    Priority: explicit figure reference → image keywords → proximity image
              → table keywords → proximity table → text.
    """
    q = question.lower()

    has_explicit = bool(_EXPLICIT_REF_RE.search(q))
    has_img_kw   = any(kw in q for kw in _IMAGE_TRIGGERS)
    has_images   = bool(image_map)

    # ── Pass 1: keyword / explicit ────────────────────────────
    if has_images and (has_explicit or has_img_kw):
        log.info(f"[Classifier] IMAGE (keyword) explicit={has_explicit} kw={has_img_kw}")
        return QuestionType(
            mode="image",
            extra_instr=_IMAGE_INSTRUCTIONS,
        )

    has_tbl_kw = any(kw in q for kw in _TABLE_TRIGGERS)
    if has_tbl_kw:
        log.info(f"[Classifier] TABLE (keyword)")
        return QuestionType(
            mode="table",
            extra_instr=_TABLE_INSTRUCTIONS,
        )

    # ── Pass 2: proximity check ───────────────────────────────
    # Only runs if we have document text to search
    if extracted_text:
        region_start, region_end = _find_answer_region(question, extracted_text)

        # Check for images near the answer region
        if has_images:
            nearby_imgs = _nearby_image_numbers(extracted_text, region_start, region_end)
            if nearby_imgs:
                log.info(
                    f"[Classifier] IMAGE (proximity) — images {nearby_imgs} "
                    f"found near answer region [{region_start}:{region_end}]"
                )
                return QuestionType(
                    mode="image",
                    extra_instr=_IMAGE_INSTRUCTIONS,
                )

        # Check for tables near the answer region
        if _nearby_has_table(extracted_text, region_start, region_end):
            log.info(
                f"[Classifier] TABLE (proximity) — table found near "
                f"answer region [{region_start}:{region_end}]"
            )
            return QuestionType(
                mode="table",
                extra_instr=_TABLE_INSTRUCTIONS,
            )

    log.info("[Classifier] TEXT (default)")
    return QuestionType(mode="text", extra_instr="")


# Instruction blocks as constants — cleaner than inline strings
_IMAGE_INSTRUCTIONS = (
    "VISUAL QUESTION INSTRUCTIONS:\n"
    "- You have been given image(s) from this document as attachments.\n"
    "- Study every image carefully: read axis labels, legends, titles,\n"
    "  data labels, and all visible text inside the image.\n"
    "- Quote specific numbers or labels you can actually see.\n"
    "- Describe trends, highs, lows, and patterns clearly.\n"
    "- When you refer to an image write: See Image N\n"
    "  (where N is the image number).\n"
    "- Only report what is clearly visible — do NOT guess.\n"
)

_TABLE_INSTRUCTIONS = (
    "TABLE QUESTION INSTRUCTIONS:\n"
    "- Tables in this document are formatted with pipe characters (|).\n"
    "- Locate the correct table by its column headers.\n"
    "- Read every row carefully — do not skip rows.\n"
    "- Quote exact cell values — never round or paraphrase numbers.\n"
    "- If multiple rows match, list each one.\n"
    "- If a cell is empty, say 'not available'.\n"
    "- Reproduce the relevant rows in your answer for clarity.\n"
)


# ─────────────────────────────────────────────────────────────
# Image encoding
# ─────────────────────────────────────────────────────────────

def encode_image_to_base64(image_path: str) -> str:
    try:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    except Exception as exc:
        log.error(f"Failed to encode image {image_path}: {exc}")
        return ""


# ─────────────────────────────────────────────────────────────
# 6-Strategy image selector
# ─────────────────────────────────────────────────────────────

_VISUAL_KW = frozenset([
    "chart", "graph", "diagram", "plot", "figure", "image",
    "visual", "trend", "growth", "comparison", "color", "colour",
    "shape", "shown", "displayed", "drawn",
])

_DATA_KW = frozenset([
    "value", "number", "percentage", "amount", "total",
    "revenue", "profit", "sales", "cost", "price", "rate",
    "increase", "decrease", "compare", "difference",
    "average", "maximum", "minimum", "highest", "lowest",
])


def find_referenced_images(
    question:        str,
    extracted_text:  str,
    image_map:       Dict[int, str],
    priority_images: Optional[List[int]] = None,  # NEW — from proximity classifier
) -> List[str]:
    """
    Select the most relevant images for this question.
    Returns a list of base64-encoded image strings.

    priority_images: image numbers found by the proximity classifier.
    These are tried first (before the 5-strategy cascade).

    Strategy order (stops at first non-empty result):
      0. Proximity priority   — image numbers from proximity classifier
      1. Explicit reference   — "figure 2", "image 3"
      2. Context matching     — keyword scoring around [Image N] markers
      3. Visual-intent fallback   — visual keywords + small image set
      4. Data-question fallback   — numeric/stats keywords + small image set
      5. Final safety net         — ≤2 images in doc → send all
    """
    if not image_map:
        return []

    q_lower    = question.lower()
    result_b64 : List[str] = []
    used_nums  : set       = set()

    def _load(num: int) -> Optional[str]:
        if num in used_nums:
            return None
        path = image_map.get(num, "")
        if not path or not Path(path).exists():
            return None
        b64 = encode_image_to_base64(path)
        if b64:
            used_nums.add(num)
            return b64
        return None

    # ── Strategy 0: Proximity priority ───────────────────────
    if priority_images:
        for num in priority_images:
            b64 = _load(num)
            if b64:
                result_b64.append(b64)
                log.info(f"[IMG] S0 proximity → image {num}")
        if result_b64:
            return result_b64[:MAX_IMAGES_PER_QUERY]

    # ── Strategy 1: Explicit reference ───────────────────────
    for num_str in _EXPLICIT_REF_RE.findall(q_lower):
        num = int(num_str)
        b64 = _load(num)
        if b64:
            result_b64.append(b64)
            log.info(f"[IMG] S1 explicit → image {num}")

    if result_b64:
        return result_b64[:MAX_IMAGES_PER_QUERY]

    # ── Prepare keywords for strategies 2-4 ──────────────────
    keywords = [
        w.strip(".,?!") for w in q_lower.split()
        if len(w) > 3 and w not in _STOP_WORDS
    ]

    # ── Strategy 2: Scored context matching ──────────────────
    scored: List[Tuple[int, int]] = []   # (score, img_num)

    for img_num in sorted(image_map.keys()):
        patterns = [
            rf"\[Image {img_num} appears here\]",
            rf"<<IMAGE_{img_num}>>",
        ]
        best_score = 0
        for pat in patterns:
            for match in re.finditer(pat, extracted_text, re.IGNORECASE):
                pos   = match.start()
                ctx_s = max(0, pos - IMAGE_CONTEXT_WINDOW)
                ctx_e = min(len(extracted_text), pos + IMAGE_CONTEXT_WINDOW)
                ctx   = extracted_text[ctx_s:ctx_e].lower()
                score = sum(1 for kw in keywords if kw in ctx.split())
                best_score = max(best_score, score)

        if best_score >= IMAGE_MIN_SCORE:
            scored.append((best_score, img_num))

    scored.sort(reverse=True)
    for _, img_num in scored[:3]:
        b64 = _load(img_num)
        if b64:
            result_b64.append(b64)
            log.info(f"[IMG] S2 context → image {img_num}")

    if result_b64:
        return result_b64[:MAX_IMAGES_PER_QUERY]

    # ── Strategy 3: Visual-intent fallback ───────────────────
    if any(vk in q_lower for vk in _VISUAL_KW) and len(image_map) <= MAX_IMAGES_PER_QUERY:
        log.info("[IMG] S3 visual fallback → all images")
        for num in sorted(image_map.keys()):
            b64 = _load(num)
            if b64:
                result_b64.append(b64)
        if result_b64:
            return result_b64

    # ── Strategy 4: Data-question fallback ───────────────────
    if any(dk in q_lower for dk in _DATA_KW) and len(image_map) <= MAX_IMAGES_PER_QUERY:
        log.info("[IMG] S4 data fallback → all images")
        for num in sorted(image_map.keys()):
            b64 = _load(num)
            if b64:
                result_b64.append(b64)
        if result_b64:
            return result_b64

    # ── Strategy 5: Final safety net ─────────────────────────
    if len(image_map) <= 2:
        log.info("[IMG] S5 safety net → ≤2 images")
        for num in sorted(image_map.keys())[:2]:
            b64 = _load(num)
            if b64:
                result_b64.append(b64)

    return result_b64[:MAX_IMAGES_PER_QUERY]


# ─────────────────────────────────────────────────────────────
# Prompt builder — with token counting and history trimming
# ─────────────────────────────────────────────────────────────

def _build_history_block(chat_history: list, max_turns: int) -> str:
    """Build the conversation history block from the most recent N turns."""
    if not chat_history:
        return ""
    lines = []
    for turn in chat_history[-max_turns:]:
        lines.append(f"User: {turn['question']}")
        lines.append(f"Assistant: {turn['answer']}")
        lines.append("")
    return (
        "\n\nCONVERSATION HISTORY (most recent last):\n"
        + "\n".join(lines)
    )


def build_prompt(
    extracted_text: str,
    chat_history:   list,
    question:       str,
    image_map:      Dict[int, str],
) -> Tuple[str, List[str], float, QuestionType]:
    """
    Classify the question, select images if needed, build the full prompt.
    Enforces token budget — trims history if prompt would overflow context.

    Returns:
        prompt        (str)          — complete prompt text for Ollama
        images_b64    (List[str])    — base64 images to attach (empty for text/table)
        build_time    (float)        — seconds taken to build
        qtype         (QuestionType) — mode + extra instructions used
    """
    t0 = time.perf_counter()

    # 1. Classify — now passes extracted_text for proximity check
    qtype = classify_question_type(question, image_map, extracted_text)

    # 2. Select images (only for image questions)
    images_b64:    List[str]        = []
    priority_imgs: Optional[List[int]] = None

    if qtype.is_image:
        # If proximity classified this as image, find which images are nearby
        if extracted_text:
            start, end    = _find_answer_region(question, extracted_text)
            priority_imgs = _nearby_image_numbers(extracted_text, start, end) or None

        images_b64 = find_referenced_images(
            question, extracted_text, image_map, priority_images=priority_imgs
        )

    # 3. Static prompt parts (don't change with history trimming)
    vision_note = ""
    if images_b64:
        vision_note = (
            f"\n• You have been given {len(images_b64)} image(s) from this document."
            "\n• Study the image(s) carefully before answering."
            "\n• Refer to images as: See Image N"
        )

    extra_block = f"\n{qtype.extra_instr}\n" if qtype.extra_instr else ""

    system_block = (
        "You are a helpful, precise document assistant with vision capabilities.\n\n"
        "GENERAL INSTRUCTIONS:\n"
        "- Answer only from the document content provided below.\n"
        "- Page markers in the document: <!-- Page 1 -->, <!-- Page 2 --> etc.\n"
        "- Always end your answer with: 📌 Source: Page <number>, <Section>\n"
        "- If the answer is not in the document: say exactly "
        "'I could not find this information in the document.'\n"
        "- Do NOT make up or guess any information."
        + vision_note + "\n"
        + extra_block
        + "═" * 60 + "\n"
        "DOCUMENT CONTENT:\n"
        + "═" * 60 + "\n"
        + extracted_text + "\n"
        + "═" * 60 + "\n"
    )

    question_block = (
        "\nCURRENT QUESTION:\n"
        + question
        + "\n\nANSWER:"
    )

    # 4. Token budget management
    # Count tokens for the fixed parts first
    fixed_tokens = _estimate_tokens(system_block + question_block)

    # Try full history first, then trim if needed
    history_turns = list(chat_history)  # copy so we don't mutate caller's list
    history_block = _build_history_block(history_turns, MAX_HISTORY_TURNS)
    total_tokens  = fixed_tokens + _estimate_tokens(history_block)

    # Trim history one turn at a time until we're within budget
    while total_tokens > _MAX_PROMPT_TOKENS and len(history_turns) > 0:
        history_turns = history_turns[1:]   # drop oldest turn
        history_block = _build_history_block(history_turns, MAX_HISTORY_TURNS)
        total_tokens  = fixed_tokens + _estimate_tokens(history_block)
        log.warning(
            f"[TokenBudget] Trimmed history to {len(history_turns)} turns | "
            f"est. tokens now: {total_tokens:,}"
        )

    # Even after clearing all history, if doc itself is too large → warn
    if total_tokens > _MAX_PROMPT_TOKENS:
        log.error(
            f"[TokenBudget] CRITICAL: Prompt ({total_tokens:,} est. tokens) "
            f"exceeds safe budget ({_MAX_PROMPT_TOKENS:,}). "
            f"Document text alone is too large. Answers may be truncated."
        )
    elif total_tokens > _MAX_PROMPT_TOKENS * _WARN_THRESHOLD:
        log.warning(
            f"[TokenBudget] Prompt is {total_tokens / _CTX_WINDOW * 100:.1f}% "
            f"of context window ({total_tokens:,} / {_CTX_WINDOW:,} est. tokens)."
        )

    # 5. Assemble final prompt
    prompt = system_block + history_block + question_block

    build_time = time.perf_counter() - t0

    log.info(
        f"[Prompt] mode={qtype.mode} | {len(prompt):,} chars | "
        f"~{total_tokens:,} tokens | {len(images_b64)} image(s) | "
        f"history={len(history_turns)} turns | build={build_time:.3f}s"
    )

    return prompt, images_b64, build_time, qtype


# ─────────────────────────────────────────────────────────────
# Streaming generator
# ─────────────────────────────────────────────────────────────

def stream_response(
    prompt: str,
    images: List[str],
    stats:  GenerationStats,
) -> Generator[str, None, None]:
    """
    Stream tokens from Ollama /api/generate.
    Passes images in the payload when provided (vision mode).
    Yields one token string at a time.
    """
    # Record estimated prompt token count in stats for logging
    stats.prompt_tokens = _estimate_tokens(prompt)

    payload = {
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": True,
        "options": {
            "num_ctx":     _CTX_WINDOW,
            "temperature": 0.1,
            "top_p":       0.9,
        },
    }
    if images:
        payload["images"] = images
        log.info(f"[Vision] {len(images)} image(s) → {OLLAMA_MODEL}")
    else:
        log.info("[Text] No images attached")

    t_start     = time.perf_counter()
    first_token = True

    with requests.post(
        f"{OLLAMA_HOST}/api/generate",
        json    = payload,
        stream  = True,
        timeout = OLLAMA_TIMEOUT,
    ) as resp:
        resp.raise_for_status()

        for raw in resp.iter_lines():
            if not raw:
                continue
            data  = json.loads(raw)
            token = data.get("response", "")

            if token:
                if first_token:
                    stats.t_ttft = time.perf_counter() - t_start
                    log.info(f"[QA] TTFT = {stats.t_ttft:.2f}s")
                    first_token  = False
                stats.chars_generated += len(token)
                yield token

            if data.get("done", False):
                break

    stats.t_total = time.perf_counter() - t_start


# ─────────────────────────────────────────────────────────────
# Connectivity check  (call via @st.cache_data in the app!)
# ─────────────────────────────────────────────────────────────

def check_ollama_connection() -> Tuple[bool, str]:
    """
    Ping Ollama and check the configured model is loaded.

    NOTE: Wrap this with @st.cache_data(ttl=60) in streamlit_app.py
    so it only fires once per minute, not on every rerender.
    """
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=10)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]

        if OLLAMA_MODEL in models:
            log.info(f"Ollama ✅  model={OLLAMA_MODEL}")
            return True, f"Connected — {len(models)} model(s) loaded"
        else:
            msg = f"Model '{OLLAMA_MODEL}' not found. Available: {models}"
            log.warning(msg)
            return False, msg

    except requests.exceptions.ConnectionError:
        msg = f"Cannot reach Ollama at {OLLAMA_HOST}"
        log.warning(msg)
        return False, msg
    except Exception as exc:
        return False, str(exc)
