"""
streamlit_app.py  —  DocQA
─────────────────────────────────────────────────────────────
Run with:
  streamlit run streamlit_app.py --server.address 0.0.0.0 --server.port 8000

Changes in this version:
  1. Token counting hidden from UI — runs silently in background.
     History trimming still happens automatically when needed.
  2. File uploader key fix — incrementing uploader_key on Clear
     Document forces Streamlit to destroy and recreate the widget,
     so the uploaded file is actually removed from the UI.
  3. Spinner shown during TTFT gap (between question submit and
     first token arriving) — user sees activity immediately.
  4. Streaming answer rendered token-by-token via st.write_stream().
─────────────────────────────────────────────────────────────
"""

import re
import uuid
import tempfile
from pathlib import Path

import streamlit as st

from config import SUPPORTED_EXTENSIONS, MAX_HISTORY_TURNS
from extractor import extract_document, cleanup_session_images
from ollama_client_sync import (
    build_prompt,
    check_ollama_connection,
    stream_response,
    GenerationStats,
)
from logger import get_logger, activity_log

log = get_logger("app")


# ── page config ───────────────────────────────────────────────

st.set_page_config(
    page_title = "DocQA",
    page_icon  = "📄",
    layout     = "wide",
)


# ── cached Ollama connection check ────────────────────────────

@st.cache_data(ttl=60, show_spinner=False)
def _cached_ollama_check() -> tuple:
    return check_ollama_connection()


# ── client IP ─────────────────────────────────────────────────

def _get_client_ip() -> str:
    try:
        headers = getattr(st.context, "headers", None)
        if headers:
            for key in ("x-forwarded-for", "x-real-ip", "remote-addr"):
                val = headers.get(key, "").split(",")[0].strip()
                if val:
                    return val
        import os
        return os.getenv("REMOTE_ADDR", "unknown")
    except Exception as exc:
        log.debug(f"IP detection: {exc}")
        return "unknown"


# ── session init ──────────────────────────────────────────────

def _init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = _get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        st.session_state.qa_turn    = 0
        activity_log.log_session_start(sid, ip)
        log.info(f"New session id={sid} ip={ip}")

    defaults = {
        "extracted_text":    None,
        "image_map":         {},
        "table_count":       0,
        "chat_history":      [],
        "messages":          [],
        "doc_name":          None,
        "doc_pages":         None,
        "doc_chars":         None,
        "doc_images":        0,
        "doc_tables":        0,
        "doc_scanned":       False,
        "md_saved_path":     None,
        "qa_turn":           0,
        "extraction_engine": None,
        "uploader_key":      0,     # incremented on Clear to reset file widget
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_session()


# ── helpers ───────────────────────────────────────────────────

_MODE_BADGE = {
    "image": "🖼️ Image question — vision mode",
    "table": "📊 Table question — structured mode",
    "text":  "📝 Text question",
}

_IMAGE_REF_RE = re.compile(r"(?:see\s+)?[Ii]mage\s+(\d+)", re.IGNORECASE)


def _render_referenced_images(answer_text: str, image_map: dict):
    """
    Parse LLM answer for 'Image N' references and render those images.
    Called after streaming completes so the full answer text is available.
    """
    rendered = []
    seen     = set()
    for m in _IMAGE_REF_RE.finditer(answer_text):
        n = int(m.group(1))
        if n not in seen and n in image_map:
            seen.add(n)
            img_path = image_map[n]
            if Path(img_path).exists():
                rendered.append(img_path)
                st.image(img_path, caption=f"Image {n}", width=700)
    return rendered


# ── sidebar ───────────────────────────────────────────────────

with st.sidebar:
    st.title("📄 DocQA")
    st.caption("Document Question Answering")
    st.divider()

    # Ollama status — re-checked at most once per minute
    ok, info = _cached_ollama_check()
    if ok:
        st.success("Ollama connected ✅")
        st.caption(info)
    else:
        st.error("Ollama not reachable ❌")
        st.caption(info)

    st.divider()

    # ── file uploader ──────────────────────────────────────────
    # key=f"uploader_{uploader_key}" — when uploader_key increments
    # (on Clear Document), Streamlit creates a brand-new empty widget.
    # This is the only reliable way to programmatically clear a
    # file_uploader in Streamlit.

    st.subheader("📂 Upload Document")
    st.caption("PDF · DOCX · TXT  |  Max 50 pages")

    uploaded_file = st.file_uploader(
        label            = "Choose a file",
        type             = SUPPORTED_EXTENSIONS,
        label_visibility = "collapsed",
        key              = f"uploader_{st.session_state.uploader_key}",
    )

    if uploaded_file is not None:
        if uploaded_file.name != st.session_state.doc_name:
            with st.spinner(f"Extracting {uploaded_file.name}…"):
                try:
                    suffix = Path(uploaded_file.name).suffix
                    tmp    = tempfile.NamedTemporaryFile(
                        delete=False, suffix=suffix
                    )
                    tmp.write(uploaded_file.read())
                    tmp.flush()
                    tmp.close()

                    res = extract_document(
                        file_path         = tmp.name,
                        file_ext          = suffix.lstrip("."),
                        session_id        = st.session_state.session_id,
                        original_filename = uploaded_file.name,
                    )

                    # Detect which extraction engine was used
                    try:
                        import marker  # noqa
                        engine = "Marker ✨"
                    except ImportError:
                        engine = "pdfplumber (fallback)"

                    st.session_state.extracted_text    = res.full_text
                    st.session_state.image_map         = res.image_map
                    st.session_state.table_count       = res.table_count
                    st.session_state.doc_name          = uploaded_file.name
                    st.session_state.doc_pages         = res.page_count
                    st.session_state.doc_chars         = len(res.full_text)
                    st.session_state.doc_images        = len(res.image_map)
                    st.session_state.doc_tables        = res.table_count
                    st.session_state.doc_scanned       = res.is_scanned
                    st.session_state.md_saved_path     = res.md_saved_path
                    st.session_state.chat_history      = []
                    st.session_state.messages          = []
                    st.session_state.qa_turn           = 0
                    st.session_state.extraction_engine = engine

                    activity_log.log_document(
                        filename = uploaded_file.name,
                        pages    = res.page_count,
                        chars    = len(res.full_text),
                        images   = len(res.image_map),
                        tables   = res.table_count,
                    )
                    activity_log.log_extraction_timing(
                        t_page_check = res.t_page_check,
                        t_text       = res.t_text_extraction,
                        t_images     = res.t_image_extraction,
                        t_total      = res.t_total,
                        t_tables     = res.t_table_extraction,
                    )

                    log.info(f"Extracted: {uploaded_file.name} | {res.summary}")
                    st.success("✅ Ready!")

                except ValueError as exc:
                    st.error(str(exc))
                    log.warning(str(exc))
                except Exception as exc:
                    st.error(f"Extraction error: {exc}")
                    log.exception(str(exc))

    st.divider()

    # ── document info panel ────────────────────────────────────
    if st.session_state.doc_name:
        st.subheader("📋 Document Info")
        st.markdown(f"**File:** {st.session_state.doc_name}")
        st.markdown(f"**Pages:** {st.session_state.doc_pages}")
        st.markdown(f"**Characters:** {st.session_state.doc_chars:,}")

        img_count = st.session_state.doc_images
        tbl_count = st.session_state.doc_tables
        st.markdown(f"**Images found:** {img_count}" + (" ✅" if img_count else ""))
        st.markdown(f"**Tables found:** {tbl_count}" + (" ✅" if tbl_count else ""))

        if st.session_state.extraction_engine:
            st.caption(f"🔧 Engine: {st.session_state.extraction_engine}")

        if st.session_state.doc_scanned:
            st.caption("🔍 Scanned PDF — OCR was used")
        else:
            st.caption("📝 Digital document")

        if st.session_state.md_saved_path:
            st.caption(f"💾 Saved: `{st.session_state.md_saved_path}`")

        st.divider()

        # ── Clear Document button ──────────────────────────────
        # Incrementing uploader_key forces Streamlit to destroy the
        # current file_uploader widget and create a fresh empty one.
        # Without this, the old file stays loaded after clear.
        if st.button("🗑️ Clear Document", use_container_width=True):
            st.session_state.uploader_key += 1   # ← key change = widget reset
            for k, v in {
                "extracted_text":    None,
                "image_map":         {},
                "table_count":       0,
                "doc_name":          None,
                "doc_pages":         None,
                "doc_chars":         None,
                "doc_images":        0,
                "doc_tables":        0,
                "doc_scanned":       False,
                "md_saved_path":     None,
                "chat_history":      [],
                "messages":          [],
                "qa_turn":           0,
                "extraction_engine": None,
            }.items():
                st.session_state[k] = v
            log.info("Document cleared by user")
            st.rerun()


# ── main chat area ────────────────────────────────────────────

st.title("💬 Ask Your Document")

if not st.session_state.extracted_text:
    st.info(
        "👈 Upload a **PDF**, **DOCX**, or **TXT** file from the sidebar.\n\n"
        "Ask any question — including questions about **images, charts, "
        "graphs, or tables** inside the document."
    )

# Render previous messages from session history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        if msg["role"] == "assistant" and msg.get("mode"):
            st.caption(_MODE_BADGE.get(msg["mode"], ""))
        st.markdown(msg["content"])
        for img_path in msg.get("images", []):
            if Path(img_path).exists():
                st.image(img_path, width=700)


# ── chat input ────────────────────────────────────────────────

question = st.chat_input(
    placeholder = "Ask about text, tables, charts, or images in your document…",
    disabled    = not st.session_state.extracted_text,
)

if question:
    log.info(f"Q: {question[:120]}")

    # Show user message immediately
    with st.chat_message("user"):
        st.markdown(question)
    st.session_state.messages.append({
        "role": "user", "content": question, "images": [], "mode": None,
    })

    # ── build prompt ───────────────────────────────────────────
    prompt, images_b64, t_prompt, qtype = build_prompt(
        extracted_text = st.session_state.extracted_text,
        chat_history   = st.session_state.chat_history,
        question       = question,
        image_map      = st.session_state.image_map,
    )
    stats = GenerationStats(t_prompt_build=t_prompt)

    log.info(
        f"Prompt: {len(prompt):,} chars | mode={qtype.mode} | "
        f"{len(images_b64)} image(s) | build={t_prompt:.3f}s"
    )

    # ── stream answer ──────────────────────────────────────────
    #
    # What happens step by step:
    #
    # 1. Assistant chat bubble opens immediately after user submits.
    #
    # 2. Mode badge shown — tells user what type of question was detected.
    #
    # 3. st.spinner("Thinking…") activates — covers the TTFT gap.
    #    TTFT (Time To First Token) is the delay between sending the full
    #    prompt to Ollama and receiving the very first token back.
    #    On local hardware this is typically 2–10 seconds depending on
    #    model size and prompt length. Without this spinner the UI looks
    #    completely frozen during this gap — user thinks it crashed.
    #    The spinner runs INSIDE the assistant bubble, right below the
    #    mode badge, so it feels like the assistant is "thinking".
    #
    # 4. st.write_stream() receives the generator from stream_response().
    #    As each token arrives from Ollama, write_stream() renders it
    #    directly to the UI — one token at a time, live typing effect.
    #    The spinner disappears the moment the first token renders.
    #    write_stream() returns the full concatenated answer string
    #    when the generator is exhausted (Ollama sends done=True).
    #
    # 5. After streaming completes, _render_referenced_images() parses
    #    the full answer for "Image N" references and renders them below.

    full_answer       = ""
    referenced_images = []

    with st.chat_message("assistant"):
        st.caption(_MODE_BADGE.get(qtype.mode, ""))

        with st.spinner("Thinking…"):
            try:
                full_answer = st.write_stream(
                    stream_response(prompt, images_b64, stats)
                )
            except Exception as exc:
                full_answer = (
                    f"❌ Ollama error: `{exc}`\n\n"
                    "Check Ollama is running and OLLAMA_HOST in config.py is correct."
                )
                st.error(full_answer)
                log.error(f"Ollama error: {exc}")

        # Render images referenced in the answer — after streaming done
        if st.session_state.image_map:
            referenced_images = _render_referenced_images(
                full_answer, st.session_state.image_map
            )

    # ── update session state ───────────────────────────────────
    st.session_state.qa_turn += 1
    st.session_state.chat_history.append({
        "question": question,
        "answer":   full_answer,
    })
    if len(st.session_state.chat_history) > MAX_HISTORY_TURNS:
        st.session_state.chat_history = (
            st.session_state.chat_history[-MAX_HISTORY_TURNS:]
        )

    st.session_state.messages.append({
        "role":    "assistant",
        "content": full_answer,
        "images":  referenced_images,
        "mode":    qtype.mode,
    })

    # ── activity log ───────────────────────────────────────────
    activity_log.log_qa(
        turn          = st.session_state.qa_turn,
        question      = question,
        answer        = full_answer,
        t_prompt      = stats.t_prompt_build,
        t_ttft        = stats.t_ttft,
        t_total       = stats.t_total,
        chars_per_sec = stats.chars_per_sec,
        question_type = qtype.mode,
        images_sent   = len(images_b64),
    )

    log.info(
        f"QA done | Turn {st.session_state.qa_turn} | "
        f"mode={qtype.mode} | {stats.summary}"
    )
