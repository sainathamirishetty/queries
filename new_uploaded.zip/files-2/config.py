# config.py
# ─────────────────────────────────────────────────────────────
#  Single source of truth for all settings
# ─────────────────────────────────────────────────────────────

# ── Ollama ────────────────────────────────────────────────────
OLLAMA_HOST    = "http://localhost:12345"   # ← change to your server
OLLAMA_MODEL   = "gemma4:e4b"              # ← Vision-enabled multimodal model
OLLAMA_TIMEOUT = 300                        # seconds

# ── Document limits ───────────────────────────────────────────
MAX_PAGES            = 50
MAX_HISTORY_TURNS    = 10
WORDS_PER_PAGE       = 500
SUPPORTED_EXTENSIONS = ["pdf", "docx", "txt"]

# ── Storage paths ─────────────────────────────────────────────
EXTRACTED_DOCS_DIR = "extracted_docs"

# ── OCR settings ─────────────────────────────────────────────
# Pages with fewer chars than this → treated as scanned → OCR
SCANNED_TEXT_THRESHOLD = 50

# ── Image QA ─────────────────────────────────────────────────
MAX_IMAGES_PER_QUERY = 5        # cap per question
IMAGE_CONTEXT_WINDOW = 500      # chars around <<IMAGE_N>> for keyword scoring
IMAGE_MIN_SCORE      = 1        # minimum keyword score to include an image

# ── Logging ───────────────────────────────────────────────────
LOG_DIR = "logs"
