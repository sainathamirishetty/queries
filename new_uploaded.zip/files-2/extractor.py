"""
extractor.py
─────────────────────────────────────────────────────────────
Document extraction pipeline for DocQA.

Supports:
  • PDF  — pdfplumber for digital text + tables (→ markdown)
           EasyOCR fallback for scanned pages
  • DOCX — python-docx for paragraphs + tables (→ markdown)
  • TXT  — plain UTF-8 read

Key design: tables are converted to pipe-formatted markdown so
the LLM can read them natively. Images are saved to disk and
referenced as <<IMAGE_N>> markers inside the extracted text,
which tells the LLM where each image appears in the document.
─────────────────────────────────────────────────────────────
"""

import io
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from config import (
    EXTRACTED_DOCS_DIR,
    MAX_PAGES,
    SCANNED_TEXT_THRESHOLD,
)
from logger import get_logger

log = get_logger("extractor")


# ── result dataclass ──────────────────────────────────────────

@dataclass
class ExtractionResult:
    full_text:           str              = ""
    image_map:           Dict[int, str]   = field(default_factory=dict)
    table_count:         int              = 0
    page_count:          int              = 0
    is_scanned:          bool             = False
    md_saved_path:       Optional[str]    = None
    t_page_check:        float            = 0.0
    t_text_extraction:   float            = 0.0
    t_image_extraction:  float            = 0.0
    t_table_extraction:  float            = 0.0
    t_total:             float            = 0.0

    @property
    def summary(self) -> str:
        return (
            f"Pages: {self.page_count} | Chars: {len(self.full_text):,} | "
            f"Images: {len(self.image_map)} | Tables: {self.table_count} | "
            f"Scanned: {self.is_scanned} | Total: {self.t_total:.2f}s"
        )


# ── shared helpers ────────────────────────────────────────────

def _make_output_dir(original_filename: str) -> Path:
    date_str  = datetime.now().strftime("%Y-%m-%d")
    stem      = Path(original_filename).stem
    safe_stem = re.sub(r"[^\w\-]", "_", stem)[:60]
    out_dir   = Path(EXTRACTED_DOCS_DIR) / date_str / safe_stem
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def _table_to_markdown(table: List[List]) -> str:
    """
    Convert a list-of-rows table to GitHub-Flavoured Markdown pipe format.

    Input:  [["Name","Score"], ["Alice","95"], ["Bob","82"]]
    Output:
        | Name  | Score |
        |-------|-------|
        | Alice | 95    |
        | Bob   | 82    |
    """
    if not table or not table[0]:
        return ""

    # Normalise: stringify cells, drop fully-empty rows
    rows = []
    for row in table:
        normalised = [str(c).strip() if c is not None else "" for c in row]
        if any(normalised):       # skip all-empty rows
            rows.append(normalised)

    if not rows:
        return ""

    col_count = max(len(r) for r in rows)
    # Pad short rows to same width
    rows = [r + [""] * (col_count - len(r)) for r in rows]

    col_widths = [
        max(max(len(rows[i][c]) for i in range(len(rows))), 3)
        for c in range(col_count)
    ]

    def _fmt(row):
        return "| " + " | ".join(row[c].ljust(col_widths[c]) for c in range(col_count)) + " |"

    header    = _fmt(rows[0])
    separator = "| " + " | ".join("-" * w for w in col_widths) + " |"
    body      = [_fmt(r) for r in rows[1:]]

    return "\n".join([header, separator] + body)


def _save_image_bytes(img_bytes: bytes, out_dir: Path, img_num: int, ext: str = "png") -> str:
    img_path = out_dir / f"image_{img_num:03d}.{ext}"
    img_path.write_bytes(img_bytes)
    return str(img_path)


def _pil_to_png_bytes(pil_image) -> bytes:
    buf = io.BytesIO()
    pil_image.save(buf, format="PNG")
    return buf.getvalue()


def _save_markdown(text: str, out_dir: Path, stem: str) -> str:
    md_path = out_dir / f"{stem}.md"
    md_path.write_text(text, encoding="utf-8")
    return str(md_path)


# ── PDF extraction ────────────────────────────────────────────

def _ocr_page(pil_image) -> str:
    """Run EasyOCR on a PIL image. Lazy-imports so app runs without it."""
    try:
        import easyocr
        import numpy as np
        reader = easyocr.Reader(["en"], gpu=False, verbose=False)
        result = reader.readtext(np.array(pil_image), detail=0, paragraph=True)
        return "\n".join(result)
    except ImportError:
        log.warning("easyocr not installed — scanned page will be blank")
        return "[scanned page — install easyocr for OCR]"
    except Exception as exc:
        log.warning(f"OCR error: {exc}")
        return "[OCR failed]"


def _extract_pdf(file_path: str, out_dir: Path) -> Tuple[
    str, Dict[int, str], int, bool, float, float, float, float
]:
    """
    Returns: full_text, image_map, table_count, is_scanned,
             t_page_check, t_text, t_images, t_tables
    """
    import pdfplumber

    pages_text: List[str]      = []
    image_map:  Dict[int, str] = {}
    img_counter                = 0
    table_count                = 0
    is_scanned                 = False
    t_page_check = t_text = t_images = t_tables = 0.0

    with pdfplumber.open(file_path) as pdf:
        total_pages = min(len(pdf.pages), MAX_PAGES)

        for page_num, page in enumerate(pdf.pages[:total_pages], start=1):
            log.debug(f"PDF page {page_num}/{total_pages}")
            parts: List[str] = [f"\n<!-- Page {page_num} -->\n"]

            # ── get raw text (page check timing) ──
            t0 = time.perf_counter()
            raw_text = page.extract_text() or ""
            t_page_check += time.perf_counter() - t0

            # ── OCR fallback for scanned pages ──
            t0 = time.perf_counter()
            if len(raw_text.strip()) < SCANNED_TEXT_THRESHOLD:
                is_scanned = True
                log.info(f"Page {page_num}: scanned — running OCR")
                pil_img  = page.to_image(resolution=150).original
                raw_text = _ocr_page(pil_img)
            parts.append(raw_text)
            t_text += time.perf_counter() - t0

            # ── table extraction → markdown ──
            t0 = time.perf_counter()
            try:
                # Use extract_tables() which handles multi-row/col spans
                page_tables = page.extract_tables() or []
                for tbl in page_tables:
                    md = _table_to_markdown(tbl)
                    if md:
                        table_count += 1
                        parts.append(
                            f"\n\n<!-- Table {table_count} (Page {page_num}) -->\n"
                            + md + "\n"
                        )
            except Exception as exc:
                log.warning(f"Table extraction failed page {page_num}: {exc}")
            t_tables += time.perf_counter() - t0

            # ── image extraction ──
            t0 = time.perf_counter()
            try:
                for img_info in page.images:
                    try:
                        x0, y0 = img_info["x0"], img_info["y0"]
                        x1, y1 = img_info["x1"], img_info["y1"]
                        cropped = page.within_bbox((x0, y0, x1, y1)).to_image(
                            resolution=150
                        ).original
                        img_counter += 1
                        img_path = _save_image_bytes(
                            _pil_to_png_bytes(cropped), out_dir, img_counter
                        )
                        image_map[img_counter] = img_path
                        # marker placed in text so LLM knows the image location
                        parts.append(f"\n[Image {img_counter} appears here]\n")
                        log.debug(f"Saved image {img_counter} from page {page_num}")
                    except Exception as exc:
                        log.warning(f"Image on page {page_num} failed: {exc}")
            except Exception as exc:
                log.warning(f"Image loop failed page {page_num}: {exc}")
            t_images += time.perf_counter() - t0

            pages_text.append("\n".join(parts))

    return (
        "\n".join(pages_text), image_map, table_count, is_scanned,
        t_page_check, t_text, t_images, t_tables,
    )


# ── DOCX extraction ───────────────────────────────────────────

def _extract_docx(file_path: str, out_dir: Path) -> Tuple[
    str, Dict[int, str], int, float, float, float
]:
    """
    Returns: full_text, image_map, table_count, t_text, t_images, t_tables
    Iterates body XML children in order so paragraphs and tables appear in
    their original reading sequence.
    """
    from docx import Document

    doc = Document(file_path)

    parts:       List[str]      = ["<!-- Page 1 -->\n"]
    image_map:   Dict[int, str] = {}
    img_counter                 = 0
    table_count                 = 0
    saved_rids:  Dict[str, int] = {}   # relationship id → image number

    t_text = t_images = t_tables = 0.0

    # Map table XML elements to Table objects for quick lookup
    tbl_lookup = {t._tbl: t for t in doc.tables}

    # Namespace constants
    NS_DRAW = "http://schemas.openxmlformats.org/drawingml/2006/main"
    NS_REL  = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    def _get_inline_image_rids(para_xml) -> List[str]:
        """Return all image relationship IDs embedded in a paragraph."""
        rids = []
        for elem in para_xml.iter():
            local = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
            if local == "blip":
                rid = elem.get(f"{{{NS_REL}}}embed")
                if rid:
                    rids.append(rid)
        return rids

    for child in doc.element.body:
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag

        # ── paragraph ──────────────────────────────────────────
        if tag == "p":
            t0 = time.perf_counter()
            from docx.text.paragraph import Paragraph as _Para
            para = _Para(child, doc)
            text = para.text.strip()
            if text:
                if para.style.name.startswith("Heading"):
                    lvl = "".join(c for c in para.style.name if c.isdigit()) or "1"
                    parts.append(f"\n{'#' * int(lvl)} {text}\n")
                else:
                    parts.append(text)
            t_text += time.perf_counter() - t0

            # inline images inside this paragraph
            t0 = time.perf_counter()
            for rid in _get_inline_image_rids(child):
                if rid not in saved_rids:
                    try:
                        img_bytes = doc.part.related_parts[rid].blob
                        img_counter += 1
                        img_path = _save_image_bytes(img_bytes, out_dir, img_counter)
                        image_map[img_counter] = img_path
                        saved_rids[rid] = img_counter
                        parts.append(f"\n[Image {img_counter} appears here]\n")
                        log.debug(f"Saved DOCX image {img_counter}")
                    except Exception as exc:
                        log.warning(f"DOCX image {rid} failed: {exc}")
            t_images += time.perf_counter() - t0

        # ── table ──────────────────────────────────────────────
        elif tag == "tbl":
            t0      = time.perf_counter()
            tbl_obj = tbl_lookup.get(child)
            if tbl_obj:
                rows = [
                    [cell.text.strip() for cell in row.cells]
                    for row in tbl_obj.rows
                ]
                md = _table_to_markdown(rows)
                if md:
                    table_count += 1
                    parts.append(
                        f"\n\n<!-- Table {table_count} -->\n" + md + "\n"
                    )
            t_tables += time.perf_counter() - t0

    return "\n".join(parts), image_map, table_count, t_text, t_images, t_tables


# ── TXT extraction ────────────────────────────────────────────

def _extract_txt(file_path: str) -> str:
    for enc in ["utf-8", "utf-8-sig", "latin-1", "cp1252"]:
        try:
            return "<!-- Page 1 -->\n" + Path(file_path).read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    raise ValueError("Could not decode text file with any supported encoding.")


# ── public API ────────────────────────────────────────────────

def extract_document(
    file_path:         str,
    file_ext:          str,
    session_id:        str,
    original_filename: str,
) -> ExtractionResult:
    """
    Main entry point. Dispatches to the right extractor, saves outputs,
    and returns a fully-populated ExtractionResult.
    """
    t_wall = time.perf_counter()
    file_ext = file_ext.lower().lstrip(".")

    if file_ext not in ("pdf", "docx", "txt"):
        raise ValueError(f"Unsupported file type: .{file_ext}")

    out_dir = _make_output_dir(original_filename)
    stem    = Path(original_filename).stem
    res     = ExtractionResult()

    if file_ext == "pdf":
        (
            res.full_text,
            res.image_map,
            res.table_count,
            res.is_scanned,
            res.t_page_check,
            res.t_text_extraction,
            res.t_image_extraction,
            res.t_table_extraction,
        ) = _extract_pdf(file_path, out_dir)
        res.page_count = len(re.findall(r"<!-- Page \d+ -->", res.full_text))

    elif file_ext == "docx":
        (
            res.full_text,
            res.image_map,
            res.table_count,
            res.t_text_extraction,
            res.t_image_extraction,
            res.t_table_extraction,
        ) = _extract_docx(file_path, out_dir)
        res.page_count   = 1
        res.t_page_check = 0.0

    elif file_ext == "txt":
        t0               = time.perf_counter()
        res.full_text    = _extract_txt(file_path)
        res.t_text_extraction = time.perf_counter() - t0
        res.page_count   = 1

    if res.page_count > MAX_PAGES:
        raise ValueError(
            f"Document has {res.page_count} pages — limit is {MAX_PAGES}."
        )

    res.md_saved_path = _save_markdown(res.full_text, out_dir, stem)
    res.t_total       = time.perf_counter() - t_wall

    log.info(f"Extracted '{original_filename}' → {res.summary}")
    return res


def cleanup_session_images(session_id: str):
    """Images stored permanently under extracted_docs/ — no-op by design."""
    log.debug(f"cleanup_session_images: no-op for session {session_id}")
