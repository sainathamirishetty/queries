"""
logger.py
─────────────────────────────────────────────────────────────
Two separate log files:

1. logs/system_YYYY-MM-DD.log   — technical / debug
2. logs/activity_YYYY-MM-DD.log — structured Q&A tracking
─────────────────────────────────────────────────────────────
"""

import logging
from datetime import datetime
from pathlib import Path

from config import LOG_DIR as _LOG_DIR_STR

LOG_DIR = Path(_LOG_DIR_STR)
LOG_DIR.mkdir(exist_ok=True)

_DATE_FMT   = "%Y-%m-%d %H:%M:%S"
_SYSTEM_FMT = "[%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s"


# ── system logger ─────────────────────────────────────────────

def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(f"system.{name}")
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter(
        "[%(asctime)s] [%(levelname)-8s] %(message)s", datefmt=_DATE_FMT
    ))
    logger.addHandler(console)

    log_file = LOG_DIR / f"system_{datetime.now().strftime('%Y-%m-%d')}.log"
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_SYSTEM_FMT, datefmt=_DATE_FMT))
    logger.addHandler(fh)

    return logger


# ── activity logger ───────────────────────────────────────────

class ActivityLogger:
    """
    Structured row-wise tracker.
    Logs: session start/end, document info, extraction timing, every Q&A.
    """

    def __init__(self):
        self._logger = logging.getLogger("activity")
        if self._logger.handlers:
            return

        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        log_file = LOG_DIR / f"activity_{datetime.now().strftime('%Y-%m-%d')}.log"
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(logging.INFO)
        fh.setFormatter(logging.Formatter("%(message)s"))
        self._logger.addHandler(fh)

    def _write(self, line: str):
        self._logger.info(line)

    def log_session_start(self, session_id: str, ip: str):
        self._write(
            f"\n{'═'*80}\n"
            f"SESSION    | {datetime.now().strftime(_DATE_FMT)} "
            f"| IP: {ip} | Session: {session_id}"
        )

    def log_document(self, filename: str, pages: int, chars: int,
                     images: int, tables: int = 0):
        self._write(
            f"DOCUMENT   | {filename} | Pages: {pages} "
            f"| Chars: {chars:,} | Images: {images} | Tables: {tables}"
        )

    def log_extraction_timing(self, t_page_check: float, t_text: float,
                               t_images: float, t_total: float,
                               t_tables: float = 0.0):
        self._write(
            f"EXTRACTION | Page check: {t_page_check:.2f}s | "
            f"Text: {t_text:.2f}s | Images: {t_images:.2f}s | "
            f"Tables: {t_tables:.2f}s | Total: {t_total:.2f}s"
        )

    def log_qa(self, turn: int, question: str, answer: str,
               t_prompt: float, t_ttft: float, t_total: float,
               chars_per_sec: float, question_type: str = "text",
               images_sent: int = 0):
        answer_log = (answer[:500] + "...") if len(answer) > 500 else answer
        answer_log = answer_log.replace("\n", " ").strip()
        question   = question.replace("\n", " ").strip()

        type_tag = f" [{question_type.upper()}]" if question_type != "text" else ""
        img_tag  = f" | Images sent: {images_sent}" if images_sent else ""

        self._write(
            f"{'─'*80}\n"
            f"Q&A ROW {turn:>3}{type_tag}{img_tag}\n"
            f"QUESTION   | {question}\n"
            f"ANSWER     | {answer_log}\n"
            f"TIMING     | Prompt: {t_prompt:.3f}s | TTFT: {t_ttft:.2f}s | "
            f"Total: {t_total:.2f}s | Speed: {chars_per_sec:.1f} chars/s"
        )

    def log_session_end(self, session_id: str, total_questions: int):
        self._write(
            f"SESSION END| {datetime.now().strftime(_DATE_FMT)} "
            f"| Session: {session_id} | Total Questions: {total_questions}\n"
            f"{'═'*80}"
        )


# single shared instance
activity_log = ActivityLogger()
