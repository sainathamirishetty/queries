
import tornado.web

# Apply the patch once per process (Streamlit re-runs your script on every
# interaction, so guard against stacking the patch).
if not getattr(tornado.web.RequestHandler, "_headers_patched", False):

    _orig_set_default_headers = tornado.web.RequestHandler.set_default_headers
    _orig_set_cookie = tornado.web.RequestHandler.set_cookie

    def _patched_set_default_headers(self):
        # Let Tornado/Streamlit set their own defaults first.
        try:
            _orig_set_default_headers(self)
        except Exception:
            pass

        # Replace the disclosed server banner (fixes HTTP Header Info Disclosure).
        self.set_header("Server", "WebServer")

        # Real HTTP security headers.
        self.set_header("X-Frame-Options", "SAMEORIGIN")
        self.set_header("X-Content-Type-Options", "nosniff")
        self.set_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.set_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.set_header("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
        self.set_header(
            "Content-Security-Policy",
            "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; "
            "connect-src 'self' wss: https:;",
        )

    def _patched_set_cookie(self, name, value, *args, **kwargs):
        # Add SameSite to cookies that don't already set it (fixes SameSite flag).
        # We do NOT force HttpOnly on _streamlit_xsrf: the Streamlit frontend must
        # read that cookie in JavaScript, so making it HttpOnly would break XSRF.
        kwargs.setdefault("samesite", "Lax")
        return _orig_set_cookie(self, name, value, *args, **kwargs)

    tornado.web.RequestHandler.set_default_headers = _patched_set_default_headers
    tornado.web.RequestHandler.set_cookie = _patched_set_cookie
    tornado.web.RequestHandler._headers_patched = True

"""
security_headers.py
===================
Adds HTTP security response headers to a Streamlit app WITHOUT upgrading
Streamlit and WITHOUT any reverse proxy.

HOW IT WORKS
------------
Streamlit serves every response through Tornado (already installed with
Streamlit). Tornado's RequestHandler.clear() sets the default headers and then
calls set_default_headers(). Patching set_default_headers() lets us add real
HTTP response headers to every response Streamlit sends — the app page, the
static assets, and the internal /_stcore/* endpoints.

HOW TO USE
----------
1. Restart the app. Verify:
       curl -kI https://<host>:<port>/ | grep -iE "server|x-frame|x-content|cache-control|referrer|permissions|content-security"

NOTES
-----
* Works with the currently installed Tornado (6.4 / 6.5). It patches internals,
  so after any Streamlit/Tornado upgrade, re-run the scan (or the curl above) to
  confirm the headers are still applied.
* If the Content-Security-Policy line ever breaks a page, comment out ONLY that
  line — the others are safe.
"""
