# Aircraft keypoints without a CNN (Tejas / Banshee, 5 points)

Finds the aircraft in a photo and predicts 5 keypoints (nose, left wing, right wing, tail, mid),
using classic image processing plus a fast non-CNN learned model (ERT trees from dlib).

**Status, honestly:** everything here was tested only on **synthetic** images (cartoon delta wings,
made by `make_synth.py`). It has NOT been tried on real Tejas or Banshee photos yet. Good numbers on
synthetic data prove the code runs, not that the method works on real photos.

## The 5 points (same for both aircraft; never change the order)
| # | name | meaning |
|---|------|---------|
| 0 | nose | front tip |
| 1 | left_wing | the aircraft's OWN left wingtip (pilot's left), not the image-left |
| 2 | right_wing | the aircraft's OWN right wingtip |
| 3 | tail | rear end of the centreline (middle of the trailing edge), not the top of Tejas's fin |
| 4 | mid | centre of the body (centreline meets the wingtip-to-wingtip line) |

Confirm these with your team before labelling real photos (edit `tc/config.py` if they change).

## The pipeline
```
photo -> 1 FIND (segment.py) -> 2 STRAIGHTEN (normalize.py) -> 3 KEYPOINTS -> 4 REFINE (refine.py)
                                                               A geometry.py (no learning)
                                                               B ert.py (ERT trees, view groups)
```
1. **Find**: strong edges (the aircraft has sharp edges, sky and clouds do not), fill the biggest outline.
2. **Straighten**: rotate and scale so the main axis is horizontal and the nose is on the right.
   (The nose is guessed from how the shape is distributed. This can be wrong for side and head-on views.)
3. **Keypoints**: A = geometry baseline. B = ERT regression; the shapes are clustered into view
   groups with cheap numbers (elongation, aspect, skew, fill) and one small model is trained per group.
4. **Refine** (optional): snap the nose, wingtips and tail onto the silhouette.

## CURRENT TASK: classical keypoints inside your team's box, scored with CVAT labels (no training)
Your team's detector gives a box. A CNN (trained on CVAT labels) gives the keypoints. Here the
keypoints come from classical image processing, and the CVAT labels are only the ANSWER KEY.
```bash
python demo_box.py --image photo.jpg --box 75 80 280 152            # one photo, no labels needed
python evaluate_cvat.py --images photos/ --cvat annotations.xml --boxes detector_boxes.csv
python evaluate_cvat.py ... --cnn-csv cnn_points.csv                  # score the CNN the same way
```
- Points (CVAT label names, case and spaces do not matter): head, left wing, right wing, tail, centre.
- Outline inside the box: paint colour (orange/red/yellow, e.g. Banshee) or GrabCut (`--mode auto|colour|grabcut`).
  A yellow nose cone at one end of the aircraft decides which end is the head.
- `make_cvat_demo.py` makes test XML files from the synthetic data (reader tested on both CVAT layouts:
  separate `<points>` and `<skeleton>`; NOT yet on a real CVAT export, send me a small sample).
- Tried on 4 real Banshee photos with boxes I simulated (no labels, so no numbers): head (yellow nose)
  was right in 3 of 4 outlines I inspected closely, centre looked reasonable, tail was right in the simple
  side views, and left/right wing were wrong in side views (wings overlap there and the rule picks the
  wrong extremes). The outline leaked into the stand/hangar in some GrabCut runs. Real boxes and
  real CVAT labels are needed for real numbers.

## Setup
```bash
sudo apt install cmake build-essential          # dlib is compiled, this takes a few minutes
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

## Try it on synthetic data (about 5 minutes)
```bash
python make_synth.py --out data/synth --n-train 600 --n-val 200
python train_ert.py --data data/synth/train --out models/ert --groups 3
python evaluate.py --data data/synth/val --model models/ert --csv outputs/results.csv
python demo.py --data data/synth/val --method ert --model models/ert --n 12
bash bench_1core.sh data/synth/val models/ert        # speed pinned to ONE core
```
`evaluate.py` prints, for each method: error per keypoint (as % of object size), the share of
points within 5% and 10%, how often left/right and nose/tail are swapped, ms per frame by stage,
and a breakdown by view group. `demo.py` writes a picture: filled dots = prediction, white rings = label.
LOOK at the pictures before trusting any number.

`make_synth.py --views below` makes only underside views (a camera on the ground looking up), which
is probably closer to real use than `--views all`. `python experiment_orientation.py` is a side
experiment (see below), not part of the pipeline.

## What I measured (SYNTHETIC data, 600 train / 200 val images, one run, seed 0)
Errors are % of the object's box diagonal (5% = small miss, 10% = big miss).

| | geometry (A) | ERT (B) |
|---|---|---|
| all views: mean error / within 10% | 24.9% / 49% | 20.0% / 52% |
| underside views: median error / within 10% | 25.5% / 40% | 3.2% / 61% |
| underside, seen flat-on: mean error, wing swaps | 28.9%, 93% | 4.2%, 4.9% |
| underside, oblique or edge-on: mean error | 29-32% | 25-27% |

- Stage 1 (find the aircraft): mask IoU 0.955 (the 3 settings were looked at on the val images; the
  train images give the same 0.957).
- Speed on one pinned core of the cloud machine I used (640x480 images): about 6 ms per frame in
  total (find 2.8, straighten 2.6, keypoints 0.6), about 165 fps. Your target CPU will be different.
- **Where it fails:** oblique and edge-on views, where nose and tail are swapped in about 40% of
  the cases. In those views a flat delta wing looks like an arbitrary triangle, so its silhouette
  alone does not say which end is the nose (my interpretation of the pattern, not proven).
  `experiment_orientation.py` tried a small random forest on a 16x16 thumbnail: nose direction
  improved from 70% to 77% overall, but oblique views stayed at 61%. Not added to the pipeline.
- "refine" (snapping to the silhouette) made no clear difference here.
- Ideas for the hard views: motion direction in video (aircraft fly nose first), cues that real
  photos have (fin, air intakes, cockpit), more data, a 3D model with `solvePnP`.

## Use REAL photos
1. Put photos in `data/real/train/images` and `data/real/val/images`. Keep photos from the same
   event or source on the same side (train OR val), otherwise the score looks better than it is.
2. Label with CVAT / Roboflow: one box + the 5 points in the order above, export as
   **YOLO keypoints**, so labels land in `data/real/{train,val}/labels` (one `.txt` per image).
3. First check stage 1 on real photos: `python demo.py --data data/real/val --method geometry`.
   If the outline is wrong (clouds, buildings, haze), tune `tc/segment.py` before anything else.
4. Then `python train_ert.py --data data/real/train ...` and `python evaluate.py --data data/real/val ...`.

## What is not done yet
- Real photos (see above). Real clouds, haze and clutter are much harder than my synthetic sky.
- Left/right check with a 3D model + `solvePnP`, and temporal smoothing + optical-flow tracking for video.
- The nano-CNN benchmark on this data (`yolo_data.yaml` has the same labels, so the earlier
  `tejas_pose` scripts can train on `data/synth`; I have not run that here).
- Speed on your target CPU. `bench_1core.sh` measures one core of the computer you run it on.
