#!/usr/bin/env bash
# Speed on ONE CPU core of THIS computer (the target CPU will be different).
#   bash bench_1core.sh data/synth/val models/ert
DATA=${1:-data/synth/val}
MODEL=${2:-models/ert}
taskset -c 0 python evaluate.py --data "$DATA" --model "$MODEL" \
    --methods geometry,ert,ert+refine --limit 200
