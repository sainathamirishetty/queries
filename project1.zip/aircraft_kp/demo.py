"""Draw predictions on images so you can LOOK at them (filled dots = prediction,
white rings = your label). Look at the pictures before trusting any number.

    python demo.py --data data/synth/val --method ert --model models/ert --n 12
    python demo.py --data data/real/val --method geometry --n 12 --out outputs/demo_real.jpg
"""
import argparse
from pathlib import Path

import cv2
import numpy as np

from tc.config import KP_COLORS, KP_NAMES
from tc.dataset import list_samples, read_label
from tc.metrics import norm_errors
from tc.pipeline import Pipeline

TILE = 300


def draw(img, pred, gt):
    for i in range(len(KP_NAMES)):
        if gt is not None:
            cv2.circle(img, tuple(int(v) for v in gt[i]), 9, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.circle(img, tuple(int(v) for v in pred[i]), 5, KP_COLORS[i], -1, cv2.LINE_AA)
        cv2.putText(img, str(i), (int(pred[i][0]) + 7, int(pred[i][1]) - 7),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, KP_COLORS[i], 2, cv2.LINE_AA)
    cv2.line(img, tuple(int(v) for v in pred[0]), tuple(int(v) for v in pred[3]), (255, 255, 255), 1, cv2.LINE_AA)
    cv2.line(img, tuple(int(v) for v in pred[1]), tuple(int(v) for v in pred[2]), (255, 255, 255), 1, cv2.LINE_AA)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/synth/val")
    ap.add_argument("--method", default="ert", help="geometry | ert | geometry+refine | ert+refine")
    ap.add_argument("--model", default=None)
    ap.add_argument("--n", type=int, default=12)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    model = None
    if args.model:
        from tc.ert import ERTModel
        model = ERTModel.load(args.model)
    refine = args.method.endswith("+refine")
    pipe = Pipeline(method=args.method.replace("+refine", ""), ert_model=model, refine=refine)

    tiles = []
    for ip, lp in list_samples(args.data)[: args.n]:
        img = cv2.imread(str(ip))
        h, w = img.shape[:2]
        gt = read_label(lp, w, h)
        res = pipe.run(img)
        if res["ok"]:
            draw(img, res["kpts"], gt["kpts"] if gt else None)
            label = f"err {norm_errors(res['kpts'], gt['kpts'], gt['box']).mean() * 100:.1f}%" if gt else ""
        else:
            label = "NOT FOUND"
        if gt is not None:
            x1, y1, x2, y2 = gt["box"].astype(int)
            pad = int(0.25 * max(x2 - x1, y2 - y1))
            img = img[max(0, y1 - pad):y2 + pad, max(0, x1 - pad):x2 + pad]
        s = TILE / max(img.shape[:2])
        img = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
        tile = np.full((TILE, TILE, 3), 255, np.uint8)
        tile[: img.shape[0], : img.shape[1]] = img
        cv2.putText(tile, f"{ip.stem[-5:]} {label}", (6, TILE - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
        tiles.append(tile)
    while len(tiles) % 4:
        tiles.append(np.full((TILE, TILE, 3), 255, np.uint8))
    sheet = np.vstack([np.hstack(tiles[i:i + 4]) for i in range(0, len(tiles), 4)])
    out = Path(args.out or f"outputs/demo_{args.method.replace('+', '_')}.jpg")
    out.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out), sheet)
    print("saved", out)


if __name__ == "__main__":
    main()
