"""Try the classical extractor on ONE photo with a box you give (no labels needed).

    python demo_box.py --image photo.jpg --box 75 80 280 152 --out outputs/one.jpg
    python demo_box.py --image photo.jpg --box 75 80 280 152 --mode grabcut

Draws: the outline it found (green), the 5 points (coloured dots, numbered 0..4 =
head, left wing, right wing, tail, centre) and the main axis. Also prints which outline method
was used and whether the yellow nose cue or the shape decided the nose end.
"""
import argparse
from pathlib import Path

import cv2

from tc.classic import extract
from tc.config import KP_COLORS, KP_NAMES


def draw(img, box, res):
    vis = img.copy()
    if res["mask"] is not None:
        cs, _ = cv2.findContours((res["mask"] > 0).astype("uint8"), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cv2.drawContours(vis, cs, -1, (0, 255, 0), 2)
    x1, y1, x2, y2 = [int(v) for v in box]
    cv2.rectangle(vis, (x1, y1), (x2, y2), (255, 255, 255), 1)
    if res["ok"]:
        k = res["kpts"]
        cv2.line(vis, tuple(int(v) for v in k[0]), tuple(int(v) for v in k[3]), (255, 255, 255), 1, cv2.LINE_AA)
        for i in range(5):
            p = tuple(int(v) for v in k[i])
            cv2.circle(vis, p, 6, KP_COLORS[i], -1, cv2.LINE_AA)
            cv2.circle(vis, p, 6, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(vis, str(i), (p[0] + 8, p[1] - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.6, KP_COLORS[i], 2, cv2.LINE_AA)
    return vis


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--box", type=float, nargs=4, required=True, metavar=("X1", "Y1", "X2", "Y2"))
    ap.add_argument("--mode", default="auto", choices=["auto", "colour", "grabcut"])
    ap.add_argument("--no-cue", action="store_true")
    ap.add_argument("--out", default="outputs/one.jpg")
    args = ap.parse_args()
    img = cv2.imread(args.image)
    res = extract(img, args.box, mode=args.mode, use_cue=not args.no_cue)
    print("ok:", res["ok"], "| outline method:", res["mode"], "| nose end decided by:", res["dir_source"])
    if res["ok"]:
        for n, (x, y) in zip(KP_NAMES, res["kpts"]):
            print(f"  {n:11s} x={x:7.1f} y={y:7.1f}")
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(args.out, draw(img, args.box, res))
    print("saved", args.out)


if __name__ == "__main__":
    main()
