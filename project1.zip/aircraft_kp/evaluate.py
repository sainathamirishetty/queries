"""Compare the methods on a labelled dataset: accuracy, left/right swaps and speed.

    python evaluate.py --data data/synth/val --model models/ert
    python evaluate.py --data data/synth/val --model models/ert --methods geometry,ert,ert+refine

ONE CORE: run it as   taskset -c 0 python evaluate.py ...   (see bench_1core.sh).
The thread limits below make numpy / OpenCV use one thread, so ms/frame is a
single-core number for THIS computer (the target CPU will differ).

Errors are divided by the object's box diagonal (so 5% = a small miss, 10% = a big miss).
"""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np

cv2.setNumThreads(1)

from tc.config import KP_NAMES
from tc.dataset import list_samples, read_label
from tc.metrics import norm_errors, nose_tail_swapped, wing_swapped
from tc.pipeline import Pipeline


def build(spec, model):
    refine = spec.endswith("+refine")
    method = spec.replace("+refine", "")
    if method == "ert" and model is None:
        raise SystemExit("method 'ert' needs --model")
    return Pipeline(method=method, ert_model=model, refine=refine)


def mask_iou(pred, gt):
    a, b = pred > 0, gt > 0
    return (a & b).sum() / max((a | b).sum(), 1)


def summarize(name, recs, n_total):
    ok = [r for r in recs if r["ok"]]
    print(f"\n=== {name}   (found object in {len(ok)}/{n_total} images) ===")
    if not ok:
        return
    E = np.array([r["err"] for r in ok]) * 100
    print("mean error % of object size : " + "  ".join(f"{n}={e:5.2f}" for n, e in zip(KP_NAMES, E.mean(0))))
    print(f"all points: mean {E.mean():.2f}%   median {np.median(E):.2f}%   "
          f"within 5%: {(E <= 5).mean() * 100:.1f}%   within 10%: {(E <= 10).mean() * 100:.1f}%")
    print(f"left/right wing swapped: {np.mean([r['ws'] for r in ok]) * 100:.1f}%    "
          f"nose/tail swapped: {np.mean([r['nts'] for r in ok]) * 100:.1f}%")
    t = np.array([r["ms"]["total"] for r in ok])
    stages = {k: np.mean([r["ms"].get(k, 0) for r in ok]) for k in ("segment", "normalize", "keypoints", "refine")}
    print(f"time per frame: mean {t.mean():.2f} ms   p95 {np.percentile(t, 95):.2f} ms   "
          f"(~{1000 / t.mean():.0f} fps)   stages: " + "  ".join(f"{k}={v:.2f}" for k, v in stages.items()))
    if all(r.get("meta") for r in ok):
        print("by TRUE view (synthetic data only): n, mean err %, wing swap %, nose/tail swap %")
        kinds = {
            "seen from top": lambda m: m["side"] == "top",
            "seen from below": lambda m: m["side"] == "bottom",
            "flat-on (elev>0.75)": lambda m: m["elev"] > 0.75,
            "oblique (0.4-0.75)": lambda m: 0.4 <= m["elev"] <= 0.75,
            "edge-on (elev<0.4)": lambda m: m["elev"] < 0.4,
        }
        for k, fn in kinds.items():
            rr = [x for x in ok if fn(x["meta"])]
            if rr:
                print(f"   {k:22s} n={len(rr):3d}  err={np.mean([x['err'].mean() for x in rr]) * 100:5.2f}  "
                      f"wing swap={np.mean([x['ws'] for x in rr]) * 100:5.1f}  "
                      f"nose/tail swap={np.mean([x['nts'] for x in rr]) * 100:5.1f}")
    groups = defaultdict(list)
    for r in ok:
        groups[r["group"]].append(r)
    if len(groups) > 1 or -1 not in groups:
        print("by view group (group id: n, mean err %, wing swap %):")
        for g in sorted(groups):
            rr = groups[g]
            print(f"   {g}: n={len(rr):3d}  err={np.mean([x['err'].mean() for x in rr]) * 100:5.2f}  "
                  f"swap={np.mean([x['ws'] for x in rr]) * 100:5.1f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/synth/val")
    ap.add_argument("--model", default=None, help="folder made by train_ert.py")
    ap.add_argument("--methods", default="geometry,geometry+refine,ert,ert+refine")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--csv", default=None)
    args = ap.parse_args()

    model = None
    if args.model:
        from tc.ert import ERTModel
        model = ERTModel.load(args.model)
    methods = [m.strip() for m in args.methods.split(",") if m.strip()]
    if model is None:
        methods = [m for m in methods if not m.startswith("ert")]
    samples = list_samples(args.data)
    if args.limit:
        samples = samples[: args.limit]
    mask_dir = Path(args.data) / "masks"
    pipes = {m: build(m, model) for m in methods}
    recs = {m: [] for m in methods}
    ious = []
    for ip, lp in samples:
        img = cv2.imread(str(ip))
        h, w = img.shape[:2]
        gt = read_label(lp, w, h)
        for m, p in pipes.items():
            res = p.run(img)
            r = dict(name=ip.name, ok=res["ok"], ms=res["ms"], group=res["group"])
            mp = Path(args.data) / "meta" / (ip.stem + ".json")
            if mp.exists():
                r["meta"] = json.loads(mp.read_text())
            if res["ok"]:
                r["err"] = norm_errors(res["kpts"], gt["kpts"], gt["box"])
                r["ws"] = wing_swapped(res["kpts"], gt["kpts"])
                r["nts"] = nose_tail_swapped(res["kpts"], gt["kpts"])
            recs[m].append(r)
            if m == methods[0] and (mask_dir / (ip.stem + ".png")).exists():
                gm = cv2.imread(str(mask_dir / (ip.stem + ".png")), 0)
                ious.append(mask_iou(res["mask"], gm) if res["mask"] is not None else 0.0)
    if ious:
        print(f"\nstage 1 (find the aircraft): mean mask IoU = {np.mean(ious):.3f}  "
              f"(images with IoU < 0.5: {sum(i < 0.5 for i in ious)}/{len(ious)})")
    for m in methods:
        summarize(m, recs[m], len(samples))
    if args.csv:
        Path(args.csv).parent.mkdir(parents=True, exist_ok=True)
        with open(args.csv, "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(["method", "image", "ok", "group", "ms_total"] + [f"err_{n}" for n in KP_NAMES] + ["wing_swap", "nose_tail_swap"])
            for m in methods:
                for r in recs[m]:
                    wr.writerow([m, r["name"], int(r["ok"]), r["group"], f"{r['ms']['total']:.3f}"]
                                + ([f"{e:.5f}" for e in r["err"]] + [int(r["ws"]), int(r["nts"])] if r["ok"] else [""] * 7))
        print("\nper-image results saved to", args.csv)


if __name__ == "__main__":
    main()
