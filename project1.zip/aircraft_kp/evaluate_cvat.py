"""Measure the CLASSICAL method against your CVAT labels (the answer key). No training anywhere.

    python evaluate_cvat.py --images photos/ --cvat annotations.xml
    python evaluate_cvat.py --images photos/ --cvat annotations.xml --boxes detector_boxes.csv
    python evaluate_cvat.py --images photos/ --cvat annotations.xml --cnn-csv cnn_points.csv

--boxes   : your team's detector boxes (image,x1,y1,x2,y2). Without it, the box drawn in CVAT is used,
            and if there is none either, a box around your labelled points (+25%) is used and counted.
--cnn-csv : the CNN's predicted points (image + 10 numbers: head x,y, left x,y, right x,y, tail x,y,
            centre x,y) so both methods are scored the same way on the same images.
--mode    : auto | colour | grabcut   (how the aircraft is outlined inside the box)
Errors are in pixels and as % of the box diagonal (5% = small miss, 10% = big miss).
"""
import argparse
import csv
from pathlib import Path

import cv2
import numpy as np

from tc.classic import extract
from tc.config import KP_COLORS, KP_NAMES
from tc.cvat import read_boxes_csv, read_cvat_xml, read_points_csv


def padded_box(kp, pad=0.25):
    x1, y1 = np.nanmin(kp, axis=0)
    x2, y2 = np.nanmax(kp, axis=0)
    return [x1 - pad * (x2 - x1), y1 - pad * (y2 - y1), x2 + pad * (x2 - x1), y2 + pad * (y2 - y1)]


def errors(pred, gt, box):
    diag = float(np.hypot(box[2] - box[0], box[3] - box[1]))
    px = np.linalg.norm(pred - gt, axis=1)               # NaN where a label is missing
    return px, px / diag * 100


def report(name, rows):
    if not rows:
        print(f"\n=== {name}: nothing to report ===")
        return
    P = np.array([r["px"] for r in rows])
    E = np.array([r["pct"] for r in rows])
    print(f"\n=== {name}  ({len(rows)} images) ===")
    print("mean error in pixels : " + "  ".join(f"{n}={np.nanmean(P[:, i]):6.1f}" for i, n in enumerate(KP_NAMES)))
    print("mean error % of size : " + "  ".join(f"{n}={np.nanmean(E[:, i]):6.2f}" for i, n in enumerate(KP_NAMES)))
    ok = E[~np.isnan(E)]
    print(f"all points: mean {ok.mean():.2f}%   median {np.median(ok):.2f}%   "
          f"within 5%: {(ok <= 5).mean() * 100:.1f}%   within 10%: {(ok <= 10).mean() * 100:.1f}%")
    ws = [r["wing_swap"] for r in rows if r["wing_swap"] is not None]
    nts = [r["nt_swap"] for r in rows if r["nt_swap"] is not None]
    if ws:
        print(f"left/right wing swapped: {np.mean(ws) * 100:.1f}%    nose/tail swapped: {np.mean(nts) * 100:.1f}%")


def swapped(pred, gt, a, b):
    if np.isnan(gt[[a, b]]).any():
        return None
    d = np.linalg.norm(pred[a] - gt[a]) + np.linalg.norm(pred[b] - gt[b])
    s = np.linalg.norm(pred[a] - gt[b]) + np.linalg.norm(pred[b] - gt[a])
    return bool(s < d)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", required=True)
    ap.add_argument("--cvat", required=True)
    ap.add_argument("--boxes", default=None)
    ap.add_argument("--cnn-csv", default=None)
    ap.add_argument("--mode", default="auto", choices=["auto", "colour", "grabcut"])
    ap.add_argument("--no-cue", action="store_true", help="do not use the yellow-nose colour cue")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--out", default="outputs/cvat_eval")
    args = ap.parse_args()

    ann = read_cvat_xml(args.cvat)
    boxes = read_boxes_csv(args.boxes) if args.boxes else {}
    cnn = read_points_csv(args.cnn_csv) if args.cnn_csv else {}
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    rows, cnn_rows, tiles, per_image = [], [], [], []
    n_pad = n_missing = n_fail = 0
    for name, a in ann.items():
        gt = a["kpts"]
        if np.isnan(gt).all():
            continue
        path = Path(args.images) / name
        img = cv2.imread(str(path)) if path.exists() else None
        if img is None:
            n_missing += 1
            continue
        if name in boxes:
            box = boxes[name]
        elif a["box"] is not None:
            box = a["box"]
        else:
            box, n_pad = padded_box(gt), n_pad + 1
        res = extract(img, box, mode=args.mode, use_cue=not args.no_cue)
        if not res["ok"]:
            n_fail += 1
            per_image.append([name, "FAILED"])
            continue
        px, pct = errors(res["kpts"], gt, box)
        rows.append(dict(px=px, pct=pct, wing_swap=swapped(res["kpts"], gt, 1, 2), nt_swap=swapped(res["kpts"], gt, 0, 3)))
        per_image.append([name, res["mode"], res["dir_source"]] + [f"{v:.1f}" for v in px])
        if name in cnn:
            cpx, cpct = errors(cnn[name], gt, box)
            cnn_rows.append(dict(px=cpx, pct=cpct, wing_swap=swapped(cnn[name], gt, 1, 2), nt_swap=swapped(cnn[name], gt, 0, 3)))
        if len(tiles) < 12:
            vis = img.copy()
            x1, y1, x2, y2 = [int(v) for v in box]
            cv2.rectangle(vis, (x1, y1), (x2, y2), (255, 255, 255), 1)
            for i in range(5):
                if not np.isnan(gt[i]).any():
                    cv2.circle(vis, tuple(int(v) for v in gt[i]), 9, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.circle(vis, tuple(int(v) for v in res["kpts"][i]), 5, KP_COLORS[i], -1, cv2.LINE_AA)
                cv2.putText(vis, str(i), (int(res["kpts"][i][0]) + 7, int(res["kpts"][i][1]) - 7),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, KP_COLORS[i], 2, cv2.LINE_AA)
            pad = int(0.3 * max(x2 - x1, y2 - y1))
            vis = vis[max(0, y1 - pad):y2 + pad, max(0, x1 - pad):x2 + pad]
            s = 300 / max(vis.shape[:2])
            vis = cv2.resize(vis, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
            t = np.full((300, 300, 3), 255, np.uint8)
            t[:vis.shape[0], :vis.shape[1]] = vis
            cv2.putText(t, f"{res['mode']}/{res['dir_source']} {pct[~np.isnan(pct)].mean():.1f}%", (5, 292),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            tiles.append(t)
        if args.limit and len(rows) >= args.limit:
            break

    print(f"images with labels: {len(ann)}   scored: {len(rows)}   photo not found: {n_missing}   "
          f"outline failed: {n_fail}   box made from your points (no box given): {n_pad}")
    report(f"classical method (mode={args.mode})", rows)
    if cnn_rows:
        report("CNN (from --cnn-csv)", cnn_rows)
    with open(out / "per_image.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["image", "outline", "nose_direction_from"] + [f"err_px_{n}" for n in KP_NAMES])
        w.writerows(per_image)
    if tiles:
        while len(tiles) % 4:
            tiles.append(np.full((300, 300, 3), 255, np.uint8))
        cv2.imwrite(str(out / "overlay.jpg"), np.vstack([np.hstack(tiles[i:i + 4]) for i in range(0, len(tiles), 4)]))
        print("pictures (dots = method, white rings = your CVAT labels):", out / "overlay.jpg")
    if n_pad:
        print("NOTE: a box made from your own points is too good. Give --boxes from the real detector for a fair result.")


if __name__ == "__main__":
    main()
