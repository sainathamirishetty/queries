"""EXPERIMENT (not part of the pipeline): can a small random forest learn (1) which end is the nose and
(2) top-vs-bottom view, from a 16x16 thumbnail of the straightened crop?
Run from the project folder after make_synth.py:   python experiment_orientation.py
On my synthetic data: nose direction 70% (heuristic) -> 77% (forest), mostly on edge-on views;
top/bottom 77%. Too weak to add to the pipeline, so it stays an experiment."""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cv2, numpy as np
from pathlib import Path
from tc.dataset import list_samples, read_label
from tc.segment import segment
from tc.normalize import canonicalize

def collect(split):
    X = []
    for ip, lp in list_samples(f"data/synth/{split}"):
        img = cv2.imread(str(ip)); h, w = img.shape[:2]; gt = read_label(lp, w, h)
        m = segment(img); n = canonicalize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), m)
        kn = cv2.transform(gt["kpts"].reshape(1, -1, 2), n["M"])[0]
        meta = json.loads((ip.parent.parent / "meta" / (ip.stem + ".json")).read_text())
        X.append(dict(crop=n["crop"], desc=n["desc"], kn=kn, meta=meta))
    return X
tr, va = collect("train"), collect("val")

def thumb(crop): return cv2.resize(crop, (16, 16), interpolation=cv2.INTER_AREA).astype(np.float32).ravel() / 255
def feats(crop, desc): return np.concatenate([desc.astype(np.float32), thumb(crop)])

def forest(X, y, depth=14, trees=200):
    rf = cv2.ml.RTrees_create(); rf.setMaxDepth(depth); rf.setMinSampleCount(2)
    rf.setTermCriteria((cv2.TERM_CRITERIA_MAX_ITER + cv2.TERM_CRITERIA_EPS, trees, 0.0))
    vt = np.array([cv2.ml.VAR_NUMERICAL] * X.shape[1] + [cv2.ml.VAR_CATEGORICAL], np.uint8)
    rf.train(cv2.ml.TrainData_create(X.astype(np.float32), cv2.ml.ROW_SAMPLE, y.astype(np.int32), varType=vt))
    return rf
def pred(rf, X): return rf.predict(X.astype(np.float32))[1].ravel().astype(int)

# task 1: does the crop need a 180 degree flip (GT nose left of GT tail)?
def t1(S, aug):
    X, y = [], []
    for s in S:
        f = int(s["kn"][0][0] < s["kn"][3][0])
        X.append(feats(s["crop"], s["desc"])); y.append(f)
        if aug:
            X.append(feats(cv2.rotate(s["crop"], cv2.ROTATE_180), s["desc"])); y.append(1 - f)
    return np.array(X), np.array(y)
Xtr, ytr = t1(tr, True); Xva, yva = t1(va, False)
rf1 = forest(Xtr, ytr); p1 = pred(rf1, Xva)
heur_acc = (yva == 0).mean()
print(f"TASK 1 flip: heuristic-only accuracy {heur_acc:.3f}   forest accuracy {(p1 == yva).mean():.3f}")
for name, fn in [("flat-on", lambda m: m["elev"] > .75), ("oblique", lambda m: .4 <= m["elev"] <= .75), ("edge-on", lambda m: m["elev"] < .4)]:
    idx = [i for i, s in enumerate(va) if fn(s["meta"])]
    print(f"   {name:8s} n={len(idx):3d}  heuristic {(yva[idx] == 0).mean():.2f}  forest {(p1[idx] == yva[idx]).mean():.2f}")

# task 2: handedness in the nose-right frame (left wing below the axis = seen from below)
def fix(s):
    if s["kn"][0][0] < s["kn"][3][0]:      # GT says nose is on the left: rotate crop 180 and keypoints with it
        c = cv2.rotate(s["crop"], cv2.ROTATE_180); k = 159 - s["kn"]
    else: c, k = s["crop"], s["kn"]
    return c, k
def t2(S, aug):
    X, y = [], []
    for s in S:
        c, k = fix(s); h = int(k[1][1] > k[2][1])
        X.append(feats(c, s["desc"])); y.append(h)
    return np.array(X), np.array(y)
Xtr2, ytr2 = t2(tr, False); Xva2, yva2 = t2(va, False)
rf2 = forest(Xtr2, ytr2); p2 = pred(rf2, Xva2)
truth_side = np.array([int(s["meta"]["side"] == "bottom") for s in va])
print(f"TASK 2 handedness (using GT-corrected orientation): forest accuracy {(p2 == yva2).mean():.3f}   (label vs true side agreement {(yva2 == truth_side).mean():.3f})")
for name, fn in [("flat-on", lambda m: m["elev"] > .75), ("oblique", lambda m: .4 <= m["elev"] <= .75), ("edge-on", lambda m: m["elev"] < .4)]:
    idx = [i for i, s in enumerate(va) if fn(s["meta"])]
    print(f"   {name:8s} n={len(idx):3d}  forest {(p2[idx] == yva2[idx]).mean():.2f}")
