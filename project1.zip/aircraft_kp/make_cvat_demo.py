"""Make two CVAT-style XML files from the SYNTHETIC data, only to test the CVAT reader and
evaluate_cvat.py before you have real CVAT exports.

    python make_cvat_demo.py --data data/synth/val --out outputs --limit 60
Writes outputs/cvat_demo_points.xml (separate <points>) and outputs/cvat_demo_skeleton.xml (<skeleton>).
"""
import argparse
from pathlib import Path

import cv2

from tc.dataset import list_samples, read_label

NAMES = ["head", "left wing", "right wing", "tail", "centre"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/synth/val")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--limit", type=int, default=60)
    args = ap.parse_args()
    flat, skel = ['<?xml version="1.0" encoding="utf-8"?>', "<annotations>", "  <version>1.1</version>"], []
    skel = list(flat)
    for i, (ip, lp) in enumerate(list_samples(args.data)[: args.limit]):
        h, w = cv2.imread(str(ip)).shape[:2]
        g = read_label(lp, w, h)
        head = f'  <image id="{i}" name="{ip.name}" width="{w}" height="{h}">'
        box = '    <box label="aircraft" source="manual" occluded="0" xtl="{:.2f}" ytl="{:.2f}" xbr="{:.2f}" ybr="{:.2f}" z_order="0"></box>'.format(*g["box"])
        flat += [head, box]
        skel += [head, box, '    <skeleton label="aircraft" source="manual" z_order="0">']
        for n, (x, y) in zip(NAMES, g["kpts"]):
            flat.append(f'    <points label="{n}" source="manual" occluded="0" points="{x:.2f},{y:.2f}" z_order="0"></points>')
            skel.append(f'      <points label="{n}" outside="0" occluded="0" keyframe="1" points="{x:.2f},{y:.2f}"></points>')
        skel.append("    </skeleton>")
        flat.append("  </image>")
        skel.append("  </image>")
    flat.append("</annotations>")
    skel.append("</annotations>")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "cvat_demo_points.xml").write_text("\n".join(flat))
    (out / "cvat_demo_skeleton.xml").write_text("\n".join(skel))
    print("wrote", out / "cvat_demo_points.xml", "and", out / "cvat_demo_skeleton.xml")


if __name__ == "__main__":
    main()
