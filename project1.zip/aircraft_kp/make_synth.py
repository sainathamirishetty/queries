"""Make a SYNTHETIC test dataset (train + val) in YOLO-pose format.

    python make_synth.py --out data/synth --n-train 600 --n-val 200

Output:
    data/synth/train/{images,labels,masks,meta}   data/synth/val/{images,labels,masks,meta}
(meta = the true viewing side/angle, only used to analyse results; real data has none.)
"""
import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from tc.synth import render, yolo_line


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/synth")
    ap.add_argument("--n-train", type=int, default=600)
    ap.add_argument("--n-val", type=int, default=200)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--views", choices=["all", "below"], default="all",
                    help="all = any viewing direction; below = only the underside is visible")
    args = ap.parse_args()

    for split, n, seed_off in (("train", args.n_train, 0), ("val", args.n_val, 10_000)):
        rng = np.random.default_rng(args.seed + seed_off)
        for sub in ("images", "labels", "masks", "meta"):
            (Path(args.out) / split / sub).mkdir(parents=True, exist_ok=True)
        for i in range(n):
            cls = int(rng.integers(0, 2))
            img, kpts, mask, box, meta = render(cls, rng, views=args.views)
            h, w = img.shape[:2]
            name = f"syn_{split}_{i:05d}"
            d = Path(args.out) / split
            cv2.imwrite(str(d / "images" / f"{name}.jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 90])
            cv2.imwrite(str(d / "masks" / f"{name}.png"), mask)
            (d / "labels" / f"{name}.txt").write_text(yolo_line(cls, box, kpts, w, h) + "\n")
            (d / "meta" / f"{name}.json").write_text(json.dumps(meta))
        print(f"{split}: {n} images -> {Path(args.out) / split}")


if __name__ == "__main__":
    main()
