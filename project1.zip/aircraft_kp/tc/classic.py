"""CLASSICAL keypoint extraction inside a box you are GIVEN (no CNN, no training).

Input : an image and the box of the aircraft (from your team's detector).
Steps : 1. cut out the box (a little bigger),
        2. outline the aircraft inside it:
             "colour"  : paint colour (orange / red / yellow, like the Banshee) with HSV thresholds,
             "grabcut" : GrabCut (a classic region-growing algorithm started from the box),
             "auto"    : colour if a sensible share of the box has that colour, otherwise grabcut,
        3. straighten it along its main axis (normalize.py); a yellow nose cone, if found at one end,
           decides which end is the nose, otherwise the shape's skew decides,
        4. read the points from the outline (geometry.py).

Left/right wing and nose/tail are rules on the OUTLINE. They are reliable for a clear top or bottom
view of a delta wing and weak for side views of a fuselage + fin aircraft. Measure it against your
CVAT labels before believing it.
"""
import cv2
import numpy as np

from . import geometry
from .normalize import canonicalize


def _largest_filled(m):
    n, lbl, st, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    if n <= 1:
        return None
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    comp = (lbl == i).astype(np.uint8)
    cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(comp)
    cv2.drawContours(out, cnts, -1, 1, -1)
    return out


def colour_mask(crop_bgr):
    hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    m = (((h <= 35) | (h >= 170)) & (s > 110) & (v > 90)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    return cv2.morphologyEx(m, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))


def grabcut_mask(crop_bgr, rect, max_side=256, iters=5):
    h, w = crop_bgr.shape[:2]
    f = min(1.0, max_side / max(h, w))
    small = cv2.resize(crop_bgr, None, fx=f, fy=f, interpolation=cv2.INTER_AREA) if f < 1 else crop_bgr
    r = tuple(max(1, int(round(v * f))) for v in rect)
    mask = np.zeros(small.shape[:2], np.uint8)
    cv2.grabCut(small, mask, r, np.zeros((1, 65)), np.zeros((1, 65)), iters, cv2.GC_INIT_WITH_RECT)
    fg = ((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD)).astype(np.uint8)
    return cv2.resize(fg, (w, h), interpolation=cv2.INTER_NEAREST) if f < 1 else fg


def segment_in_box(img, box, mode="auto", pad=0.10):
    """Returns (mask 0/255 with the size of the image or None, method used)."""
    H, W = img.shape[:2]
    x1, y1, x2, y2 = [float(v) for v in box]
    bw, bh = x2 - x1, y2 - y1
    cx1, cy1 = int(max(0, x1 - pad * bw)), int(max(0, y1 - pad * bh))
    cx2, cy2 = int(min(W, x2 + pad * bw)), int(min(H, y2 + pad * bh))
    crop = img[cy1:cy2, cx1:cx2]
    rx1, ry1 = int(max(0, x1 - cx1)), int(max(0, y1 - cy1))
    rx2, ry2 = int(min(cx2 - cx1, x2 - cx1)), int(min(cy2 - cy1, y2 - cy1))
    if rx2 - rx1 < 8 or ry2 - ry1 < 8:
        return None, mode
    m, used = None, mode
    if mode in ("auto", "colour"):
        cm = colour_mask(crop)
        inner = np.zeros_like(cm)
        inner[ry1:ry2, rx1:rx2] = 1
        cm = cm & inner
        frac = cm.sum() / max((rx2 - rx1) * (ry2 - ry1), 1)
        if mode == "colour" or 0.10 < frac < 0.85:
            m, used = _largest_filled(cm), "colour"
    if m is None:
        m, used = _largest_filled(grabcut_mask(crop, (rx1, ry1, rx2 - rx1, ry2 - ry1))), "grabcut"
    if m is None:
        return None, used
    full = np.zeros((H, W), np.uint8)
    full[cy1:cy2, cx1:cx2] = m * 255
    return full, used


def yellow_cue(img, mask):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    return ((h >= 18) & (h <= 38) & (s > 100) & (v > 120) & (mask > 0)).astype(np.uint8)


def extract(img, box, mode="auto", use_cue=True):
    """Returns dict(ok, kpts (5,2) in image pixels, mask, mode, dir_source)."""
    mask, used = segment_in_box(img, box, mode)
    if mask is None:
        return dict(ok=False, kpts=None, mask=None, mode=used, dir_source=None)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    norm = canonicalize(gray, mask, cue_mask=yellow_cue(img, mask) if use_cue else None)
    if norm is None:
        return dict(ok=False, kpts=None, mask=mask, mode=used, dir_source=None)
    kn = geometry.predict(norm)
    kp = cv2.transform(kn.reshape(1, -1, 2).astype(np.float32), norm["Minv"].astype(np.float32))[0]
    return dict(ok=True, kpts=kp.astype(float), mask=mask, mode=used, dir_source=norm["dir_source"])
