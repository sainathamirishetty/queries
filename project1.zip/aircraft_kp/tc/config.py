"""Shared settings. Change keypoint definitions HERE and in your labels together."""

# Keypoint order. NEVER change after you start labelling.
# Same physical part = same index, from every viewing angle.
KP_NAMES = ["nose", "left_wing", "right_wing", "tail", "mid"]
NUM_KP = len(KP_NAMES)

# Definitions (same for Tejas and Banshee):
#   nose       front tip
#   left_wing  aircraft's OWN left wingtip (pilot's left), not the image-left
#   right_wing aircraft's OWN right wingtip
#   tail       rear end of the centreline (centre of the trailing edge),
#              NOT the top of Tejas's fin
#   mid        centre of the body (centreline meets the wingtip-to-wingtip line)

CLASS_NAMES = ["tejas", "banshee"]

# Size (pixels) of the straightened square crop the keypoint model works on.
CROP = 160

# Colours (BGR) used when drawing, same as the diagrams.
KP_COLORS = [(53, 57, 229), (71, 160, 67), (229, 136, 30), (37, 168, 249), (170, 36, 142)]
