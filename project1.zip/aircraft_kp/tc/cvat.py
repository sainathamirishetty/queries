"""Read CVAT annotations ("CVAT for images 1.1" XML export) and box lists.

In CVAT you mark the keypoints by hand on each photo. For the classical method these hand-made
points are NOT training data: they are the ANSWER KEY used to measure how close the method gets.

Label names are matched loosely (upper/lower case, spaces, underscores ignored):
    head / nose -> 0     left wing / left -> 1     right wing / right -> 2
    tail -> 3            centre / center / mid -> 4
Both layouts are read: separate <points> elements, and <skeleton> elements that contain <points>.
A point marked "outside" (not visible) is left empty (NaN).

NOTE: written from the CVAT 1.1 format description and tested only on files made by
make_cvat_demo.py. If your real export has a different layout, send me a small sample.
"""
import csv
import re
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

ALIASES = {"head": 0, "nose": 0, "leftwing": 1, "left": 1, "lwing": 1, "rightwing": 2, "right": 2,
           "rwing": 2, "tail": 3, "centre": 4, "center": 4, "mid": 4, "middle": 4}


def kp_index(label):
    return ALIASES.get(re.sub(r"[^a-z]", "", label.lower()))


def read_cvat_xml(path):
    """Returns {image file name: dict(box=[x1,y1,x2,y2] or None, kpts=(5,2) with NaN for missing)}."""
    root = ET.parse(path).getroot()
    out = {}
    for im in root.iter("image"):
        name = Path(im.get("name")).name
        box = None
        for b in im.findall("box"):
            box = [float(b.get(k)) for k in ("xtl", "ytl", "xbr", "ybr")]
            break
        kp = np.full((5, 2), np.nan)
        for pt in im.iter("points"):
            idx = kp_index(pt.get("label", ""))
            if idx is None or pt.get("outside", "0") == "1":
                continue
            x, y = pt.get("points").split(";")[0].split(",")
            kp[idx] = [float(x), float(y)]
        out[name] = dict(box=box, kpts=kp)
    return out


def read_boxes_csv(path):
    """CSV with columns: image,x1,y1,x2,y2 (header line optional). From your team's detector."""
    out = {}
    for row in csv.reader(open(path)):
        try:
            out[Path(row[0]).name] = [float(v) for v in row[1:5]]
        except ValueError:
            continue                                   # header line
    return out


def read_points_csv(path):
    """CSV with columns: image, then 10 numbers: head x,y, left x,y, right x,y, tail x,y, centre x,y."""
    out = {}
    for row in csv.reader(open(path)):
        try:
            out[Path(row[0]).name] = np.array([float(v) for v in row[1:11]]).reshape(5, 2)
        except ValueError:
            continue
    return out
