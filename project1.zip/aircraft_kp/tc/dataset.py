"""Read datasets in YOLO-pose label format (what CVAT / Roboflow export).

Folder layout:
    <data_dir>/images/*.jpg
    <data_dir>/labels/*.txt     one line per image:
        class cx cy w h  x1 y1 v1  x2 y2 v2 ... x5 y5 v5     (all 0..1)
Only the first object in each label file is used.
"""
from pathlib import Path

import numpy as np

from .config import NUM_KP

IMG_EXTS = {".jpg", ".jpeg", ".png"}


def list_samples(data_dir):
    d = Path(data_dir)
    imgs = sorted(p for p in (d / "images").iterdir() if p.suffix.lower() in IMG_EXTS)
    out = []
    for p in imgs:
        lab = d / "labels" / (p.stem + ".txt")
        if lab.exists():
            out.append((p, lab))
    return out


def read_label(label_path, w, h):
    lines = Path(label_path).read_text().strip().splitlines()
    if not lines:
        return None
    vals = lines[0].split()
    if len(vals) < 5 + 3 * NUM_KP:
        return None
    v = np.array(vals[: 5 + 3 * NUM_KP], dtype=float)
    cls = int(v[0])
    cx, cy, bw, bh = v[1:5]
    box = np.array([(cx - bw / 2) * w, (cy - bh / 2) * h, (cx + bw / 2) * w, (cy + bh / 2) * h])
    k = v[5:].reshape(NUM_KP, 3)
    kpts = np.stack([k[:, 0] * w, k[:, 1] * h], axis=1)
    return dict(cls=cls, box=box, kpts=kpts, vis=k[:, 2])
