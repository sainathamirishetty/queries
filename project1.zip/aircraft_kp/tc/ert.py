"""METHOD B: ERT keypoint regression (non-CNN, learned) with VIEW GROUPS.

ERT = Ensemble of Regression Trees (Kazemi and Sullivan, CVPR 2014, "One Millisecond
Face Alignment"). dlib implements it. It starts from an average shape and refines it
step by step using simple pixel-difference tests inside trees. No convolutions.

Why view groups? One regressor struggles when the same keypoint can look very
different (side view vs top view vs head-on). We cluster the training shapes into K
groups with a few cheap numbers (elongation, aspect ratio, skew, fill) and train one
small ERT per group. At test time the same numbers pick the group. A global model
is kept as a fallback for groups with too few samples.

dlib stores keypoints as whole pixels, so predictions are rounded to 1 pixel of the
CROP x CROP straightened image.
"""
from pathlib import Path

import cv2
import dlib
import numpy as np

from .config import CROP, NUM_KP

OPTS = dict(tree_depth=4, nu=0.1, cascade_depth=12, feature_pool_size=400,
            num_test_splits=40, oversampling_amount=20,
            oversampling_translation_jitter=0.05, num_trees_per_cascade_level=300,
            lambda_param=0.1)
MIN_PER_GROUP = 40


def _rect():
    return dlib.rectangle(0, 0, CROP - 1, CROP - 1)


def _train_one(crops, kpts, threads):
    opts = dlib.shape_predictor_training_options()
    for k, v in OPTS.items():
        setattr(opts, k, v)
    opts.num_threads = int(threads)
    opts.be_verbose = False
    dets = []
    for kp in kpts:
        parts = dlib.points([dlib.point(int(round(x)), int(round(y))) for x, y in kp])
        dets.append(dlib.full_object_detections())
        dets[-1].append(dlib.full_object_detection(_rect(), parts))
    return dlib.train_shape_predictor(list(crops), dets, opts)


class ERTModel:
    def __init__(self):
        self.k = 0
        self.mean = self.std = self.centers = None
        self.models = {}          # group -> shape_predictor (or missing -> use global)
        self.global_model = None

    # ---- training ----
    def fit(self, crops, kpts_norm, descs, k=3, threads=2):
        descs = np.asarray(descs, np.float32)
        self.mean, self.std = descs.mean(0), descs.std(0) + 1e-6
        z = ((descs - self.mean) / self.std).astype(np.float32)
        self.k = int(k)
        if self.k > 1:
            cv2.setRNGSeed(0)
            _, labels, centers = cv2.kmeans(
                z, self.k, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-4),
                10, cv2.KMEANS_PP_CENTERS)
            self.centers, labels = centers, labels.ravel()
        else:
            self.centers, labels = np.zeros((1, z.shape[1]), np.float32), np.zeros(len(z), int)
        self.global_model = _train_one(crops, kpts_norm, threads)
        sizes = {}
        for g in range(self.k):
            idx = np.nonzero(labels == g)[0]
            sizes[g] = len(idx)
            if self.k > 1 and len(idx) >= MIN_PER_GROUP:
                self.models[g] = _train_one([crops[i] for i in idx], [kpts_norm[i] for i in idx], threads)
        return sizes

    # ---- inference ----
    def assign(self, desc):
        z = ((np.asarray(desc, np.float32) - self.mean) / self.std)
        return int(np.argmin(((self.centers - z) ** 2).sum(axis=1)))

    def predict(self, crop_gray, desc):
        g = self.assign(desc)
        sp = self.models.get(g, self.global_model)
        det = sp(np.ascontiguousarray(crop_gray), _rect())
        pts = np.array([[det.part(i).x, det.part(i).y] for i in range(NUM_KP)], float)
        return pts, g

    # ---- save / load ----
    def save(self, d):
        d = Path(d)
        d.mkdir(parents=True, exist_ok=True)
        self.global_model.save(str(d / "global.dat"))
        for g, sp in self.models.items():
            sp.save(str(d / f"group_{g}.dat"))
        np.savez(d / "meta.npz", mean=self.mean, std=self.std, centers=self.centers,
                 k=self.k, groups=np.array(sorted(self.models), dtype=int))

    @classmethod
    def load(cls, d):
        d = Path(d)
        m = cls()
        meta = np.load(d / "meta.npz")
        m.mean, m.std, m.centers, m.k = meta["mean"], meta["std"], meta["centers"], int(meta["k"])
        m.global_model = dlib.shape_predictor(str(d / "global.dat"))
        for g in meta["groups"]:
            m.models[int(g)] = dlib.shape_predictor(str(d / f"group_{int(g)}.dat"))
        return m
