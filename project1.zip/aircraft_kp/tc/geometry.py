"""METHOD A: pure geometry baseline (no learning at all).

Works in the straightened frame (nose to the right):
    nose  = right-most part of the silhouette
    tail  = centre of the left-most part (trailing edge of a delta wing)
    wings = top-most and bottom-most parts of the silhouette
    mid   = centroid of the silhouette

Left/right ASSUMPTION: we see the aircraft from ABOVE. With the nose pointing right
the pilot's left is the top of the picture, so left_wing = top-most point. From
BELOW the true left and right are swapped, and a silhouette alone cannot tell
top from bottom. So this baseline is expected to swap left/right on bottom views.
That is the honest reason to compare it with a learned method.
"""
import numpy as np

from .config import CROP


def predict(norm, tol_frac=0.02):
    p = norm["pts_norm"]
    tol = tol_frac * CROP
    nose = p[p[:, 0] >= p[:, 0].max() - tol].mean(axis=0)
    tail = p[p[:, 0] <= p[:, 0].min() + tol].mean(axis=0)
    left = p[p[:, 1] <= p[:, 1].min() + tol].mean(axis=0)
    right = p[p[:, 1] >= p[:, 1].max() - tol].mean(axis=0)
    mid = np.asarray(norm["centroid_norm"], float)
    return np.array([nose, left, right, tail, mid])
