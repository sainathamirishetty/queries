"""Error measures. Everything is divided by the size of the object so that big and
small aircraft are comparable: error% = pixel error / diagonal of the object's box."""
import numpy as np


def box_diag(box):
    return float(np.hypot(box[2] - box[0], box[3] - box[1]))


def norm_errors(pred, gt, box):
    """Per-keypoint error as a fraction of the box diagonal (5,)."""
    return np.linalg.norm(pred - gt, axis=1) / box_diag(box)


def wing_swapped(pred, gt):
    """True if left and right wing are closer to each other's ground truth."""
    direct = np.linalg.norm(pred[1] - gt[1]) + np.linalg.norm(pred[2] - gt[2])
    swap = np.linalg.norm(pred[1] - gt[2]) + np.linalg.norm(pred[2] - gt[1])
    return bool(swap < direct)


def nose_tail_swapped(pred, gt):
    direct = np.linalg.norm(pred[0] - gt[0]) + np.linalg.norm(pred[3] - gt[3])
    swap = np.linalg.norm(pred[0] - gt[3]) + np.linalg.norm(pred[3] - gt[0])
    return bool(swap < direct)
