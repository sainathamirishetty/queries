"""STAGE 2: straighten the aircraft.

From the mask we find the main axis (the long direction of the shape) and rotate
+ scale + crop so that the axis is horizontal and the object fills a fixed-size
square. The nose should end up on the RIGHT (+x). This removes in-plane rotation
so the keypoint model sees far fewer variations.

How we choose which end is the nose: along the axis, a delta wing is thin at the
nose and wide at the rear, so the pixel distribution is skewed toward the nose.
We point the axis in the direction of positive skew. This is a heuristic: it works
for top/bottom views and can be wrong for side or head-on views. Those failures
are exactly what the evaluation reports.
"""
import cv2
import numpy as np

from .config import CROP


def canonicalize(gray, mask, crop=CROP, fill=0.8, max_pts=3000, cue_mask=None, cue_min=15):
    """cue_mask (optional): pixels that mark the NOSE end by colour (for example the yellow nose cone
    of a Banshee). If they sit at exactly one end of the main axis, that end is the nose."""
    ys, xs = np.nonzero(mask)
    if len(xs) < 30:
        return None
    pts = np.stack([xs, ys], axis=1).astype(np.float64)
    c = pts.mean(axis=0)
    d = pts - c
    cov = d.T @ d / len(d)
    ev, evec = np.linalg.eigh(cov)                  # ascending eigenvalues
    u = evec[:, 1]                                  # main axis
    proj = d @ u
    sd = proj.std() + 1e-9
    skew = float((proj ** 3).mean() / sd ** 3)
    flip, dir_source = skew < 0, "skew"
    if cue_mask is not None:
        cy_, cx_ = np.nonzero(cue_mask)
        if len(cx_) >= cue_min:
            pc = (np.stack([cx_, cy_], axis=1) - c) @ u
            lo, hi = proj.min(), proj.max()
            at_pos = int((pc > hi - 0.2 * (hi - lo)).sum())
            at_neg = int((pc < lo + 0.2 * (hi - lo)).sum())
            if at_pos >= cue_min and at_neg < 0.25 * at_pos:
                flip, dir_source = False, "cue"
            elif at_neg >= cue_min and at_pos < 0.25 * at_neg:
                flip, dir_source = True, "cue"
    if flip:
        u, skew = -u, -skew
    ang = np.arctan2(u[1], u[0])
    ca, sa = np.cos(ang), np.sin(ang)
    A = np.array([[ca, sa], [-sa, ca]])             # maps u -> (1, 0)
    q = d @ A.T
    mn, mx = q.min(axis=0), q.max(axis=0)
    ext = float((mx - mn).max())
    scale = fill * crop / max(ext, 1e-6)
    ctr = (mn + mx) / 2
    M = np.zeros((2, 3))
    M[:, :2] = scale * A
    M[:, 2] = -scale * (A @ c) - scale * ctr + crop / 2

    crop_img = cv2.warpAffine(gray, M, (crop, crop), flags=cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    maskw = cv2.warpAffine(mask, M, (crop, crop), flags=cv2.INTER_NEAREST)
    crop_img = np.ascontiguousarray(crop_img * (maskw > 0))     # background -> 0

    step = max(1, len(q) // max_pts)
    pts_norm = (q[::step] - ctr) * scale + crop / 2
    centroid_norm = (-ctr) * scale + crop / 2                   # centroid of q is 0
    ex = (mx - mn)
    desc = np.array([
        np.sqrt(max(ev[0], 0) / max(ev[1], 1e-9)),   # elongation (thin = edge-on view)
        ex[1] / max(ex[0], 1e-9),                    # aspect ratio
        min(abs(skew), 2.0),                         # skew
        len(pts) / max(ex[0] * ex[1], 1e-9),         # how much of its box the shape fills
    ])
    return dict(crop=crop_img, maskw=maskw, M=M, Minv=cv2.invertAffineTransform(M),
                pts_norm=pts_norm, centroid_norm=centroid_norm, desc=desc, dir_source=dir_source)
