"""The whole pipeline: image in, 5 keypoints out, with timing per stage."""
from time import perf_counter

import cv2
import numpy as np

from . import geometry
from .normalize import canonicalize
from .refine import snap_to_silhouette
from .segment import segment


class Pipeline:
    """method: "geometry" (Method A) or "ert" (Method B). refine: snap to silhouette."""

    def __init__(self, method="ert", ert_model=None, refine=False):
        self.method, self.ert, self.refine = method, ert_model, refine
        if method == "ert" and ert_model is None:
            raise ValueError("method 'ert' needs a trained ERT model")

    def run(self, img_bgr):
        t0 = perf_counter()
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        mask = segment(img_bgr)
        t1 = perf_counter()
        res = dict(ok=False, kpts=None, mask=mask, group=-1, ms={})
        if mask is None:
            res["ms"] = dict(segment=(t1 - t0) * 1e3, total=(t1 - t0) * 1e3)
            return res
        norm = canonicalize(gray, mask)
        t2 = perf_counter()
        if norm is None:
            res["ms"] = dict(segment=(t1 - t0) * 1e3, total=(t2 - t0) * 1e3)
            return res
        group = self.ert.assign(norm["desc"]) if self.ert is not None else -1
        if self.method == "geometry":
            kn = geometry.predict(norm)
        else:
            kn, group = self.ert.predict(norm["crop"], norm["desc"])
        t3 = perf_counter()
        if self.refine:
            kn = snap_to_silhouette(kn, norm["maskw"], norm["centroid_norm"])
        t4 = perf_counter()
        kp = cv2.transform(kn.reshape(1, -1, 2).astype(np.float32), norm["Minv"].astype(np.float32))[0]
        res.update(ok=True, kpts=kp.astype(float), group=group, norm=norm,
                   ms=dict(segment=(t1 - t0) * 1e3, normalize=(t2 - t1) * 1e3,
                           keypoints=(t3 - t2) * 1e3, refine=(t4 - t3) * 1e3,
                           total=(t4 - t0) * 1e3))
        return res
