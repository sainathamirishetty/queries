"""STAGE 4 (refine): snap keypoints that sit on the silhouette back onto the silhouette.

nose / left_wing / right_wing are the most extreme points of the shape, so among the
outline pixels near the prediction we take the one FARTHEST from the centre.
tail is the middle of the trailing edge, so we take the NEAREST outline pixel.
mid is inside the body and is left alone.

Whether this helps is measured by evaluate.py (compare "ert" and "ert+refine").
Not implemented yet (ideas for later): check left/right with a 3D model and
solvePnP, and smoothing + Lucas-Kanade tracking between video frames.
"""
import cv2
import numpy as np

from .config import CROP


def snap_to_silhouette(kp_norm, maskw, centroid_norm, radius_frac=0.10):
    cnts, _ = cv2.findContours(maskw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not cnts:
        return kp_norm
    pts = np.vstack([c[:, 0, :] for c in cnts]).astype(float)
    r = radius_frac * CROP
    out = kp_norm.copy()
    dc = np.linalg.norm(pts - np.asarray(centroid_norm), axis=1)
    for i in range(4):
        near = np.linalg.norm(pts - kp_norm[i], axis=1) <= r
        if not near.any():
            continue
        cand = np.nonzero(near)[0]
        if i == 3:                                  # tail: nearest outline pixel
            j = cand[np.argmin(np.linalg.norm(pts[cand] - kp_norm[i], axis=1))]
        else:                                       # extremes: farthest from centre
            j = cand[np.argmax(dc[cand])]
        out[i] = pts[j]
    return out
