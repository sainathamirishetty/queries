"""STAGE 1: find the aircraft (classic image processing, no training).

Idea: an aircraft has SHARP edges, the sky and clouds do not. We
  1. blur a little, convert to Lab colour, and measure the edge strength (Sobel),
  2. keep only strong edges (a fraction of the strongest edges in the image),
  3. close small gaps, take the biggest outline and fill it, then shrink 2 px
     to remove the thickness the edge detector adds.
An earlier version compared every pixel with the median colour of its row (sky model);
it failed whenever a wide cloud covered more than half a row, so it was replaced.

THE SETTINGS BELOW WERE TUNED ON SYNTHETIC IMAGES. Real photos (haze, motion blur,
birds, buildings, other aircraft) will need re-tuning, or a better stage 1.
Always check the mask on real photos (python demo.py shows results) before trusting numbers.
"""
import cv2
import numpy as np


def segment(img_bgr, work_max=320, edge_frac=0.4, floor=40.0, sigma=1.0, close=5, erode=5,
            min_area=0.001, max_area=0.5):
    """Return a 0/255 uint8 mask (same size as the image) or None if nothing found."""
    h, w = img_bgr.shape[:2]
    f = min(1.0, work_max / max(h, w))
    small = cv2.resize(img_bgr, (int(w * f), int(h * f)), interpolation=cv2.INTER_AREA) if f < 1 else img_bgr
    lab = cv2.cvtColor(cv2.GaussianBlur(small, (0, 0), sigma), cv2.COLOR_BGR2LAB).astype(np.float32)
    gx = cv2.Sobel(lab, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(lab, cv2.CV_32F, 0, 1, ksize=3)
    g = np.sqrt((gx ** 2 + gy ** 2).sum(axis=2))          # edge strength
    gmax = float(np.percentile(g, 99.7))
    if gmax < floor:                                       # no strong edges: nothing to find
        return None
    e = (g > max(edge_frac * gmax, floor * 0.5)).astype(np.uint8)
    e = cv2.morphologyEx(e, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close, close)))
    cnts, _ = cv2.findContours(e, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)                     # biggest outline
    m = np.zeros(e.shape, np.uint8)
    cv2.drawContours(m, [c], -1, 1, -1)                    # fill it
    if erode:
        m = cv2.erode(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (erode, erode)))
    frac = m.sum() / m.size
    if frac < min_area or frac > max_area:
        return None
    if f < 1:
        m = cv2.resize(m, (w, h), interpolation=cv2.INTER_NEAREST)
    return m * 255
