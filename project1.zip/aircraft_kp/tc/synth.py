"""SYNTHETIC aircraft images, for testing the pipeline before you have real data.

A small 3D delta-wing model is rotated to a random view (any angle, including
top, bottom, head-on and upside down), drawn over a sky, and the 5 keypoints
are projected EXACTLY. Because the keypoints belong to the 3D model, point 1 is
always the aircraft's own left wing, from any view. This is the "same part =
same index" rule your team asked for.

Class 0 "tejas"   : delta wing + vertical fin
Class 1 "banshee" : delta wing, no fin (wider, slightly different proportions)

IMPORTANT: these are cartoon-like shapes. Results on them do NOT prove the
method works on real Tejas / Banshee photos. They only prove the code works.
"""
import numpy as np
import cv2


def random_rotation(rng):
    q = rng.normal(size=4)
    q /= np.linalg.norm(q)
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def build_model(cls, rng):
    """Object frame (right-handed): x forward, y to the aircraft's LEFT, z up.
    (forward, right, up would be left-handed = a mirror image, so y must point LEFT.)"""
    if cls == 0:   # tejas-like
        half_span, rear, fin = rng.uniform(0.55, 0.66), -0.5, True
        top_c, bot_c, fin_c = (128, 122, 112), (88, 86, 82), (112, 106, 98)
    else:          # banshee-like
        half_span, rear, fin = rng.uniform(0.60, 0.74), -0.45, False
        top_c, bot_c, fin_c = (172, 172, 170), (112, 112, 116), (150, 150, 150)
    v = dict(
        N=(1.0, 0, 0), L=(rear, half_span, 0), R=(rear, -half_span, 0), T=(rear, 0, 0),
        H=(-0.1, 0, 0.15), B=(-0.1, 0, -0.10),
        F1=(-0.15, 0, 0.12), F2=(rear, 0, 0.12), F3=(rear, 0, 0.40),
    )
    faces = [
        (("N", "R", "H"), top_c), (("R", "T", "H"), top_c), (("T", "L", "H"), top_c), (("L", "N", "H"), top_c),
        (("N", "B", "R"), bot_c), (("R", "B", "T"), bot_c), (("T", "B", "L"), bot_c), (("L", "B", "N"), bot_c),
    ]
    if fin:
        faces.append((("F1", "F2", "F3"), fin_c))
    mid = ((1.0 + 2 * rear) / 3.0, 0, 0)
    # keypoint order must match tc.config.KP_NAMES: nose, left, right, tail, mid
    kp3d = [v["N"], v["L"], v["R"], v["T"], mid]
    return v, faces, kp3d


def make_sky(W, H, rng):
    top = np.array([rng.uniform(150, 215), rng.uniform(110, 165), rng.uniform(40, 110)])
    bot = np.clip(top + rng.uniform(20, 65, size=3), 0, 255)
    t = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    img = (top * (1 - t) + bot * t) * np.ones((1, W, 1), np.float32)
    for _ in range(rng.integers(0, 5)):
        layer = np.zeros((H, W), np.float32)
        cv2.ellipse(layer, (int(rng.uniform(0, W)), int(rng.uniform(0, H))),
                    (int(rng.uniform(40, 160)), int(rng.uniform(15, 60))), 0, 0, 360,
                    float(rng.uniform(0.2, 0.45)), -1)
        layer = cv2.GaussianBlur(layer, (0, 0), rng.uniform(18, 40))[..., None]
        img = img * (1 - layer) + 255 * layer
    img += rng.normal(0, rng.uniform(1.0, 4.0), img.shape)
    return np.clip(img, 0, 255).astype(np.uint8)


def render(cls, rng, W=640, H=480, views="all"):
    """Returns image (BGR), keypoints (5,2) px, mask (H,W) uint8, box xyxy, meta dict.

    views="all"   : any viewing direction (top, bottom, head-on, edge-on...)
    views="below" : camera sees the UNDERSIDE only (like a camera on the ground looking up)
    meta: side ("top"/"bottom") and elev (1 = seen flat-on, 0 = seen exactly edge-on)
    """
    verts, faces, kp3d = build_model(cls, rng)
    R = random_rotation(rng)                      # object -> camera (x right, y down, z forward)
    while views == "below" and R[2, 2] < 0:       # up axis pointing away from camera = underside visible
        R = random_rotation(rng)
    cam = {k: R @ np.array(p, float) for k, p in verts.items()}
    kcam = [R @ np.array(p, float) for p in kp3d]
    s = rng.uniform(110, 280) / 1.5
    margin = 12
    while True:
        allp = np.array([[p[0], p[1]] for p in cam.values()]) * s
        mn, mx = allp.min(0), allp.max(0)
        lo, hi = margin - mn, np.array([W, H]) - margin - mx
        if np.all(hi >= lo):
            break
        s *= 0.85
    off = rng.uniform(lo, hi)

    img = make_sky(W, H, rng)
    mask = np.zeros((H, W), np.uint8)
    light = np.array([-0.3, -0.5, -0.8])
    light /= np.linalg.norm(light)
    order = sorted(faces, key=lambda f: -np.mean([cam[n][2] for n in f[0]]))   # far first
    for names, color in order:
        P3 = np.array([cam[n] for n in names])
        P2 = P3[:, :2] * s + off
        nrm = np.cross(P3[1] - P3[0], P3[2] - P3[0])
        nrm /= (np.linalg.norm(nrm) + 1e-9)
        shade = 0.55 + 0.45 * abs(float(nrm @ light))
        col = tuple(int(np.clip(c * shade, 0, 255)) for c in color)
        cv2.fillConvexPoly(img, np.round(P2 * 16).astype(np.int32), col, cv2.LINE_AA, shift=4)
        cv2.fillConvexPoly(mask, np.round(P2 * 16).astype(np.int32), 255, cv2.LINE_8, shift=4)
    sigma = rng.uniform(0.0, 1.0)
    if sigma > 0.3:
        img = cv2.GaussianBlur(img, (0, 0), sigma)
    kpts = np.array([[p[0] * s + off[0], p[1] * s + off[1]] for p in kcam])
    ys, xs = np.nonzero(mask)
    box = np.array([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1], float)
    meta = dict(cls=int(cls), side="bottom" if R[2, 2] > 0 else "top", elev=float(abs(R[2, 2])))
    return img, kpts, mask, box, meta


def yolo_line(cls, box, kpts, W, H):
    cx, cy = (box[0] + box[2]) / 2 / W, (box[1] + box[3]) / 2 / H
    bw, bh = (box[2] - box[0]) / W, (box[3] - box[1]) / H
    s = f"{cls} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}"
    for x, y in kpts:
        s += f" {x / W:.6f} {y / H:.6f} 2"
    return s
