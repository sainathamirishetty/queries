"""Train Method B (ERT keypoints with view groups) from a labelled dataset.

    python train_ert.py --data data/synth/train --out models/ert --groups 3

Training uses the SAME stage 1 + stage 2 as inference (segment -> straighten), so the
model learns from exactly what it will see later. Images where stage 1 fails
(mask does not overlap the labelled box) are skipped and counted.
"""
import argparse
import os
from pathlib import Path

import cv2
import numpy as np

from tc.config import CROP
from tc.dataset import list_samples, read_label
from tc.ert import ERTModel
from tc.normalize import canonicalize
from tc.segment import segment


def box_iou(a, b):
    ix1, iy1, ix2, iy2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / max(union, 1e-9)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/synth/train")
    ap.add_argument("--out", default="models/ert")
    ap.add_argument("--groups", type=int, default=3, help="number of view groups (1 = a single model)")
    ap.add_argument("--threads", type=int, default=os.cpu_count() or 1)
    args = ap.parse_args()

    crops, kps, descs = [], [], []
    skipped = dict(no_label=0, no_mask=0, bad_mask=0, out_of_crop=0)
    samples = list_samples(args.data)
    for ip, lp in samples:
        img = cv2.imread(str(ip))
        h, w = img.shape[:2]
        gt = read_label(lp, w, h)
        if gt is None:
            skipped["no_label"] += 1
            continue
        mask = segment(img)
        if mask is None:
            skipped["no_mask"] += 1
            continue
        ys, xs = np.nonzero(mask)
        if box_iou([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1], gt["box"]) < 0.5:
            skipped["bad_mask"] += 1
            continue
        norm = canonicalize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), mask)
        if norm is None:
            skipped["no_mask"] += 1
            continue
        kn = cv2.transform(gt["kpts"].reshape(1, -1, 2), norm["M"])[0]
        if kn.min() < -2 or kn.max() > CROP + 1:
            skipped["out_of_crop"] += 1
            continue
        crops.append(norm["crop"])
        kps.append(np.clip(kn, 0, CROP - 1))
        descs.append(norm["desc"])

    print(f"samples: {len(samples)}  used for training: {len(crops)}  skipped: {skipped}")
    if len(crops) < 50:
        raise SystemExit("Too few usable samples (need at least ~50). Check labels and stage 1.")
    model = ERTModel()
    sizes = model.fit(crops, kps, descs, k=args.groups, threads=args.threads)
    model.save(args.out)
    print("view groups (size):", sizes, "| groups with their own model:", sorted(model.models))
    print("saved to", Path(args.out).resolve())


if __name__ == "__main__":
    main()
