
import cv2
import os

# 1. Image path
image_path = "images/banshee.jpeg"

# 2. Load image
image = cv2.imread(image_path)

# 3. Check image loading
if image is None:
    raise FileNotFoundError(f"Image not found: {image_path}")

# 4. Get image properties
height, width, channels = image.shape

print("Image loaded successfully!")
print("Width:", width)
print("Height:", height)
print("Channels:", channels)
print("Total pixels:", width * height)

# 5. Display image
cv2.imshow("Stage 1 - Original Banshee Image", image)

# 6. Save a copy
cv2.imwrite("outputs/stage1_original.jpg", image)

cv2.waitKey(0)
cv2.destroyAllWindows()
