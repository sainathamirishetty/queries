
import cv2
import matplotlib.pyplot as plt

# Load original image
image_path = "images/banshee.jpeg"
image = cv2.imread(image_path)

if image is None:
    raise FileNotFoundError(f"Image not found: {image_path}")

# Convert BGR image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Print image information
print("Original image shape:", image.shape)
print("Grayscale image shape:", gray.shape)
print("Minimum pixel intensity:", gray.min())
print("Maximum pixel intensity:", gray.max())

# Display original and grayscale images
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title("Original Banshee Image")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(gray, cmap="gray")
plt.title("Grayscale Banshee Image")
plt.axis("off")

plt.tight_layout()
plt.show()

# Save grayscale image
cv2.imwrite("outputs/stage2_grayscale.jpg", gray)
print("Grayscale image saved successfully!")
