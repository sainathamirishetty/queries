
import cv2
import matplotlib.pyplot as plt

# Load image
image = cv2.imread("images/banshee.jpeg")

if image is None:
    raise FileNotFoundError("Image not found")

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Gaussian blur
blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Apply Otsu thresholding
threshold_value, binary = cv2.threshold(
    blurred,
    0,
    255,
    cv2.THRESH_BINARY + cv2.THRESH_OTSU
)

# Display results
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.imshow(gray, cmap="gray")
plt.title("Grayscale")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(binary, cmap="gray")
plt.title("Otsu Binary Threshold")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(cv2.Canny(blurred, 50, 150), cmap="gray")
plt.title("Canny Edges")
plt.axis("off")

plt.tight_layout()
plt.show()

# Save result
cv2.imwrite("outputs/stage2_otsu.jpg", binary)

print("Otsu thresholding completed!")
print("Automatically selected threshold:", threshold_value)
print("Binary image shape:", binary.shape)
print("White pixels:", cv2.countNonZero(binary))
print("Black pixels:", binary.size - cv2.countNonZero(binary))
