
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the cleaned binary mask
mask = cv2.imread(
    "outputs/stage3_closing.jpg",
    cv2.IMREAD_GRAYSCALE
)

if mask is None:
    raise FileNotFoundError("Cleaned mask not found")

# Convert to binary mask
_, binary = cv2.threshold(
    mask, 127, 255, cv2.THRESH_BINARY
)

# Connected Component Analysis
num_labels, labels, stats, centroids = (
    cv2.connectedComponentsWithStats(
        binary,
        connectivity=8
    )
)

print("Connected Components Analysis")
print("Total labels including background:", num_labels)
print("Detected foreground components:", num_labels - 1)

# Create colour visualization
output = np.zeros(
    (binary.shape[0], binary.shape[1], 3),
    dtype=np.uint8
)

for i in range(1, num_labels):

    x = stats[i, cv2.CC_STAT_LEFT]
    y = stats[i, cv2.CC_STAT_TOP]
    w = stats[i, cv2.CC_STAT_WIDTH]
    h = stats[i, cv2.CC_STAT_HEIGHT]
    area = stats[i, cv2.CC_STAT_AREA]

    # Give each component a different colour
    output[labels == i] = np.random.randint(
        50, 255, size=3
    )

    print(
        f"Component {i}: "
        f"Area={area}, "
        f"Bounding Box=({x}, {y}, {w}, {h})"
    )

# Display results
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.imshow(binary, cmap="gray")
plt.title("Cleaned Binary Mask")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(output)
plt.title("Connected Components")
plt.axis("off")

plt.tight_layout()
plt.show()

# Save visualization
cv2.imwrite(
    "outputs/stage3_connected_components.jpg",
    cv2.cvtColor(output, cv2.COLOR_RGB2BGR)
)

print("Connected component analysis completed!")
