
import cv2
import numpy as np
import matplotlib.pyplot as plt

# 1. Load original image
image = cv2.imread("images/banshee.jpeg")

if image is None:
    raise FileNotFoundError("Image not found. Check the image path.")

# 2. Convert BGR to HSV
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# 3. Define red colour ranges
lower_red1 = np.array([0, 70, 50])
upper_red1 = np.array([10, 255, 255])

lower_red2 = np.array([170, 70, 50])
upper_red2 = np.array([179, 255, 255])

# 4. Define yellow colour range
lower_yellow = np.array([15, 70, 70])
upper_yellow = np.array([40, 255, 255])

# 5. Create colour masks
red_mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
red_mask2 = cv2.inRange(hsv, lower_red2, upper_red2)

red_mask = cv2.bitwise_or(red_mask1, red_mask2)

yellow_mask = cv2.inRange(
    hsv, lower_yellow, upper_yellow
)

# 6. Combine red and yellow masks
combined_mask = cv2.bitwise_or(red_mask, yellow_mask)

# 7. Apply mask to original image
segmented = cv2.bitwise_and(
    image, image, mask=combined_mask
)

# 8. Display results
plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title("Original Banshee")
plt.axis("off")

plt.subplot(2, 2, 2)
plt.imshow(red_mask, cmap="gray")
plt.title("Red Colour Mask")
plt.axis("off")

plt.subplot(2, 2, 3)
plt.imshow(yellow_mask, cmap="gray")
plt.title("Yellow Colour Mask")
plt.axis("off")

plt.subplot(2, 2, 4)
plt.imshow(cv2.cvtColor(segmented, cv2.COLOR_BGR2RGB))
plt.title("Combined Red + Yellow Segmentation")
plt.axis("off")

plt.tight_layout()
plt.show()

# 9. Save outputs
cv2.imwrite("outputs/stage3_red_mask.jpg", red_mask)
cv2.imwrite("outputs/stage3_yellow_mask.jpg", yellow_mask)
cv2.imwrite("outputs/stage3_combined_mask.jpg", combined_mask)
cv2.imwrite("outputs/stage3_segmented.jpg", segmented)

# 10. Print statistics
print("HSV segmentation completed!")
print("Red pixels:", cv2.countNonZero(red_mask))
print("Yellow pixels:", cv2.countNonZero(yellow_mask))
print("Combined colour pixels:", cv2.countNonZero(combined_mask))
print("Total image pixels:", combined_mask.size)
