
import cv2
import numpy as np
import matplotlib.pyplot as plt

# 1. Load original image
image = cv2.imread("images/banshee.jpeg")

if image is None:
    raise FileNotFoundError("Image not found")

# 2. Convert to HSV
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# 3. Define red ranges
lower_red1 = np.array([0, 70, 50])
upper_red1 = np.array([10, 255, 255])

lower_red2 = np.array([170, 70, 50])
upper_red2 = np.array([179, 255, 255])

# 4. Define yellow range
lower_yellow = np.array([15, 70, 70])
upper_yellow = np.array([40, 255, 255])

# 5. Create masks
red1 = cv2.inRange(hsv, lower_red1, upper_red1)
red2 = cv2.inRange(hsv, lower_red2, upper_red2)

red_mask = cv2.bitwise_or(red1, red2)

yellow_mask = cv2.inRange(
    hsv, lower_yellow, upper_yellow
)

# 6. Combine masks
combined_mask = cv2.bitwise_or(
    red_mask, yellow_mask
)

# 7. Create 5x5 kernel
kernel = np.ones((5, 5), np.uint8)

# 8. Apply morphological opening
opening = cv2.morphologyEx(
    combined_mask,
    cv2.MORPH_OPEN,
    kernel
)

# 9. Apply morphological closing
closing = cv2.morphologyEx(
    opening,
    cv2.MORPH_CLOSE,
    kernel
)

# 10. Display results
plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
plt.imshow(combined_mask, cmap="gray")
plt.title("Original HSV Mask")
plt.axis("off")

plt.subplot(2, 2, 2)
plt.imshow(opening, cmap="gray")
plt.title("After Opening")
plt.axis("off")

plt.subplot(2, 2, 3)
plt.imshow(closing, cmap="gray")
plt.title("After Closing")
plt.axis("off")

plt.subplot(2, 2, 4)
segmented = cv2.bitwise_and(
    image, image, mask=closing
)
plt.imshow(cv2.cvtColor(segmented, cv2.COLOR_BGR2RGB))
plt.title("Final Cleaned Segmentation")
plt.axis("off")

plt.tight_layout()
plt.show()

# 11. Save results
cv2.imwrite("outputs/stage3_opening.jpg", opening)
cv2.imwrite("outputs/stage3_closing.jpg", closing)
cv2.imwrite("outputs/stage3_cleaned.jpg", closing)

# 12. Print statistics
print("Morphological operations completed!")
print("Original mask pixels:", cv2.countNonZero(combined_mask))
print("After opening:", cv2.countNonZero(opening))
print("After closing:", cv2.countNonZero(closing))
