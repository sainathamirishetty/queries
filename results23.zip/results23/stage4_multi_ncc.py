
import cv2
import matplotlib.pyplot as plt

# 1. Load images
reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check image filenames")

# 2. Enlarge reference for ROI selection
scale = 1.5

display_image = cv2.resize(
    reference,
    None,
    fx=scale,
    fy=scale,
    interpolation=cv2.INTER_CUBIC
)

template_names = [
    "Nose and Fuselage",
    "Central Junction",
    "Wing Region"
]

colors = [
    (0, 255, 0),
    (255, 0, 0),
    (0, 165, 255)
]

templates = []

# 3. Select three templates
for name in template_names:

    print("\nSelect template:", name)

    x, y, w, h = cv2.selectROI(
        "Select " + name,
        display_image,
        showCrosshair=True,
        fromCenter=False
    )

    cv2.destroyAllWindows()

    if w == 0 or h == 0:
        raise ValueError(
            "No selection made for " + name
        )

    # Convert coordinates to original scale
    x = round(x / scale)
    y = round(y / scale)
    w = round(w / scale)
    h = round(h / scale)

    template = reference[y:y+h, x:x+w]

    template_gray = cv2.cvtColor(
        template, cv2.COLOR_BGR2GRAY
    )

    templates.append((name, template, template_gray))

# 4. Convert test image to grayscale
test_gray = cv2.cvtColor(
    test, cv2.COLOR_BGR2GRAY
)

output = test.copy()

print("\nMULTI-TEMPLATE NCC RESULTS")

# 5. Match each template
for i, (name, template, template_gray) in enumerate(templates):

    th, tw = template_gray.shape

    if th > test_gray.shape[0] or tw > test_gray.shape[1]:
        raise ValueError("Template is larger than test image")

    result = cv2.matchTemplate(
        test_gray,
        template_gray,
        cv2.TM_CCOEFF_NORMED
    )

    min_val, max_val, min_loc, max_loc = (
        cv2.minMaxLoc(result)
    )

    top_left = max_loc
    bottom_right = (
        top_left[0] + tw,
        top_left[1] + th
    )

    # Draw matching rectangle
    cv2.rectangle(
        output,
        top_left,
        bottom_right,
        colors[i],
        2
    )

    cv2.putText(
        output,
        f"T{i+1}: {max_val:.2f}",
        (top_left[0], max(20, top_left[1] - 5)),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        colors[i],
        2
    )

    print("\n", name)
    print("Template size:", tw, "x", th)
    print("Matching location:", max_loc)
    print("NCC score:", max_val)

# 6. Display all results
plt.figure(figsize=(14, 6))

plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(reference, cv2.COLOR_BGR2RGB))
plt.title("Reference Image")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(cv2.cvtColor(output, cv2.COLOR_BGR2RGB))
plt.title("Multi-Template NCC Results")
plt.axis("off")

plt.tight_layout()
plt.show()

# 7. Save output
cv2.imwrite(
    "outputs/stage4_multi_ncc.jpg",
    output
)

print("\nMulti-template NCC experiment completed!")
