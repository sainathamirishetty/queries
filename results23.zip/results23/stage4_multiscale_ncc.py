
import cv2
import matplotlib.pyplot as plt

# 1. Load reference and test images
reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check image filenames")

# 2. Select a distinctive aircraft region
print("Select a small aircraft region.")
print("Avoid unnecessary background.")

scale_display = 1.5

display_image = cv2.resize(
    reference,
    None,
    fx=scale_display,
    fy=scale_display,
    interpolation=cv2.INTER_CUBIC
)

x, y, w, h = cv2.selectROI(
    "Select NCC Template",
    display_image,
    showCrosshair=True,
    fromCenter=False
)

cv2.destroyAllWindows()

if w == 0 or h == 0:
    raise ValueError("No template selected")

# 3. Convert selection to original coordinates
x = round(x / scale_display)
y = round(y / scale_display)
w = round(w / scale_display)
h = round(h / scale_display)

template = reference[y:y+h, x:x+w]

# 4. Convert images to grayscale
template_gray = cv2.cvtColor(
    template, cv2.COLOR_BGR2GRAY
)

test_gray = cv2.cvtColor(
    test, cv2.COLOR_BGR2GRAY
)

# 5. Define template scales
scales = [0.6, 0.7, 0.8, 0.9, 1.0,
          1.1, 1.2, 1.3, 1.4]

best_score = -1
best_location = None
best_scale = None
best_size = None

results = []

# 6. Perform multi-scale NCC
for scale in scales:

    resized_template = cv2.resize(
        template_gray,
        None,
        fx=scale,
        fy=scale,
        interpolation=cv2.INTER_AREA if scale < 1
        else cv2.INTER_CUBIC
    )

    th, tw = resized_template.shape

    # Skip templates larger than test image
    if th > test_gray.shape[0] or tw > test_gray.shape[1]:
        continue

    result = cv2.matchTemplate(
        test_gray,
        resized_template,
        cv2.TM_CCOEFF_NORMED
    )

    min_val, max_val, min_loc, max_loc = (
        cv2.minMaxLoc(result)
    )

    results.append((scale, max_val, max_loc))

    print(
        f"Scale: {scale:.1f}, "
        f"Score: {max_val:.4f}, "
        f"Location: {max_loc}"
    )

    if max_val > best_score:
        best_score = max_val
        best_location = max_loc
        best_scale = scale
        best_size = (tw, th)

# 7. Draw best matching rectangle
output = test.copy()

if best_location is not None:

    x_match, y_match = best_location
    tw, th = best_size

    cv2.rectangle(
        output,
        (x_match, y_match),
        (x_match + tw, y_match + th),
        (0, 255, 0),
        3
    )

# 8. Display results
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(reference, cv2.COLOR_BGR2RGB))
plt.title("Reference Image")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(cv2.cvtColor(template, cv2.COLOR_BGR2RGB))
plt.title("Selected Template")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(cv2.cvtColor(output, cv2.COLOR_BGR2RGB))
plt.title("Best Multi-scale NCC Match")
plt.axis("off")

plt.tight_layout()
plt.show()

# 9. Save output
cv2.imwrite(
    "outputs/stage4_multiscale_ncc.jpg",
    output
)

# 10. Print final results
print("\nMULTI-SCALE NCC SUMMARY")
print("Best scale:", best_scale)
print("Best matching location:", best_location)
print("Best template size:", best_size)
print("Best NCC score:", best_score)

print("Result saved successfully!")
