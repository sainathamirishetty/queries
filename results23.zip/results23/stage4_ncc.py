
import cv2
import matplotlib.pyplot as plt

# 1. Load reference and test images
reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check your image filenames")

# 2. Select aircraft template from reference image
print("Select the complete aircraft using your mouse.")
print("Press ENTER or SPACE to confirm.")

x, y, w, h = cv2.selectROI(
    "Select Banshee Template",
    reference,
    showCrosshair=True,
    fromCenter=False
)
print("Template coordinates:", x, y, w, h)

cv2.destroyAllWindows()

if w == 0 or h == 0:
    raise ValueError("No template selected")

# 3. Crop selected region
template = reference[y:y+h, x:x+w]

# 4. Convert both images to grayscale
template_gray = cv2.cvtColor(
    template, cv2.COLOR_BGR2GRAY
)

test_gray = cv2.cvtColor(
    test, cv2.COLOR_BGR2GRAY
)

# 5. Check template dimensions
th, tw = template_gray.shape
ih, iw = test_gray.shape

if th > ih or tw > iw:
    raise ValueError("Template is larger than test image")

# 6. Perform NCC template matching
result = cv2.matchTemplate(
    test_gray,
    template_gray,
    cv2.TM_CCOEFF_NORMED
)

# 7. Find best matching location
min_val, max_val, min_loc, max_loc = (
    cv2.minMaxLoc(result)
)

# 8. Draw bounding box around best match
top_left = max_loc
bottom_right = (
    top_left[0] + tw,
    top_left[1] + th
)

output = test.copy()

cv2.rectangle(
    output,
    top_left,
    bottom_right,
    (0, 255, 0),
    3
)

# 9. Display results
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(reference, cv2.COLOR_BGR2RGB))
plt.title("Reference Image")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(cv2.cvtColor(template, cv2.COLOR_BGR2RGB))
plt.title("Selected Template")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(cv2.cvtColor(output, cv2.COLOR_BGR2RGB))
plt.title("NCC Matching Result")
print("NCC similarity score:", max_val)
plt.axis("off")

plt.tight_layout()
plt.show()

# 10. Save results
cv2.imwrite("outputs/stage4_template.jpg", template)
cv2.imwrite("outputs/stage4_ncc_result.jpg", output)

print("NCC experiment completed!")
print("Template width:", tw)
print("Template height:", th)
print("Best matching location:", max_loc)
print("NCC similarity score:", max_val)
