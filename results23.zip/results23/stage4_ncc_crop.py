
import cv2
import matplotlib.pyplot as plt

# 1. Load images
reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check image filenames")

# 2. Enlarge reference image for easier selection
scale = 1.5

display_image = cv2.resize(
    reference,
    None,
    fx=scale,
    fy=scale,
    interpolation=cv2.INTER_CUBIC
)

print("Select a smaller distinctive aircraft region.")
print("Avoid unnecessary background.")
print("Press ENTER to confirm.")

# 3. Select ROI on enlarged image
x, y, w, h = cv2.selectROI(
    "Select Aircraft Region",
    display_image,
    showCrosshair=True,
    fromCenter=False
)

cv2.destroyAllWindows()

if w == 0 or h == 0:
    raise ValueError("No template selected")

# 4. Convert coordinates to original image scale
x = round(x / scale)
y = round(y / scale)
w = round(w / scale)
h = round(h / scale)

# 5. Crop template
template = reference[y:y+h, x:x+w]

# 6. Convert to grayscale
template_gray = cv2.cvtColor(
    template, cv2.COLOR_BGR2GRAY
)

test_gray = cv2.cvtColor(
    test, cv2.COLOR_BGR2GRAY
)

# 7. Check template dimensions
th, tw = template_gray.shape
ih, iw = test_gray.shape

if th > ih or tw > iw:
    raise ValueError("Template larger than test image")

# 8. Perform NCC
result = cv2.matchTemplate(
    test_gray,
    template_gray,
    cv2.TM_CCOEFF_NORMED
)

min_val, max_val, min_loc, max_loc = (
    cv2.minMaxLoc(result)
)

# 9. Draw rectangle around matching patch
output = test.copy()

top_left = max_loc
bottom_right = (
    top_left[0] + tw,
    top_left[1] + th
)

cv2.rectangle(
    output,
    top_left,
    bottom_right,
    (0, 255, 0),
    3
)

# 10. Display results
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(reference, cv2.COLOR_BGR2RGB))
plt.title("Reference Image")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(cv2.cvtColor(template, cv2.COLOR_BGR2RGB))
plt.title("Selected Smaller Template")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(cv2.cvtColor(output, cv2.COLOR_BGR2RGB))
plt.title("NCC Matching Result")
plt.axis("off")

plt.tight_layout()
plt.show()

# 11. Save results
cv2.imwrite("outputs/stage4_small_template.jpg", template)
cv2.imwrite("outputs/stage4_small_ncc_result.jpg", output)

print("\nNCC experiment completed!")
print("Template coordinates:", x, y, w, h)
print("Template width:", tw)
print("Template height:", th)
print("Best matching location:", max_loc)
print("NCC similarity score:", max_val)
