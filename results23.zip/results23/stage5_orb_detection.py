
import cv2
import matplotlib.pyplot as plt

# 1. Load original image
image = cv2.imread("images/banshee.jpeg")

if image is None:
    raise FileNotFoundError("Banshee image not found")

# 2. Convert to grayscale
gray = cv2.cvtColor(
    image,
    cv2.COLOR_BGR2GRAY
)

# 3. Create ORB detector
orb = cv2.ORB_create(
    nfeatures=1000
)

# 4. Detect keypoints and calculate descriptors
keypoints, descriptors = orb.detectAndCompute(
    gray,
    None
)

# 5. Draw detected keypoints
orb_image = cv2.drawKeypoints(
    image,
    keypoints,
    None,
    color=(0, 255, 0),
    flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS
)

# 6. Print information
print("ORB feature detection completed!")
print("Total keypoints detected:", len(keypoints))

if descriptors is not None:
    print("Descriptor shape:", descriptors.shape)
    print("Descriptor data type:", descriptors.dtype)
else:
    print("No descriptors generated")

# 7. Display results
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title("Original Banshee")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(gray, cmap="gray")
plt.title("Grayscale Image")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(cv2.cvtColor(orb_image, cv2.COLOR_BGR2RGB))
plt.title("ORB Detected Keypoints")
plt.axis("off")

plt.tight_layout()
plt.show()

# 8. Save output
cv2.imwrite(
    "outputs/stage5_orb_keypoints.jpg",
    orb_image
)

print("ORB output saved successfully!")
