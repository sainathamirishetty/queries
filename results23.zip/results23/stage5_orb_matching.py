
import cv2
import matplotlib.pyplot as plt

# 1. Load both images
reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check image filenames")

# 2. Convert to grayscale
gray1 = cv2.cvtColor(reference, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(test, cv2.COLOR_BGR2GRAY)

# 3. Create ORB detector
orb = cv2.ORB_create(nfeatures=1000)

# 4. Detect keypoints and descriptors
kp1, des1 = orb.detectAndCompute(gray1, None)
kp2, des2 = orb.detectAndCompute(gray2, None)

print("Reference keypoints:", len(kp1))
print("Test keypoints:", len(kp2))

# 5. Create Brute Force Matcher
bf = cv2.BFMatcher(
    cv2.NORM_HAMMING,
    crossCheck=True
)

# 6. Match descriptors
matches = bf.match(des1, des2)

# 7. Sort matches by distance
matches = sorted(
    matches,
    key=lambda match: match.distance
)

# 8. Select the best 50 matches
good_matches = matches[:50]

# 9. Draw matches
match_image = cv2.drawMatches(
    reference,
    kp1,
    test,
    kp2,
    good_matches,
    None,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# 10. Print matching information
print("Total raw matches:", len(matches))
print("Selected matches:", len(good_matches))

if matches:
    distances = [m.distance for m in good_matches]
    print("Best matching distance:", matches[0].distance)
    print("Average selected distance:",
          sum(distances) / len(distances))

# 11. Display result
plt.figure(figsize=(16, 8))
plt.imshow(cv2.cvtColor(match_image, cv2.COLOR_BGR2RGB))
plt.title("ORB Feature Matching")
plt.axis("off")
plt.show()

# 12. Save result
cv2.imwrite(
    "outputs/stage5_orb_matches.jpg",
    match_image
)

print("ORB matching completed!")
