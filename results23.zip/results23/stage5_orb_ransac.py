
import cv2
import numpy as np
import matplotlib.pyplot as plt

# --------------------------------------------------
# 1. Load images
# --------------------------------------------------

reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check image filenames")

# --------------------------------------------------
# 2. Convert images to grayscale
# --------------------------------------------------

gray1 = cv2.cvtColor(reference, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(test, cv2.COLOR_BGR2GRAY)

# --------------------------------------------------
# 3. ORB feature detection
# --------------------------------------------------

orb = cv2.ORB_create(nfeatures=1000)

kp1, des1 = orb.detectAndCompute(gray1, None)
kp2, des2 = orb.detectAndCompute(gray2, None)

print("Reference keypoints:", len(kp1))
print("Test keypoints:", len(kp2))

if des1 is None or des2 is None:
    raise ValueError("ORB descriptors not generated")

# --------------------------------------------------
# 4. KNN feature matching
# --------------------------------------------------

bf = cv2.BFMatcher(cv2.NORM_HAMMING)

knn_matches = bf.knnMatch(
    des1,
    des2,
    k=2
)

# --------------------------------------------------
# 5. Lowe ratio test
# --------------------------------------------------

ratio_threshold = 0.85

good_matches = []

for pair in knn_matches:

    if len(pair) < 2:
        continue

    m, n = pair

    if m.distance < ratio_threshold * n.distance:
        good_matches.append(m)

print("\nCandidate matches:", len(good_matches))

# --------------------------------------------------
# 6. Check minimum matches
# --------------------------------------------------

if len(good_matches) < 4:
    raise ValueError(
        "Not enough matches for homography estimation"
    )

# --------------------------------------------------
# 7. Extract corresponding coordinates
# --------------------------------------------------

src_pts = np.float32([
    kp1[m.queryIdx].pt for m in good_matches
]).reshape(-1, 1, 2)

dst_pts = np.float32([
    kp2[m.trainIdx].pt for m in good_matches
]).reshape(-1, 1, 2)

# --------------------------------------------------
# 8. Estimate homography using RANSAC
# --------------------------------------------------

H, mask = cv2.findHomography(
    src_pts,
    dst_pts,
    cv2.RANSAC,
    5.0
)

if H is None or mask is None:
    raise RuntimeError("Homography estimation failed")

# --------------------------------------------------
# 9. Separate inliers and outliers
# --------------------------------------------------

matches_mask = mask.ravel().tolist()

inlier_matches = [
    m for m, keep in zip(good_matches, matches_mask)
    if keep
]

outlier_matches = [
    m for m, keep in zip(good_matches, matches_mask)
    if not keep
]

inlier_count = len(inlier_matches)
outlier_count = len(outlier_matches)

# --------------------------------------------------
# 10. Draw inlier matches
# --------------------------------------------------

inlier_image = cv2.drawMatches(
    reference,
    kp1,
    test,
    kp2,
    good_matches,
    None,
    matchColor=(0, 255, 0),
    matchesMask=matches_mask,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# --------------------------------------------------
# 11. Draw outlier matches
# --------------------------------------------------

outlier_mask = [
    0 if value == 1 else 1
    for value in matches_mask
]

outlier_image = cv2.drawMatches(
    reference,
    kp1,
    test,
    kp2,
    good_matches,
    None,
    matchColor=(0, 0, 255),
    matchesMask=outlier_mask,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# --------------------------------------------------
# 12. Display both visualizations
# --------------------------------------------------

plt.figure(figsize=(16, 10))

plt.subplot(2, 1, 1)

plt.imshow(
    cv2.cvtColor(inlier_image, cv2.COLOR_BGR2RGB)
)

plt.title("RANSAC Inliers - Accepted Matches")
plt.axis("off")

plt.subplot(2, 1, 2)

plt.imshow(
    cv2.cvtColor(outlier_image, cv2.COLOR_BGR2RGB)
)

plt.title("RANSAC Outliers - Rejected Matches")
plt.axis("off")

plt.tight_layout()
plt.show()

# --------------------------------------------------
# 13. Save both images
# --------------------------------------------------

cv2.imwrite(
    "outputs/stage5_ransac_inliers.jpg",
    inlier_image
)

cv2.imwrite(
    "outputs/stage5_ransac_outliers.jpg",
    outlier_image
)

# --------------------------------------------------
# 14. Print final results
# --------------------------------------------------

print("\n========== RANSAC RESULTS ==========")

print("Candidate matches:", len(good_matches))
print("Inliers:", inlier_count)
print("Outliers:", outlier_count)

if good_matches:
    inlier_ratio = inlier_count / len(good_matches)

    print("Inlier ratio:", round(inlier_ratio, 4))
    print("Inlier percentage:", round(inlier_ratio * 100, 2), "%")

print("\nRANSAC experiment completed!")
print("Inlier image saved successfully!")
print("Outlier image saved successfully!")
