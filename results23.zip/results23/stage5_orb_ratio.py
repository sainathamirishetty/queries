
import cv2
import matplotlib.pyplot as plt

# 1. Load images
reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check image filenames")

# 2. Convert to grayscale
gray1 = cv2.cvtColor(reference, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(test, cv2.COLOR_BGR2GRAY)

# 3. Create ORB detector
orb = cv2.ORB_create(nfeatures=1000)

# 4. Detect keypoints and descriptors
kp1, des1 = orb.detectAndCompute(gray1, None)
kp2, des2 = orb.detectAndCompute(gray2, None)

print("Reference keypoints:", len(kp1))
print("Test keypoints:", len(kp2))

if des1 is None or des2 is None:
    raise ValueError("ORB descriptors not generated")

# 5. Create BFMatcher
bf = cv2.BFMatcher(cv2.NORM_HAMMING)

# 6. Find two nearest matches
knn_matches = bf.knnMatch(
    des1,
    des2,
    k=2
)

# 7. Apply Lowe's ratio test
ratio_threshold = 0.85

good_matches = []

for pair in knn_matches:

    if len(pair) < 2:
        continue

    m, n = pair

    if m.distance < ratio_threshold * n.distance:
        good_matches.append(m)

# 8. Sort accepted matches
good_matches = sorted(
    good_matches,
    key=lambda match: match.distance
)

# 9. Draw matches
match_image = cv2.drawMatches(
    reference,
    kp1,
    test,
    kp2,
    good_matches,
    None,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# 10. Print results
print("\nORB KNN RATIO TEST RESULTS")

print("Total KNN pairs:", len(knn_matches))
print("Accepted matches:", len(good_matches))

if good_matches:
    avg_distance = sum(
        m.distance for m in good_matches
    ) / len(good_matches)

    print("Best Hamming distance:",
          good_matches[0].distance)

    print("Average Hamming distance:",
          avg_distance)

# 11. Display result
plt.figure(figsize=(16, 8))

plt.imshow(
    cv2.cvtColor(match_image, cv2.COLOR_BGR2RGB)
)

plt.title("ORB Matching - Lowe Ratio Test")
plt.axis("off")
plt.tight_layout()
plt.show()

# 12. Save result
cv2.imwrite(
    "outputs/stage5_orb_ratio.jpg",
    match_image
)

print("ORB ratio test completed!")
