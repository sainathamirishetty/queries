
import cv2
import numpy as np
import matplotlib.pyplot as plt

# --------------------------------------------------
# 1. Load images
# --------------------------------------------------

reference = cv2.imread("images/banshee.jpeg")
test = cv2.imread("images/banshee_test1.jpeg")

if reference is None or test is None:
    raise FileNotFoundError("Check image filenames")

# --------------------------------------------------
# 2. Select aircraft ROI in reference image
# --------------------------------------------------

print("Select the complete aircraft in REFERENCE image.")
print("Avoid unnecessary background.")
print("Press ENTER or SPACE to confirm.")

x1, y1, w1, h1 = cv2.selectROI(
    "Reference - Select Aircraft",
    reference,
    showCrosshair=True,
    fromCenter=False
)

cv2.destroyAllWindows()

if w1 == 0 or h1 == 0:
    raise ValueError("Reference ROI not selected")

reference_roi = reference[y1:y1+h1, x1:x1+w1]

# --------------------------------------------------
# 3. Select aircraft ROI in test image
# --------------------------------------------------

print("Select the complete aircraft in TEST image.")
print("Avoid unnecessary background.")
print("Press ENTER or SPACE to confirm.")

x2, y2, w2, h2 = cv2.selectROI(
    "Test - Select Aircraft",
    test,
    showCrosshair=True,
    fromCenter=False
)

cv2.destroyAllWindows()

if w2 == 0 or h2 == 0:
    raise ValueError("Test ROI not selected")

test_roi = test[y2:y2+h2, x2:x2+w2]

# --------------------------------------------------
# 4. Convert ROIs to grayscale
# --------------------------------------------------

gray1 = cv2.cvtColor(
    reference_roi,
    cv2.COLOR_BGR2GRAY
)

gray2 = cv2.cvtColor(
    test_roi,
    cv2.COLOR_BGR2GRAY
)

# --------------------------------------------------
# 5. ORB feature detection
# --------------------------------------------------

orb = cv2.ORB_create(nfeatures=1000)

kp1, des1 = orb.detectAndCompute(gray1, None)
kp2, des2 = orb.detectAndCompute(gray2, None)

print("\nROI ORB RESULTS")
print("Reference ROI keypoints:", len(kp1))
print("Test ROI keypoints:", len(kp2))

if des1 is None or des2 is None:
    raise ValueError("Not enough ORB descriptors")

# --------------------------------------------------
# 6. KNN feature matching
# --------------------------------------------------

bf = cv2.BFMatcher(cv2.NORM_HAMMING)

knn_matches = bf.knnMatch(
    des1,
    des2,
    k=2
)

# --------------------------------------------------
# 7. Lowe ratio test
# --------------------------------------------------

ratio_threshold = 0.85

good_matches = []

for pair in knn_matches:

    if len(pair) < 2:
        continue

    m, n = pair

    if m.distance < ratio_threshold * n.distance:
        good_matches.append(m)

print("Candidate matches:", len(good_matches))

# --------------------------------------------------
# 8. Check minimum matches
# --------------------------------------------------

if len(good_matches) < 4:
    raise ValueError(
        "Not enough matches for homography estimation"
    )

# --------------------------------------------------
# 9. Extract matching coordinates
# --------------------------------------------------

src_pts = np.float32([
    kp1[m.queryIdx].pt for m in good_matches
]).reshape(-1, 1, 2)

dst_pts = np.float32([
    kp2[m.trainIdx].pt for m in good_matches
]).reshape(-1, 1, 2)

# --------------------------------------------------
# 10. RANSAC homography
# --------------------------------------------------

H, mask = cv2.findHomography(
    src_pts,
    dst_pts,
    cv2.RANSAC,
    5.0
)

if H is None or mask is None:
    raise RuntimeError("Homography estimation failed")

matches_mask = mask.ravel().tolist()

inlier_count = sum(matches_mask)
outlier_count = len(matches_mask) - inlier_count

# --------------------------------------------------
# 11. Draw inlier matches
# --------------------------------------------------

inlier_image = cv2.drawMatches(
    reference_roi,
    kp1,
    test_roi,
    kp2,
    good_matches,
    None,
    matchColor=(0, 255, 0),
    matchesMask=matches_mask,
    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
)

# --------------------------------------------------
# 12. Display results
# --------------------------------------------------

plt.figure(figsize=(16, 8))

plt.imshow(
    cv2.cvtColor(inlier_image, cv2.COLOR_BGR2RGB)
)

plt.title("Aircraft ROI - ORB RANSAC Inliers")
plt.axis("off")

plt.tight_layout()
plt.show()

# --------------------------------------------------
# 13. Save output
# --------------------------------------------------

cv2.imwrite(
    "outputs/stage5_orb_roi_ransac.jpg",
    inlier_image
)

# --------------------------------------------------
# 14. Print results
# --------------------------------------------------

print("\n========== AIRCRAFT ROI RANSAC RESULTS ==========")

print("Reference ROI keypoints:", len(kp1))
print("Test ROI keypoints:", len(kp2))
print("Candidate matches:", len(good_matches))
print("Inliers:", inlier_count)
print("Outliers:", outlier_count)

inlier_ratio = inlier_count / len(good_matches)

print("Inlier ratio:", round(inlier_ratio, 4))
print("Inlier percentage:", round(inlier_ratio * 100, 2), "%")

print("\nAircraft ROI experiment completed!")
