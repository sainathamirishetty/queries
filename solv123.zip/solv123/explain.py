I’ve written the complete security_headers.py. It passes a syntax check but I haven’t run it against a live Streamlit server, so the curl checks below are how you confirm it. Keep import security_headers as the first line of your main script. It covers every item that can be fixed from this file.
What it fixes
VAPT finding	How
HSTS, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy	Applied to every response, including /_stcore/health and /_stcore/host-config.
Server header disclosure	Server: WebServer everywhere.
Missing or permissive CSP, and report-to missing	Strict CSP with object-src 'none', base-uri, form-action and frame-ancestors, plus report-uri and report-to.
Cookie without Secure	Secure and SameSite=Lax are added.
Weak TLS ciphers	Only TLS 1.2 and above, AEAD ciphers only. This is best effort.
/_csp-report returns 404	A small receiver logs reports to csp_reports.log.
What you must still do in your main script
Self-host the fonts and delete the @import on line 39. This clears “Broken Resources” and “Subresource Integrity”. The CSP no longer allows Google Fonts.
Escape the filename in the three st.markdown blocks at lines 579, 587 and 595:
python
   import html
   f'<div class="doc-name">{html.escape(doc["name"])}</div>'
What remains in the next report
_streamlit_xsrf without HttpOnly. Fixing it would break file uploads, so accept the risk.
'unsafe-inline' in style-src, because Streamlit needs it. Try removing 'unsafe-eval' from script-src after testing.
Informational items: PostMessage, WebSocket, API detected, wildcard certificate and security.txt.
How to apply and verify
Replace your security_headers.py with this one and restart your app.
Open the app once in a browser, because the patch loads on the first session.
Run the checks listed at the bottom of the file:
   curl -kI https://ai.rcilab.in:8560/_stcore/health
   curl -kI https://ai.rcilab.in:8560/
   nmap --script ssl-enum-ciphers -p 8560 ai.rcilab.in
If the UI breaks, set CSP_HEADER_NAME to "Content-Security-Policy-Report-Only", read the DevTools console, and relax only the directive it names.
If nmap still lists CBC ciphers, Streamlit can’t restrict TLS from inside the script, and the fix is an nginx proxy in front of it. I can write that config if you want it.
Security headers
PY
I think you’re asking whether cipher settings can go in config.toml, to disable the weak ones. They can’t.
Why config.toml can’t do it
Streamlit’s [server] section accepts only the certificate and key for TLS:
toml
[server]
sslCertFile = "/path/to/fullchain.pem"
sslKeyFile  = "/path/to/privkey.pem"
There is no setting for ciphers or TLS versions. The certificate only identifies your server, and the cipher list comes from the TLS context that Python builds at runtime.
What does this instead
The TLS section of security_headers.py sets the minimum version to TLS 1.2 and restricts ciphers to AES-GCM and ChaCha20 (no CBC). I can’t promise it takes effect with your Streamlit and Tornado versions, so test it after restarting and opening the app once. It works only if Tornado builds the TLS context after your script has loaded.
How to check it
This tries to connect using one of the two CBC suites that were flagged:
openssl s_client -connect ai.rcilab.in:8560 -tls1_2 -cipher ECDHE-RSA-AES256-SHA384
If the connection fails with a handshake error, the weak cipher is disabled and the patch works.
If it connects and shows Cipher is ECDHE-RSA-AES256-SHA384, the patch didn’t apply.
You can also run nmap --script ssl-enum-ciphers -p 8560 ai.rcilab.in to see the full list.
If it didn’t apply
Without a proxy, the options are limited. You could try pointing the process at an OpenSSL config file with OPENSSL_CONF, but Python may ignore it depending on how it was built, so treat that as an experiment. Otherwise, document the finding as Low risk, as in the explanation I gave for your boss: SSL 3.0, TLS 1.0 and TLS 1.1 are disabled, the two remaining CBC suites use ECDHE, and the apps run only on the internal network. If you tell me the result of the openssl s_client test, I can say which case you’re in.
ECDHE-RSA-AES256-SHA384   where should I add tis one?
You don’t add ECDHE-RSA-AES256-SHA384 anywhere in your files. It is one of the two weak ciphers the scanner flagged, and it appears only in the test command I gave you, to check that it is disabled.
What to do with it
Run the test from a terminal (Command Prompt, PowerShell or Linux shell) on any machine that can reach the server and has OpenSSL:
   openssl s_client -connect ai.rcilab.in:8560 -tls1_2 -cipher ECDHE-RSA-AES256-SHA384
Read the result:
A handshake failure means the weak cipher is disabled, which is what you want.
Cipher is ECDHE-RSA-AES256-SHA384 means the server still accepts it.
The other flagged cipher is ECDHE-RSA-AES128-SHA256. You can test it by replacing the name after -cipher in the same command.
What is already in your files
The settings that control which ciphers are allowed are already in security_headers.py:
python
TLS_CIPHERS = "ECDHE+AESGCM:ECDHE+CHACHA20"
That line lists only the strong ciphers. You don’t need to add the weak one to it, and doing so would turn it back on. Leave config.toml as it is, with only the certificate and key paths.
If you run the test and send me what it prints, I can tell you whether the patch worked.
TLS_CIPHERS = "ECDHE+AESGCM:ECDHE+CHACHA20" can't I use this line in config.toml
Determining that config.toml cannot hold the setting.
No, that line can’t go in config.toml. Streamlit’s config file only recognizes its own named settings, and none of them controls TLS ciphers. If you add a line like TLS_CIPHERS = "...", Streamlit will either ignore it or print an unknown-option warning. Either way the ciphers won’t change.
Where it belongs
TLS_CIPHERS is a Python variable in security_headers.py, and it only works because that file’s code reads it and applies it:
python
TLS_CIPHERS = "ECDHE+AESGCM:ECDHE+CHACHA20"
...
ctx.set_ciphers(TLS_CIPHERS)
Leave it there. config.toml keeps only the certificate and key paths:
toml
[server]
sslCertFile = "/path/to/fullchain.pem"
sslKeyFile  = "/path/to/privkey.pem"
The cipher test I gave you earlier shows whether the setting took effect. If it didn’t, config.toml has no alternative for it, and the finding should be documented as Low risk, as in the explanation for your boss.

5.
code.py(Software
Dev
Assistant, / code
on
5001) and think_chat.py(Information
Chatbot, / think_chat
on
5001)
The
same
edits
apply
to
both
files.
Line
1: change  # import security_headers to import security_headers. This is the most important fix for these two apps.
Add
an
import after

line
1:
python
import html

The
render_with_mathml
function(code.py
lines
30 and 34
become
31 and 35
after
step
2;
think_chat.py
32 and 35
become
33 and 36):
Change
python
content = content.replace("$", "💰")
to
python
content = html.escape(content.replace("$", "💰"), quote=False)
Change
python
mathml_content = latex2mathml.converter.convert(match.group(1))
to
python
mathml_content = latex2mathml.converter.convert(html.unescape(match.group(1)))
This is a
safety
improvement and isn’t in the
report.After
this
change, a
line
beginning
with > shows as text, so test a few chat replies.
4.
Lines
777 - 778(code.py) and 741 - 742(think_chat.py): these
st.page_link
calls
point
to
http: // ai.rcilab. in: 5000.
Once
the
HSTS
header is cached, browsers
upgrade
these
to
https: // ai.rcilab. in: 5000.
Check
that
port
5000
runs
HTTPS.If
it
doesn’t, those
links
will
break.
5.
Optional,
for the “Full Path Disclosure” finding: add
the.map - blocking
snippet
from my earlier

message
to
the
end
of
the
security_headers.py in these
two
folders, or document
it as a
false
positive.It is not a
real
path.
