"""
security_headers.py
Hardening patch for a Streamlit (Tornado) app on an offline intranet.
Use:  keep "import security_headers" as the FIRST line of the main script.
NOTE: with this launch style the patch loads when the first browser session
starts, so open the app once yourself after every restart.

Addresses VAPT findings:
  HSTS missing                      -> Strict-Transport-Security
  X-Frame-Options / nosniff / Referrer / Permissions-Policy missing
                                    -> applied to ALL handlers (incl. /_stcore/*)
  Server header disclosure          -> Server: WebServer
  Missing / permissive CSP, report-to missing
                                    -> strict CSP with report-uri/report-to
  Cookie without Secure             -> Secure + SameSite=Lax
  Weak TLS 1.2 CBC ciphers          -> TLS1.2+ and AEAD ciphers only (best effort)
Cannot be fixed here (document as accepted risk):
  - _streamlit_xsrf cookie HttpOnly (frontend JS must read it)
  - 'unsafe-inline' in style-src (Streamlit's own inline styles)
"""
import gc
import logging
import ssl
import sys

import tornado.web
import tornado.netutil

# ---------------------------------------------------------------- CONFIG
HSTS_VALUE = "max-age=31536000"   # don't add includeSubDomains unless every *.rcilab.in host is HTTPS

# Start here. If the console shows violations, relax ONLY the named directive.
#   try removing 'unsafe-eval' from script-src first;
#   'unsafe-inline' in style-src is needed by Streamlit itself.
CSP = "; ".join([
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",              # fonts must be self-hosted (offline)
    "connect-src 'self' wss: ws:",
    "media-src 'self' data: blob:",
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "report-uri /_csp-report",
    "report-to csp-endpoint",
])
CSP_HEADER_NAME = "Content-Security-Policy"   # use "Content-Security-Policy-Report-Only" to test
TLS_CIPHERS = "ECDHE+AESGCM:ECDHE+CHACHA20"   # AEAD only (no CBC)


def _is_https(handler):
    try:
        r = handler.request
        return r.protocol == "https" or r.headers.get("X-Forwarded-Proto", "").lower() == "https"
    except Exception:
        return True


# ------------------------------------------- 1. headers + cookies (all handlers)
# clear() is patched, not set_default_headers(): Streamlit's /_stcore/health and
# /_stcore/host-config override set_default_headers() without calling super().
if not getattr(tornado.web.RequestHandler, "_headers_patched_v3", False):

    _orig_clear = tornado.web.RequestHandler.clear
    _orig_set_cookie = tornado.web.RequestHandler.set_cookie

    def _patched_clear(self):
        _orig_clear(self)
        try:
            self.set_header("Server", "WebServer")
            self.set_header("X-Frame-Options", "DENY")
            self.set_header("X-Content-Type-Options", "nosniff")
            self.set_header("Referrer-Policy", "strict-origin-when-cross-origin")
            self.set_header("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
            self.set_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.set_header(CSP_HEADER_NAME, CSP)
            self.set_header("Reporting-Endpoints", 'csp-endpoint="/_csp-report"')
            if _is_https(self):
                self.set_header("Strict-Transport-Security", HSTS_VALUE)
        except Exception:
            pass

    def _patched_set_cookie(self, name, value, *args, **kwargs):
        kwargs.setdefault("samesite", "Lax")
        if _is_https(self):
            kwargs.setdefault("secure", True)
        # HttpOnly intentionally NOT set on _streamlit_xsrf (frontend needs to read it).
        return _orig_set_cookie(self, name, value, *args, **kwargs)

    tornado.web.RequestHandler.clear = _patched_clear
    tornado.web.RequestHandler.set_cookie = _patched_set_cookie
    tornado.web.RequestHandler._headers_patched_v3 = True


# ------------------------------------------- 2. TLS hardening (best effort)
if not getattr(tornado.netutil, "_tls_patched", False):

    _orig_ctx = tornado.netutil.ssl_options_to_context

    def _hardened_ctx(*args, **kwargs):
        ctx = _orig_ctx(*args, **kwargs)
        try:
            ctx.minimum_version = ssl.TLSVersion.TLSv1_2
            ctx.set_ciphers(TLS_CIPHERS)      # TLS 1.3 suites unaffected
        except Exception:
            pass
        return ctx

    tornado.netutil.ssl_options_to_context = _hardened_ctx
    for _n, _m in list(sys.modules.items()):
        if _n.startswith("tornado") and getattr(_m, "ssl_options_to_context", None) is _orig_ctx:
            setattr(_m, "ssl_options_to_context", _hardened_ctx)
    tornado.netutil._tls_patched = True


# ------------------------------------------- 3. CSP report receiver (/_csp-report)
_csp_log = logging.getLogger("csp_reports")
if not _csp_log.handlers:
    try:
        _fh = logging.FileHandler("csp_reports.log")
        _fh.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
        _csp_log.addHandler(_fh)
        _csp_log.setLevel(logging.INFO)
        _csp_log.propagate = False
    except Exception:
        pass


class _CSPReportHandler(tornado.web.RequestHandler):
    def check_xsrf_cookie(self):      # browsers send reports without the XSRF token
        pass

    def post(self):
        _csp_log.info(self.request.body[:2000].decode("utf-8", "replace"))
        self.set_status(204)

    def get(self):
        self.set_status(405)


def _register_csp_route():
    for obj in gc.get_objects():
        try:
            if isinstance(obj, tornado.web.Application) and not getattr(obj, "_csp_route", False):
                obj.add_handlers(r".*$", [(r"/_csp-report", _CSPReportHandler)])
                obj._csp_route = True
        except Exception:
            pass


_register_csp_route()

"""
VERIFY (after opening the app once in a browser):
  curl -kI https://ai.rcilab.in:8560/_stcore/health
  curl -kI https://ai.rcilab.in:8560/
  curl -k -X POST -d '{"t":1}' -i https://ai.rcilab.in:8560/_csp-report      (expect 204)
  nmap --script ssl-enum-ciphers -p 8560 ai.rcilab.in                        (expect no CBC)
If the page breaks: set CSP_HEADER_NAME to "Content-Security-Policy-Report-Only",
read DevTools > Console, and relax only the directive named there.
"""
