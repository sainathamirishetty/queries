"""
admin.py  —  DocQA Admin Dashboard
─────────────────────────────────────────────────────────────────────────────
Run on a different port so students can't stumble onto it:
    streamlit run admin.py --server.address 0.0.0.0 --server.port 8001

Features:
  • Password-protected login
  • Live stats: total questions, unique users, avg TTFT, avg answer time
  • Searchable & filterable Q&A log (by IP, question type, date)
  • Per-IP activity leaderboard
  • Timing trend charts (TTFT and total time over last 100 queries)
  • Document upload history
  • Session list
  • Auto-refresh every 30 seconds
─────────────────────────────────────────────────────────────────────────────
"""

import time
from datetime import datetime

import pandas as pd
import streamlit as st

from config import ADMIN_PASSWORD
from logger import db_logger, get_logger

log = get_logger("admin")


# ── Page config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title = "DocQA Admin",
    page_icon  = "🛡️",
    layout     = "wide",
)

st.markdown("""
<style>
.stat-card {
    background: #f0f7ff;
    border: 1px solid #c8e0ff;
    border-radius: 10px;
    padding: 16px 20px;
    text-align: center;
}
.stat-number { font-size: 2.2rem; font-weight: 700; color: #1a4e8a; }
.stat-label  { font-size: 0.85rem; color: #555; margin-top: 2px; }
.answer-box  {
    background: #f9f9f9;
    border-left: 3px solid #aaa;
    padding: 8px 12px;
    border-radius: 0 6px 6px 0;
    font-size: 0.9rem;
    white-space: pre-wrap;
}
</style>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# AUTH
# ═══════════════════════════════════════════════════════════════════════════════

def _check_auth() -> bool:
    if st.session_state.get("admin_ok"):
        return True

    st.markdown("# 🔐 DocQA Admin Login")
    st.markdown("Enter the admin password to access the dashboard.")

    pwd = st.text_input("Password", type="password", key="admin_pwd_input")
    col1, col2 = st.columns([1, 5])
    with col1:
        if st.button("Login", use_container_width=True):
            if pwd == ADMIN_PASSWORD:
                st.session_state.admin_ok = True
                log.info("Admin login successful")
                st.rerun()
            else:
                st.error("❌ Wrong password")
                log.warning("Admin login failed — wrong password")
    return False

if not _check_auth():
    st.stop()


# ═══════════════════════════════════════════════════════════════════════════════
# HEADER
# ═══════════════════════════════════════════════════════════════════════════════

col_title, col_time, col_refresh, col_logout = st.columns([5, 3, 1, 1])

with col_title:
    st.markdown("## 🛡️ DocQA Admin Dashboard")
with col_time:
    st.caption(f"🕐 Last refreshed: {datetime.now().strftime('%Y-%m-%d  %H:%M:%S')}")
with col_refresh:
    if st.button("🔄 Refresh", use_container_width=True):
        st.rerun()
with col_logout:
    if st.button("🚪 Logout", use_container_width=True):
        st.session_state.admin_ok = False
        st.rerun()

st.divider()


# ═══════════════════════════════════════════════════════════════════════════════
# STATS CARDS
# ═══════════════════════════════════════════════════════════════════════════════

stats = db_logger.get_stats()

c1, c2, c3, c4, c5, c6, c7 = st.columns(7)

def _card(col, number, label):
    col.markdown(
        f"<div class='stat-card'>"
        f"<div class='stat-number'>{number}</div>"
        f"<div class='stat-label'>{label}</div>"
        f"</div>",
        unsafe_allow_html=True,
    )

_card(c1, stats["total_questions"],  "Total Questions")
_card(c2, stats["today_questions"],  "Today's Questions")
_card(c3, stats["total_sessions"],   "Total Sessions")
_card(c4, stats["unique_users"],     "Unique Users (IPs)")
_card(c5, stats["total_documents"],  "Documents Uploaded")
_card(c6, f"{stats['avg_ttft']:.2f}s",  "Avg TTFT")
_card(c7, f"{stats['avg_total']:.2f}s", "Avg Answer Time")

st.divider()


# ═══════════════════════════════════════════════════════════════════════════════
# TABS
# ═══════════════════════════════════════════════════════════════════════════════

tab_qa, tab_timing, tab_users, tab_sessions, tab_docs = st.tabs([
    "💬 Q&A Logs",
    "📊 Timing Charts",
    "👥 User Activity",
    "🔑 Sessions",
    "📄 Documents",
])


# ── TAB 1: Q&A Logs ──────────────────────────────────────────────────────────

with tab_qa:
    st.subheader("Recent Questions & Answers")

    # Filters
    fc1, fc2, fc3 = st.columns([3, 2, 2])
    ip_filter   = fc1.text_input("Filter by IP address", placeholder="e.g. 192.168")
    type_filter = fc2.selectbox("Question type", ["All", "text", "image"])
    limit       = fc3.slider("Max rows", 20, 200, 50, 10)

    rows = db_logger.get_recent_qa(
        limit       = limit,
        ip_filter   = ip_filter if ip_filter else "",
        type_filter = "" if type_filter == "All" else type_filter,
    )

    if not rows:
        st.info("No Q&A logs match the current filters.")
    else:
        st.caption(f"Showing {len(rows)} record(s)")
        for row in rows:
            q_short = row["question"][:90] + ("…" if len(row["question"]) > 90 else "")
            icon    = "🖼️" if row["question_type"] == "image" else "📝"
            with st.expander(
                f"{icon} [{row['created_at']}]  IP: `{row['ip']}`  —  {q_short}"
            ):
                st.markdown(f"**Session:** `{row['session_id'][:12]}…`")
                st.markdown(f"**Turn:** {row['turn']} &nbsp;|&nbsp; **Type:** `{row['question_type']}` &nbsp;|&nbsp; **Images sent:** {row['images_sent']}")
                st.markdown("**Question:**")
                st.info(row["question"])
                st.markdown("**Answer:**")
                answer_preview = row["answer"][:1200] + ("…" if len(row["answer"]) > 1200 else "")
                st.markdown(f"<div class='answer-box'>{answer_preview}</div>", unsafe_allow_html=True)

                tm1, tm2, tm3, tm4 = st.columns(4)
                tm1.metric("TTFT",       f"{row['t_ttft']:.2f}s")
                tm2.metric("Total Time", f"{row['t_total']:.2f}s")
                tm3.metric("Speed",      f"{row['chars_per_sec']:.0f} c/s")
                tm4.metric("Prompt Build", f"{row['t_prompt']:.3f}s")


# ── TAB 2: Timing Charts ──────────────────────────────────────────────────────

with tab_timing:
    st.subheader("Response Timing Trends (last 100 queries)")

    series = db_logger.get_timing_series(limit=100)

    if len(series) < 2:
        st.info("Not enough data yet — ask some questions first.")
    else:
        df = pd.DataFrame(series)
        df["idx"] = range(1, len(df) + 1)

        # TTFT chart
        st.markdown("**⚡ Time-To-First-Token (TTFT) per query**")
        st.line_chart(df.set_index("idx")[["t_ttft"]], height=200)

        # Total time chart
        st.markdown("**⏱️ Total Answer Time per query**")
        st.line_chart(df.set_index("idx")[["t_total"]], height=200)

        # Speed chart
        st.markdown("**🚀 Generation Speed (chars/sec) per query**")
        st.line_chart(df.set_index("idx")[["chars_per_sec"]], height=200)

        # Summary stats table
        st.markdown("**📋 Summary Statistics**")
        summary = {
            "Metric":    ["TTFT (s)", "Total Time (s)", "Chars/sec"],
            "Min":       [df.t_ttft.min(), df.t_total.min(), df.chars_per_sec.min()],
            "Max":       [df.t_ttft.max(), df.t_total.max(), df.chars_per_sec.max()],
            "Mean":      [df.t_ttft.mean(), df.t_total.mean(), df.chars_per_sec.mean()],
            "Median":    [df.t_ttft.median(), df.t_total.median(), df.chars_per_sec.median()],
        }
        st.dataframe(
            pd.DataFrame(summary).set_index("Metric").round(3),
            use_container_width=True,
        )


# ── TAB 3: User Activity ──────────────────────────────────────────────────────

with tab_users:
    st.subheader("Per-User (IP) Activity")

    ip_rows = db_logger.get_ip_activity()
    if not ip_rows:
        st.info("No user activity yet.")
    else:
        df_ip = pd.DataFrame(ip_rows)
        df_ip.columns = ["IP Address", "Questions", "Avg TTFT (s)", "Avg Total (s)", "Last Seen"]
        st.dataframe(df_ip, use_container_width=True, height=400)

        # Bar chart of questions per IP
        if len(df_ip) > 1:
            st.markdown("**Questions per user**")
            st.bar_chart(df_ip.set_index("IP Address")["Questions"], height=250)


# ── TAB 4: Sessions ───────────────────────────────────────────────────────────

with tab_sessions:
    st.subheader("All Sessions")

    session_rows = db_logger.get_sessions(limit=200)
    if not session_rows:
        st.info("No sessions recorded yet.")
    else:
        df_s = pd.DataFrame(session_rows)
        df_s["session_id"] = df_s["session_id"].str[:16] + "…"
        df_s.columns = ["Session ID", "IP", "Started At", "Ended At", "Total Questions"]
        st.dataframe(df_s, use_container_width=True, height=500)


# ── TAB 5: Documents ─────────────────────────────────────────────────────────

with tab_docs:
    st.subheader("Document Upload History")

    doc_rows = db_logger.get_documents(limit=200)
    if not doc_rows:
        st.info("No documents uploaded yet.")
    else:
        df_d = pd.DataFrame(doc_rows)
        # Format for display
        df_d["chars"] = df_d["chars"].apply(lambda x: f"{x:,}")
        df_d["is_scanned"] = df_d["is_scanned"].apply(lambda x: "Yes" if x else "No")
        df_d["session_id"] = df_d["session_id"].str[:12] + "…"

        cols_show = ["created_at", "ip", "session_id", "filename", "file_type",
                     "pages", "chars", "images", "tables", "is_scanned", "t_extraction"]
        df_display = df_d[[c for c in cols_show if c in df_d.columns]]
        df_display.columns = [c.replace("_", " ").title() for c in df_display.columns]

        st.dataframe(df_display, use_container_width=True, height=500)

        # File type breakdown
        if "File Type" in df_display.columns:
            ft_counts = df_d["file_type"].value_counts()
            if len(ft_counts) > 0:
                st.markdown("**Uploads by file type**")
                st.bar_chart(ft_counts, height=200)


# ── Footer ────────────────────────────────────────────────────────────────────

st.divider()
st.caption(
    f"DocQA Admin Dashboard — DB: `logs/docqa.db` — "
    f"Refreshed: {datetime.now().strftime('%H:%M:%S')}"
)
