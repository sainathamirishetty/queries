"""
app.py  —  DocQA  Student Interface
─────────────────────────────────────────────────────────────────────────────
Run with:
    streamlit run app.py --server.address 0.0.0.0 --server.port 8000

Features:
  • Upload PDF / DOCX / PPTX / TXT / images  (MarkItDown converts all)
  • Full document context passed to Gemma4:e4b via Ollama
  • Vision mode auto-activated for image/chart questions
  • Timing metrics: extraction time, TTFT, total answer time, chars/sec
  • All activity logged to SQLite (admin can query)
  • Multi-user safe (each Streamlit session is isolated)
─────────────────────────────────────────────────────────────────────────────
"""

import re
import tempfile
import uuid
from pathlib import Path

import streamlit as st

from config import MAX_HISTORY_TURNS, SUPPORTED_EXTENSIONS
from extractor import extract_document
from logger import db_logger, get_logger
from ollama_client import (
    GenerationStats,
    build_messages,
    check_ollama_connection,
    stream_response,
)

log = get_logger("app")


# ── Page configuration ────────────────────────────────────────────────────────

st.set_page_config(
    page_title = "DocQA — Document Assistant",
    page_icon  = "📄",
    layout     = "wide",
)

# Minimal custom CSS — clean card-like metrics
st.markdown("""
<style>
/* Timing pill badges */
.timing-pill {
    display: inline-block;
    background: #e8f4fd;
    color: #1a6196;
    border-radius: 12px;
    padding: 2px 10px;
    font-size: 0.8rem;
    font-weight: 600;
    margin-right: 6px;
}
.timing-pill.ttft  { background: #e8f8e8; color: #1a6b1a; }
.timing-pill.speed { background: #fef3e8; color: #8b5a00; }

/* Sidebar doc info box */
.doc-info-box {
    background: #f7f7f7;
    border-left: 3px solid #4CAF50;
    padding: 10px 14px;
    border-radius: 0 6px 6px 0;
    margin: 8px 0;
    font-size: 0.88rem;
}

/* Hide Streamlit menu in production */
/* #MainMenu { visibility: hidden; } */
</style>
""", unsafe_allow_html=True)


# ── Cached Ollama health-check  (re-checked max once/min) ────────────────────

@st.cache_data(ttl=60, show_spinner=False)
def _check_ollama() -> tuple:
    return check_ollama_connection()


# ── Client IP detection ───────────────────────────────────────────────────────

def _get_client_ip() -> str:
    try:
        headers = getattr(st.context, "headers", None)
        if headers:
            for key in ("x-forwarded-for", "x-real-ip", "remote-addr"):
                val = headers.get(key, "").split(",")[0].strip()
                if val:
                    return val
    except Exception:
        pass
    return "unknown"


# ── Session initialisation ────────────────────────────────────────────────────

def _init_session():
    if "session_id" not in st.session_state:
        sid = str(uuid.uuid4())
        ip  = _get_client_ip()
        st.session_state.session_id = sid
        st.session_state.client_ip  = ip
        db_logger.log_session_start(sid, ip)
        log.info(f"New session  id={sid}  ip={ip}")

    _defaults = {
        "doc_name":       None,
        "doc_meta":       {},
        "extracted_text": None,
        "image_map":      {},
        "chat_history":   [],   # [{question, answer}, ...]  for LLM context
        "messages":       [],   # [{role, content, stats?, images?}]  for UI
        "qa_turn":        0,
    }
    for k, v in _defaults.items():
        st.session_state.setdefault(k, v)

_init_session()


# ─────────────────────────────────────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────

with st.sidebar:

    st.markdown("## 📄 DocQA")
    st.caption("Local Document Assistant — Gemma4 Vision")
    st.divider()

    # ── Ollama status ─────────────────────────────────────────
    ok, info = _check_ollama()
    if ok:
        st.success(f"🟢 Ollama: {info}")
    else:
        st.error(f"🔴 Ollama offline\n\n`{info}`")
        st.caption("Fix: start Ollama on your GPU server, then refresh.")

    st.divider()

    # ── File uploader ─────────────────────────────────────────
    st.subheader("📂 Upload Document")
    ext_display = " · ".join(e.upper() for e in SUPPORTED_EXTENSIONS[:8]) + " …"
    st.caption(f"Formats: {ext_display}")
    st.caption("Max 50 pages / slides")

    uploaded = st.file_uploader(
        label            = "Drop a file here",
        type             = SUPPORTED_EXTENSIONS,
        label_visibility = "collapsed",
        key              = "file_uploader",
    )

    # Process new upload
    if uploaded and uploaded.name != st.session_state.doc_name:
        progress_bar = st.progress(0, text="📖 Reading file…")

        try:
            suffix = Path(uploaded.name).suffix

            # Write to temp file
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(uploaded.read())
                tmp_path = tmp.name
            progress_bar.progress(20, text="🔄 Converting to Markdown…")

            # Extract
            res = extract_document(
                file_path         = tmp_path,
                file_ext          = suffix.lstrip("."),
                session_id        = st.session_state.session_id,
                original_filename = uploaded.name,
            )
            progress_bar.progress(80, text="💾 Saving…")

            # Store in session
            st.session_state.doc_name       = uploaded.name
            st.session_state.extracted_text = res.full_text
            st.session_state.image_map      = res.image_map
            st.session_state.doc_meta       = {
                "pages":        res.page_count,
                "chars":        len(res.full_text),
                "images":       len(res.image_map),
                "tables":       res.table_count,
                "is_scanned":   res.is_scanned,
                "file_type":    res.file_type.upper(),
                "t_extraction": res.t_total,
                "md_path":      res.md_saved_path or "",
            }
            # Reset chat
            st.session_state.chat_history = []
            st.session_state.messages     = []
            st.session_state.qa_turn      = 0

            # Log to DB
            db_logger.log_document(
                session_id   = st.session_state.session_id,
                ip           = st.session_state.client_ip,
                filename     = uploaded.name,
                file_type    = res.file_type,
                pages        = res.page_count,
                chars        = len(res.full_text),
                images       = len(res.image_map),
                tables       = res.table_count,
                is_scanned   = res.is_scanned,
                md_path      = res.md_saved_path or "",
                t_extraction = res.t_total,
            )

            progress_bar.progress(100, text="✅ Done!")
            log.info(f"Extracted: {uploaded.name} | {res.summary}")

        except ValueError as e:
            progress_bar.empty()
            st.error(str(e))
            log.warning(str(e))
        except Exception as e:
            progress_bar.empty()
            st.error(f"Extraction error: {e}")
            log.exception(str(e))

    st.divider()

    # ── Document info panel ───────────────────────────────────
    if st.session_state.doc_name:
        meta = st.session_state.doc_meta
        st.subheader("📋 Document Info")

        st.markdown(
            f"<div class='doc-info-box'>"
            f"<b>File:</b> {st.session_state.doc_name}<br>"
            f"<b>Type:</b> {meta.get('file_type','—')} &nbsp;|&nbsp; "
            f"<b>Pages:</b> {meta.get('pages','—')}<br>"
            f"<b>Images:</b> {meta.get('images',0)} &nbsp;|&nbsp; "
            f"<b>Tables:</b> {meta.get('tables',0)}<br>"
            f"<b>Chars:</b> {meta.get('chars',0):,}"
            f"</div>",
            unsafe_allow_html=True,
        )

        ex_t = meta.get("t_extraction", 0)
        st.markdown(
            f"⏱️ **Extraction time:** `{ex_t:.2f}s`",
            help="Time taken by MarkItDown to convert the document to Markdown.",
        )
        if meta.get("is_scanned"):
            st.caption("🔍 Scanned PDF detected")
        if meta.get("md_path"):
            st.caption(f"💾 Saved: `{meta['md_path']}`")

        st.divider()

        if st.button("🗑️ Clear Document", use_container_width=True):
            for k in ("doc_name", "extracted_text", "doc_meta"):
                st.session_state[k] = None
            st.session_state.image_map    = {}
            st.session_state.chat_history = []
            st.session_state.messages     = []
            st.session_state.qa_turn      = 0
            log.info("Document cleared by user")
            st.rerun()


# ─────────────────────────────────────────────────────────────────────────────
# MAIN CHAT AREA
# ─────────────────────────────────────────────────────────────────────────────

st.title("💬 Ask Your Document")

if not st.session_state.extracted_text:
    st.info(
        "### 👈 Upload a document from the sidebar\n\n"
        "Supported formats: **PDF · DOCX · PPTX · TXT · PNG · JPG** and more.\n\n"
        "After upload, ask anything — text, tables, charts, images are all understood."
    )
    st.stop()


# ── Render chat history ───────────────────────────────────────────────────────

_MODE_ICON = {"image": "🖼️ Vision", "text": "📝 Text"}

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

        # Show timing pills for assistant messages
        if msg["role"] == "assistant":
            s = msg.get("stats")
            if s:
                st.markdown(
                    f"<span class='timing-pill ttft'>⚡ TTFT {s['ttft']:.2f}s</span>"
                    f"<span class='timing-pill'>⏱️ Total {s['total']:.2f}s</span>"
                    f"<span class='timing-pill speed'>🚀 {s['cps']:.0f} chars/s</span>"
                    f"<span class='timing-pill'>{_MODE_ICON.get(s.get('mode','text'),'')}</span>",
                    unsafe_allow_html=True,
                )
            # Re-render images referenced in the answer
            for img_path in msg.get("images", []):
                if Path(img_path).exists():
                    st.image(img_path, width=680)


# ── Chat input ────────────────────────────────────────────────────────────────

question = st.chat_input(
    placeholder = "Ask about text, tables, charts, images in the document…",
    disabled    = not st.session_state.extracted_text,
)

if not question:
    st.stop()

# ── Show user message ─────────────────────────────────────────────────────────

with st.chat_message("user"):
    st.markdown(question)
st.session_state.messages.append({"role": "user", "content": question})

# ── Build Ollama messages ─────────────────────────────────────────────────────

messages, images_b64, t_prompt, mode = build_messages(
    extracted_text = st.session_state.extracted_text,
    chat_history   = st.session_state.chat_history,
    question       = question,
    image_map      = st.session_state.image_map,
)

stats = GenerationStats(t_prompt_build=t_prompt)

log.info(
    f"[Q] Turn {st.session_state.qa_turn + 1} | mode={mode} | "
    f"{len(images_b64)} image(s) | prompt_build={t_prompt:.3f}s"
)

# ── Stream assistant answer ───────────────────────────────────────────────────

full_answer    = ""
rendered_imgs  = []

with st.chat_message("assistant"):
    st.caption(_MODE_ICON.get(mode, ""))

    # Stream tokens
    full_answer = st.write_stream(stream_response(messages, stats))

    # Timing pills (shown immediately after streaming finishes)
    st.markdown(
        f"<span class='timing-pill ttft'>⚡ TTFT {stats.t_ttft:.2f}s</span>"
        f"<span class='timing-pill'>⏱️ Total {stats.t_total:.2f}s</span>"
        f"<span class='timing-pill speed'>🚀 {stats.chars_per_sec:.0f} chars/s</span>"
        f"<span class='timing-pill'>{_MODE_ICON.get(mode,'')}</span>",
        unsafe_allow_html=True,
    )

    # Render images the LLM referenced  ("See Image N" / "Image N")
    if st.session_state.image_map:
        ref_nums = {int(m) for m in re.findall(r"(?:see\s+)?image\s+(\d+)", full_answer, re.I)}
        for n in sorted(ref_nums):
            img_path = st.session_state.image_map.get(n)
            if img_path and Path(img_path).exists():
                st.image(img_path, caption=f"Image {n}", width=680)
                rendered_imgs.append(img_path)

# ── Update session state ──────────────────────────────────────────────────────

st.session_state.qa_turn += 1
st.session_state.chat_history.append({"question": question, "answer": full_answer})
if len(st.session_state.chat_history) > MAX_HISTORY_TURNS:
    st.session_state.chat_history = st.session_state.chat_history[-MAX_HISTORY_TURNS:]

st.session_state.messages.append({
    "role":    "assistant",
    "content": full_answer,
    "images":  rendered_imgs,
    "stats": {
        "ttft":  stats.t_ttft,
        "total": stats.t_total,
        "cps":   stats.chars_per_sec,
        "mode":  mode,
    },
})

# ── Log to DB ─────────────────────────────────────────────────────────────────

db_logger.log_qa(
    session_id    = st.session_state.session_id,
    ip            = st.session_state.client_ip,
    turn          = st.session_state.qa_turn,
    question      = question,
    answer        = full_answer,
    question_type = mode,
    images_sent   = len(images_b64),
    t_prompt      = stats.t_prompt_build,
    t_ttft        = stats.t_ttft,
    t_total       = stats.t_total,
    chars_per_sec = stats.chars_per_sec,
)

log.info(
    f"[QA Done] Turn {st.session_state.qa_turn} | "
    f"ip={st.session_state.client_ip} | {stats.summary}"
)
