# config.py
# ─────────────────────────────────────────────────────────────────────────────
#  Single source of truth for all settings.
#  Edit ONLY this file to reconfigure the system.
# ─────────────────────────────────────────────────────────────────────────────

# ── Ollama ────────────────────────────────────────────────────────────────────
OLLAMA_HOST    = "http://localhost:11434"   # ← change to your GPU server IP e.g. http://192.168.1.100:11434
OLLAMA_MODEL   = "gemma4:e4b"              # multimodal vision model
OLLAMA_TIMEOUT = 600                        # seconds — large docs may take longer

# ── LLM generation ────────────────────────────────────────────────────────────
LLM_CONTEXT_SIZE  = 128000   # Gemma4 supports 128k
LLM_TEMPERATURE   = 0.1      # low = more factual / deterministic
LLM_TOP_P         = 0.9

# ── Document limits ───────────────────────────────────────────────────────────
MAX_PAGES         = 50        # reject docs larger than this
MAX_HISTORY_TURNS = 10        # how many previous Q&A turns to keep in context

# ── Image selection ───────────────────────────────────────────────────────────
MAX_IMAGES_PER_QUERY = 5      # max images sent to LLM per question

# ── Storage ───────────────────────────────────────────────────────────────────
EXTRACTED_DOCS_DIR = "extracted_docs"
# Structure: extracted_docs/YYYY-MM-DD/<file_stem>/
#               <file_stem>.md          ← full markdown
#               images/image_001.png    ← extracted images

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_DIR = "logs"
LOG_DB  = "logs/docqa.db"     # SQLite — all activity stored here

# ── Admin dashboard ───────────────────────────────────────────────────────────
ADMIN_PASSWORD = "admin123"   # ← CHANGE THIS before deploying

# ── Supported file types ──────────────────────────────────────────────────────
SUPPORTED_EXTENSIONS = [
    # Documents
    "pdf", "docx", "pptx", "ppt", "txt",
    # Images (sent directly to vision model)
    "png", "jpg", "jpeg", "bmp", "gif", "webp",
]
