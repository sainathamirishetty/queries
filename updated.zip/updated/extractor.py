"""
extractor.py
─────────────────────────────────────────────────────────────────────────────
Universal document extraction pipeline using MarkItDown + PyMuPDF.

Pipeline:
  1. MarkItDown  → converts ANY supported format to clean Markdown text
  2. Format-specific image extractor → saves images to /images/ folder
  3. Image references injected into markdown as  [Image N](path)
  4. Final .md saved to  extracted_docs/YYYY-MM-DD/<stem>/<stem>.md

Supported formats:
  Documents : PDF, DOCX, PPTX, TXT
  Images    : PNG, JPG, JPEG, BMP, GIF, WEBP  (passed directly as vision)

MarkItDown handles all text-extraction complexity:
  — heading levels, bold/italic, tables as pipe-markdown, code blocks, lists
  — page breaks preserved in output
─────────────────────────────────────────────────────────────────────────────
"""

import io
import re
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from config import EXTRACTED_DOCS_DIR, MAX_PAGES
from logger import get_logger

log = get_logger("extractor")

# ── MarkItDown singleton (instantiate once, reuse) ────────────────────────────

try:
    from markitdown import MarkItDown
    _mdi = MarkItDown(enable_plugins=False)   # no LLM description needed
    log.info("MarkItDown loaded ✅")
except ImportError:
    _mdi = None
    log.warning("MarkItDown not installed — install: pip install markitdown[all]")


# ═══════════════════════════════════════════════════════════════════════════════
# Result dataclass
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ExtractionResult:
    full_text:     str            = ""
    image_map:     Dict[int, str] = field(default_factory=dict)   # {1: "path/to/img"}
    table_count:   int            = 0
    page_count:    int            = 0
    is_scanned:    bool           = False
    md_saved_path: Optional[str] = None
    file_type:     str            = ""
    t_total:       float          = 0.0

    @property
    def summary(self) -> str:
        return (
            f"Pages: {self.page_count} | Chars: {len(self.full_text):,} | "
            f"Images: {len(self.image_map)} | Tables: {self.table_count} | "
            f"Scanned: {self.is_scanned} | Time: {self.t_total:.2f}s"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# Directory helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _make_output_dirs(original_filename: str) -> Tuple[Path, Path]:
    """
    Create and return:
        out_dir   → extracted_docs/YYYY-MM-DD/<safe_stem>/
        img_dir   → extracted_docs/YYYY-MM-DD/<safe_stem>/images/
    """
    date_str  = datetime.now().strftime("%Y-%m-%d")
    stem      = Path(original_filename).stem
    safe_stem = re.sub(r"[^\w\-]", "_", stem)[:60]
    out_dir   = Path(EXTRACTED_DOCS_DIR) / date_str / safe_stem
    img_dir   = out_dir / "images"
    out_dir.mkdir(parents=True, exist_ok=True)
    img_dir.mkdir(parents=True, exist_ok=True)
    return out_dir, img_dir


def _safe_stem(original_filename: str) -> str:
    return re.sub(r"[^\w\-]", "_", Path(original_filename).stem)[:60]


# ═══════════════════════════════════════════════════════════════════════════════
# MarkItDown text extraction  (universal)
# ═══════════════════════════════════════════════════════════════════════════════

def _markitdown_convert(file_path: str) -> str:
    """Convert any file to markdown text using MarkItDown."""
    if _mdi is None:
        raise RuntimeError(
            "MarkItDown is not installed. Run: pip install markitdown[all]"
        )
    result = _mdi.convert(file_path)
    return result.text_content or ""


# ═══════════════════════════════════════════════════════════════════════════════
# Image extractors  (format-specific)
# ═══════════════════════════════════════════════════════════════════════════════

def _extract_images_pdf(file_path: str, img_dir: Path) -> Dict[int, str]:
    """
    Extract embedded images from PDF using PyMuPDF (fitz).
    Much more reliable than pdfplumber bbox-cropping.
    """
    image_map: Dict[int, str] = {}
    counter = 0
    try:
        import fitz  # PyMuPDF

        doc = fitz.open(file_path)
        seen_xrefs = set()

        for page_num, page in enumerate(doc):
            for img_info in page.get_images(full=True):
                xref = img_info[0]
                if xref in seen_xrefs:
                    continue               # skip duplicate xrefs (same image on multiple pages)
                seen_xrefs.add(xref)

                try:
                    base = doc.extract_image(xref)
                    img_bytes = base["image"]
                    ext       = base.get("ext", "png")
                    if ext == "jpx":
                        ext = "jpg"
                    counter += 1
                    img_path = img_dir / f"image_{counter:03d}.{ext}"
                    img_path.write_bytes(img_bytes)
                    image_map[counter] = str(img_path)
                    log.debug(f"PDF: saved image {counter} (xref {xref}) from page {page_num+1}")
                except Exception as e:
                    log.warning(f"PDF image xref {xref}: {e}")

        doc.close()

    except ImportError:
        log.warning("PyMuPDF not installed — PDF images skipped. Run: pip install pymupdf")
    except Exception as e:
        log.error(f"PDF image extraction failed: {e}")

    return image_map


def _extract_images_docx(file_path: str, img_dir: Path) -> Dict[int, str]:
    """Extract images embedded in a DOCX via its relationships."""
    image_map: Dict[int, str] = {}
    counter = 0
    try:
        from docx import Document

        doc = Document(file_path)
        for rel in doc.part.rels.values():
            if "image" not in rel.reltype:
                continue
            try:
                img_bytes = rel.target_part.blob
                ct  = rel.target_part.content_type          # e.g. "image/png"
                ext = ct.split("/")[-1] if "/" in ct else "png"
                ext = "jpg" if ext in ("jpeg", "jpg") else ext
                counter += 1
                img_path = img_dir / f"image_{counter:03d}.{ext}"
                img_path.write_bytes(img_bytes)
                image_map[counter] = str(img_path)
                log.debug(f"DOCX: saved image {counter}")
            except Exception as e:
                log.warning(f"DOCX image rel: {e}")

    except ImportError:
        log.warning("python-docx not installed. Run: pip install python-docx")
    except Exception as e:
        log.error(f"DOCX image extraction failed: {e}")

    return image_map


def _extract_images_pptx(file_path: str, img_dir: Path) -> Dict[int, str]:
    """Extract images from every slide in a PPTX."""
    image_map: Dict[int, str] = {}
    counter = 0
    try:
        from pptx import Presentation

        prs = Presentation(file_path)
        for slide_idx, slide in enumerate(prs.slides, 1):
            for shape in slide.shapes:
                if not hasattr(shape, "image"):
                    continue
                try:
                    img   = shape.image
                    ext   = img.ext or "png"
                    counter += 1
                    img_path = img_dir / f"image_{counter:03d}.{ext}"
                    img_path.write_bytes(img.blob)
                    image_map[counter] = str(img_path)
                    log.debug(f"PPTX: saved image {counter} from slide {slide_idx}")
                except Exception as e:
                    log.warning(f"PPTX image slide {slide_idx}: {e}")

    except ImportError:
        log.warning("python-pptx not installed. Run: pip install python-pptx")
    except Exception as e:
        log.error(f"PPTX image extraction failed: {e}")

    return image_map


def _handle_image_file(file_path: str, img_dir: Path, file_ext: str) -> Dict[int, str]:
    """
    The uploaded file IS an image — copy it to the images folder.
    MarkItDown will provide basic metadata; we pass the image to vision LLM.
    """
    img_path = img_dir / f"image_001.{file_ext}"
    shutil.copy2(file_path, img_path)
    log.debug(f"Image file saved: {img_path}")
    return {1: str(img_path)}


# ═══════════════════════════════════════════════════════════════════════════════
# Markdown finaliser  — inject image references
# ═══════════════════════════════════════════════════════════════════════════════

def _inject_image_refs(text: str, image_map: Dict[int, str]) -> str:
    """
    Append an '## Extracted Images' section to the markdown with:
      - A [Image N appears here] anchor  (so the LLM knows they exist)
      - A proper markdown image link     (so the .md file is viewable)
    """
    if not image_map:
        return text

    lines = [text.rstrip(), "\n\n---\n", "## 📸 Extracted Images\n"]
    for num, path in sorted(image_map.items()):
        lines.append(f"[Image {num} appears here]")
        lines.append(f"![Image {num}]({path})\n")

    return "\n".join(lines)


def _count_tables(text: str) -> int:
    """Rough count of markdown pipe tables in the extracted text."""
    return len(re.findall(r"^\|.+\|$", text, re.MULTILINE))


def _estimate_pages(text: str, file_ext: str) -> int:
    """Estimate page count from form-feeds or page markers in text."""
    if file_ext == "pdf":
        # pdfminer / markitdown inserts \f between pages
        return max(1, text.count("\f") + 1)
    if file_ext == "pptx":
        # MarkItDown separates slides with '---' or '# Slide N'
        slides = len(re.findall(r"^#{1,2}\s+Slide\s+\d+", text, re.MULTILINE))
        return max(1, slides)
    return 1


# ═══════════════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════════════

_IMAGE_EXTS = {"png", "jpg", "jpeg", "bmp", "gif", "webp"}
_DOC_EXTS   = {"pdf", "docx", "pptx", "ppt", "txt"}


def extract_document(
    file_path:         str,
    file_ext:          str,
    session_id:        str,
    original_filename: str,
) -> ExtractionResult:
    """
    Main entry point — dispatch to correct extractor, save outputs,
    return a fully-populated ExtractionResult.

    Args:
        file_path:         Path to the temporary uploaded file on disk.
        file_ext:          Extension WITHOUT dot (e.g. 'pdf', 'docx').
        session_id:        Current Streamlit session UUID.
        original_filename: Original name the user uploaded (for folder naming).

    Returns:
        ExtractionResult  with full_text, image_map, timings, and saved paths.
    """
    t_wall   = time.perf_counter()
    file_ext = file_ext.lower().lstrip(".")

    supported = _IMAGE_EXTS | _DOC_EXTS
    if file_ext not in supported:
        raise ValueError(f"Unsupported file type: .{file_ext}  |  Supported: {sorted(supported)}")

    out_dir, img_dir = _make_output_dirs(original_filename)
    stem             = _safe_stem(original_filename)
    res              = ExtractionResult(file_type=file_ext)

    # ── STEP 1 — Text extraction via MarkItDown ───────────────────────────────
    log.info(f"[{file_ext.upper()}] Starting MarkItDown conversion: {original_filename}")
    t0 = time.perf_counter()
    try:
        res.full_text = _markitdown_convert(file_path)
        log.info(f"MarkItDown: {len(res.full_text):,} chars in {time.perf_counter()-t0:.2f}s")
    except Exception as e:
        log.error(f"MarkItDown failed: {e}")
        res.full_text = f"# {original_filename}\n\n[Text extraction failed: {e}]"

    # ── STEP 2 — Image extraction (format-specific) ───────────────────────────
    t0 = time.perf_counter()
    image_map: Dict[int, str] = {}

    if file_ext == "pdf":
        image_map      = _extract_images_pdf(file_path, img_dir)
        res.page_count = _estimate_pages(res.full_text, "pdf")

    elif file_ext == "docx":
        image_map      = _extract_images_docx(file_path, img_dir)
        res.page_count = 1

    elif file_ext in ("pptx", "ppt"):
        image_map      = _extract_images_pptx(file_path, img_dir)
        res.page_count = _estimate_pages(res.full_text, "pptx")
        if res.page_count == 1:
            # Fallback: count slides via python-pptx
            try:
                from pptx import Presentation
                res.page_count = len(Presentation(file_path).slides)
            except Exception:
                pass

    elif file_ext == "txt":
        res.page_count = 1

    elif file_ext in _IMAGE_EXTS:
        image_map      = _handle_image_file(file_path, img_dir, file_ext)
        res.page_count = 1
        # For a raw image, full_text may be minimal — annotate it
        if not res.full_text.strip():
            res.full_text = f"# {original_filename}\n\n[Image file — see image below]\n"

    log.info(f"Images extracted: {len(image_map)} in {time.perf_counter()-t0:.2f}s")

    # ── STEP 3 — Page limit check ─────────────────────────────────────────────
    if res.page_count > MAX_PAGES:
        raise ValueError(
            f"Document has {res.page_count} pages — the limit is {MAX_PAGES}. "
            "Please upload a shorter document."
        )

    # ── STEP 4 — Finalise markdown ────────────────────────────────────────────
    res.image_map   = image_map
    res.table_count = _count_tables(res.full_text)
    res.full_text   = _inject_image_refs(res.full_text, image_map)

    # ── STEP 5 — Save .md file ────────────────────────────────────────────────
    md_path = out_dir / f"{stem}.md"
    md_path.write_text(res.full_text, encoding="utf-8")
    res.md_saved_path = str(md_path)

    res.t_total = time.perf_counter() - t_wall
    log.info(f"Extraction complete: {original_filename} → {res.summary}")
    return res
