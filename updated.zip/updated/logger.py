"""
logger.py
─────────────────────────────────────────────────────────────────────────────
Two logging layers:

  1. System logger  → rotating daily .log files (debug / info / errors)
  2. Activity logger → SQLite database   (sessions, documents, Q&A with timings)

SQLite gives the admin dashboard real-time queryable data — filter by IP,
question type, date range, timing percentiles, etc.
─────────────────────────────────────────────────────────────────────────────
"""

import logging
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ── import config safely (logger is imported before config in some edge cases) ─

try:
    from config import LOG_DIR as _LOG_DIR_STR, LOG_DB as _LOG_DB_STR
except ImportError:
    _LOG_DIR_STR = "logs"
    _LOG_DB_STR  = "logs/docqa.db"


# ═══════════════════════════════════════════════════════════════════════════════
# System logger  (Python logging → daily .log file + console)
# ═══════════════════════════════════════════════════════════════════════════════

_LOG_DIR = Path(_LOG_DIR_STR)
_LOG_DIR.mkdir(parents=True, exist_ok=True)

_DATE_FMT   = "%Y-%m-%d %H:%M:%S"
_CONSOLE_FMT = "[%(asctime)s] %(levelname)-8s %(name)s — %(message)s"
_FILE_FMT    = "[%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s"


def get_logger(name: str) -> logging.Logger:
    """Return a named logger with console + daily file handlers (idempotent)."""
    full_name = f"docqa.{name}"
    logger    = logging.getLogger(full_name)

    if logger.handlers:
        return logger   # already configured

    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Console — INFO and above
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(logging.Formatter(_CONSOLE_FMT, datefmt="%H:%M:%S"))
    logger.addHandler(ch)

    # File — DEBUG and above, rotates daily
    log_file = _LOG_DIR / f"system_{datetime.now().strftime('%Y-%m-%d')}.log"
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_FILE_FMT, datefmt=_DATE_FMT))
    logger.addHandler(fh)

    return logger


# ═══════════════════════════════════════════════════════════════════════════════
# Activity logger  (SQLite — structured, queryable)
# ═══════════════════════════════════════════════════════════════════════════════

_SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS sessions (
    session_id      TEXT    PRIMARY KEY,
    ip              TEXT    NOT NULL,
    started_at      TEXT    NOT NULL,
    ended_at        TEXT,
    total_questions INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS documents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT    NOT NULL,
    ip              TEXT    NOT NULL,
    filename        TEXT    NOT NULL,
    file_type       TEXT    NOT NULL,
    pages           INTEGER DEFAULT 0,
    chars           INTEGER DEFAULT 0,
    images          INTEGER DEFAULT 0,
    tables          INTEGER DEFAULT 0,
    is_scanned      INTEGER DEFAULT 0,
    md_path         TEXT,
    t_extraction    REAL    DEFAULT 0.0,
    created_at      TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS qa_logs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT    NOT NULL,
    ip              TEXT    NOT NULL,
    turn            INTEGER NOT NULL,
    question        TEXT    NOT NULL,
    answer          TEXT    NOT NULL,
    question_type   TEXT    DEFAULT 'text',
    images_sent     INTEGER DEFAULT 0,
    t_prompt        REAL    DEFAULT 0.0,
    t_ttft          REAL    DEFAULT 0.0,
    t_total         REAL    DEFAULT 0.0,
    chars_per_sec   REAL    DEFAULT 0.0,
    created_at      TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_qa_ip         ON qa_logs(ip);
CREATE INDEX IF NOT EXISTS idx_qa_created    ON qa_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_doc_session   ON documents(session_id);
CREATE INDEX IF NOT EXISTS idx_session_ip    ON sessions(ip);
"""


class DBLogger:
    """
    Thread-safe SQLite activity logger.
    All methods are safe to call from multiple Streamlit sessions concurrently.
    """

    def __init__(self, db_path: str = _LOG_DB_STR):
        self._db_path = db_path
        self._lock    = threading.Lock()
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    # ── internal ─────────────────────────────────────────────────────────────

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self):
        with self._lock:
            with self._connect() as conn:
                conn.executescript(_SCHEMA)

    def _now(self) -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # ── write API ────────────────────────────────────────────────────────────

    def log_session_start(self, session_id: str, ip: str):
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    "INSERT OR IGNORE INTO sessions (session_id, ip, started_at) VALUES (?, ?, ?)",
                    (session_id, ip, self._now()),
                )

    def log_session_end(self, session_id: str):
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    "UPDATE sessions SET ended_at = ? WHERE session_id = ?",
                    (self._now(), session_id),
                )

    def log_document(
        self,
        session_id:   str,
        ip:           str,
        filename:     str,
        file_type:    str,
        pages:        int,
        chars:        int,
        images:       int,
        tables:       int,
        is_scanned:   bool,
        md_path:      str,
        t_extraction: float,
    ):
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """INSERT INTO documents
                       (session_id, ip, filename, file_type, pages, chars,
                        images, tables, is_scanned, md_path, t_extraction, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        session_id, ip, filename, file_type, pages, chars,
                        images, tables, int(is_scanned), md_path, t_extraction,
                        self._now(),
                    ),
                )

    def log_qa(
        self,
        session_id:    str,
        ip:            str,
        turn:          int,
        question:      str,
        answer:        str,
        question_type: str,
        images_sent:   int,
        t_prompt:      float,
        t_ttft:        float,
        t_total:       float,
        chars_per_sec: float,
    ):
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """INSERT INTO qa_logs
                       (session_id, ip, turn, question, answer, question_type,
                        images_sent, t_prompt, t_ttft, t_total, chars_per_sec, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        session_id, ip, turn, question, answer, question_type,
                        images_sent, t_prompt, t_ttft, t_total, chars_per_sec,
                        self._now(),
                    ),
                )
                conn.execute(
                    "UPDATE sessions SET total_questions = total_questions + 1 WHERE session_id = ?",
                    (session_id,),
                )

    # ── read API (for admin dashboard) ───────────────────────────────────────

    def get_stats(self) -> Dict:
        with self._connect() as conn:
            total_q       = conn.execute("SELECT COUNT(*) FROM qa_logs").fetchone()[0]
            total_sessions= conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
            unique_ips    = conn.execute("SELECT COUNT(DISTINCT ip) FROM sessions").fetchone()[0]
            avg_ttft      = conn.execute("SELECT AVG(t_ttft)  FROM qa_logs").fetchone()[0] or 0.0
            avg_total     = conn.execute("SELECT AVG(t_total) FROM qa_logs").fetchone()[0] or 0.0
            total_docs    = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
            today         = datetime.now().strftime("%Y-%m-%d")
            today_q       = conn.execute(
                "SELECT COUNT(*) FROM qa_logs WHERE created_at LIKE ?", (f"{today}%",)
            ).fetchone()[0]
        return {
            "total_questions":  total_q,
            "today_questions":  today_q,
            "total_sessions":   total_sessions,
            "unique_users":     unique_ips,
            "total_documents":  total_docs,
            "avg_ttft":         round(avg_ttft, 3),
            "avg_total":        round(avg_total, 3),
        }

    def get_recent_qa(self, limit: int = 200, ip_filter: str = "", type_filter: str = "") -> List[Dict]:
        sql    = "SELECT * FROM qa_logs WHERE 1=1"
        params = []
        if ip_filter:
            sql += " AND ip LIKE ?"
            params.append(f"%{ip_filter}%")
        if type_filter:
            sql += " AND question_type = ?"
            params.append(type_filter)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def get_sessions(self, limit: int = 100) -> List[Dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM sessions ORDER BY started_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def get_documents(self, limit: int = 100) -> List[Dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM documents ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def get_timing_series(self, limit: int = 100) -> List[Dict]:
        """For charting TTFT and total time over recent queries."""
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT created_at, t_ttft, t_total, chars_per_sec, question_type
                   FROM qa_logs ORDER BY created_at DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [dict(r) for r in reversed(rows)]  # oldest → newest for charts

    def get_ip_activity(self) -> List[Dict]:
        """Per-IP question count and avg timing."""
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT ip,
                          COUNT(*) AS questions,
                          ROUND(AVG(t_ttft),  2) AS avg_ttft,
                          ROUND(AVG(t_total), 2) AS avg_total,
                          MAX(created_at)        AS last_seen
                   FROM qa_logs
                   GROUP BY ip
                   ORDER BY questions DESC""",
            ).fetchall()
        return [dict(r) for r in rows]


# ── module-level shared instance ──────────────────────────────────────────────
db_logger = DBLogger()
