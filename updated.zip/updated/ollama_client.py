"""
ollama_client.py
─────────────────────────────────────────────────────────────────────────────
Synchronous streaming client for Gemma4 via Ollama.

Key design decisions:
  • Uses /api/chat  (not the deprecated /api/generate)
    → proper multi-turn conversation, cleaner system prompts
  • Images sent inside the user message dict as base64 strings
  • TTFT measured from first HTTP byte → first non-empty token
  • Total time measured from request → last token
  • Question classifier selects image mode automatically
─────────────────────────────────────────────────────────────────────────────
"""

import base64
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Generator, List, Tuple

import requests

from config import (
    LLM_CONTEXT_SIZE,
    LLM_TEMPERATURE,
    LLM_TOP_P,
    MAX_HISTORY_TURNS,
    MAX_IMAGES_PER_QUERY,
    OLLAMA_HOST,
    OLLAMA_MODEL,
    OLLAMA_TIMEOUT,
)
from logger import get_logger

log = get_logger("ollama")


# ═══════════════════════════════════════════════════════════════════════════════
# Stats dataclass
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class GenerationStats:
    t_prompt_build: float = 0.0
    t_ttft:         float = 0.0    # Time-To-First-Token
    t_total:        float = 0.0    # total answer time
    chars_generated:int   = 0

    @property
    def chars_per_sec(self) -> float:
        return self.chars_generated / self.t_total if self.t_total > 0 else 0.0

    @property
    def summary(self) -> str:
        return (
            f"Prompt build: {self.t_prompt_build:.3f}s | "
            f"TTFT: {self.t_ttft:.2f}s | "
            f"Total: {self.t_total:.2f}s | "
            f"Speed: {self.chars_per_sec:.0f} chars/s"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# Question classifier
# ═══════════════════════════════════════════════════════════════════════════════

_IMAGE_KW = frozenset([
    "chart", "graph", "diagram", "plot", "figure", "image", "picture",
    "visual", "bar", "pie", "trend", "growth", "comparison", "photo",
    "screenshot", "illustration", "color", "colour", "shape", "icon",
    "logo", "look like", "depicted", "drawn", "shown", "displayed",
])

_EXPLICIT_REF_RE = re.compile(
    r"(?:image|figure|fig|graph|chart|photo|picture)\s*\.?\s*(\d+)",
    re.IGNORECASE,
)


def _classify_question(question: str, image_map: Dict) -> str:
    """Return 'image' if vision mode needed, else 'text'."""
    if not image_map:
        return "text"
    q = question.lower()
    if _EXPLICIT_REF_RE.search(q):
        return "image"
    if any(kw in q for kw in _IMAGE_KW):
        return "image"
    return "text"


# ═══════════════════════════════════════════════════════════════════════════════
# Image utilities
# ═══════════════════════════════════════════════════════════════════════════════

def _encode_image(path: str) -> str:
    """Read an image file and return base64-encoded string."""
    try:
        return base64.b64encode(Path(path).read_bytes()).decode()
    except Exception as e:
        log.error(f"Image encode failed {path}: {e}")
        return ""


def _select_images(
    question:       str,
    image_map:      Dict[int, str],
) -> List[str]:
    """
    Choose the most relevant images for the question.

    Strategy (first non-empty result wins):
      1. Explicit reference → "image 2", "figure 3"  → send those specifically
      2. Image keywords in question + ≤ MAX images   → send all
      3. Small doc (≤ 2 images total)                → send all
    """
    if not image_map:
        return []

    q       = question.lower()
    result  : List[str] = []

    # Strategy 1 — explicit number reference
    explicit_nums = [int(m.group(1)) for m in _EXPLICIT_REF_RE.finditer(q)]
    if explicit_nums:
        for n in explicit_nums:
            if n in image_map:
                b64 = _encode_image(image_map[n])
                if b64:
                    result.append(b64)
        if result:
            log.info(f"[ImageSel] Explicit refs {explicit_nums} → {len(result)} image(s)")
            return result[:MAX_IMAGES_PER_QUERY]

    # Strategy 2 — image keywords → send up to MAX images
    if any(kw in q for kw in _IMAGE_KW):
        for num in sorted(image_map.keys())[:MAX_IMAGES_PER_QUERY]:
            b64 = _encode_image(image_map[num])
            if b64:
                result.append(b64)
        if result:
            log.info(f"[ImageSel] Keyword match → {len(result)} image(s)")
            return result

    # Strategy 3 — small doc safety net
    if len(image_map) <= 2:
        for num in sorted(image_map.keys()):
            b64 = _encode_image(image_map[num])
            if b64:
                result.append(b64)
        if result:
            log.info(f"[ImageSel] Safety net (≤2 imgs) → {len(result)} image(s)")

    return result[:MAX_IMAGES_PER_QUERY]


# ═══════════════════════════════════════════════════════════════════════════════
# Prompt / message builder
# ═══════════════════════════════════════════════════════════════════════════════

_SYSTEM_PROMPT = """\
You are a precise, helpful document assistant with full vision capability.

CORE RULES:
1. Answer ONLY from the document content provided — never use outside knowledge.
2. If the answer is not in the document, respond exactly:
   "I could not find this information in the document."
3. Always cite your source: end every answer with:
   📌 Source: Page <N> / Section "<heading>"
4. Do NOT guess, infer, or fill gaps with general knowledge.
5. For numbers, quotes, and dates — copy them exactly as they appear in the document.
"""

_VISION_ADDENDUM = """\

VISION INSTRUCTIONS (images are attached):
- Carefully study every attached image: read all axis labels, legends, titles, and data values.
- Describe trends, highs, lows, and patterns with the exact numbers visible.
- Reference images in your answer as: See Image N
- Only report what is clearly visible — do NOT guess.
"""


def build_messages(
    extracted_text: str,
    chat_history:   List[Dict],
    question:       str,
    image_map:      Dict[int, str],
) -> Tuple[List[Dict], List[str], float, str]:
    """
    Build the Ollama /api/chat message list.

    Returns:
        messages    — full message list for Ollama
        images_b64  — list of base64 image strings to attach
        build_time  — seconds taken
        mode        — 'image' or 'text'
    """
    t0   = time.perf_counter()
    mode = _classify_question(question, image_map)

    # Select images if vision mode
    images_b64: List[str] = []
    if mode == "image":
        images_b64 = _select_images(question, image_map)
        if not images_b64:
            mode = "text"   # no images found → fall back to text

    system_content = _SYSTEM_PROMPT + (_VISION_ADDENDUM if images_b64 else "")

    # Build message list
    messages = [{"role": "system", "content": system_content}]

    # Inject previous turns as alternating user/assistant messages
    for turn in chat_history[-MAX_HISTORY_TURNS:]:
        messages.append({"role": "user",      "content": turn["question"]})
        messages.append({"role": "assistant", "content": turn["answer"]})

    # Current user message with full document context
    vision_note = (
        f"\n\n[{len(images_b64)} image(s) from this document are attached. "
        "Study them carefully before answering.]\n"
        if images_b64 else ""
    )

    user_content = (
        f"DOCUMENT CONTENT:\n{'━'*60}\n"
        f"{extracted_text}\n"
        f"{'━'*60}"
        f"{vision_note}\n\n"
        f"QUESTION: {question}"
    )

    user_msg: Dict = {"role": "user", "content": user_content}
    if images_b64:
        user_msg["images"] = images_b64

    messages.append(user_msg)

    build_time = time.perf_counter() - t0
    log.info(
        f"[Prompt] mode={mode} | {len(user_content):,} chars | "
        f"{len(images_b64)} image(s) | build={build_time:.3f}s"
    )
    return messages, images_b64, build_time, mode


# ═══════════════════════════════════════════════════════════════════════════════
# Streaming generator
# ═══════════════════════════════════════════════════════════════════════════════

def stream_response(
    messages: List[Dict],
    stats:    GenerationStats,
) -> Generator[str, None, None]:
    """
    Stream tokens from Ollama /api/chat.
    Yields one token string at a time (Streamlit st.write_stream compatible).
    Measures TTFT and total time into the provided GenerationStats object.
    """
    payload = {
        "model":   OLLAMA_MODEL,
        "messages": messages,
        "stream":  True,
        "options": {
            "num_ctx":     LLM_CONTEXT_SIZE,
            "temperature": LLM_TEMPERATURE,
            "top_p":       LLM_TOP_P,
        },
    }

    t_start     = time.perf_counter()
    first_token = True

    try:
        with requests.post(
            f"{OLLAMA_HOST}/api/chat",
            json    = payload,
            stream  = True,
            timeout = OLLAMA_TIMEOUT,
        ) as resp:
            resp.raise_for_status()

            for raw in resp.iter_lines():
                if not raw:
                    continue
                try:
                    data  = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                token = data.get("message", {}).get("content", "")

                if token:
                    if first_token:
                        stats.t_ttft = time.perf_counter() - t_start
                        log.info(f"[QA] TTFT = {stats.t_ttft:.2f}s")
                        first_token  = False
                    stats.chars_generated += len(token)
                    yield token

                if data.get("done", False):
                    break

    except requests.exceptions.ConnectionError as e:
        yield f"\n\n❌ **Cannot connect to Ollama at `{OLLAMA_HOST}`**\n`{e}`"
    except requests.exceptions.Timeout:
        yield f"\n\n⏱️ **Ollama timed out after {OLLAMA_TIMEOUT}s.** Try a shorter document or increase OLLAMA_TIMEOUT in config.py"
    except requests.exceptions.HTTPError as e:
        yield f"\n\n❌ **Ollama HTTP error:** `{e}`"
    except Exception as e:
        yield f"\n\n❌ **Unexpected error:** `{e}`"
        log.exception("stream_response error")

    finally:
        stats.t_total = time.perf_counter() - t_start
        log.info(f"[QA] {stats.summary}")


# ═══════════════════════════════════════════════════════════════════════════════
# Connectivity check
# ═══════════════════════════════════════════════════════════════════════════════

def check_ollama_connection() -> Tuple[bool, str]:
    """
    Ping Ollama and verify the configured model is available.
    Wrap with @st.cache_data(ttl=60) in the app to avoid re-checking every render.
    """
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=8)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]

        if any(OLLAMA_MODEL in m for m in models):
            log.info(f"Ollama ✅  model={OLLAMA_MODEL}  host={OLLAMA_HOST}")
            return True, f"Connected — `{OLLAMA_MODEL}` ready ({len(models)} model(s) loaded)"

        msg = f"Model `{OLLAMA_MODEL}` not found. Available: {', '.join(models) or 'none'}"
        log.warning(msg)
        return False, msg

    except requests.exceptions.ConnectionError:
        msg = f"Cannot reach Ollama at `{OLLAMA_HOST}` — is it running?"
        log.warning(msg)
        return False, msg

    except Exception as e:
        return False, str(e)
