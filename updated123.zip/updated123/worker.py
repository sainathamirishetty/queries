#!/usr/bin/env python3
"""
worker.py  (GPU-SAFE EDITION)
==============================
Standalone background worker – run ONCE alongside Streamlit:

    python worker.py

FIX SUMMARY
-----------
1. CUDA OOM  – MinerU loads the Qwen2-VL model (~8-9 GiB) once per subprocess.
   When multiple uploads arrive quickly, several subprocesses run simultaneously
   and exhaust the 20 GiB GPU.  Fix: a file-based GPU lock
   (gpu.lock) makes every MinerU call strictly sequential, and
   torch.cuda.empty_cache() is called after each job to return cached-but-free
   VRAM to the driver.  Also sets PYTORCH_ALLOC_CONF=expandable_segments:True
   so PyTorch handles fragmentation gracefully if pressure ever gets close.

2. GPU DEVICE DISCOVERY WARNING – ONNXRuntime tries to read
   /sys/class/drm/card0/device/vendor at startup and prints a harmless but
   noisy warning when that sysfs file is absent (common on some kernels /
   container setups).  Fix: ONNXRUNTIME_DEVICE_DISCOVERY is set to skip GPU
   discovery, and the warning is filtered from the log so it no longer appears.

Both fixes are applied at process start before any imports touch CUDA.
"""

# ============================================================
# STEP 0 – apply environment patches BEFORE any GPU import
# ============================================================
import os
import logging
import warnings

# Fix 2: suppress ONNXRuntime sysfs GPU-discovery warning
os.environ.setdefault("ORT_DISABLE_GPU_DEVICE_DISCOVERY", "1")
# Fix 1: tell PyTorch allocator to use expandable segments → reduces fragmentation
os.environ.setdefault("PYTORCH_ALLOC_CONF", "expandable_segments:True")

# Silence the ORT warning at the Python-logging level as well
logging.getLogger("onnxruntime").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", message=".*GPU device discovery failed.*")
warnings.filterwarnings("ignore", message=".*device_discovery.*")

# ============================================================
# Standard imports
# ============================================================
import sys
import time
import fcntl
import json
import urllib.request
import urllib.error
from pathlib import Path

import config
import shared_db
from document_ingestion import (
    compute_file_hash,
    convert_office_to_pdf,
    convert_with_mineru,
    convert_with_mineru_remote,
    enrich_images_with_descriptions,
    build_final_markdown_from_json,
    OFFICE_EXTENSIONS,
)

import threading
import concurrent.futures
import httpx
import cluster_manager
from cluster_manager import WorkerPool, WorkerInfo, TunnelManager

# ============================================================
# Logging
# ============================================================

_LOG_DIR = Path(__file__).parent / "logs"
_LOG_DIR.mkdir(parents=True, exist_ok=True)

_INDEXER_THREAD_NAME = "indexer-loop"
_ENRICH_THREAD_PREFIX = "enrich"


def _is_indexer_thread(name: str) -> bool:

    return name.startswith(_INDEXER_THREAD_NAME)


def _is_enrich_thread(name: str) -> bool:
    return name.startswith(_ENRICH_THREAD_PREFIX)


class _OnlyIndexing(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return _is_indexer_thread(record.threadName)


class _OnlyEnrich(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return _is_enrich_thread(record.threadName)


class _OcrOnly(logging.Filter):
    """Everything that is NEITHER indexing NOR image-description."""
    def filter(self, record: logging.LogRecord) -> bool:
        return not _is_indexer_thread(record.threadName) and not _is_enrich_thread(record.threadName)


_CONSOLE_IMPORTANT_MARKERS = (
    "Worker started.",
    "[POOL] Registered new H100 worker",
    "[POOL] PBS job",                       # "... ended — removing worker ..."
    "[POOL] Removing dead cluster worker",
    "is ready (mineru-api responded)",
    "never became ready within",
    "[PBS] Submitted worker job:",
    "[PBS] Uploaded",
    "Background enrichment",
    "Background image-description thread pool started",
    "Background indexer thread started",
)


class _ConsoleImportantOnly(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if record.levelno >= logging.WARNING:
            return True
        msg = record.getMessage()
        return any(marker in msg for marker in _CONSOLE_IMPORTANT_MARKERS)


_console_handler = logging.StreamHandler(sys.stdout)
_console_handler.setFormatter(
    logging.Formatter("%(asctime)s [WORKER] %(levelname)s  %(message)s")
)
_console_handler.addFilter(_ConsoleImportantOnly())

_ocr_handler = logging.FileHandler(_LOG_DIR / "ocr.log", encoding="utf-8")
_ocr_handler.setFormatter(
    logging.Formatter("%(asctime)s [OCR] %(levelname)s  %(message)s")
)
_ocr_handler.addFilter(_OcrOnly())

_enrich_handler = logging.FileHandler(_LOG_DIR / "enrich.log", encoding="utf-8")
_enrich_handler.setFormatter(
    logging.Formatter("%(asctime)s [ENRICH] %(levelname)s  %(message)s")
)
_enrich_handler.addFilter(_OnlyEnrich())

_index_handler = logging.FileHandler(_LOG_DIR / "indexing.log", encoding="utf-8")
_index_handler.setFormatter(
    logging.Formatter("%(asctime)s [INDEX] %(levelname)s  %(message)s")
)
_index_handler.addFilter(_OnlyIndexing())

logging.basicConfig(
    level=logging.INFO,
    handlers=[_console_handler, _ocr_handler, _enrich_handler, _index_handler],
    force=True,
)
logger = logging.getLogger(__name__)


for _noisy in ("httpx", "httpcore", "urllib3", "qdrant_client"):
    logging.getLogger(_noisy).setLevel(
        getattr(logging, getattr(config, "NOISY_LIBRARY_LOG_LEVEL", "WARNING"), logging.WARNING)
    )

# ============================================================
# HANG DIAGNOSTICS
# ============================================================
# The whole reason previous hangs were hard to diagnose from the logs
# alone is that a genuine hang produces NO exception and NO log line —
# the thread is just sitting inside some blocking call (network read,
# lock acquire, etc.) with nothing to report. The only way to actually
# see WHERE a thread is stuck is to look at its live Python call stack
# at the moment it's stuck, which is what this section provides, via two
# mechanisms:
#
#   1. On-demand: `kill -USR1 <worker.py pid>` at any time writes every
#      thread's exact current stack frame to logs/thread_dump.log — no
#      restart needed, and it can be run the moment things look stuck.
#
#   2. Automatic: a background watchdog tracks how long each in-flight
#      OCR/enrichment/indexing job has been running. If one runs past a
#      generous per-stage threshold, the watchdog writes that same full
#      thread dump automatically — so even if nobody was watching when it
#      first got stuck, the dump still exists afterward showing exactly
#      which call, in which file, on which line, every thread was blocked
#      in at that moment.
#
# Next time something looks hung, check logs/thread_dump.log before
# restarting — it will show the exact blocking call (e.g. stuck in an
# httpx read, a paramiko recv, a lock acquire, etc.), which is the
# difference between guessing and knowing.
import faulthandler
import signal

_progress_lock = threading.Lock()
_active_since: dict[str, float] = {}   # label -> start timestamp (time.time())
_dumped_labels: set[str] = set()        # labels we've already auto-dumped for (avoid repeat spam)


def _track_start(label: str) -> None:
    with _progress_lock:
        _active_since[label] = time.time()
        _dumped_labels.discard(label)


def _track_end(label: str) -> None:
    with _progress_lock:
        _active_since.pop(label, None)
        _dumped_labels.discard(label)


# ------------------------------------------------------------------
# LOOP HEARTBEATS — covers the gap _track_start/_track_end can't see.
# ------------------------------------------------------------------
# _track_start/_track_end only cover time spent actually PROCESSING a
# job (inside process_single_file_ocr / _run_enrichment_job /
# chunk_and_index_for_user). But every loop also calls shared_db /
# pool.* functions BEFORE any job is picked up — shared_db.get_all_
# pending_jobs(), shared_db.get_jobs_at_status(...), shared_db.
# get_users_with_status(...), pool.acquire_best_available_worker(),
# pool.write_status_snapshot(). If any of THOSE hang (a stuck SQLite
# lock, a stale OS-level file lock, a slow/stuck disk), the loop never
# gets far enough to set any _track_start label — so the previous
# watchdog would stay silent forever even though the whole process is
# frozen, which matches "all three logs and the terminal go completely
# silent, nothing processes, until I restart".
#
# Each loop calls _beat(name) once per iteration, right at the top,
# before doing anything else. If a loop hasn't beaten in far longer
# than its own poll interval, it's stuck somewhere in that iteration
# — most likely in the shared_db/pool call — and this fires a full
# thread dump the same way a stuck job does.
_loop_heartbeat: dict[str, float] = {}
_loop_dumped: set[str] = set()
_LOOP_STALL_THRESHOLD_SECONDS = 120  # generous vs. every loop's 3-10s poll interval


def _beat(loop_name: str) -> None:
    with _progress_lock:
        _loop_heartbeat[loop_name] = time.time()
        _loop_dumped.discard(loop_name)


def _dump_all_threads(reason: str) -> None:
    dump_path = _LOG_DIR / "thread_dump.log"
    try:
        with open(dump_path, "a", encoding="utf-8") as f:
            f.write(
                f"\n\n===== THREAD DUMP  "
                f"{time.strftime('%Y-%m-%d %H:%M:%S')}  ({reason}) =====\n"
            )
            faulthandler.dump_traceback(file=f, all_threads=True)
        logger.warning(
            "[WATCHDOG] Wrote a full thread dump to %s (%s). Every thread's exact "
            "current line of code is in that file — open it to see what's actually "
            "stuck instead of guessing.",
            dump_path, reason,
        )
    except Exception as exc:
        logger.error("[WATCHDOG] Failed to write thread dump: %s", exc)


def _install_manual_dump_signal() -> None:
    def _handler(signum, frame):
        _dump_all_threads(reason="manual SIGUSR1 request")

    try:
        signal.signal(signal.SIGUSR1, _handler)
        logger.info(
            "[WATCHDOG] Run `kill -USR1 %d` at any time to dump every thread's "
            "current stack to logs/thread_dump.log without restarting.", os.getpid(),
        )
    except (ValueError, AttributeError):
        # SIGUSR1 doesn't exist on this platform (e.g. native Windows) — skip.
        pass


# Per-stage stall thresholds before the watchdog auto-dumps. OCR already
# has its own MINERU_HARD_DEADLINE_SECONDS enforced via future.result(), so
# anything stuck past that PLUS a buffer is stuck OUTSIDE that mechanism
# (e.g. waiting on the GPU lock, or on SSH/tunnel setup before the timed
# call even starts) — see cluster_manager.py's tunnel-health notes.
# Enrichment/indexing have no built-in deadline of their own, so use a
# tighter threshold for those.
_STALL_THRESHOLDS = {
    "ocr":    getattr(config, "MINERU_HARD_DEADLINE_SECONDS", 1800) + 300,
    "enrich": 600,
    "index":  600,
}


# Set in run_worker() when the cluster is enabled, so the watchdog can
# break a hung SSH call (see _watchdog_loop).
_TUNNEL_MGR: "TunnelManager | None" = None
_last_ssh_unblock: float = 0.0


def _try_unblock_cluster_sync(elapsed: float) -> None:
    """
    SELF-HEALING for a stuck cluster-sync thread. All remote commands now
    have hard deadlines, so this should rarely be needed — but if that
    thread is still blocked inside paramiko for any reason, closing the
    shared SSH connection from here wakes up every call waiting on it
    (paramiko releases all waiters when the transport closes). The thread
    then gets an exception, logs it, and continues with a fresh connection
    on its next iteration — no restart of worker.py needed.
    """
    global _last_ssh_unblock
    if _TUNNEL_MGR is None:
        return
    now = time.time()
    if now - _last_ssh_unblock < _LOOP_STALL_THRESHOLD_SECONDS:
        return
    _last_ssh_unblock = now
    logger.warning(
        "[WATCHDOG] cluster-sync-loop stuck for %.0fs — closing its SSH connection "
        "to break the hung call (it will reconnect automatically).", elapsed,
    )
    try:
        _TUNNEL_MGR._drop_control_client()
    except Exception as exc:
        logger.error("[WATCHDOG] Could not close SSH connection: %s", exc)


def _watchdog_loop(poll_interval: float = 60.0) -> None:
    while True:
        time.sleep(poll_interval)
        now = time.time()

        with _progress_lock:
            snapshot = dict(_active_since)
            loop_snapshot = dict(_loop_heartbeat)

        for label, started in snapshot.items():
            stage = label.split(":", 1)[0]
            threshold = _STALL_THRESHOLDS.get(stage, 600)
            elapsed = now - started
            if elapsed > threshold and label not in _dumped_labels:
                with _progress_lock:
                    _dumped_labels.add(label)
                logger.warning(
                    "[WATCHDOG] '%s' has been running %.0fs (> %.0fs threshold) — "
                    "looks stuck. Auto-dumping every thread's stack now.",
                    label, elapsed, threshold,
                )
                _dump_all_threads(reason=f"{label} stalled {elapsed:.0f}s")

        # A loop that hasn't beaten in far longer than its own poll interval
        # is stuck BEFORE it even got to pick up a job (most likely inside
        # a shared_db/pool call) — see the note above _loop_heartbeat.
        for loop_name, last_beat in loop_snapshot.items():
            elapsed = now - last_beat
            if elapsed > _LOOP_STALL_THRESHOLD_SECONDS and loop_name not in _loop_dumped:
                with _progress_lock:
                    _loop_dumped.add(loop_name)
                logger.warning(
                    "[WATCHDOG] Loop '%s' hasn't completed an iteration in %.0fs "
                    "(> %ds) — it's stuck somewhere BEFORE picking up a job "
                    "(most likely a shared_db/pool call). Auto-dumping every "
                    "thread's stack now.",
                    loop_name, elapsed, _LOOP_STALL_THRESHOLD_SECONDS,
                )
                _dump_all_threads(reason=f"loop '{loop_name}' stalled {elapsed:.0f}s")
            if elapsed > _LOOP_STALL_THRESHOLD_SECONDS and loop_name == "cluster-sync-loop":
                # Not just report it — actively unstick it (after the dump
                # above has captured where it was stuck; repeats every
                # threshold period for as long as the loop stays stuck).
                _try_unblock_cluster_sync(elapsed)


_install_manual_dump_signal()

try:
    import onnxruntime as _ort
    _ort.set_default_logger_severity(3)
except Exception:
    pass

# ============================================================
# Configuration
# ============================================================
POLL_INTERVAL  = 10   # seconds between queue polls
JOB_PAUSE      = 2    # seconds between consecutive jobs
OOM_RETRY_WAIT = 30   # seconds to wait before retrying after CUDA OOM
MAX_OOM_RETRY  = 2    # max automatic retries on OOM per job

# File-lock path – lives next to the output dir so every process sees it
_GPU_LOCK_FILE = Path(config.MARKDOWN_OUTPUT_DIR) / ".gpu.lock"
_BASE_INPUT_DIR = Path(config.DOCUMENTS_INPUT_DIR)
OUTPUT_DIR      = Path(config.MARKDOWN_OUTPUT_DIR)


# ============================================================
# Ollama VRAM eviction helpers
# ============================================================


_OLLAMA_BASE = "http://localhost:11434"

# Models that should be reloaded after MinerU finishes.
# Derive from config so there is only one place to change them.
_OLLAMA_LLM_MODEL   = None   # filled lazily from config
_OLLAMA_EMBED_MODEL = None

def _ollama_get(path: str) -> dict:
    """Tiny helper: GET from Ollama API, return parsed JSON or {}."""
    try:
        with urllib.request.urlopen(f"{_OLLAMA_BASE}{path}", timeout=5) as r:
            return json.loads(r.read())
    except Exception:
        return {}

def _ollama_post(path: str, payload: dict) -> None:
    """Tiny helper: POST JSON to Ollama API (fire-and-forget)."""
    try:
        data = json.dumps(payload).encode()
        req  = urllib.request.Request(
            f"{_OLLAMA_BASE}{path}",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10):
            pass
    except Exception as exc:
        logger.debug("[OLLAMA] POST %s failed (ignored): %s", path, exc)

def _get_ollama_models() -> list[str]:
    """Return the names of all models Ollama currently has resident in VRAM."""
    data = _ollama_get("/api/ps")
    return [m.get("name", "") for m in data.get("models", [])]

def _evict_ollama_models() -> list[str]:
    """
    Unload every Ollama model from VRAM (keep_alive=0).
    Returns the list of model names that were evicted so they can be reloaded.
    """
    resident = _get_ollama_models()
    if not resident:
        return []

    logger.info("[OLLAMA] Evicting %d model(s) from VRAM: %s", len(resident), resident)
    for model in resident:
        # Sending keep_alive=0 to /api/generate with no prompt triggers an unload.
        _ollama_post("/api/generate", {"model": model, "keep_alive": 0})

    # Wait up to 15 s for Ollama to actually free the memory
    for _ in range(15):
        time.sleep(1)
        if not _get_ollama_models():
            break

    remaining = _get_ollama_models()
    if remaining:
        logger.warning("[OLLAMA] Models still in VRAM after eviction: %s", remaining)
    else:
        logger.info("[OLLAMA] All models evicted from VRAM.")

    return resident

def _restore_ollama_models(models: list[str]) -> None:
    """
    Warm up previously-evicted Ollama models so chat / embedding latency is not
    impacted for the user.  Uses keep_alive=-1 (never auto-evict).
    Only the LLM and embedding models defined in config are restored; any other
    model that happened to be running is intentionally not pinned.
    """
    global _OLLAMA_LLM_MODEL, _OLLAMA_EMBED_MODEL
    if _OLLAMA_LLM_MODEL is None:
        try:
            import config as _cfg
            _OLLAMA_LLM_MODEL   = getattr(_cfg, "OLLAMA_LLM_MODEL",   "")
            _OLLAMA_EMBED_MODEL = getattr(_cfg, "DENSE_EMBEDDING_MODEL", "")
        except Exception:
            pass

    to_restore = {m for m in models if m in (_OLLAMA_LLM_MODEL, _OLLAMA_EMBED_MODEL)}
    if not to_restore:
        return

    logger.info("[OLLAMA] Restoring model(s) to VRAM: %s", to_restore)
    for model in to_restore:
        # Sending an empty prompt with keep_alive=-1 warms the model without
        # generating output and pins it until the next explicit eviction.
        _ollama_post("/api/generate", {"model": model, "keep_alive": -1, "prompt": ""})
    logger.info("[OLLAMA] Model restore requests sent.")


# ============================================================
# GPU helpers  (Fix 1)
# ============================================================

def _free_gpu_memory() -> None:
    """
    Return all cached-but-free VRAM to the driver.
    Called after every document job finishes (success or failure).
    """
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            free, total = torch.cuda.mem_get_info()
            logger.info(
                "[GPU] VRAM after cleanup → free: %.2f GiB / total: %.2f GiB",
                free  / 1024**3,
                total / 1024**3,
            )
    except Exception as exc:
        logger.warning("[GPU] Could not clear VRAM cache: %s", exc)


class _GpuLock:
    """
    Cross-process exclusive lock around any call that loads a model onto the GPU.

    Uses an OS-level flock so it works even if the worker spawns subprocesses
    (which MinerU does).  Guarantees only ONE MinerU process holds the GPU at a time.

    Additionally evicts Ollama models from VRAM *after* acquiring the lock so that
    MinerU has enough headroom (Ollama's LLM can occupy 14+ GiB), then restores
    them after MinerU finishes so chat/embedding latency is not impacted.
    """

    def __init__(self, path: Path):
        self._path    = path
        self._fh      = None
        self._evicted = []   # remember which Ollama models to restore

    def __enter__(self):
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self._path, "w")
        logger.info("[GPU-LOCK] Waiting for exclusive GPU access …")
        fcntl.flock(self._fh, fcntl.LOCK_EX)   # blocks until free
        logger.info("[GPU-LOCK] GPU lock acquired.")
        # Evict Ollama *after* the lock is held so we don't disturb a
        # concurrently running MinerU job on another worker.
        self._evicted = _evict_ollama_models()
        return self

    def __exit__(self, *_):
        try:
            _free_gpu_memory()                   # free VRAM before releasing lock
            fcntl.flock(self._fh, fcntl.LOCK_UN)
            self._fh.close()
            logger.info("[GPU-LOCK] GPU lock released.")
        except Exception as exc:
            logger.warning("[GPU-LOCK] Error releasing lock: %s", exc)
        finally:
            # Restore Ollama models after the lock is released so the next
            # queued job is not delayed by model warm-up time.
            if self._evicted:
                _restore_ollama_models(self._evicted)


# ============================================================
# Per-user directory helper
# ============================================================

def _user_input_dir(user_name: str) -> Path:
    d = _BASE_INPUT_DIR / user_name
    d.mkdir(parents=True, exist_ok=True)
    return d


# ============================================================
# Core processing logic
# ============================================================

# Concurrent soffice (LibreOffice) invocations sharing the default user
# profile can crash each other. Now that many documents run in parallel
# (one per H100 worker), serialise just this CPU step; it's cheap compared
# to OCR so it isn't a bottleneck.
_LIBREOFFICE_LOCK = threading.Lock()

# One lock per user so two files finishing for the same user at nearly the
# same time can't both trigger chunk_and_index_for_user() concurrently and
# corrupt that user's Qdrant collection.
_user_index_locks: dict[str, threading.Lock] = {}
_user_index_locks_guard = threading.Lock()


def _index_lock_for(user_name: str) -> threading.Lock:
    with _user_index_locks_guard:
        return _user_index_locks.setdefault(user_name, threading.Lock())


def _run_mineru_with_lock(pdf_path: Path, output_dir: Path) -> Path:
    """
    Local A100 fallback path: convert_with_mineru now calls the local
    mineru-api server over HTTP (config.MINERU_API_URL) instead of running
    the `mineru` CLI as a subprocess. Still wrapped in the GPU lock (plus
    Ollama VRAM eviction) so only one ingestion job touches this machine's
    GPU/VRAM-adjacent resources at a time.
    """
    with _GpuLock(_GPU_LOCK_FILE):
        return convert_with_mineru(pdf_path, output_dir)


def _run_mineru_on_cluster_worker(pdf_path: Path, output_dir: Path, endpoint_url: str) -> Path:
    """
    H100 cluster path: each PBS worker owns a dedicated GPU on its own
    machine and runs mineru-api (HTTP), so no local GPU lock / Ollama
    eviction is needed here — many of these can (and should) run at the
    same time, one per active worker.
    """
    return convert_with_mineru_remote(pdf_path, output_dir, endpoint_url)


def _resolve_input_file(filename: str, user_name: str = "") -> Path:
    if user_name:
        file = _user_input_dir(user_name) / filename
        if not file.exists():
            file = _BASE_INPUT_DIR / filename
    else:
        file = _BASE_INPUT_DIR / filename

    if not file.exists():
        raise FileNotFoundError(f"Document not found on disk: {filename}")
    return file


def process_single_file_ocr(
    filename: str, user_name: str = "", worker: "WorkerInfo | None" = None
) -> bool:
    """
    STAGE 1 ONLY: convert + OCR one document file. This is the one stage
    that actually needs the H100/A100 GPU worker, so it's the only stage
    this function performs — image description (Ollama qwen3-vl) and
    chunk-summary/indexing (Ollama gpt-oss + qwen-embedding) are handled
    later, by _run_enrichment_job() / chunk_and_index_for_user(), on their
    own dedicated background thread pools that never hold a WorkerPool
    slot. This is what lets a freed H100 node pick up the NEXT pending file
    immediately, instead of sitting idle while this file's images are
    being described or its chunks summarized.

    `worker` says where the OCR step should run:
      - tier 1 (worker.tier == 1)  -> a remote H100 PBS worker (mineru-api
                                       over HTTP), no local GPU lock
      - tier 2 / None              -> the local mineru-api server
                                       (config.MINERU_API_URL) over HTTP,
                                       GPU-locked + Ollama-eviction on this
                                       machine, exactly as before.
    On CUDA OOM the function waits OOM_RETRY_WAIT seconds and retries up to
    MAX_OOM_RETRY times before re-raising so the job is marked failed.

    Returns True if the file was already fully cached (OCR + image-desc
    both previously done) and nothing more needs to happen for it, False
    if OCR just ran and the file still needs to go through image
    description + indexing.
    """
    file = _resolve_input_file(filename, user_name)

    output_dir   = OUTPUT_DIR
    temp_pdf_dir = output_dir / "_temp_pdfs"
    output_dir.mkdir(parents=True, exist_ok=True)
    temp_pdf_dir.mkdir(parents=True, exist_ok=True)

    file_hash = compute_file_hash(file)

    if shared_db.is_file_cached(file_hash):
        logger.info("Already cached, skipping heavy work: %s", filename)
        return True

    is_cluster_worker = bool(worker and worker.tier == 1)

    # ── STEP 1: Convert & OCR (OOM-retried; GPU-locked only for local A100) ─
    oom_attempts = 0
    while True:
        try:
            if file.suffix.lower() in OFFICE_EXTENSIONS:
                logger.info("Office→PDF: %s", filename)
                with _LIBREOFFICE_LOCK:
                    pdf = convert_office_to_pdf(file, temp_pdf_dir)
                if is_cluster_worker:
                    doc_dir = _run_mineru_on_cluster_worker(pdf, output_dir, worker.endpoint_url)
                else:
                    doc_dir = _run_mineru_with_lock(pdf, output_dir)

            elif file.suffix.lower() == ".pdf":
                if is_cluster_worker:
                    doc_dir = _run_mineru_on_cluster_worker(file, output_dir, worker.endpoint_url)
                else:
                    doc_dir = _run_mineru_with_lock(file, output_dir)

            else:
                # Plain text / CSV / MD — CPU-only Docling path (no lock needed)
                from docling.document_converter import DocumentConverter
                logger.info("Docling fallback: %s", filename)
                docling = DocumentConverter()
                result  = docling.convert(file)
                if not result.document:
                    raise RuntimeError("Docling produced no document")
                doc_dir = output_dir / file.stem
                doc_dir.mkdir(parents=True, exist_ok=True)
                (doc_dir / f"{file.stem}.md").write_text(
                    result.document.export_to_markdown(), encoding="utf-8"
                )
            break  # success – exit retry loop

        except RuntimeError as exc:
            if "CUDA out of memory" in str(exc) and oom_attempts < MAX_OOM_RETRY:
                oom_attempts += 1
                logger.warning(
                    "[OOM] CUDA out of memory on attempt %d/%d for %s — "
                    "clearing VRAM and retrying in %ds …",
                    oom_attempts, MAX_OOM_RETRY, filename, OOM_RETRY_WAIT,
                )
                _free_gpu_memory()
                time.sleep(OOM_RETRY_WAIT)
            else:
                raise  # give up – caller marks job as failed

    logger.info("[OCR] Done (mineru): %s", filename)
    return False


def _run_enrichment_job(filename: str, user_name: str) -> None:
    """
    STAGE 2 ONLY: image description (Ollama qwen3-vl) + page-tagged
    markdown + cache update, for one file whose OCR has already finished.

    Runs on the dedicated enrichment thread pool (_enrichment_loop below),
    entirely separate from the H100/A100 WorkerPool and from the OCR
    dispatch executor — it talks only to the local Ollama qwen3-vl server,
    never to a GPU worker, so it never blocks (and is never blocked by)
    OCR dispatch. On success the file moves to 'indexing', where the
    dedicated indexer thread pool picks up chunk-summary + embedding.
    """
    file = _resolve_input_file(filename, user_name)
    file_hash = compute_file_hash(file)

    stem      = Path(filename).stem
    doc_dir   = OUTPUT_DIR / stem
    json_file = doc_dir / f"{stem}.json"

    shared_db.mark_stage(filename, user_name, "🖼️ Describing images (Ollama qwen3-vl)")

    _track_start(f"enrich:{user_name}:{filename}")
    try:
        if json_file.exists():
            enriched_json = enrich_images_with_descriptions(json_file)
            build_final_markdown_from_json(enriched_json)
        else:
            logger.warning(
                "[ENRICH] %s has no %s — nothing to enrich, moving straight to indexing.",
                filename, json_file.name,
            )
    finally:
        _track_end(f"enrich:{user_name}:{filename}")

    # OCR + image-desc are now BOTH done — this is what "cached" means.
    shared_db.mark_file_cached(file_hash, filename, user_name)

    shared_db.mark_indexing(filename, user_name)
    shared_db.update_document_status(filename, user_name, "indexing")
    shared_db.mark_stage(filename, user_name, "📦 Queued for chunk summarization (gpt-oss:20b)")
    logger.info("[ENRICH] Done: %s (user: %s) → indexing", filename, user_name)


def _enrichment_loop(poll_interval: float = 3.0) -> None:
    """
    Dedicated background thread pool for Ollama qwen3-vl image-description.

    This is the fix for the bug where a file's H100/A100 worker slot used
    to stay "occupied" (per the WorkerPool's bookkeeping) for the entire
    duration of image description, even though that step runs against the
    local Ollama server and touches the GPU worker not at all. Because
    _handle_job() now releases the WorkerPool slot the moment OCR finishes
    (see below) and hands the file off to this loop instead, a freed H100
    node is immediately available for the next pending file — image
    description for the previous file proceeds concurrently, bounded only
    by config.ENRICH_MAX_CONCURRENCY (protecting the local Ollama server
    from being flooded), never by GPU worker availability.

    Poll-based (reads status='enriching' from the DB) rather than an
    in-memory queue so it also picks up files restored to 'enriching' by
    the crash-recovery logic in run_worker() after a restart. Runs on a
    thread named "enrichment-loop" — see the logging setup above for how
    that's routed to its own log file, same as "indexer-loop".
    """
    max_workers = max(getattr(config, "ENRICH_MAX_CONCURRENCY", 3), 1)
    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=max_workers, thread_name_prefix="enrich"
    )
    in_flight: set[tuple[str, str]] = set()
    guard = threading.Lock()

    logger.info(
        "[ENRICH] Background image-description thread pool started "
        "(%d concurrent, poll every %ss).", max_workers, poll_interval,
    )

    while True:
        _beat("enrichment-loop")
        try:
            jobs = shared_db.get_jobs_at_status("enriching")
            for job in jobs:
                filename, user_name = job["filename"], job["user_name"]
                key = (filename, user_name)
                with guard:
                    if key in in_flight:
                        continue
                    in_flight.add(key)

                def _run(filename=filename, user_name=user_name, key=key):
                    try:
                        _run_enrichment_job(filename, user_name)
                    except Exception as exc:
                        shared_db.mark_failed(filename, str(exc), user_name)
                        shared_db.update_document_status(filename, user_name, "failed")
                        logger.error(
                            "[ENRICH] Failed on %s (user: %s): %s",
                            filename, user_name, exc, exc_info=True,
                        )
                    finally:
                        with guard:
                            in_flight.discard(key)

                executor.submit(_run)
        except Exception as exc:
            logger.error("[ENRICH] Loop error (will retry): %s", exc, exc_info=True)
        time.sleep(poll_interval)


def chunk_and_index_for_user(user_name: str) -> None:
    """
    Chunk + vector-store ingestion for all documents of a user currently
    sitting at 'indexing'. Called immediately after EACH file's own OCR
    finishes (not deferred until the whole per-user queue drains), so a
    file goes running -> indexing -> done on its own timeline. Guarded by
    a per-user lock so concurrent calls (multiple cluster workers finishing
    OCR close together) don't double-process the same file.

    PER-DOCUMENT, not batched: each document's chunks are contextualized
    (gpt-oss) AND inserted into Qdrant AND verified/marked 'done' before
    moving on to the next document. This means a document becomes
    queryable as soon as its own turn finishes, instead of every document
    in the batch waiting for the single slowest one (or the whole batch)
    to complete before any of them are searchable.

    A document sits at 'indexing' (set right after its own image
    description finishes, in _run_enrichment_job) until its chunks are
    actually confirmed present in Qdrant here — not just because this call
    returned without raising.

    Errors on one document are logged and that document is skipped (stays
    at 'indexing', retried on the next batch run) — they do NOT block or
    roll back documents that already finished earlier in this same loop.
    """
    logger.info("[CHUNK+INDEX] Starting for user: %s", user_name)
    with _index_lock_for(user_name):
        from rag_pipeline import (
            create_contextualized_documents_for_file,
            create_vector_store,
            get_existing_chunk_hashes_for_filenames,
            get_markdown_files,
            get_qdrant_client,
            initialize_embeddings,
            load_context_cache,
            save_context_cache,
        )

        # Snapshot of who is actually waiting on this run, taken before the
        # (possibly slow) work below starts.
        awaiting = {j["filename"] for j in shared_db.get_jobs_by_status(user_name, "indexing")}
        if not awaiting:
            logger.info("[CHUNK+INDEX] Nothing awaiting indexing for user: %s", user_name)
            return

        files = get_markdown_files(user_name)
        files_by_stem = {f.stem: f for f in files}
        cache = load_context_cache()

        # Initialize ONCE, reuse for every document in this run — avoids
        # re-loading the embedding models and reopening a Qdrant client
        # connection on every single iteration (see create_vector_store's
        # docstring). At 500-1000 documents this is the difference between
        # 1 embedding-model load and 500-1000 of them.
        dense_embeddings, sparse_embeddings = initialize_embeddings()
        client = get_qdrant_client()

        for filename in sorted(awaiting):
            stem = Path(filename).stem
            file = files_by_stem.get(stem)
            if file is None:
                logger.warning(
                    "[CHUNK+INDEX] %s has no markdown file yet — skipping this run.", filename
                )
                continue

            try:
                _track_start(f"index:{user_name}:{filename}")
                # 1. Chunk-summary (gpt-oss) for THIS document only.
                shared_db.mark_stage(filename, user_name, "✂️ Summarizing chunks (gpt-oss:20b)")
                doc_chunks = create_contextualized_documents_for_file(
                    file, cache, user_name=user_name
                )
                save_context_cache(cache)  # persist immediately

                if not doc_chunks:
                    logger.warning("[CHUNK+INDEX] No chunks produced for %s — skipping.", filename)
                    continue

                # 2. Index THIS document only, reusing the shared
                #    embeddings/client instead of re-initializing them.
                shared_db.mark_stage(filename, user_name, "📈 Embedding & indexing (qwen-embedding → Qdrant)")
                create_vector_store(
                    doc_chunks,
                    dense_embeddings=dense_embeddings,
                    sparse_embeddings=sparse_embeddings,
                    client=client,
                )

                # 3. Verify THIS document's chunks are actually in Qdrant

                confirmed_hashes = get_existing_chunk_hashes_for_filenames(client, [stem], user_name=user_name)
                if all(c.metadata.get("chunk_hash") in confirmed_hashes for c in doc_chunks):
                    shared_db.mark_done(filename, user_name)
                    shared_db.update_document_status(filename, user_name, "done")
                    logger.info(
                        "[CHUNK+INDEX] %s confirmed in Qdrant → done "
                        "(ready for querying now, independent of the rest of the batch).",
                        filename,
                    )
                else:
                    logger.warning(
                        "[CHUNK+INDEX] %s not confirmed in Qdrant — left at 'indexing', "
                        "will be retried on the next batch run.",
                        filename,
                    )
            except Exception as exc:
                logger.error(
                    "[CHUNK+INDEX] Failed on %s (user: %s): %s — leaving it at 'indexing', "
                    "continuing with the remaining documents.",
                    filename, user_name, exc, exc_info=True,
                )
                continue
            finally:
                _track_end(f"index:{user_name}:{filename}")

        logger.info("[CHUNK+INDEX] Finished run for user: %s", user_name)


def _cluster_sync_loop(tunnel_mgr: "TunnelManager", pool: "WorkerPool", heartbeat: float) -> None:
    """
    Dedicated background thread for H100 pool/PBS sync (SSH to the login
    node via paramiko: worker discovery, tunnel open/close, qstat, etc.).

    BUG FIX: this used to run inline in run_worker()'s main dispatch loop,
    once per heartbeat cycle, on the SAME thread that fetches pending jobs
    and hands them out to free workers. Each cycle opens several fresh SSH
    connections (announcement fetch, qstat) — normally a couple of
    seconds, but paramiko's connect() only bounds the initial TCP connect
    by default; the banner exchange / key exchange / auth phase can hang
    much longer than that on a slow, overloaded, or flaky login node
    (fixed alongside this — see _ssh_client()'s new banner_timeout /
    auth_timeout). While ANY of that was stuck, the whole worker process
    looked "unresponsive": no new jobs dispatched, nothing polled, even
    though already-running OCR/enrichment/indexing jobs kept finishing on
    their own separate threads — which is exactly why the symptom looked
    like "processes a handful of files, then just stops until restarted."

    Moving this to its own always-on daemon thread means even a slow (but
    now correctly bounded) SSH round trip can never delay job dispatch —
    the two are fully decoupled, the same way OCR/enrichment/indexing
    already are.
    """
    logger.info("[CLUSTER] Background cluster-sync thread started (every %ss).", heartbeat)
    while True:
        _beat("cluster-sync-loop")
        try:
            control = cluster_manager.read_control_state()
            if control.get("cluster_running"):
                tunnel_mgr.sync_cluster_workers(pool)
            else:
                pool.set_ids(set())
                tunnel_mgr.close_all_tunnels()
        except Exception as exc:
            logger.warning("[CLUSTER] Sync failed (will retry): %s", exc)
        pool.write_status_snapshot()
        time.sleep(heartbeat)


def _indexer_loop(poll_interval: float = 5.0) -> None:
    """
    Dedicated background thread for gpt-oss chunk-summary + Qdrant indexing.

    Runs completely independently of the OCR ThreadPoolExecutor used by the
    main dispatch loop below. Previously, indexing was triggered
    synchronously inside _handle_job() — even after the fix that released
    the WorkerPool slot early, the call still ran on the SAME executor
    thread, so that thread stayed occupied for the whole (often long)
    indexing run. With enough documents finishing OCR close together, most
    or all executor threads end up blocked inside indexing calls, and new
    pending OCR jobs have nowhere to run even though WorkerPool reports
    free H100/A100 capacity.

    Moving indexing to its own always-on thread — entirely separate from
    the OCR executor's thread pool AND from the _enrichment_loop's image-
    description pool — means OCR dispatch, image description, and
    indexing genuinely run in parallel: an executor thread is never held
    hostage by indexing (or image-description) work. A document only
    reaches 'indexing' once its own image description
    (_run_enrichment_job) has finished, so no further gating on other
    users'/documents' pending/running/enriching state is needed here.
    """
    max_workers = max(getattr(config, "INDEXER_MAX_CONCURRENCY", 3), 1)
    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=max_workers, thread_name_prefix=_INDEXER_THREAD_NAME
    )
    in_flight: set[str] = set()
    guard = threading.Lock()

    logger.info(
        "[INDEXER] Background indexer thread pool started "
        "(%d concurrent user(s), poll every %ss).", max_workers, poll_interval,
    )

    while True:
        _beat("indexer-loop")
        try:
            users_needing_index = shared_db.get_users_with_status("indexing")
            if users_needing_index:
                logger.info(
                    "[INDEXER] %d user(s) have documents awaiting indexing: %s",
                    len(users_needing_index), ", ".join(users_needing_index),
                )
            for user_name in users_needing_index:
                with guard:
                    if user_name in in_flight:
                        continue  # already being indexed on another pool thread
                    in_flight.add(user_name)

                def _run(user_name=user_name):
                    try:
                        # NOTE: deliberately NOT gated on "the user's OCR
                        # queue has drained". An earlier version skipped
                        # any user that still had pending/running jobs —
                        # with a queue of thousands of documents that
                        # condition never became true, so indexing never
                        # ran at all. Documents are indexed as soon as
                        # they reach 'indexing', continuously, while OCR
                        # keeps running in parallel.
                        chunk_and_index_for_user(user_name)
                    except Exception as exc:
                        logger.error(
                            "[INDEXER] Loop error for user %s (will retry): %s",
                            user_name, exc, exc_info=True,
                        )
                    finally:
                        with guard:
                            in_flight.discard(user_name)

                executor.submit(_run)
        except Exception as exc:
            logger.error("[INDEXER] Loop error (will retry): %s", exc, exc_info=True)
        time.sleep(poll_interval)


# ============================================================
# Cluster-aware concurrent dispatcher
# ============================================================
#
# Replaces the old "one job at a time" loop. Jobs are now handed out to
# whichever worker (an H100 PBS node, or the local A100 fallback) has a
# free slot, and many run at the same time — this is what actually makes
# processing 10k-15k documents fast when 20-40 H100 workers are online.
#
# If cluster.enabled is false in cluster_config.yaml, this behaves exactly
# like before: one local worker (the local mineru-api server on this machine), one
# job at a time.

def _is_transient_infra_error(exc: BaseException) -> bool:
    """
    True for failures that are about the INFRASTRUCTURE being momentarily
    unavailable, not about the document itself — the kind that a retry on
    a (likely different) worker will very plausibly succeed at:
      - ConnectionRefusedError / httpx.ConnectError: nothing listening yet
        on the other end (e.g. a freshly-started H100 worker whose
        mineru-api hasn't finished loading — see _start_readiness_check in
        cluster_manager.py, which now mostly prevents this at the source,
        but a node can still drop mid-session).
      - ConnectionResetError / httpx.ReadError ('Connection reset by
        peer'): the remote process died/was killed mid-request.
      - httpx.RemoteProtocolError ('Server disconnected without sending a
        response'): the remote process or its tunnel closed cleanly before
        writing anything.
      - httpx.HTTPStatusError with status 409: the target mineru-api is
        still processing a PREVIOUS request that this app already gave up
        on client-side (its hard deadline fired and released the pool
        slot) — the fix for the root cause is a real cancellation signal
        server-side, but until then, retrying elsewhere is the safe move
        rather than a permanent failure.
    Walks exc.__cause__ once because these are usually reraised/wrapped
    (see convert_with_mineru_remote), so the interesting type is often one
    level down from what worker.py actually catches.
    """
    for e in (exc, getattr(exc, "__cause__", None)):
        if e is None:
            continue
        if isinstance(e, (ConnectionRefusedError, ConnectionResetError)):
            return True
        if isinstance(e, (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError)):
            return True
        if isinstance(e, httpx.HTTPStatusError) and e.response is not None and e.response.status_code == 409:
            return True
    return False


# Cooldowns (seconds) during which a worker gets no NEW documents.
ABANDONED_REQUEST_COOLDOWN_SECONDS = int(os.environ.get(
    "ABANDONED_REQUEST_COOLDOWN_SECONDS", str(getattr(config, "MINERU_HARD_DEADLINE_SECONDS", 1800))))
BUSY_409_COOLDOWN_SECONDS = int(os.environ.get("BUSY_409_COOLDOWN_SECONDS", "300"))
TRANSIENT_ERROR_COOLDOWN_SECONDS = int(os.environ.get("TRANSIENT_ERROR_COOLDOWN_SECONDS", "60"))


def _is_http_409(exc: BaseException) -> bool:
    for e in (exc, getattr(exc, "__cause__", None)):
        if isinstance(e, httpx.HTTPStatusError) and e.response is not None \
                and e.response.status_code == 409:
            return True
    return False


def _is_hard_deadline_error(exc: BaseException) -> bool:
    """convert_with_mineru(_remote) raise RuntimeError('... exceeded hard
    deadline ...') when we stop waiting on a request the server is still
    working on."""
    return "exceeded hard deadline" in str(exc)


def _handle_job(job: dict, worker: WorkerInfo, pool: WorkerPool) -> None:
    """
    Runs OCR ONLY on this executor thread / this WorkerPool slot.

    BUG FIX: previously this called the full process_single_file() — OCR
    *and* image description — before releasing the H100/A100 slot, so a
    file sitting in Ollama-based image description (which never touches
    the GPU worker at all) still counted as "occupying" that worker as far
    as WorkerPool.acquire_best_available_worker() was concerned. With
    enough files finishing OCR close together, every H100 node ended up
    "busy" running image description, and new pending files had nowhere to
    dispatch to even though every GPU was actually idle.

    Now: the worker slot is released the INSTANT mineru OCR returns —
    image description and chunk-summary/indexing happen afterward, on
    their own background thread pools (_enrichment_loop / _indexer_loop),
    so a freed H100 node can start the next file's OCR immediately, fully
    in parallel with the previous file's Ollama-based post-processing.
    """
    filename  = job["filename"]
    user_name = job["user_name"]
    processed_by = f"H100 cluster ({worker.worker_id})" if worker.tier == 1 else "Local A100"
    h100_released = False
    try:
        shared_db.mark_running(filename, user_name, processed_by=processed_by)
        shared_db.update_document_status(filename, user_name, "running")
        shared_db.mark_stage(filename, user_name, f"🔎 OCR via {processed_by} (mineru)")
        logger.info("[%s] Picked up job: %s (user: %s)", worker.worker_id, filename, user_name)

        _track_start(f"ocr:{user_name}:{filename}")
        try:
            already_cached = process_single_file_ocr(filename, user_name, worker=worker)
        finally:
            _track_end(f"ocr:{user_name}:{filename}")

        # OCR is done — this is the ONLY stage that needed the GPU worker,
        # so release it right here, before doing anything else. Everything
        # after this point runs against the local Ollama server, not the
        # GPU worker, and must never hold this slot.
        if worker.tier == 1:
            pool.release(worker.worker_id)
            h100_released = True

        if already_cached:
            # A previous run already finished OCR + image-desc for this
            # exact file content — nothing left to do but make sure it's
            # sitting at the right stage for the indexer to pick up.
            shared_db.mark_indexing(filename, user_name)
            shared_db.update_document_status(filename, user_name, "indexing")
            shared_db.mark_stage(filename, user_name, "📦 Queued for chunk summarization (gpt-oss:20b)")
        else:
            # Hand off to the dedicated enrichment thread pool — a
            # completely separate background loop, never the OCR executor,
            # never a WorkerPool slot. See _enrichment_loop()/
            # _run_enrichment_job() for the image-description step itself.
            shared_db.mark_enriching(filename, user_name)
            shared_db.update_document_status(filename, user_name, "enriching")
            shared_db.mark_stage(filename, user_name, "🖼️ Queued for image description (Ollama qwen3-vl)")

        logger.info(
            "[%s] OCR done for %s (user: %s); worker slot released, handed "
            "off to the background image-description pool.",
            worker.worker_id, filename, user_name,
        )

    except Exception as exc:
        if not (worker and worker.tier == 1):
            _free_gpu_memory()  # only relevant for the local A100 path

        # FIX (409 storms): keep the worker out of rotation while its
        # mineru-api is known to be busy, so the next documents go to
        # OTHER workers instead of bouncing off this one.
        busy_409 = _is_http_409(exc)
        if _is_hard_deadline_error(exc):
            # We stopped waiting, but the remote mineru-api is still
            # parsing that PDF. Sending it the next document right away is
            # exactly what produced the 409s.
            pool.set_cooldown(worker.worker_id, ABANDONED_REQUEST_COOLDOWN_SECONDS)
            logger.warning(
                "[%s] Gave up waiting on %s; its server is probably still busy with it — "
                "keeping this worker out of rotation for %ds.",
                worker.worker_id, filename, ABANDONED_REQUEST_COOLDOWN_SECONDS,
            )
        elif busy_409:
            pool.set_cooldown(worker.worker_id, BUSY_409_COOLDOWN_SECONDS)
        elif _is_transient_infra_error(exc):
            # Connection refused/reset etc. — don't hand this worker the
            # very next document; give the health check time to notice.
            pool.set_cooldown(worker.worker_id, TRANSIENT_ERROR_COOLDOWN_SECONDS)

        if _is_transient_infra_error(exc):
            retry_count = shared_db.get_retry_count(filename, user_name)
            # A 409 says nothing about the document — only that one worker
            # was busy — so it gets a much larger retry budget (the
            # cooldown above already makes the retry go to another worker).
            retry_limit = max(config.MAX_TRANSIENT_RETRIES, 10) if busy_409 else config.MAX_TRANSIENT_RETRIES
            if retry_count < retry_limit:
                new_count = shared_db.requeue_for_transient_retry(filename, user_name, str(exc))
                shared_db.update_document_status(filename, user_name, "pending")
                logger.warning(
                    "[%s] Transient infra error on %s (user: %s), auto-retrying "
                    "(%d/%d): %s",
                    worker.worker_id, filename, user_name,
                    new_count, retry_limit, exc,
                )
            else:
                # Exhausted the auto-retry budget — this isn't self-healing,
                # a person needs to look at it (dead node, misconfigured
                # tunnel, etc). Falls through to a real 'failed' exactly
                # like any other error.
                shared_db.mark_failed(
                    filename,
                    f"Gave up after {retry_count} automatic retries: {exc}",
                    user_name,
                )
                shared_db.update_document_status(filename, user_name, "failed")
                logger.error(
                    "[%s] Job failed [%s] after %d automatic retries: %s",
                    worker.worker_id, filename, retry_count, exc, exc_info=True,
                )
        else:
            # Not an infra blip — a real content/processing failure
            # (corrupt PDF, mineru model crash on this specific page,
            # etc). Retrying elsewhere won't help, so this stays a normal
            # permanent failure, same as before.
            shared_db.mark_failed(filename, str(exc), user_name)
            shared_db.update_document_status(filename, user_name, "failed")
            logger.error("[%s] Job failed [%s]: %s", worker.worker_id, filename, exc, exc_info=True)
    finally:
        if not h100_released:
            pool.release(worker.worker_id)


_INSTANCE_LOCK_FH = None


def _acquire_single_instance_lock() -> None:
    """
    Refuse to start if another worker.py is already running on this
    machine. Two copies would each believe every H100 worker is free and
    send it documents at the same time — a direct cause of 409s — and both
    would requeue/redo each other's 'running' jobs at startup. The OS
    releases this lock automatically when the process exits, even on a
    crash or kill -9, so it can never get stuck "held".
    """
    global _INSTANCE_LOCK_FH
    lock_path = Path(config.MARKDOWN_OUTPUT_DIR).parent / "worker.instance.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(lock_path, "a+")
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.seek(0)
        other = fh.read().strip() or "unknown"
        logger.error(
            "Another worker.py is already running (PID %s). Stop it first "
            "(`kill %s`) — running two at once causes duplicate work and 409 errors.",
            other, other,
        )
        sys.exit(1)
    fh.seek(0)
    fh.truncate()
    fh.write(str(os.getpid()))
    fh.flush()
    _INSTANCE_LOCK_FH = fh  # keep the file open for the life of the process


def run_worker() -> None:
    """
    Main loop:
      1. Every heartbeat_interval_seconds, sync the H100 cluster worker pool
         (discover PBS jobs, open/close SSH tunnels) if cluster.enabled.
      2. Every POLL_INTERVAL, pull pending jobs and hand each one to the
         best available worker (H100 first, then local), running as many
         concurrently as there is worker capacity for.
    """
    _acquire_single_instance_lock()

    cluster_cfg = {}
    tunnel_mgr: TunnelManager | None = None
    full_cfg = {}
    try:
        full_cfg = cluster_manager.load_cluster_config()
        cluster_cfg = full_cfg.get("cluster", {})
    except FileNotFoundError:
        logger.warning("cluster_config.yaml not found — running with local A100 only.")

    # ── Crash / power-cut recovery ──────────────────────────────────────
    # 'running' jobs died mid-OCR — no guarantee of flushed output, always
    # unsafe to trust, so they're unconditionally redone.
    requeued = shared_db.requeue_stale_jobs()
    if requeued:
        logger.warning(
            "[RECOVERY] Found %d job(s) stuck mid-OCR from a previous run "
            "(likely an interrupted/crashed process) — requeued as 'pending': %s",
            len(requeued),
            ", ".join(f"{j['filename']}({j['previous_status']})" for j in requeued),
        )

    # 'indexing' jobs are different: their OCR step already finished
    # successfully (that's what put them at 'indexing' in the first place).
    # Blindly resetting these to 'pending' — as the old code did — redoes
    # OCR for work that's already sitting on disk, wasting hours of GPU
    # time and leaving stray duplicate MARKDOWN output folders behind.
    # Instead, check file_hash_cache per file: if the hash is present, OCR
    # genuinely completed and was cached — restore straight to 'indexing'
    # (skip OCR) and let chunk-summary/indexing pick it up below. Only
    # files with NO cache entry (e.g. the process died between finishing
    # OCR and writing the cache row) go back to 'pending'.
    stuck_indexing = shared_db.get_indexing_status_jobs()
    restored_to_indexing, requeued_for_ocr = [], []
    affected_users = set()
    for job in stuck_indexing:
        filename, user_name = job["filename"], job["user_name"]
        try:
            file = _user_input_dir(user_name) / filename
            if not file.exists():
                file = _BASE_INPUT_DIR / filename
            file_hash = compute_file_hash(file) if file.exists() else None
        except Exception:
            file_hash = None

        if file_hash and shared_db.is_file_cached(file_hash):
            shared_db.reset_job_status(filename, user_name, "indexing",
                                        reason="restored after restart — OCR already cached")
            restored_to_indexing.append(filename)
        else:
            shared_db.reset_job_status(filename, user_name, "pending",
                                        reason="auto-requeued after restart — no cache entry, OCR redone")
            requeued_for_ocr.append(filename)
        affected_users.add(user_name)

    if restored_to_indexing:
        logger.warning(
            "[RECOVERY] %d file(s) had OCR already cached from before the restart — "
            "skipping straight to indexing (no OCR rework): %s",
            len(restored_to_indexing), ", ".join(restored_to_indexing),
        )
    if requeued_for_ocr:
        logger.warning(
            "[RECOVERY] %d file(s) at 'indexing' had NO cache entry — requeued as 'pending' "
            "(OCR will be redone): %s",
            len(requeued_for_ocr), ", ".join(requeued_for_ocr),
        )

    stuck_enriching = shared_db.get_jobs_at_status("enriching")
    for job in stuck_enriching:
        shared_db.reset_job_status(
            job["filename"], job["user_name"], "enriching",
            reason="restored after restart — OCR already done, retrying image description",
        )
    if stuck_enriching:
        logger.warning(
            "[RECOVERY] %d file(s) were mid image-description from a previous run "
            "(OCR already done, GPU slot already free) — retrying image description "
            "only: %s",
            len(stuck_enriching),
            ", ".join(j["filename"] for j in stuck_enriching),
        )

    pool = WorkerPool()

    watchdog_thread = threading.Thread(
        target=_watchdog_loop, daemon=True, name="hang-watchdog"
    )
    watchdog_thread.start()

    enrichment_thread = threading.Thread(
        target=_enrichment_loop, daemon=True, name="enrichment-loop"
    )
    enrichment_thread.start()

    indexer_thread = threading.Thread(
        target=_indexer_loop, daemon=True, name="indexer-loop"
    )
    indexer_thread.start()

    local_fallback_cfg = full_cfg.get("local_fallback", {}) or {"enabled": True, "max_concurrency": 1}
    if local_fallback_cfg.get("enabled", True):
        pool.register(WorkerInfo(
            worker_id="local-a100",
            endpoint_url="local-subprocess",   # sentinel — Tier 2 uses the local `mineru` CLI, not HTTP
            tier=2,
            gpu_type="A100",
            max_concurrency=local_fallback_cfg.get("max_concurrency", 1),
        ))

    cluster_enabled = bool(cluster_cfg.get("enabled", False))
    heartbeat = cluster_cfg.get("heartbeat_interval_seconds", 20)
    if cluster_enabled:
        global _TUNNEL_MGR
        tunnel_mgr = TunnelManager(cluster_cfg)
        _TUNNEL_MGR = tunnel_mgr  # lets the watchdog break a hung SSH call
        # Cluster sync (SSH to the login node) now runs on its own daemon
        # thread — see _cluster_sync_loop()'s docstring for why this used
        # to freeze the whole worker process.
        cluster_sync_thread = threading.Thread(
            target=_cluster_sync_loop, args=(tunnel_mgr, pool, heartbeat),
            daemon=True, name="cluster-sync-loop",
        )
        cluster_sync_thread.start()

    max_workers_total = max(cluster_cfg.get("max_workers", 40), 1) + 2
    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=max_workers_total, thread_name_prefix="job-dispatch"
    )
    in_flight: set[tuple[str, str]] = set()
    in_flight_guard = threading.Lock()

    logger.info(
        "Worker started. cluster.enabled=%s | local_fallback.enabled=%s | "
        "PYTORCH_ALLOC_CONF=%s | Poll interval=%ds",
        cluster_enabled, local_fallback_cfg.get("enabled", True),
        os.environ.get("PYTORCH_ALLOC_CONF", "not set"), POLL_INTERVAL,
    )

    while True:
        _beat("dispatch-loop")


        # ── 1. fetch queue ──────────────────────────────────────────────────
        try:
            pending = shared_db.get_all_pending_jobs()
        except Exception as exc:
            logger.exception("Failed to fetch pending jobs: %s", exc)
            time.sleep(POLL_INTERVAL)
            continue

        # ── 2. dispatch as many jobs as there is worker capacity for ────────
        for job in pending:
            key = (job["filename"], job["user_name"])
            with in_flight_guard:
                if key in in_flight:
                    continue
            worker = pool.acquire_best_available_worker()
            if worker is None:
                break  # no free capacity right now — try again next poll

            with in_flight_guard:
                in_flight.add(key)

            def _run(job=job, worker=worker, key=key):
                try:
                    _handle_job(job, worker, pool)
                finally:
                    with in_flight_guard:
                        in_flight.discard(key)

            executor.submit(_run)

        pool.write_status_snapshot()
        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    run_worker()


The main cause: worker.py checks the H100 workers over SSH every 20 seconds, and that SSH check had no time limit.
Here's what happened:
Sometimes the cluster's login node or its shared disk is slow for a moment.
The SSH check then waited forever for an answer that never came.
That check was the only thing that marks workers as "ready" again. Once it was stuck, any worker that looked busy for a moment was never marked ready again.
One by one, all workers ended up "not ready", so no documents were sent to the miners. That's the freeze.
A restart created a fresh SSH connection, which is why it worked again.
Why sometimes 10 minutes and sometimes 5 hours: it depends on when the cluster has that slow moment, which is random.
A second, smaller cause: each time a tunnel dropped, the code used a new port and never gave the old one back. After about 20 drops the ports ran out, and workers were lost one by one.
The fix: every SSH check now gives up after a fixed time and reconnects, and ports are given back after use.
