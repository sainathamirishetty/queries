import streamlit as st
import requests
import base64
import json
import fitz  # PyMuPDF
from PIL import Image
import io

# ── Config ────────────────────────────────────────────────────────────────────
OLLAMA_URL   = "http://localhost:11434/api/chat"
DEFAULT_MODEL = "gemma4_e4b"   # change if your model tag differs

st.set_page_config(
    page_title="Ollama Chat",
    page_icon="🦙",
    layout="wide",
)

# ── Helpers ───────────────────────────────────────────────────────────────────

def image_to_base64(uploaded_file) -> str:
    """Convert an uploaded image file to base64 string."""
    img_bytes = uploaded_file.read()
    uploaded_file.seek(0)
    return base64.b64encode(img_bytes).decode("utf-8")


def extract_pdf_text(uploaded_file) -> str:
    """Extract all text from a PDF using PyMuPDF."""
    pdf_bytes = uploaded_file.read()
    uploaded_file.seek(0)
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    text_parts = []
    for page_num, page in enumerate(doc, start=1):
        text = page.get_text()
        if text.strip():
            text_parts.append(f"--- Page {page_num} ---\n{text}")
    doc.close()
    return "\n\n".join(text_parts) if text_parts else "[No text found in PDF]"


def extract_text_file(uploaded_file) -> str:
    """Read a plain-text file."""
    content = uploaded_file.read().decode("utf-8", errors="replace")
    uploaded_file.seek(0)
    return content


def stream_ollama(messages: list, model: str):
    """
    Stream a response from Ollama.
    Yields text chunks as they arrive.
    """
    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
    }
    with requests.post(OLLAMA_URL, json=payload, stream=True, timeout=300) as resp:
        resp.raise_for_status()
        for raw_line in resp.iter_lines():
            if not raw_line:
                continue
            chunk = json.loads(raw_line)
            delta = chunk.get("message", {}).get("content", "")
            if delta:
                yield delta
            if chunk.get("done"):
                break


def build_ollama_message(role: str, text: str, images_b64: list[str] | None = None) -> dict:
    """Build a message dict for the Ollama /api/chat endpoint."""
    msg: dict = {"role": role, "content": text}
    if images_b64:
        msg["images"] = images_b64
    return msg


# ── Session state ─────────────────────────────────────────────────────────────
if "messages" not in st.session_state:
    st.session_state.messages = []   # list of {role, content, images?, meta?}

if "model" not in st.session_state:
    st.session_state.model = DEFAULT_MODEL

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("🦙 Ollama Chat")
    st.divider()

    # Model selector
    st.session_state.model = st.text_input(
        "Model name",
        value=st.session_state.model,
        help="Exact tag shown by `ollama list`",
    )

    st.caption(f"Endpoint: `{OLLAMA_URL}`")
    st.divider()

    # File uploader
    st.subheader("📎 Attach files")
    uploaded_files = st.file_uploader(
        "Upload text, images, or PDFs",
        type=["txt", "md", "py", "csv", "json",   # text
              "png", "jpg", "jpeg", "webp", "gif", # images
              "pdf"],                               # PDFs
        accept_multiple_files=True,
        label_visibility="collapsed",
    )

    st.divider()

    # Clear chat
    if st.button("🗑️ Clear chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    st.caption("Built with Streamlit + Ollama")


# ── Main chat area ────────────────────────────────────────────────────────────
st.header("💬 Chat", divider="gray")

# Render existing messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        # Show any attached-file summary above the text
        if msg.get("meta"):
            st.caption(msg["meta"])
        st.markdown(msg["content"])
        # Show thumbnails for image messages
        if msg.get("images_b64"):
            cols = st.columns(min(len(msg["images_b64"]), 4))
            for col, b64 in zip(cols, msg["images_b64"]):
                img_bytes = base64.b64decode(b64)
                col.image(Image.open(io.BytesIO(img_bytes)), use_container_width=True)


# ── User input ────────────────────────────────────────────────────────────────
user_input = st.chat_input("Ask anything… (attach files in the sidebar)")

if user_input:
    # ── Process attached files ────────────────────────────────────────────────
    images_b64: list[str] = []
    extra_text_parts: list[str] = []
    file_summary_parts: list[str] = []

    for f in (uploaded_files or []):
        fname = f.name
        ext = fname.rsplit(".", 1)[-1].lower()

        if ext in ("png", "jpg", "jpeg", "webp", "gif"):
            b64 = image_to_base64(f)
            images_b64.append(b64)
            file_summary_parts.append(f"🖼️ `{fname}`")

        elif ext == "pdf":
            pdf_text = extract_pdf_text(f)
            extra_text_parts.append(
                f"[Attached PDF: {fname}]\n\n{pdf_text}"
            )
            file_summary_parts.append(f"📄 `{fname}` ({len(pdf_text):,} chars extracted)")

        else:  # plain text / code / csv / json / md …
            txt = extract_text_file(f)
            extra_text_parts.append(
                f"[Attached file: {fname}]\n\n```\n{txt}\n```"
            )
            file_summary_parts.append(f"📝 `{fname}` ({len(txt):,} chars)")

    # ── Build full prompt ─────────────────────────────────────────────────────
    full_prompt = user_input
    if extra_text_parts:
        full_prompt = "\n\n".join(extra_text_parts) + "\n\n" + user_input

    meta_str = "  ·  ".join(file_summary_parts) if file_summary_parts else ""

    # ── Show user bubble ──────────────────────────────────────────────────────
    with st.chat_message("user"):
        if meta_str:
            st.caption(meta_str)
        st.markdown(user_input)
        if images_b64:
            cols = st.columns(min(len(images_b64), 4))
            for col, b64 in zip(cols, images_b64):
                img_bytes = base64.b64decode(b64)
                col.image(Image.open(io.BytesIO(img_bytes)), use_container_width=True)

    # Store user message in history
    st.session_state.messages.append({
        "role": "user",
        "content": user_input,          # display text (without injected file content)
        "images_b64": images_b64 if images_b64 else None,
        "meta": meta_str or None,
    })

    # ── Build Ollama message history ──────────────────────────────────────────
    ollama_history = []
    for prev in st.session_state.messages[:-1]:   # all but the latest
        ollama_history.append(
            build_ollama_message(
                prev["role"],
                prev["content"],
                prev.get("images_b64"),
            )
        )
    # Latest user message (with injected file text + images)
    ollama_history.append(
        build_ollama_message("user", full_prompt, images_b64 or None)
    )

    # ── Stream assistant response ─────────────────────────────────────────────
    with st.chat_message("assistant"):
        placeholder = st.empty()
        full_response = ""
        try:
            for chunk in stream_ollama(ollama_history, st.session_state.model):
                full_response += chunk
                placeholder.markdown(full_response + "▌")   # blinking cursor
            placeholder.markdown(full_response)
        except requests.exceptions.ConnectionError:
            full_response = (
                "❌ **Cannot connect to Ollama.**\n\n"
                "Make sure Ollama is running:\n```\nollama serve\n```\n"
                f"And that the model `{st.session_state.model}` is pulled:\n"
                f"```\nollama pull {st.session_state.model}\n```"
            )
            placeholder.markdown(full_response)
        except requests.exceptions.HTTPError as e:
            full_response = f"❌ **Ollama returned an error:** `{e}`"
            placeholder.markdown(full_response)
        except Exception as e:
            full_response = f"❌ **Unexpected error:** `{e}`"
            placeholder.markdown(full_response)

    # Store assistant message
    st.session_state.messages.append({
        "role": "assistant",
        "content": full_response,
    })
