"""
cluster_manager.py
===================
Everything needed to turn a pool of H100 PBS compute nodes into extra
mineru-api workers that worker.py can send documents to, alongside the
existing local A100 endpoint.

Responsibilities:
  - Read cluster_config.yaml
  - SSH to the cluster login node and `qsub` N copies of
    cluster/submit_miner_u.pbs  (start_cluster)
  - `qdel` all of them again                                (stop_cluster)
  - Discover which PBS jobs are alive + which port their mineru-api is
    listening on, and open one local SSH tunnel per worker so worker.py can
    reach it at http://127.0.0.1:<local_port>                (sync_workers)
  - Track a simple in-memory + on-disk registry of workers (WorkerPool) so
    worker.py can hand out jobs to whichever worker is free, and the
    Streamlit "Cluster" page can show live status.

Deliberately NOT included (per product decision): the v1 "local worker
auto-spawn" tier. The local A100 fallback here is just a thin wrapper
around the app's existing, already-working config.MINERU_API_URL call.
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import threading
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import httpx
import yaml

import config

logger = logging.getLogger("cluster_manager")

CLUSTER_CONFIG_PATH = Path(__file__).resolve().parent / "cluster_config.yaml"
STATUS_SNAPSHOT_PATH = Path(config.MARKDOWN_OUTPUT_DIR).parent / "cluster_status.json"
CONTROL_FILE_PATH = Path(config.MARKDOWN_OUTPUT_DIR).parent / "cluster_control.json"


# ==============================================================================
# Config loading
# ==============================================================================

def load_cluster_config() -> dict:
    if not CLUSTER_CONFIG_PATH.exists():
        raise FileNotFoundError(
            f"cluster_config.yaml not found at {CLUSTER_CONFIG_PATH}"
        )
    with open(CLUSTER_CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ==============================================================================
# Worker pool (in-process registry, shared by worker.py's dispatch loop)
# ==============================================================================

@dataclass
class WorkerInfo:
    worker_id: str
    endpoint_url: str
    tier: int                 # 1 = remote H100, 2 = local A100 fallback
    gpu_type: str
    max_concurrency: int = 1
    pbs_job_id: Optional[str] = None
    active_jobs: int = 0
    healthy: bool = True
    last_seen: float = field(default_factory=time.time)

    def has_capacity(self) -> bool:
        return self.healthy and self.active_jobs < self.max_concurrency


class WorkerPool:
    """Thread-safe registry of everything worker.py can currently send a
    document to. Tier 1 (H100 cluster) is always tried before Tier 2
    (local A100 fallback)."""

    def __init__(self):
        self._lock = threading.Lock()
        self._workers: dict[str, WorkerInfo] = {}

    # -- registration -----------------------------------------------------
    def register(self, info: WorkerInfo) -> None:
        with self._lock:
            existing = self._workers.get(info.worker_id)
            if existing:
                info.active_jobs = existing.active_jobs  # preserve in-flight count
            self._workers[info.worker_id] = info

    def deregister(self, worker_id: str) -> None:
        with self._lock:
            self._workers.pop(worker_id, None)

    def set_ids(self, tier1_ids: set[str]) -> None:
        """Drop any Tier-1 worker not present in tier1_ids (job ended / node died)."""
        with self._lock:
            for wid in list(self._workers.keys()):
                w = self._workers[wid]
                if w.tier == 1 and wid not in tier1_ids:
                    logger.info("[POOL] Removing dead cluster worker: %s", wid)
                    del self._workers[wid]

    # -- acquire / release --------------------------------------------------
    def acquire_best_available_worker(self) -> Optional[WorkerInfo]:
        with self._lock:
            candidates = sorted(
                (w for w in self._workers.values() if w.has_capacity()),
                key=lambda w: (w.tier, w.active_jobs),
            )
            if not candidates:
                return None
            chosen = candidates[0]
            chosen.active_jobs += 1
            return chosen

    def get_endpoint(self, worker_id: str) -> Optional[str]:
        with self._lock:
            w = self._workers.get(worker_id)
            return w.endpoint_url if w else None

    def release(self, worker_id: str) -> None:
        with self._lock:
            w = self._workers.get(worker_id)
            if w and w.active_jobs > 0:
                w.active_jobs -= 1

    def mark_health(self, worker_id: str, healthy: bool) -> None:
        with self._lock:
            w = self._workers.get(worker_id)
            if w:
                w.healthy = healthy
                w.last_seen = time.time()

    def update_endpoint(self, worker_id: str, endpoint_url: str) -> None:
        """Point an already-registered worker at a new endpoint URL —
        used when _check_tunnel_health() has to reopen a dead tunnel on a
        different local port without dropping/re-registering the worker
        (which would lose its in-flight job accounting)."""
        with self._lock:
            w = self._workers.get(worker_id)
            if w:
                w.endpoint_url = endpoint_url

    # -- introspection ------------------------------------------------------
    def list_workers(self) -> list[WorkerInfo]:
        with self._lock:
            return list(self._workers.values())

    def capacity_summary(self) -> dict:
        with self._lock:
            tier1 = [w for w in self._workers.values() if w.tier == 1]
            tier2 = [w for w in self._workers.values() if w.tier == 2]
            return {
                "h100_workers_online": len(tier1),
                "h100_workers_healthy": sum(1 for w in tier1 if w.healthy),
                "h100_active_jobs": sum(w.active_jobs for w in tier1),
                "h100_capacity": sum(w.max_concurrency for w in tier1),
                "local_a100_online": len(tier2),
                "local_a100_active_jobs": sum(w.active_jobs for w in tier2),
            }

    def write_status_snapshot(self) -> None:
        """Dump current state to disk so the Streamlit Cluster page (a
        separate process) can display live status without sharing memory."""
        try:
            snapshot = {
                "updated_at": time.time(),
                "workers": [asdict(w) for w in self.list_workers()],
                "summary": self.capacity_summary(),
            }
            STATUS_SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            STATUS_SNAPSHOT_PATH.write_text(json.dumps(snapshot, indent=2))
        except Exception as exc:
            logger.warning("[POOL] Failed to write status snapshot: %s", exc)


def read_status_snapshot() -> dict:
    """Used by the Streamlit page. Returns {} if worker.py hasn't written one yet."""
    if not STATUS_SNAPSHOT_PATH.exists():
        return {}
    try:
        return json.loads(STATUS_SNAPSHOT_PATH.read_text())
    except Exception:
        return {}


# ==============================================================================
# Cluster control state (desired worker count etc, set by the Streamlit page,
# read by worker.py — this is how a separate process "clicks a button" that
# the background worker process acts on)
# ==============================================================================

def read_control_state() -> dict:
    if not CONTROL_FILE_PATH.exists():
        return {"cluster_running": False, "desired_workers": 0}
    try:
        return json.loads(CONTROL_FILE_PATH.read_text())
    except Exception:
        return {"cluster_running": False, "desired_workers": 0}


def write_control_state(cluster_running: bool, desired_workers: int) -> None:
    CONTROL_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONTROL_FILE_PATH.write_text(json.dumps({
        "cluster_running": cluster_running,
        "desired_workers": desired_workers,
        "updated_at": time.time(),
    }))


# ==============================================================================
# SSH / PBS control
# ==============================================================================

def _real_home_dir() -> Path:
    """
    Resolve the OS user's actual home directory, bypassing the HOME
    environment variable. config.py intentionally overrides HOME (so
    Hugging Face model caching writes under APP_CACHE instead of a real
    user profile) — but that also silently breaks '~' expansion for
    anything evaluated afterward, including ssh_key_path in
    cluster_config.yaml. This looks the real home dir up from the OS
    user database instead, so '~/.ssh/id_rsa' resolves correctly
    regardless of what HOME has been set to.
    """
    try:
        import pwd
        return Path(pwd.getpwuid(os.getuid()).pw_dir)
    except Exception:
        return Path(os.environ.get("USERPROFILE") or os.path.expanduser("~"))


def _resolve_ssh_key_path(raw_path: str) -> str:
    if raw_path.startswith("~"):
        return str(_real_home_dir() / raw_path.lstrip("~/"))
    return str(Path(raw_path).expanduser())


class TunnelManager:
    """Owns the SSH connection to the login node, PBS job submission/kill,
    worker discovery, and the local SSH tunnels used to reach each H100
    compute node's mineru-api port."""

    def __init__(self, cluster_cfg: dict):
        self.cfg = cluster_cfg
        self.login_host = cluster_cfg["login_host"]
        self.login_user = cluster_cfg["login_user"]
        self.ssh_key_path = _resolve_ssh_key_path(cluster_cfg["ssh_key_path"])
        self.ssh_port = cluster_cfg.get("ssh_port", 22)
        self.remote_workspace = cluster_cfg.get("remote_workspace", "~/.miner_u_workspace")
        self.worker_port = cluster_cfg.get("worker_port", 8444)
        self.pbs_job_template = cluster_cfg.get("pbs_job_template", "./cluster/submit_miner_u.pbs")
        self._tunnels: dict[str, subprocess.Popen] = {}
        self._next_port = cluster_cfg.get("base_port_range_start", 9001)
        self._max_port = cluster_cfg.get("base_port_range_end", 9040)
        self._used_ports: set[int] = set()
        self._job_id_to_worker_id: dict[str, str] = {}
        self._remote_endpoint_to_job_id: dict[tuple[str, int], str] = {}
        # Remembers each tunnel's (remote_host, remote_port) so a dead
        # local `ssh -N -L` process can be reopened on the fly by
        # _check_tunnel_health() without waiting for the next full
        # discovery cycle.
        self._worker_remote_target: dict[str, tuple[str, int]] = {}
        # Consecutive failed health checks per worker — used to debounce
        # marking a worker unhealthy (one missed check is noise, several
        # in a row means the tunnel is actually down).
        self._tunnel_fail_counts: dict[str, int] = {}
        # Persistent SSH connection reused for every control-plane command
        # (qstat, announcement fetch, qdel, sftp upload) — see
        # _get_control_client() for why this replaced opening a brand-new
        # SSH session per call.
        self._control_client = None
        self._control_lock = threading.Lock()
        # Used to only log routine "N workers discovered" lines on change,
        # instead of every single heartbeat cycle forever (see
        # sync_cluster_workers below) — that repetition was a big chunk of
        # the "too verbose" worker-terminal complaint.
        self._last_logged_candidate_count: int | None = None

        if not Path(self.ssh_key_path).is_file():
            logger.warning(
                "[SSH] Key file not found at %s (resolved from cluster_config.yaml's "
                "ssh_key_path: %r). PBS submission and worker discovery will fail "
                "until this points at a real private key.",
                self.ssh_key_path, cluster_cfg["ssh_key_path"],
            )

    # -- low level SSH helpers ------------------------------------------------
    def _ssh_client(self):
        """One-shot SSH connection (still used by anything that wants its
        own dedicated session). Prefer _get_control_client() for anything
        called repeatedly from the heartbeat loop — see its docstring."""
        import paramiko
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=self.login_host,
            port=self.ssh_port,
            username=self.login_user,
            key_filename=self.ssh_key_path,
            timeout=15,
            banner_timeout=15,
            auth_timeout=15,
        )
        return client

    def _get_control_client(self):
        """
        Reuse a single persistent SSH connection to the login node for all
        control-plane commands (qstat, announcement fetch, qdel, sftp
        upload) instead of opening a brand-new SSH session for every call.

        BUG FIX: every _run_remote() call used to open a fresh _ssh_client()
        — a brand-new TCP+SSH+auth handshake — and close it right after.
        The cluster-sync heartbeat calls _run_remote() 2-3 times per cycle
        (announcement fetch does two, qstat does one), every
        heartbeat_interval_seconds (default 20s), forever, for the whole
        life of worker.py. On a shared HPC login node that's enough new SSH
        sessions to eventually trip sshd's connection-rate limiting (e.g.
        MaxStartups) — which is exactly what showed up in the logs after
        ~30-45 minutes as a storm of "Error reading SSH protocol banner"
        and repeated "Authentication (publickey) failed" retries. Once
        that starts, the heartbeat can no longer reliably talk to the
        login node, tunnels stop being discovered/replaced, and any job
        routed through an already-broken tunnel just hangs until
        MINERU_HARD_DEADLINE_SECONDS — which is why even a 1-2 page PDF can
        appear to "take" 30 minutes: the tunnel underneath it is dead, not
        the OCR itself.

        Reusing one long-lived, keep-alived connection cuts that down to a
        single handshake, reconnecting only when the connection has
        actually broken.
        """
        import paramiko
        with self._control_lock:
            if self._control_client is not None:
                transport = self._control_client.get_transport()
                if transport is not None and transport.is_active():
                    return self._control_client
                try:
                    self._control_client.close()
                except Exception:
                    pass
                self._control_client = None

            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(
                hostname=self.login_host,
                port=self.ssh_port,
                username=self.login_user,
                key_filename=self.ssh_key_path,
                timeout=15,
                banner_timeout=15,
                auth_timeout=15,
            )
            transport = client.get_transport()
            if transport is not None:
                # Keep the connection alive across idle heartbeats so NAT/
                # firewalls between us and the login node don't silently
                # drop it before the next command needs it.
                transport.set_keepalive(30)
            self._control_client = client
            return client

    def _drop_control_client(self) -> None:
        """Force the next _run_remote()/etc. call to reconnect from
        scratch — used when a command fails in a way that suggests the
        persistent connection itself has gone bad."""
        with self._control_lock:
            if self._control_client is not None:
                try:
                    self._control_client.close()
                except Exception:
                    pass
                self._control_client = None

    def _run_remote(self, command: str, timeout: int = 30) -> tuple[int, str, str]:
        import paramiko
        client = self._get_control_client()
        try:
            stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
            exit_code = stdout.channel.recv_exit_status()
            out = stdout.read().decode(errors="replace")
            err = stderr.read().decode(errors="replace")
            return exit_code, out, err
        except (paramiko.SSHException, OSError):
            # The persistent connection may have gone bad mid-command —
            # drop it so the *next* call reconnects fresh instead of
            # repeatedly failing against a broken transport.
            self._drop_control_client()
            raise

    def _qdel(self, pbs_job_id: str, reason: str = "") -> None:
        """
        Cancel a PBS job over SSH. Used to auto-terminate the confirmed
        LOSER of a port collision (see sync_cluster_workers) instead of
        leaving it fully GPU-allocated and completely idle for its entire
        walltime — every collision the app silently skipped before this
        was a whole H100 node wasted for up to pbs_walltime. Best-effort:
        logs and swallows failures (job may have already ended on its own)
        rather than raising, since this always runs from the background
        heartbeat thread.
        """
        try:
            code, out, err = self._run_remote(f"qdel {pbs_job_id}", timeout=20)
            if code == 0:
                logger.warning(
                    "[CLUSTER] Auto-terminated PBS job %s (%s) — freeing that GPU "
                    "allocation for a future, non-colliding job instead of leaving "
                    "it idle for the rest of its walltime.",
                    pbs_job_id, reason or "no reason given",
                )
            else:
                logger.info(
                    "[CLUSTER] qdel %s returned %s (%s) — likely already ended.",
                    pbs_job_id, code, (err or out).strip()[:200],
                )
        except Exception as exc:
            logger.warning("[CLUSTER] Could not qdel %s: %s", pbs_job_id, exc)

    def _start_readiness_check(self, worker_id: str, endpoint_url: str, pool: "WorkerPool") -> None:
        """
        A newly-tunnelled H100 worker is registered with healthy=False
        immediately (see sync_cluster_workers) — has_capacity() excludes
        unhealthy workers, so nothing gets dispatched to it yet. This
        background thread polls the ALREADY-EXISTING (previously unused)
        health_check() helper until the worker's mineru-api actually
        answers, then flips it to healthy=True.

        FIX for the "Connection refused" failures on freshly-started
        workers: mineru-api's VLM backend can take well over a minute to
        load its model onto the GPU before it's listening at all — jobs
        dispatched during that window used to fail immediately. Now the
        pool simply doesn't offer this worker up until it's proven ready.
        Bounded at 20 minutes (generous for a large VLM checkpoint); if it
        never comes up, the worker just stays unused — the next heartbeat
        cycle's normal "job ended" cleanup removes it once its PBS job
        actually exits.
        """
        def _poll():
            deadline = time.time() + 20 * 60
            delay = 3.0
            while time.time() < deadline:
                if health_check(endpoint_url, timeout=5.0):
                    pool.mark_health(worker_id, True)
                    logger.info(
                        "[CLUSTER] %s is ready (mineru-api responded) — now eligible for dispatch.",
                        worker_id,
                    )
                    return
                time.sleep(delay)
                delay = min(delay * 1.3, 15.0)  # back off gradually, cap at 15s
            logger.warning(
                "[CLUSTER] %s never became ready within 20 minutes — leaving it "
                "out of rotation. It'll be cleaned up once its PBS job ends "
                "(or investigate: the model may have failed to load).",
                worker_id,
            )

        threading.Thread(target=_poll, daemon=True, name=f"readiness-{worker_id}").start()

    # -- PBS submit / kill ------------------------------------------------------
    def _ensure_pbs_script_uploaded(self) -> str:
        """
        SFTP the local cluster/submit_miner_u.pbs up to the login node.
        The script only ever existed on the machine running worker.py/
        Streamlit — qsub runs on the remote login node, so it needs its
        own copy. Returns the remote path to pass to `qsub`.
        Re-uploads every call so edits to the local .pbs script are always
        picked up on the next "Start cluster" click.
        """
        local_script = (Path(__file__).resolve().parent / self.pbs_job_template.lstrip("./"))
        if not local_script.is_file():
            raise RuntimeError(f"PBS script not found locally at {local_script}")

        # mkdir (shell expands ~ here)
        code, out, err = self._run_remote(f"mkdir -p {self.remote_workspace}", timeout=20)
        if code != 0:
            raise RuntimeError(f"Could not create remote workspace {self.remote_workspace}: {err or out}")

        # SFTP has no shell, so it can't expand '~' — an SFTP session's
        # starting directory is already the user's home, so a workspace
        # given as "~/.miner_u_workspace" becomes the relative path
        # ".miner_u_workspace" for SFTP purposes. Absolute paths (starting
        # with "/") are used as-is.
        if self.remote_workspace.startswith("~/"):
            sftp_dir = self.remote_workspace[2:]
        elif self.remote_workspace == "~":
            sftp_dir = "."
        else:
            sftp_dir = self.remote_workspace

        remote_script_path = f"{sftp_dir}/submit_miner_u.pbs"

        client = self._get_control_client()
        sftp = client.open_sftp()
        try:
            sftp.put(str(local_script), remote_script_path)
        finally:
            sftp.close()

        logger.info("[PBS] Uploaded %s -> %s:%s", local_script, self.login_host, remote_script_path)
        # Return the same path via the shell-visible (tilde) form, since
        # qsub itself runs through a normal shell that WILL expand '~'.
        return f"{self.remote_workspace}/submit_miner_u.pbs"

    def submit_pbs_job(self) -> str:
        """qsub one copy of the mineru-api PBS script. Returns the PBS job id."""
        if not Path(self.ssh_key_path).is_file():
            raise RuntimeError(
                f"SSH key not found at {self.ssh_key_path}. Fix `ssh_key_path` "
                f"in cluster_config.yaml — it must point to a real private key "
                f"readable by the account running worker.py."
            )
        remote_script_path = self._ensure_pbs_script_uploaded()
        cmd = f"cd $HOME && qsub {remote_script_path}"
        code, out, err = self._run_remote(cmd, timeout=30)
        if code != 0:
            raise RuntimeError(f"qsub failed (exit {code}): {err or out}")
        job_id = out.strip().splitlines()[-1].strip()
        logger.info("[PBS] Submitted worker job: %s", job_id)
        return job_id

    def start_cluster(self, num_workers: int) -> list[str]:
        """Submit `num_workers` PBS jobs. Returns the list of job ids submitted."""
        if not Path(self.ssh_key_path).is_file():
            raise RuntimeError(
                f"SSH key not found at {self.ssh_key_path}. Fix `ssh_key_path` "
                f"in cluster_config.yaml before starting the cluster — it must "
                f"point to a real private key readable by the account running "
                f"worker.py (not a path inside APP_CACHE)."
            )
        job_ids = []
        for i in range(num_workers):
            try:
                job_ids.append(self.submit_pbs_job())
            except Exception as exc:
                logger.error("[PBS] Failed to submit worker %d/%d: %s", i + 1, num_workers, exc)
        return job_ids

    def kill_pbs_job(self, job_id: str) -> None:
        code, out, err = self._run_remote(f"qdel {job_id}", timeout=20)
        if code != 0:
            logger.warning("[PBS] qdel %s returned %d: %s", job_id, code, err or out)

    def kill_all_pbs_jobs(self) -> int:
        """Kill every currently-tracked mineru-api PBS job. Returns count killed."""
        job_ids = list(self._list_pbs_job_ids())
        for jid in job_ids:
            try:
                self.kill_pbs_job(jid)
            except Exception as exc:
                logger.warning("[PBS] Failed to kill %s: %s", jid, exc)
        self.close_all_tunnels()
        return len(job_ids)

    # -- discovery ---------------------------------------------------------
    def query_pbs_jobs_with_qstat_fx(self) -> dict:
        """
        Ask PBS directly which nodes our worker jobs are running on. This is
        the critical fallback ported from v1: it does NOT depend on any
        shared filesystem between the login node and compute nodes — PBS
        itself always knows a running job's exec_host, so this works even
        when worker_<jobid>.json announcement files never appear because
        compute-node $HOME isn't the same filesystem as the login node's.
        """
        try:
            client = self._get_control_client()
            cmd = (
                "bash -l -c 'qstat -fx -u {u} 2>/dev/null || qstat -f -u {u} 2>/dev/null "
                "|| qstat -fx 2>/dev/null || qstat -u {u} 2>/dev/null || qstat 2>/dev/null'"
            ).format(u=self.login_user)
            stdin, stdout, stderr = client.exec_command(cmd, timeout=20)
            output = stdout.read().decode(errors="replace")
            if output:
                return self._parse_qstat_output(output)
        except Exception as exc:
            logger.debug("[CLUSTER] qstat -fx query failed: %s", exc)
            self._drop_control_client()
        return {}

    def _parse_qstat_output(self, output: str) -> dict:
        jobs: dict = {}

        # Try the "Job Id:" block format first (qstat -f / -fx text mode)
        current_job_id = None
        current_job = {}
        for raw_line in output.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith("Job Id:") or line.startswith("Job:"):
                if current_job_id and current_job:
                    jobs[current_job_id] = current_job
                current_job_id = line.split(":", 1)[1].strip()
                current_job = {"job_id": current_job_id, "job_state": "", "exec_host": "", "job_name": ""}
            elif "=" in line and current_job_id:
                key, val = [p.strip() for p in line.split("=", 1)]
                if key == "job_state":
                    current_job["job_state"] = val
                elif key in ("exec_host", "exec_vnode"):
                    current_job["exec_host"] = self._clean_exec_host(val)
                elif key == "Job_Name":
                    current_job["job_name"] = val
        if current_job_id and current_job:
            jobs[current_job_id] = current_job

        if not jobs:
            # Fallback: plain tabular `qstat` output has no exec_host column,
            # but still gives us job id + state so kill_all_pbs_jobs works.
            for raw_line in output.splitlines():
                parts = raw_line.split()
                if len(parts) >= 5 and ("." in parts[0] or parts[0].isdigit()):
                    jid = parts[0]
                    name = parts[1] if len(parts) > 1 else "miner_u"
                    state = next((p for p in parts[2:] if p in ("R", "Q", "H", "E", "C", "T", "W")), None)
                    if state and jid not in jobs:
                        jobs[jid] = {"job_id": jid, "job_name": name, "job_state": state, "exec_host": ""}
        return jobs

    def _clean_exec_host(self, raw_host: str) -> str:
        if not raw_host:
            return ""
        cleaned = re.sub(r"[()]", "", raw_host)
        first_node = cleaned.split("+")[0]
        return re.split(r"[/:]", first_node)[0].strip()

    def _list_pbs_job_ids(self) -> set[str]:
        """All currently known mineru_u_h100_worker PBS job ids (for kill_all)."""
        jobs = self.query_pbs_jobs_with_qstat_fx()
        return {
            jid for jid, info in jobs.items()
            if "miner_u" in info.get("job_name", "").lower() or not info.get("job_name")
        } or set(jobs.keys())

    @staticmethod
    def _parse_concatenated_json_objects(text: str) -> list[dict]:
        """
        Parse zero or more back-to-back, possibly multi-line/pretty-printed
        JSON objects out of one blob of text (e.g. several `cat`'d files
        concatenated together). Uses json.JSONDecoder.raw_decode in a loop
        so it doesn't matter how much whitespace/newlines sit between or
        inside objects — unlike splitting on '\\n' or a fixed delimiter.
        """
        decoder = json.JSONDecoder()
        objects: list[dict] = []
        idx = 0
        n = len(text)
        while idx < n:
            while idx < n and text[idx] in " \t\r\n":
                idx += 1
            if idx >= n:
                break
            try:
                obj, end = decoder.raw_decode(text, idx)
                objects.append(obj)
                idx = end
            except json.JSONDecodeError:
                # Not valid JSON starting here — skip to the next '{' and retry,
                # so one malformed/partial file doesn't take down the rest.
                next_brace = text.find("{", idx + 1)
                if next_brace == -1:
                    break
                idx = next_brace
        return objects

    def _fetch_announcements(self) -> list[dict]:
        """Read every worker_<jobid>.json file the PBS script publishes."""
        remote_dir = f"{self.remote_workspace}/active_workers"

        diag_code, diag_out, diag_err = self._run_remote(
            f'echo "HOME=$HOME"; '
            f'if [ -d {remote_dir} ]; then '
            f'  echo "DIR_EXISTS=yes"; ls -la {remote_dir} 2>&1; '
            f'else '
            f'  echo "DIR_EXISTS=no: {remote_dir}"; '
            f'fi',
            timeout=20,
        )
        logger.debug("[CLUSTER][DIAG] %s", diag_out.replace("\n", " | ").strip() or diag_err)

        code, out, err = self._run_remote(
            f"for f in {remote_dir}/worker_*.json; do "
            f'[ -f "$f" ] && (cat "$f"; echo); done', timeout=20,
        )
        if code != 0:
            logger.warning("[CLUSTER] Announcement fetch command failed (exit %d): %s", code, err)


        announcements = self._parse_concatenated_json_objects(out)

        if not announcements:
            logger.debug(
                "[CLUSTER] 0 worker announcements found under %s. If `qstat` shows "
                "PBS jobs Running but this stays 0, the most common cause is that "
                "the compute node's $HOME (where the PBS script writes the "
                "announcement file) is NOT the same filesystem as the login "
                "node's $HOME (where this check runs) — check the DIAG line "
                "above, and compare it against `cat ~/.miner_u_workspace/logs/"
                "worker_<jobid>.log` on the login node to confirm the compute "
                "node actually wrote its announcement file.",
                remote_dir,
            )
        else:
            logger.debug("[CLUSTER] Found %d worker announcement(s).", len(announcements))

        return announcements

    # -- tunnels -------------------------------------------------------------
    def _allocate_local_port(self) -> int:
        for p in range(self._next_port, self._max_port + 1):
            if p not in self._used_ports:
                self._used_ports.add(p)
                return p
        raise RuntimeError("No free local tunnel ports left (raise base_port_range in cluster_config.yaml)")

    def _open_tunnel(self, worker_id: str, remote_host: str, remote_port: int, local_port: int) -> int:
        cmd = [
            "ssh", "-N",
            "-L", f"{local_port}:{remote_host}:{remote_port}",
            "-o", "StrictHostKeyChecking=no",
            "-o", "ServerAliveInterval=30",
            "-i", self.ssh_key_path,
            "-p", str(self.ssh_port),
            f"{self.login_user}@{self.login_host}",
        ]
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self._tunnels[worker_id] = proc
        self._worker_remote_target[worker_id] = (remote_host, remote_port)
        logger.info("[TUNNEL] Opened 127.0.0.1:%d -> %s:%d (%s)", local_port, remote_host, remote_port, worker_id)
        return local_port

    def _close_tunnel(self, worker_id: str) -> None:
        proc = self._tunnels.pop(worker_id, None)
        self._worker_remote_target.pop(worker_id, None)
        self._tunnel_fail_counts.pop(worker_id, None)
        if proc:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except Exception:
                proc.kill()

    def close_all_tunnels(self) -> None:
        for wid in list(self._tunnels.keys()):
            self._close_tunnel(wid)
        self._used_ports.clear()
        self._job_id_to_worker_id.clear()
        self._drop_control_client()

    def _check_tunnel_health(self, pool: "WorkerPool") -> None:
        """
        Periodic self-healing check for already-open tunnels — run every
        heartbeat, in addition to the one-shot _start_readiness_check done
        right after a tunnel is first opened.

        BUG FIX: previously a tunnel was only ever health-checked ONCE,
        immediately after opening. After that, the pool just trusted it
        forever. If the local `ssh -N -L` tunnel process died, or the
        connection went quietly stale (e.g. during the SSH banner-timeout
        storm — see _get_control_client()), the pool kept treating that
        worker as healthy and dispatching new jobs to it. Each such job had
        no way to fail fast: the mineru-api HTTP call just waits for a
        response that will never come, all the way out to
        MINERU_HARD_DEADLINE_SECONDS (1800s) — which is why even a 1-2 page
        PDF can appear to "take" 30 minutes: it's the tunnel that's dead,
        not the OCR.

        This re-checks every tunnelled worker every heartbeat cycle and:
          - reopens the local ssh process immediately if it has exited;
          - marks a worker unhealthy after a couple of consecutive failed
            HTTP health checks, so new jobs stop being routed to it (jobs
            already in flight on it still have to hit their own timeout —
            this can't rescue those, but it stops new ones from piling up);
          - marks it healthy again once checks start passing.
        """
        for worker_id in list(self._tunnels.keys()):
            proc = self._tunnels.get(worker_id)
            target = self._worker_remote_target.get(worker_id)
            if proc is None or target is None:
                continue

            if proc.poll() is not None:
                logger.warning(
                    "[TUNNEL] %s's local ssh tunnel process exited unexpectedly "
                    "(exit code %s) — reopening.", worker_id, proc.returncode,
                )
                pool.mark_health(worker_id, False)
                self._tunnels.pop(worker_id, None)
                hostname, remote_port = target
                try:
                    local_port = self._allocate_local_port()
                    self._open_tunnel(worker_id, hostname, remote_port, local_port)
                    new_endpoint = f"http://127.0.0.1:{local_port}"
                    pool.update_endpoint(worker_id, new_endpoint)
                    self._tunnel_fail_counts[worker_id] = 0
                    self._start_readiness_check(worker_id, new_endpoint, pool)
                except Exception as exc:
                    logger.error("[TUNNEL] Could not reopen tunnel for %s: %s", worker_id, exc)
                continue

            endpoint_url = pool.get_endpoint(worker_id)
            if not endpoint_url:
                continue

            if health_check(endpoint_url, timeout=5.0):
                if self._tunnel_fail_counts.get(worker_id):
                    logger.info("[TUNNEL] %s recovered — marking healthy again.", worker_id)
                self._tunnel_fail_counts[worker_id] = 0
                pool.mark_health(worker_id, True)
            else:
                fails = self._tunnel_fail_counts.get(worker_id, 0) + 1
                self._tunnel_fail_counts[worker_id] = fails
                if fails == 2:
                    logger.warning(
                        "[TUNNEL] %s failed %d consecutive health checks — marking "
                        "unhealthy (no new jobs) until it recovers.", worker_id, fails,
                    )
                if fails >= 2:
                    pool.mark_health(worker_id, False)

    # -- main sync entry point (called periodically by worker.py) -----------
    def sync_cluster_workers(self, pool: WorkerPool) -> None:
        """
        Discover currently-running H100 PBS workers, open tunnels for new
        ones, register them in the pool, and clean up ones that ended.

        Merges TWO discovery sources (ported from v1, where this combination
        is what actually made cluster dispatch work):
          1. Shared-filesystem announcement files — precise port + GPU type,
             but requires compute-node $HOME to be visible from the login
             node.
          2. `qstat -fx` exec_host — asks PBS directly which node a Running
             job landed on. This does NOT depend on any shared filesystem,
             so it still works when source 1 finds nothing (assumes the
             default mineru-api port from cluster_config.yaml).
        Source 1 is preferred per job when both are available (it has the
        real port); source 2 fills in anything source 1 missed.
        """
        announcements = self._fetch_announcements()
        pbs_jobs = self.query_pbs_jobs_with_qstat_fx()

        candidates: dict[str, dict] = {}  # keyed by pbs_job_id

        for ann in announcements:
            job_id = str(ann.get("pbs_job_id", "")).strip()
            hostname = ann.get("hostname")
            if job_id and hostname:
                candidates[job_id] = {
                    "hostname": hostname,
                    "port": ann.get("port", self.worker_port),
                    "gpu_type": ann.get("gpu_type", "H100"),
                    "max_concurrency": ann.get("max_concurrency", 1),
                    "source": "announcement",
                }

        for job_id, info in pbs_jobs.items():
            job_id = str(job_id).strip()
            if job_id in candidates:
                continue  # already have the more precise announcement data
            if info.get("job_state") == "R" and info.get("exec_host"):
                candidates[job_id] = {
                    "hostname": info["exec_host"],
                    "port": self.worker_port,  # can't know the real port without the announcement
                    "gpu_type": "H100",
                    "max_concurrency": 1,
                    "source": "qstat",
                }

        if not candidates:
            log_fn = (
                logger.warning if self._last_logged_candidate_count != 0
                else logger.debug
            )
            log_fn(
                "[CLUSTER] Neither announcement files nor `qstat -fx` found any "
                "running H100 worker. If PBS jobs show state R in `qstat`, check "
                "that login_user/login_host in cluster_config.yaml can run "
                "`qstat -fx` non-interactively over SSH."
            )
        else:
            n_ann = sum(1 for c in candidates.values() if c["source"] == "announcement")
            n_qstat = sum(1 for c in candidates.values() if c["source"] == "qstat")
            # Only log this at INFO when the discovered count actually
            # changes — otherwise it repeats unchanged every heartbeat
            # cycle forever, which was a big source of terminal noise.
            log_fn = (
                logger.info if len(candidates) != self._last_logged_candidate_count
                else logger.debug
            )
            log_fn(
                "[CLUSTER] Discovered %d worker(s) (%d via announcement, %d via qstat fallback).",
                len(candidates), n_ann, n_qstat,
            )
        self._last_logged_candidate_count = len(candidates)

        seen_job_ids = set(candidates.keys())

        # Register anything new
        for job_id, cand in candidates.items():
            if job_id in self._job_id_to_worker_id:
                continue  # already registered + tunnelled

            hostname = cand["hostname"]
            remote_port = cand["port"]
            remote_key = (hostname, remote_port)

            colliding_job_id = self._remote_endpoint_to_job_id.get(remote_key)
            if colliding_job_id and colliding_job_id != job_id:
                existing_worker_id = self._job_id_to_worker_id.get(colliding_job_id)
                existing_endpoint = pool.get_endpoint(existing_worker_id) if existing_worker_id else None
                existing_is_alive = bool(existing_endpoint and health_check(existing_endpoint, timeout=5.0))

                if existing_is_alive:
                    # The already-registered job genuinely holds the port —
                    # job_id (this candidate) is the confirmed loser.
                    logger.error(
                        "[CLUSTER] PORT COLLISION: PBS job %s announced %s:%s, but job "
                        "%s already holds that port (confirmed via health check) — "
                        "skipping %s. This needs fixing on the PBS/announcement side "
                        "(each job on a node must get a distinct port).",
                        job_id, hostname, remote_port, colliding_job_id, job_id,
                    )
                    if (self.cfg.get("mode") == "auto"
                            and self.cfg.get("auto_terminate_colliding_jobs", True)):
                        self._qdel(job_id, reason=f"lost port collision on {hostname}:{remote_port}")
                    continue
                else:

                    logger.warning(
                        "[CLUSTER] PORT COLLISION: PBS job %s announced %s:%s, and "
                        "previously-registered job %s does not actually respond to a "
                        "health check — treating %s as the real winner and dropping "
                        "the stale registration instead.",
                        job_id, hostname, remote_port, colliding_job_id, job_id,
                    )
                    if existing_worker_id:
                        self._close_tunnel(existing_worker_id)
                        pool.deregister(existing_worker_id)
                    self._job_id_to_worker_id.pop(colliding_job_id, None)
                    if (self.cfg.get("mode") == "auto"
                            and self.cfg.get("auto_terminate_colliding_jobs", True)):
                        self._qdel(colliding_job_id, reason=f"lost port collision on {hostname}:{remote_port} (unresponsive)")
                    # fall through and register job_id normally below


            short_job_id = job_id.split(".")[0]
            worker_id = f"h100-{hostname}-{short_job_id}"
            try:
                local_port = self._allocate_local_port()
                self._open_tunnel(worker_id, hostname, remote_port, local_port)
            except Exception as exc:
                logger.error("[TUNNEL] Could not open tunnel for PBS job %s (%s): %s", job_id, hostname, exc)
                continue

            self._job_id_to_worker_id[job_id] = worker_id
            self._remote_endpoint_to_job_id[remote_key] = job_id
            endpoint_url = f"http://127.0.0.1:{local_port}"
            pool.register(WorkerInfo(
                worker_id=worker_id,
                endpoint_url=endpoint_url,
                tier=1,
                gpu_type=cand["gpu_type"],
                max_concurrency=cand["max_concurrency"],
                pbs_job_id=job_id,
                healthy=False,  # gated until _start_readiness_check confirms it — see there
            ))
            logger.info(
                "[POOL] Registered new H100 worker: %s (job %s, via %s) — waiting for "
                "readiness check before it receives any jobs.",
                worker_id, job_id, cand["source"],
            )
            self._start_readiness_check(worker_id, endpoint_url, pool)

        # Drop workers whose PBS job ended
        for job_id in list(self._job_id_to_worker_id.keys()):
            if job_id not in seen_job_ids:
                worker_id = self._job_id_to_worker_id.pop(job_id)
                logger.info("[POOL] PBS job %s ended — removing worker %s", job_id, worker_id)
                self._close_tunnel(worker_id)
                pool.deregister(worker_id)
                # Free up this (hostname, port) so a future job legitimately
                # reusing it later won't be falsely flagged as a collision.
                stale_keys = [k for k, v in self._remote_endpoint_to_job_id.items() if v == job_id]
                for k in stale_keys:
                    del self._remote_endpoint_to_job_id[k]

        # Re-check every already-open tunnel's health every heartbeat, not
        # just once at registration time — see _check_tunnel_health().
        self._check_tunnel_health(pool)



# ==============================================================================
# Dispatch helper — the actual mineru-api call routed to whichever worker
# (H100 tunnel endpoint, or the existing local A100 endpoint) was assigned.
# ==============================================================================

def health_check(endpoint_url: str, timeout: float = 5.0) -> bool:
    try:
        r = httpx.get(f"{endpoint_url}/docs", timeout=timeout)
        return r.status_code < 500
    except Exception:
        try:
            r = httpx.get(endpoint_url, timeout=timeout)
            return r.status_code < 500
        except Exception:
            return False
