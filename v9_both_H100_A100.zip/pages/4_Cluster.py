# =====================================================================
#  pages/4_Cluster.py
#  Start/stop the H100 PBS worker cluster and see live worker status.
#  Simple by design: one slider, two buttons, one status table.
# =====================================================================

import time

import streamlit as st

import cluster_manager

st.set_page_config(page_title="Cluster", page_icon="🖥️", layout="wide")

# ── Auth guard ───────────────────────────────────────────────────────────
if "user" not in st.session_state:
    st.warning("Please log in first.")
    st.stop()

# ── Load config ─────────────────────────────────────────────────────────
try:
    full_cfg = cluster_manager.load_cluster_config()
    cluster_cfg = full_cfg.get("cluster", {})
except FileNotFoundError:
    st.error("cluster_config.yaml is missing — cluster processing isn't configured.")
    st.stop()

if not cluster_cfg.get("enabled", False):
    st.info(
        "The H100 cluster is disabled in `cluster_config.yaml` "
        "(`cluster.enabled: false`). Documents are processed using the "
        "local A100 endpoint only."
    )
    st.stop()

st.title("🖥️ H100 Cluster")
st.caption(
    "Spin up remote H100 workers on the PBS cluster to process many "
    "documents in parallel. When the cluster is off, or busy, jobs "
    "automatically fall back to the local A100 server."
)

control = cluster_manager.read_control_state()
snapshot = cluster_manager.read_status_snapshot()
summary = snapshot.get("summary", {})
workers = snapshot.get("workers", [])

# ── Status row ───────────────────────────────────────────────────────────
c1, c2, c3, c4 = st.columns(4)
c1.metric("H100 workers online", summary.get("h100_workers_online", 0))
c2.metric("H100 jobs running now", f"{summary.get('h100_active_jobs', 0)} / {summary.get('h100_capacity', 0)}")
c3.metric("Local A100", "online" if summary.get("local_a100_online", 0) else "not registered")
c4.metric("Local A100 jobs running", summary.get("local_a100_active_jobs", 0))

if control.get("cluster_running"):
    st.success(f"Cluster is ON — target size: {control.get('desired_workers', 0)} workers.")
else:
    st.warning("Cluster is OFF. Documents are processing on the local A100 server only.")

st.divider()

# ── Controls ─────────────────────────────────────────────────────────────
left, right = st.columns([2, 1])

with left:
    st.subheader("Start / stop")
    default_n = control.get("desired_workers") or cluster_cfg.get("default_workers", 20)
    n_workers = st.slider(
        "Number of H100 workers",
        min_value=1,
        max_value=cluster_cfg.get("max_workers", 40),
        value=min(max(default_n, 1), cluster_cfg.get("max_workers", 40)),
        help="Each worker is one PBS job running on its own H100 node. "
             "More workers = more documents processed in parallel.",
    )

    b1, b2 = st.columns(2)
    with b1:
        if st.button("🚀 Start cluster", type="primary", use_container_width=True,
                      disabled=control.get("cluster_running", False)):
            with st.spinner(f"Submitting {n_workers} PBS jobs to {cluster_cfg['login_host']} …"):
                try:
                    tm = cluster_manager.TunnelManager(cluster_cfg)
                    job_ids = tm.start_cluster(n_workers)
                    cluster_manager.write_control_state(True, n_workers)
                    st.success(
                        f"Submitted {len(job_ids)}/{n_workers} PBS jobs. "
                        f"Workers will appear below within ~{cluster_cfg.get('heartbeat_interval_seconds', 20)}s "
                        f"of starting on their nodes."
                    )
                except Exception as exc:
                    st.error(f"Failed to start cluster: {exc}")
            time.sleep(1)
            st.rerun()

    with b2:
        if st.button("🛑 Stop cluster", use_container_width=True,
                      disabled=not control.get("cluster_running", False)):
            with st.spinner("Stopping all H100 workers …"):
                try:
                    tm = cluster_manager.TunnelManager(cluster_cfg)
                    killed = tm.kill_all_pbs_jobs()
                    cluster_manager.write_control_state(False, 0)
                    st.success(f"Stopped {killed} PBS job(s). New documents will use the local A100 server.")
                except Exception as exc:
                    st.error(f"Failed to stop cluster: {exc}")
            time.sleep(1)
            st.rerun()

with right:
    st.subheader("Cluster settings")
    st.markdown(
        f"""
        - **Login node:** `{cluster_cfg['login_host']}`
        - **PBS queue:** `{cluster_cfg.get('pbs_queue', '-')}`
        - **Per worker:** {cluster_cfg.get('pbs_ngpus', 1)} GPU · {cluster_cfg.get('pbs_ncpus', '-')} CPUs · {cluster_cfg.get('pbs_mem', '-')} RAM
        - **Walltime:** {cluster_cfg.get('pbs_walltime', '-')}
        """
    )
    st.caption("Edit `cluster_config.yaml` to change these.")

st.divider()

# ── Live worker table ────────────────────────────────────────────────────
st.subheader("Active workers")

if not workers:
    st.caption(
        "No workers registered yet. After clicking **Start cluster**, this "
        "list fills in as each PBS job boots its mineru-api service "
        f"(usually within a minute or two, refreshed every "
        f"{cluster_cfg.get('heartbeat_interval_seconds', 20)}s)."
    )
else:
    rows = []
    for w in sorted(workers, key=lambda w: (w["tier"], w["worker_id"])):
        rows.append({
            "Worker": w["worker_id"],
            "Type": "H100 (cluster)" if w["tier"] == 1 else "A100 (local fallback)",
            "PBS Job ID": w.get("pbs_job_id") or "—",
            "Status": "🟢 healthy" if w["healthy"] else "🔴 unresponsive",
            "Jobs in flight": f'{w["active_jobs"]} / {w["max_concurrency"]}',
        })
    st.dataframe(rows, use_container_width=True, hide_index=True)

st.caption(
    "This page reads status written by the background worker process "
    "(`python worker.py`) — make sure that process is running for the "
    "cluster to actually start, discover workers, and process documents."
)

if st.button("🔄 Refresh status"):
    st.rerun()
