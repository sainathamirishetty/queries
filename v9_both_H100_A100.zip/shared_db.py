"""
shared_db.py
============
Centralised SQLite access for:
  - documents        → file metadata (filename, title, date, size …)
  - processing_jobs  → per‑document background processing state
  - users            → simple username / password store (plain‑text for demo)

Both the Streamlit UI pages and the background worker import this module.
"""

import sqlite3
from datetime import datetime
from pathlib import Path

import config

# ----------------------------------------------------------------------
# ── Database location
# ----------------------------------------------------------------------
DB_PATH = Path(config.DOCUMENTS_INPUT_DIR).parent / "APP_CACHE" / "file_metadata.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


# ----------------------------------------------------------------------
# ── Low‑level connection helper
# ----------------------------------------------------------------------
def _conn() -> sqlite3.Connection:
    con = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
    con.execute("PRAGMA journal_mode=WAL")          # concurrent readers + one writer
    con.execute("PRAGMA busy_timeout=10000")       # wait up to 10 s on lock
    _ensure_schema(con)                            # always make sure the schema exists
    return con


# ----------------------------------------------------------------------
# ── Schema creation (run on every connection)
# ----------------------------------------------------------------------
def _ensure_schema(con: sqlite3.Connection):
    con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS documents (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            filename    TEXT NOT NULL,
            user_name   TEXT NOT NULL,
            title       TEXT,
            doc_date    TEXT,
            category    TEXT,
            doc_id      TEXT,
            status      TEXT NOT NULL DEFAULT 'pending',
            created_at  TEXT NOT NULL,
            updated_at  TEXT,
            size_bytes  INTEGER,
            FOREIGN KEY(user_name) REFERENCES users(username),
            UNIQUE(filename, user_name)
        );

        CREATE TABLE IF NOT EXISTS processing_jobs (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            filename     TEXT NOT NULL,
            user_name    TEXT NOT NULL,
            status       TEXT NOT NULL DEFAULT 'pending',
            queued_at    TEXT,
            started_at   TEXT,
            finished_at  TEXT,
            error_message TEXT,
            FOREIGN KEY(user_name) REFERENCES users(username)
        );

        -- Unique index for the ON CONFLICT clause
        CREATE UNIQUE INDEX IF NOT EXISTS idx_processing_jobs_unique
            ON processing_jobs(filename, user_name);

        -- Replaces document_cache.json. A plain JSON file rewritten wholesale
        -- on every completed file (load-entire-dict, mutate one key, write-
        -- entire-dict-back) loses entries under concurrent writers: if two
        -- cluster workers finish OCR close together, whichever one calls
        -- save_cache() second overwrites the file with a snapshot that does
        -- not include the first worker's newly-added entry. SQLite in WAL
        -- mode (see _conn() above) makes each INSERT its own atomic,
        -- serialized transaction, so no entry can ever be silently dropped
        -- this way, however many workers finish at once.
        CREATE TABLE IF NOT EXISTS file_hash_cache (
            file_hash  TEXT PRIMARY KEY,
            filename   TEXT NOT NULL,
            user_name  TEXT,
            cached_at  TEXT NOT NULL
        );
    """)
    con.commit()

    # Lightweight migration: add processed_by so the UI can show which
    # worker (H100 cluster node, or the local A100) handled each document.
    # SQLite has no "ADD COLUMN IF NOT EXISTS", so probe and ignore if present.
    try:
        con.execute("ALTER TABLE processing_jobs ADD COLUMN processed_by TEXT")
        con.commit()
    except sqlite3.OperationalError:
        pass  # column already exists


    try:
        con.execute("ALTER TABLE processing_jobs ADD COLUMN stage_detail TEXT")
        con.commit()
    except sqlite3.OperationalError:
        pass  # column already exists


    try:
        con.execute("ALTER TABLE processing_jobs ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0")
        con.commit()
    except sqlite3.OperationalError:
        pass  # column already exists

def validate_user(username: str, password: str) -> bool:
    """Check that the supplied credentials match a row in the users table."""
    con = _conn()
    row = con.execute(
        "SELECT 1 FROM users WHERE username = ? AND password = ?",
        (username, password),
    ).fetchone()
    con.close()
    return row is not None


def change_password(username: str, new_password: str) -> None:
    """Replace the password for an existing user."""
    con = _conn()
    con.execute(
        "UPDATE users SET password = ? WHERE username = ?",
        (new_password, username),
    )
    con.commit()
    con.close()


# ----------------------------------------------------------------------
# ── DOCUMENTS TABLE
# ----------------------------------------------------------------------
def load_all_documents(user_name: str | None = None) -> dict:
    """
    Return {filename: record_dict} for every document belonging to *user_name*.
    The function is tolerant to older DB schemas that lack any of the
    optional columns (doc_date, created_at, updated_at, size_bytes, status).
    """
    con = _conn()
    try:
        rows = con.execute(
            """
            SELECT filename, title, doc_date, created_at, updated_at,
                   size_bytes, status
            FROM documents
            WHERE user_name = ?
            """,
            (user_name,),
        ).fetchall()
        # Normal case – all columns exist
        return {
            r[0]: {
                "filename": r[0],
                "title": r[1],
                "date": r[2],
                "uploaded_at": r[3],
                "updated_at": r[4],
                "size_bytes": r[5],
                "status": r[6],
            }
            for r in rows
        }
    except sqlite3.OperationalError as e:
        # One or more columns are missing – fall back to a minimal query
        missing = str(e).lower()
        cols = ["filename", "title"]
        if "created_at" not in missing and "updated_at" not in missing:
            cols += ["created_at", "updated_at"]
        if "size_bytes" not in missing:
            cols.append("size_bytes")
        if "status" not in missing:
            cols.append("status")

        # Build a dynamic SELECT list
        select_clause = ", ".join(cols)
        rows = con.execute(
            f"""
            SELECT {select_clause}
            FROM documents
            WHERE user_name = ?
            """,
            (user_name,),
        ).fetchall()

        # Map the result back to the same dict shape (missing fields become None)
        result = {}
        for r in rows:
            # Pad the tuple so we can index safely
            padded = list(r) + [None] * (7 - len(r))
            result[padded[0]] = {
                "filename": padded[0],
                "title": padded[1],
                "date": None,                     # doc_date missing
                "uploaded_at": padded[2] if "created_at" in cols else None,
                "updated_at": padded[3] if "updated_at" in cols else None,
                "size_bytes": padded[4] if "size_bytes" in cols else None,
                "status": padded[5] if "status" in cols else None,
            }
        return result
    finally:
        con.close()


def save_document(record: dict, user_name: str):
    """Insert or replace a document row for *user_name*."""
    con = _conn()
    now = datetime.now().isoformat()
    con.execute(
        """
        INSERT OR REPLACE INTO documents
            (filename, user_name, title, doc_date, category, doc_id,
             status, created_at, updated_at, size_bytes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            record["filename"],
            user_name,
            record.get("title"),
            record.get("date"),
            record.get("category"),
            record.get("doc_id"),
            record.get("status", "pending"),
            record.get("created_at", now),
            record.get("updated_at", now),
            record.get("size_bytes"),
        ),
    )
    con.commit()
    con.close()


def delete_document(filename: str, user_name: str):
    con = _conn()
    con.execute(
        "DELETE FROM documents WHERE filename = ? AND user_name = ?",
        (filename, user_name),
    )
    con.execute(
        "DELETE FROM processing_jobs WHERE filename = ? AND user_name = ?",
        (filename, user_name),
    )
    con.commit()
    con.close()


# ----------------------------------------------------------------------
# ── PROCESSING_JOBS TABLE
# ----------------------------------------------------------------------
def enqueue_job(filename: str, user_name: str):
    con = _conn()
    now = datetime.now().isoformat()
    # INSERT OR REPLACE will overwrite the row if it already exists
    con.execute(
        """
        INSERT OR REPLACE INTO processing_jobs
            (filename, user_name, status, queued_at)
        VALUES (?, ?, 'pending', ?)
        """,
        (filename, user_name, now),
    )
    con.commit()
    con.close()


def requeue_all_failed(user_name: str) -> int:
    """
    Move every 'failed' job for this user back to 'pending' in one shot.
    Returns how many jobs were requeued. Same effect as clicking "Re-queue"
    on each failed job individually, without the one-by-one UI round trips.
    """
    con = _conn()
    now = datetime.now().isoformat()
    cur = con.execute(
        """
        UPDATE processing_jobs
        SET status = 'pending', queued_at = ?, started_at = NULL,
            finished_at = NULL, error_message = NULL, retry_count = 0
        WHERE status = 'failed' AND user_name = ?
        """,
        (now, user_name),
    )
    count = cur.rowcount
    con.execute(
        "UPDATE documents SET status = 'pending', updated_at = ? "
        "WHERE status = 'failed' AND user_name = ?",
        (now, user_name),
    )
    con.commit()
    con.close()
    return count


def is_file_cached(file_hash: str) -> bool:
    """True if this file's content hash already has OCR + image-desc done."""
    con = _conn()
    row = con.execute(
        "SELECT 1 FROM file_hash_cache WHERE file_hash = ?", (file_hash,)
    ).fetchone()
    con.close()
    return row is not None


def mark_file_cached(file_hash: str, filename: str, user_name: str = ""):
    """Atomic, race-safe replacement for the old JSON document_cache.json."""
    con = _conn()
    con.execute(
        """
        INSERT OR REPLACE INTO file_hash_cache (file_hash, filename, user_name, cached_at)
        VALUES (?, ?, ?, ?)
        """,
        (file_hash, filename, user_name, datetime.now().isoformat()),
    )
    con.commit()
    con.close()


def mark_running(filename: str, user_name: str, processed_by: str | None = None):
    con = _conn()
    con.execute(
        """
        UPDATE processing_jobs
        SET status = 'running', started_at = ?, processed_by = ?
        WHERE filename = ? AND user_name = ?
        """,
        (datetime.now().isoformat(), processed_by, filename, user_name),
    )
    con.commit()
    con.close()


def mark_enriching(filename: str, user_name: str):
    """
    Set status to 'enriching' — OCR is done (this file's H100/A100 GPU slot
    has already been released), image description (Ollama qwen3-vl) is in
    progress on the dedicated enrichment thread pool. Document is NOT yet
    queryable at this stage.
    """
    con = _conn()
    con.execute(
        """
        UPDATE processing_jobs
        SET status = 'enriching', finished_at = NULL
        WHERE filename = ? AND user_name = ?
        """,
        (filename, user_name),
    )
    con.commit()
    con.close()


def mark_indexing(filename: str, user_name: str):
    """
    Set status to 'indexing' — OCR + image description are both done, chunk
    summarization / vector indexing in progress.
    Document is NOT yet queryable at this stage.
    Clears finished_at so the elapsed timer runs live until mark_done() sets the real time.
    """
    con = _conn()
    con.execute(
        """
        UPDATE processing_jobs
        SET status = 'indexing', finished_at = NULL
        WHERE filename = ? AND user_name = ?
        """,
        (filename, user_name),
    )
    con.commit()
    con.close()


def mark_stage(filename: str, user_name: str, detail: str):
    """
    Record a short human-readable description of exactly what's happening
    to this document right now (which of the three parallel pipeline
    stages, and on which worker/model). Purely informational — does NOT
    change `status`, so it never affects queue routing. Safe to call often;
    failures are swallowed so a UI-only detail string can never break the
    pipeline itself.
    """
    con = None
    try:
        con = _conn()
        con.execute(
            """
            UPDATE processing_jobs
            SET stage_detail = ?
            WHERE filename = ? AND user_name = ?
            """,
            (detail, filename, user_name),
        )
        con.commit()
    except Exception:
        pass
    finally:
        if con is not None:
            con.close()


def mark_done(filename: str, user_name: str):
    """
    Set status to 'done' — vectors are fully indexed and document is queryable.
    Only called AFTER chunk_and_index_for_user() completes successfully.
    """
    con = _conn()
    con.execute(
        """
        UPDATE processing_jobs
        SET status = 'done', finished_at = ?
        WHERE filename = ? AND user_name = ?
        """,
        (datetime.now().isoformat(), filename, user_name),
    )
    con.commit()
    con.close()


def mark_failed(filename: str, error: str, user_name: str):
    con = _conn()
    con.execute(
        """
        UPDATE processing_jobs
        SET status = 'failed',
            finished_at = ?,
            error_message = ?
        WHERE filename = ? AND user_name = ?
        """,
        (datetime.now().isoformat(), str(error)[:2000], filename, user_name),
    )
    con.commit()
    con.close()


def get_retry_count(filename: str, user_name: str) -> int:
    con = _conn()
    row = con.execute(
        "SELECT retry_count FROM processing_jobs WHERE filename = ? AND user_name = ?",
        (filename, user_name),
    ).fetchone()
    con.close()
    return row[0] if row else 0


def requeue_for_transient_retry(filename: str, user_name: str, error: str) -> int:
    """
    Send a job back to 'pending' after a TRANSIENT infrastructure failure
    (worker not ready yet, node briefly unreachable, a stale/colliding pool
    slot — see worker.py's _TRANSIENT_ERROR_TYPES), instead of permanently
    failing it on the first hiccup. Bumps `retry_count` and returns the new
    value so the caller can stop retrying past
    config.MAX_TRANSIENT_RETRIES and fall through to mark_failed() instead
    — this function does NOT enforce that cap itself, so it never loops a
    genuinely broken document forever on its own.

    Deliberately separate from requeue_stale_jobs()/reset_job_status(),
    which are for crash recovery (this process restarting) — this one is
    for the still-running process reacting to one job's failure.
    """
    con = _conn()
    row = con.execute(
        "SELECT retry_count FROM processing_jobs WHERE filename = ? AND user_name = ?",
        (filename, user_name),
    ).fetchone()
    new_count = (row[0] if row else 0) + 1
    con.execute(
        """
        UPDATE processing_jobs
        SET status = 'pending',
            retry_count = ?,
            started_at = NULL,
            finished_at = NULL,
            error_message = ?,
            stage_detail = ?
        WHERE filename = ? AND user_name = ?
        """,
        (
            new_count,
            f"auto-retry {new_count}: {str(error)[:500]}",
            f"🔁 Requeued after transient error (attempt {new_count})",
            filename, user_name,
        ),
    )
    con.commit()
    con.close()
    return new_count


def get_all_jobs(user_name: str | None = None) -> list[dict]:
    """
    Return all processing‑job rows for *user_name*.
    If any timestamp columns are missing the function falls back to a minimal query.
    """
    con = _conn()

    try:
        if user_name is None:
            # Return jobs for **all** users (useful for admin views)
            rows = con.execute(
                """
                SELECT filename, status, queued_at, started_at,
                       finished_at, error_message, processed_by, stage_detail,
                       retry_count
                FROM processing_jobs
                ORDER BY queued_at DESC
                """
            ).fetchall()
        else:
            rows = con.execute(
                """
                SELECT filename, status, queued_at, started_at,
                       finished_at, error_message, processed_by, stage_detail,
                       retry_count
                FROM processing_jobs
                WHERE user_name = ?
                ORDER BY queued_at DESC
                """,
                (user_name,),
            ).fetchall()
        return [
            {
                "filename": r[0],
                "status": r[1],
                "queued_at": r[2],
                "started_at": r[3],
                "finished_at": r[4],
                "error_message": r[5],
                "processed_by": r[6],
                "stage_detail": r[7],
                "retry_count": r[8],
            }
            for r in rows
        ]
    except sqlite3.OperationalError as e:
        # Missing timestamp columns – return only the columns we have
        if "queued_at" in str(e) or "started_at" in str(e):
            rows = con.execute(
                """
                SELECT filename, status
                FROM processing_jobs
                WHERE user_name = ?
                ORDER BY filename
                """,
                (user_name,),
            ).fetchall()
            return [
                {
                    "filename": r[0],
                    "status": r[1],
                    "queued_at": None,
                    "started_at": None,
                    "finished_at": None,
                    "error_message": None,
                    "processed_by": None,
                    "stage_detail": None,
                    "retry_count": 0,
                }
                for r in rows
            ]
        else:
            raise
    finally:
        con.close()


def get_job(filename: str, user_name: str) -> dict | None:
    con = _conn()
    row = con.execute(
        """
        SELECT filename, status, queued_at, started_at,
               finished_at, error_message
        FROM processing_jobs
        WHERE filename = ? AND user_name = ?
        """,
        (filename, user_name),
    ).fetchone()
    con.close()
    if row is None:
        return None
    return {
        "filename": row[0],
        "status": row[1],
        "queued_at": row[2],
        "started_at": row[3],
        "finished_at": row[4],
        "error_message": row[5],
    }


def count_by_status(user_name: str) -> dict:
    con = _conn()
    rows = con.execute(
        """
        SELECT status, COUNT(*)
        FROM processing_jobs
        WHERE user_name = ?
        GROUP BY status
        """,
        (user_name,),
    ).fetchall()
    con.close()
    return {r[0]: r[1] for r in rows}


def get_newly_done_since(last_seen_count: int, user_name: str | None = None) -> int:
    """Return current count of 'done' jobs for *user_name* (or globally if None)."""
    con = _conn()
    if user_name:
        cnt = con.execute(
            "SELECT COUNT(*) FROM processing_jobs WHERE status = 'done' AND user_name = ?",
            (user_name,),
        ).fetchone()[0]
    else:
        cnt = con.execute(
            "SELECT COUNT(*) FROM processing_jobs WHERE status = 'done'"
        ).fetchone()[0]
    con.close()
    return cnt


def get_pending_jobs(user_name: str) -> list[str]:
    """Return filenames of all pending jobs for *user_name* (used by the worker)."""
    con = _conn()
    rows = con.execute(
        """
        SELECT filename
        FROM processing_jobs
        WHERE status = 'pending' AND user_name = ?
        ORDER BY queued_at
        """,
        (user_name,),
    ).fetchall()
    con.close()
    return [r[0] for r in rows]

def requeue_stale_jobs() -> list[dict]:
    """
    Recovery step for power-cuts / crashes — 'running' jobs only.

    A job left sitting in 'running' died mid-OCR (power loss, OOM kill,
    etc.) with no guarantee any output was flushed to disk, so it's always
    unsafe to trust partial work here — reset it to 'pending' unconditionally.

    'indexing' jobs are handled separately by the caller (worker.py), which
    checks file_hash_cache per file before deciding whether OCR genuinely
    needs to be redone — see get_indexing_status_jobs() below.

    Call this once, at worker startup, BEFORE the main dispatch loop begins.
    """
    con = _conn()
    now = datetime.now().isoformat()
    stale = con.execute(
        "SELECT filename, user_name, status FROM processing_jobs "
        "WHERE status = 'running'"
    ).fetchall()

    if stale:
        con.execute(
            """
            UPDATE processing_jobs
            SET status = 'pending',
                queued_at = ?,
                started_at = NULL,
                finished_at = NULL,
                error_message = 'auto-requeued after restart (was stuck in-flight)'
            WHERE status = 'running'
            """,
            (now,),
        )
        con.execute(
            """
            UPDATE documents
            SET status = 'pending', updated_at = ?
            WHERE status = 'running'
            """,
            (now,),
        )
        con.commit()
    con.close()

    return [{"filename": r[0], "user_name": r[1], "previous_status": r[2]} for r in stale]


def get_jobs_at_status(status: str) -> list[dict]:
    """
    Read-only: every job currently sitting at *status* (across all users).
    Generic helper used both by startup recovery (for 'indexing' and
    'enriching') and by the dedicated background loops (worker.py's
    _enrichment_loop / _indexer_loop) to find their own work without
    touching jobs that belong to a different stage.
    """
    con = _conn()
    rows = con.execute(
        "SELECT filename, user_name FROM processing_jobs WHERE status = ?", (status,)
    ).fetchall()
    con.close()
    return [{"filename": r[0], "user_name": r[1]} for r in rows]


def get_indexing_status_jobs() -> list[dict]:
    """
    Back-compat wrapper: every job currently sitting at 'indexing' (across
    all users), surviving from a previous run. Does NOT modify anything —
    the caller (worker.py, at startup) checks file_hash_cache per file and
    decides, per file, whether to restore it straight to 'indexing' (OCR
    genuinely done) or drop it back to 'pending' (no cache entry, must redo
    OCR).
    """
    return get_jobs_at_status("indexing")


def reset_job_status(filename: str, user_name: str, status: str, reason: str = ""):
    """Generic status reset used by startup recovery (status: 'pending' or 'indexing')."""
    con = _conn()
    now = datetime.now().isoformat()
    con.execute(
        """
        UPDATE processing_jobs
        SET status = ?, queued_at = ?, started_at = NULL, finished_at = NULL,
            error_message = ?
        WHERE filename = ? AND user_name = ?
        """,
        (status, now, reason, filename, user_name),
    )
    con.execute(
        "UPDATE documents SET status = ?, updated_at = ? WHERE filename = ? AND user_name = ?",
        (status, now, filename, user_name),
    )
    con.commit()
    con.close()


def get_users_with_status(status: str) -> list[str]:
    """Distinct user_names that currently have at least one job at *status*."""
    con = _conn()
    rows = con.execute(
        "SELECT DISTINCT user_name FROM processing_jobs WHERE status = ?", (status,)
    ).fetchall()
    con.close()
    return [r[0] for r in rows]


def get_jobs_by_status(user_name: str, status: str) -> list[dict]:
    """Return {filename, user_name} rows for a given user currently at *status*."""
    con = _conn()
    rows = con.execute(
        "SELECT filename, user_name FROM processing_jobs WHERE user_name = ? AND status = ?",
        (user_name, status),
    ).fetchall()
    con.close()
    return [{"filename": r[0], "user_name": r[1]} for r in rows]


def get_all_pending_jobs() -> list[dict]:
    """Return ALL pending jobs across ALL users (used by the multi-user worker)."""
    con = _conn()
    rows = con.execute(
        """
        SELECT filename, user_name, queued_at
        FROM processing_jobs
        WHERE status = 'pending'
        ORDER BY queued_at
        """
    ).fetchall()
    con.close()
    return [{"filename": r[0], "user_name": r[1], "queued_at": r[2]} for r in rows]


def update_document_status(filename: str, user_name: str, status: str):
    """Update the status column in the documents table."""
    con = _conn()
    con.execute(
        """
        UPDATE documents
        SET status = ?, updated_at = ?
        WHERE filename = ? AND user_name = ?
        """,
        (status, __import__("datetime").datetime.now().isoformat(), filename, user_name),
    )
    con.commit()
    con.close()


# ----------------------------------------------------------------------
# ── FULL ARTIFACT PURGE  (called from Delete button)
# ----------------------------------------------------------------------
def purge_document_artifacts(filename: str, user_name: str) -> dict:
    """
    Delete every artifact produced when *filename* was ingested.
    Touches ONLY the files/entries that belong to this one document.
    All other documents are completely unaffected.

    Deletion order matters — hashes are computed BEFORE the files are removed:
      1. Compute file hash & markdown hash first (while files still exist)
      2. Delete original uploaded file
      3. Delete MARKDOWNS/<stem>/ folder  (md, json, images, pdf copy)
      4. Delete MARKDOWNS/_temp_pdfs/<stem>.pdf  (Office→PDF intermediate)
      5. Delete CHUNK_DUMP_DIR/<stem>_all_chunks.txt
      6. Remove exactly ONE hash key from document_cache.json
      7. Remove exactly ONE doc_hash key from contextual_chunks.json
      8. Delete Qdrant vectors filtered by  metadata.filename == stem
      9. Delete DB rows from documents + processing_jobs
    """
    import hashlib
    import json
    import shutil
    import logging
    from pathlib import Path

    log = logging.getLogger(__name__)
    deleted = []
    errors  = []

    stem        = Path(filename).stem
    original    = Path(config.DOCUMENTS_INPUT_DIR) / user_name / filename
    md_dir      = Path(config.MARKDOWN_OUTPUT_DIR) / stem
    md_file     = md_dir / f"{stem}.md"
    temp_pdf    = Path(config.MARKDOWN_OUTPUT_DIR) / "_temp_pdfs" / f"{stem}.pdf"
    chunk_dump  = Path(config.CHUNK_DUMP_DIR) / f"{stem}_all_chunks.txt"
    cache_file  = Path(config.DOCUMENT_CACHE) / "document_cache.json"
    ctx_path    = Path(str(config.CONTEXT_CACHE_PATH))

    # ── helpers ──────────────────────────────────────────────────────────
    def _rm_file(p: Path):
        try:
            if p.exists():
                p.unlink()
                deleted.append(str(p))
                log.info(f"[PURGE] file deleted: {p}")
        except Exception as exc:
            errors.append(f"file {p}: {exc}")
            log.warning(f"[PURGE] cannot delete {p}: {exc}")

    def _rm_dir(p: Path):
        try:
            if p.exists() and p.is_dir():
                shutil.rmtree(p)
                deleted.append(str(p))
                log.info(f"[PURGE] dir deleted: {p}")
        except Exception as exc:
            errors.append(f"dir {p}: {exc}")
            log.warning(f"[PURGE] cannot delete dir {p}: {exc}")

    def _sha256_file(p: Path) -> str:
        sha = hashlib.sha256()
        with open(p, "rb") as fh:
            for block in iter(lambda: fh.read(65536), b""):
                sha.update(block)
        return sha.hexdigest()

    def _sha256_bytes(b: bytes) -> str:
        return hashlib.sha256(b).hexdigest()

    # ══════════════════════════════════════════════════════════════════════
    # STEP 1 — Compute hashes BEFORE any file is deleted
    # ══════════════════════════════════════════════════════════════════════
    # file_hash  → key to remove from document_cache.json
    # md_hash    → key to remove from contextual_chunks.json
    file_hash = None
    md_hash   = None

    try:
        if original.exists():
            file_hash = _sha256_file(original)
            log.info(f"[PURGE] file_hash computed for {filename}: {file_hash[:12]}…")
    except Exception as exc:
        errors.append(f"hash(original): {exc}")
        log.warning(f"[PURGE] could not hash original file: {exc}")

    try:
        if md_file.exists():
            md_hash = _sha256_bytes(md_file.read_bytes())
            log.info(f"[PURGE] md_hash computed for {stem}: {md_hash[:12]}…")
    except Exception as exc:
        errors.append(f"hash(md): {exc}")
        log.warning(f"[PURGE] could not hash markdown file: {exc}")

    # ══════════════════════════════════════════════════════════════════════
    # STEP 2 — Delete original uploaded file
    # ══════════════════════════════════════════════════════════════════════
    _rm_file(original)

    # ══════════════════════════════════════════════════════════════════════
    # STEP 3 — Delete MARKDOWNS/<stem>/ folder
    # ══════════════════════════════════════════════════════════════════════
    _rm_dir(md_dir)

    # ══════════════════════════════════════════════════════════════════════
    # STEP 4 — Delete temp PDF (only exists when source was Office file)
    # ══════════════════════════════════════════════════════════════════════
    _rm_file(temp_pdf)

    # ══════════════════════════════════════════════════════════════════════
    # STEP 5 — Delete chunk dump text file
    # ══════════════════════════════════════════════════════════════════════
    _rm_file(chunk_dump)

    # ══════════════════════════════════════════════════════════════════════
    # STEP 6 — Remove exactly ONE hash key from document_cache.json
    #
    # document_cache.json  structure:  { "<sha256_of_original_file>": "cached", … }
    # We computed file_hash in Step 1 while the original still existed.
    # We pop only that one key — every other document's hash is untouched.
    # ══════════════════════════════════════════════════════════════════════
    try:
        if cache_file.exists() and file_hash:
            cache: dict = json.loads(cache_file.read_text(encoding="utf-8"))
            if file_hash in cache:
                cache.pop(file_hash)
                cache_file.write_text(json.dumps(cache, indent=2), encoding="utf-8")
                deleted.append(f"document_cache.json entry for {stem}")
                log.info(f"[PURGE] removed 1 hash from document_cache.json ({stem})")
            else:
                log.info(f"[PURGE] hash not found in document_cache.json — already clean")
        elif not file_hash:
            log.info(f"[PURGE] skipping document_cache.json — original file was already missing before delete")
    except Exception as exc:
        errors.append(f"document_cache.json: {exc}")
        log.warning(f"[PURGE] document_cache.json update failed: {exc}")

    # ══════════════════════════════════════════════════════════════════════
    # STEP 7 — Remove exactly ONE doc_hash key from contextual_chunks.json
    #
    # contextual_chunks.json  structure:
    #   { "<sha256_of_markdown_text>": { "<chunk_hash>": {context, …}, … }, … }
    # We computed md_hash in Step 1 while the markdown still existed.
    # We pop only that one key — every other document's context is untouched.
    # ══════════════════════════════════════════════════════════════════════
    try:
        if ctx_path.exists() and ctx_path.stat().st_size > 2 and md_hash:
            ctx: dict = json.loads(ctx_path.read_text(encoding="utf-8"))
            if md_hash in ctx:
                ctx.pop(md_hash)
                ctx_path.write_text(json.dumps(ctx, indent=2, ensure_ascii=False), encoding="utf-8")
                deleted.append(f"contextual_chunks.json entry for {stem}")
                log.info(f"[PURGE] removed 1 doc_hash from contextual_chunks.json ({stem})")
            else:
                log.info(f"[PURGE] doc_hash not found in contextual_chunks.json — already clean")
        elif not md_hash:
            log.info(f"[PURGE] skipping contextual_chunks.json — markdown was already missing before delete")
    except Exception as exc:
        errors.append(f"contextual_chunks.json: {exc}")
        log.warning(f"[PURGE] contextual_chunks.json update failed: {exc}")

    # ══════════════════════════════════════════════════════════════════════
    # STEP 8 — Delete Qdrant vectors for this document only
    #
    # Every vector point was stored with  metadata.filename == stem.
    # The filter targets exactly those points and nothing else.
    # ══════════════════════════════════════════════════════════════════════
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.http.models import Filter, FieldCondition, MatchValue

        import rag_pipeline as _rp
        _rp.start_qdrant_server()  # no-op if already running; starts it if not

        qdrant_url = getattr(config, "QDRANT_URL", "http://localhost:6333")
        client = QdrantClient(url=qdrant_url, timeout=60)
        collections = [c.name for c in client.get_collections().collections]

        if config.QDRANT_COLLECTION_NAME in collections:
            qdrant_filter = Filter(
                must=[
                    FieldCondition(
                        key="metadata.filename",
                        match=MatchValue(value=stem),
                    )
                ]
            )
            client.delete(
                collection_name=config.QDRANT_COLLECTION_NAME,
                points_selector=qdrant_filter,
                wait=True,
            )
            remaining = client.count(
                collection_name=config.QDRANT_COLLECTION_NAME,
                count_filter=qdrant_filter,
                exact=True,
            ).count

            if remaining == 0:
                deleted.append(f"Qdrant vectors for {stem}")
                log.info(f"[PURGE] Qdrant vectors deleted (metadata.filename={stem})")
            else:
                errors.append(
                    f"qdrant: {remaining} point(s) for '{stem}' still present after delete"
                )
                log.warning(
                    f"[PURGE] Qdrant delete call returned but {remaining} point(s) "
                    f"for filename={stem} still remain"
                )
        else:
            log.info(f"[PURGE] Qdrant collection not found — skipping vector delete")
    except Exception as exc:
        errors.append(f"qdrant: {exc}")
        log.warning(f"[PURGE] Qdrant delete failed: {exc}")

    # ══════════════════════════════════════════════════════════════════════
    # STEP 9 — Remove DB rows for this file + user only
    # ══════════════════════════════════════════════════════════════════════
    try:
        delete_document(filename, user_name)
        deleted.append(f"DB rows ({filename} / {user_name})")
        log.info(f"[PURGE] DB rows removed ({filename} / {user_name})")
    except Exception as exc:
        errors.append(f"db: {exc}")
        log.warning(f"[PURGE] DB delete failed: {exc}")

    return {"deleted": deleted, "errors": errors}
