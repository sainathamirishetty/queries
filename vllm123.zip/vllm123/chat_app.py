# ==================================================================
# Streamlit chat app for Qwen3.8-27B served by vLLM.
#
# Setup (typical): vLLM runs on the H100 compute node; you reach it
# from your local machine through an SSH tunnel, e.g.
#     ssh -N -L 8000:MPFCS-GN-0003:8000 rcideais03@<login-node>
# Then this app talks to http://localhost:8000 as if the model were local.
#
# If instead you run this app ON the cluster (same network as vLLM),
# just change VLLM_HOST below to the compute node, e.g. "MPFCS-GN-0003".
#
# Run:  streamlit run chat_app.py
# ==================================================================
import json
import requests
import streamlit as st

# ---- Connection ---------------------------------------------------
VLLM_HOST   = "localhost"       # "localhost" when using the SSH tunnel;
                                #  or the compute node name if app runs on the cluster
VLLM_PORT   = 8000
MODEL_NAME  = "qwen38"          # must match --served-model-name in the PBS script
BASE_URL    = f"http://{VLLM_HOST}:{VLLM_PORT}"
CHAT_URL    = f"{BASE_URL}/v1/chat/completions"
MODELS_URL  = f"{BASE_URL}/v1/models"
# -------------------------------------------------------------------

st.set_page_config(page_title="Qwen3.8 Chat", page_icon="\U0001F916", layout="wide")


# ---- Helpers ------------------------------------------------------
def server_online() -> bool:
    """Quick health check: is the vLLM server reachable?"""
    try:
        r = requests.get(MODELS_URL, timeout=3)
        return r.status_code == 200
    except Exception:
        return False


def stream_reply(api_messages, settings):
    """
    Yield (reasoning_delta, content_delta) chunks from vLLM's streaming API.
    Requires the server to run with --reasoning-parser qwen3 so that
    'reasoning_content' comes back as its own field.
    """
    payload = {
        "model":       MODEL_NAME,
        "messages":    api_messages,
        "max_tokens":  settings["max_tokens"],
        "temperature": settings["temperature"],
        "top_p":       settings["top_p"],
        "top_k":       settings["top_k"],
        "stream":      True,
        "chat_template_kwargs": {"enable_thinking": settings["enable_thinking"]},
    }
    with requests.post(
        CHAT_URL,
        headers={"Content-Type": "application/json",
                 "Authorization": "Bearer EMPTY"},
        data=json.dumps(payload),
        stream=True,
        timeout=600,
    ) as resp:
        resp.raise_for_status()
        for raw in resp.iter_lines():
            if not raw:
                continue
            line = raw.decode("utf-8")
            if not line.startswith("data: "):
                continue
            data = line[len("data: "):]
            if data.strip() == "[DONE]":
                break
            try:
                delta = json.loads(data)["choices"][0]["delta"]
            except Exception:
                continue
            yield delta.get("reasoning_content") or "", delta.get("content") or ""


# ---- Sidebar: settings + status ----------------------------------
with st.sidebar:
    st.header("Settings")

    online = server_online()
    if online:
        st.success("vLLM server: online")
    else:
        st.error("vLLM server: unreachable")
        st.caption(f"Trying {BASE_URL}. Is the PBS job running and the tunnel open?")

    enable_thinking = st.toggle("Thinking mode", value=True,
                                help="Off = faster, direct answers. On = shows reasoning.")
    max_tokens  = st.slider("Max reply tokens", 256, 8192, 2048, step=256)
    # Qwen recommends higher temp for thinking, lower for direct answers.
    default_temp = 1.0 if enable_thinking else 0.7
    temperature = st.slider("Temperature", 0.0, 1.5, default_temp, step=0.1)
    top_p       = st.slider("top_p", 0.1, 1.0, 0.95, step=0.05)
    top_k       = st.slider("top_k", 1, 100, 20, step=1)

    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()

settings = {
    "max_tokens":  max_tokens,
    "temperature": temperature,
    "top_p":       top_p,
    "top_k":       top_k,
    "enable_thinking": enable_thinking,
}

# ---- Main chat area ----------------------------------------------
st.title("\U0001F916 Qwen3.8-27B Chat")

if "messages" not in st.session_state:
    st.session_state.messages = []      # each: {role, content, reasoning?}

# render history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        if msg.get("reasoning"):
            with st.expander("Thinking"):
                st.markdown(msg["reasoning"])
        st.markdown(msg["content"])

# input
user_input = st.chat_input("Type your message...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    # send only role+content upstream (drop our local 'reasoning' key)
    api_messages = [{"role": m["role"], "content": m["content"]}
                    for m in st.session_state.messages]

    with st.chat_message("assistant"):
        think_box  = st.expander("Thinking", expanded=True)
        think_slot = think_box.empty()
        answer_slot = st.empty()

        reasoning, answer = "", ""
        try:
            for r_delta, c_delta in stream_reply(api_messages, settings):
                if r_delta:
                    reasoning += r_delta
                    think_slot.markdown(reasoning)
                if c_delta:
                    answer += c_delta
                    answer_slot.markdown(answer + "▌")   # cursor while streaming
            answer_slot.markdown(answer)                       # final, no cursor
        except requests.exceptions.ConnectionError:
            answer = "Cannot reach the vLLM server. Is the job running and the tunnel open?"
            answer_slot.markdown(answer)
        except requests.exceptions.Timeout:
            answer = "Request timed out. The model may still be loading."
            answer_slot.markdown(answer)
        except Exception as e:
            answer = f"Error: {e}"
            answer_slot.markdown(answer)

    st.session_state.messages.append(
        {"role": "assistant", "content": answer, "reasoning": reasoning}
    )
