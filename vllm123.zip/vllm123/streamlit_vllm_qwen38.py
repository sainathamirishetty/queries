# ------------------------------------------------------------------
# Streamlit chat client for Qwen3.8-27B served by vLLM.
# Changes vs your old vLLM app:
#   - reads message["reasoning_content"] (the <think> block) SEPARATELY
#     from message["content"] (the clean answer) -> no more "We need to
#     respond to user..." junk leaking into the answer.
#   - shows thinking in a collapsible expander, answer below it.
#   - served-model-name is "qwen38" (matches the PBS script).
#   - sampling params match Qwen's recommendation for thinking mode.
# ------------------------------------------------------------------
import streamlit as st
import requests
import json

# --- Configuration ------------------------------------------------
VLLM_URL    = "http://MPFCS-GN-0003:8000/v1/chat/completions"
MODEL_NAME  = "qwen38"          # must match --served-model-name in the PBS script
SYSTEM_MSG  = "You are a helpful assistant."
MAX_TOKENS  = 2048              # was 512; give the model room to think + answer
TEMPERATURE = 1.0               # thinking-mode recommendation (0.6-1.0)
TOP_P       = 0.95
TOP_K       = 20
# Set to False to turn OFF the model's <think> reasoning (faster, direct answers).
ENABLE_THINKING = True
# ------------------------------------------------------------------

st.set_page_config(page_title="Chat Assistant", page_icon="\U0001F4AC")
st.title("\U0001F4AC Chat Assistant")
st.caption("Powered by Qwen3.8-27B via vLLM")

if "messages" not in st.session_state:
    st.session_state.messages = []      # each: {role, content, reasoning?}

# --- render history -----------------------------------------------
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        if msg.get("reasoning"):
            with st.expander("Thinking"):
                st.markdown(msg["reasoning"])
        st.write(msg["content"])

# --- chat input ---------------------------------------------------
user_input = st.chat_input("Type your message...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.write(user_input)

    # Build the request. Only send role+content upstream (not our reasoning key).
    api_messages = [{"role": "system", "content": SYSTEM_MSG}] + [
        {"role": m["role"], "content": m["content"]} for m in st.session_state.messages
    ]

    payload = {
        "model":       MODEL_NAME,
        "messages":    api_messages,
        "max_tokens":  MAX_TOKENS,
        "temperature": TEMPERATURE,
        "top_p":       TOP_P,
        "top_k":       TOP_K,
        # per-request thinking control (server must run with --reasoning-parser qwen3)
        "chat_template_kwargs": {"enable_thinking": ENABLE_THINKING},
    }

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            reasoning = ""
            try:
                response = requests.post(
                    VLLM_URL,
                    headers={"Content-Type": "application/json",
                             "Authorization": "Bearer EMPTY"},
                    data=json.dumps(payload),
                    timeout=600,
                )
                response.raise_for_status()
                message   = response.json()["choices"][0]["message"]
                reply     = message.get("content") or ""
                reasoning = message.get("reasoning_content") or ""   # the <think> block
            except requests.exceptions.ConnectionError:
                reply = "Cannot reach the vLLM server. Make sure the PBS job is running."
            except requests.exceptions.Timeout:
                reply = "Request timed out. The model may still be loading or overloaded."
            except Exception as e:
                reply = f"Error: {str(e)}"

        if reasoning:
            with st.expander("Thinking"):
                st.markdown(reasoning)
        st.write(reply)

    st.session_state.messages.append(
        {"role": "assistant", "content": reply, "reasoning": reasoning}
    )
