# Qwen3.8-27B on an offline H100 cluster via Apptainer/Singularity + vLLM

Both machines are Ubuntu 24.x, x86_64. Build on the internet box, copy two artifacts,
run on the cluster. Replace anything in <angle brackets> with your real values.

Files used: vllm38.def (build) and serve_qwen38.pbs (run).

================================================================================
PHASE A — INTERNET BOX (build the image)
================================================================================

A1. Find the model's absolute path:
        realpath Qwen3.8-27B
    -> e.g. /home/you/Qwen3.8-27B   (this is <MODEL_PATH>)

A2. Install the builder (once):
        sudo apt-get update
        sudo apt-get install -y apptainer
        apptainer --version
    (If not in apt: download the Ubuntu 24 .deb from the Apptainer GitHub
     releases page and: sudo apt install ./<file>.deb)

A3. Put vllm38.def in a folder, cd into it, build (needs internet, ~10-20 min):
        apptainer build --fakeroot vllm38.sif vllm38.def
    If --fakeroot errors:
        sudo apptainer build vllm38.sif vllm38.def

A4. Verify the image:
        apptainer exec vllm38.sif cat /opt/versions.txt
    transformers must be >= 5.8.0. Result: vllm38.sif (~8-10 GB).

================================================================================
PHASE B — TRANSFER (three items into one directory on the cluster)
================================================================================

Items: vllm38.sif, the Qwen3.8-27B folder, serve_qwen38.pbs

With a network link:
        rsync -avP vllm38.sif serve_qwen38.pbs <user>@<cluster>:/scratch/<user>/qwen38/
        rsync -avP <MODEL_PATH> <user>@<cluster>:/scratch/<user>/qwen38/

Truly air-gapped: rsync onto an approved drive, carry it over, rsync onto the cluster.

================================================================================
PHASE C — CLUSTER (prepare)
================================================================================

C1. Confirm a container runtime exists:
        apptainer --version   ||   singularity --version
    If neither: module avail 2>&1 | grep -i -E 'apptainer|singularity'
    If it's a module, note the name (add 'module load <name>' to the job script).

C2. Confirm files arrived:
        cd /scratch/<user>/qwen38
        ls -lh vllm38.sif
        du -sh Qwen3.8-27B          # ~55 GB

C3. Edit serve_qwen38.pbs near the top:
      - #PBS -q <your_gpu_queue>
      - #PBS -l select=...          (exact GPU syntax from your admin)
      - CONFIG block: WORKDIR / SIF / MODEL_DIR match where files are
      - if C1 found a module: add 'module load <name>' after 'set -euo pipefail'

================================================================================
PHASE D — RUN
================================================================================

D1. (Recommended) Interactive smoke test first — grab one GPU and load by hand:
        qsub -I -q <your_gpu_queue> -l select=1:ngpus=1:ncpus=16:mem=120gb -l walltime=01:00:00
    On the GPU node:
        cd /scratch/<user>/qwen38
        nvidia-smi -L
        apptainer exec --nv --bind ./Qwen3.8-27B:/model:ro vllm38.sif \
          vllm serve /model --served-model-name qwen38 \
          --reasoning-parser qwen3 --mm-encoder-tp-mode data \
          --max-model-len 32768 --gpu-memory-utilization 0.90
    In a second shell on the SAME node:
        curl http://localhost:8000/v1/chat/completions \
          -H "Content-Type: application/json" \
          -d '{"model":"qwen38","messages":[{"role":"user","content":"hi"}],"temperature":1.0,"top_p":0.95}'
    Reply received = success. Ctrl-C to stop, exit to leave the job.

D2. Batch job:
        qsub serve_qwen38.pbs
        qstat -u $USER            # R = running, Q = queued
        tail -f qwen38.log        # watch it load and serve

================================================================================
NOTES
================================================================================

- No conflict between build and run machines: the .sif carries its own OS libs,
  CUDA runtime, Python and vLLM. It only uses the host NVIDIA driver via --nv,
  and driver 595 is new enough to run it. The 20 GB build GPU is irrelevant.

- --reasoning-parser qwen3 is mandatory (the chat template opens turns with
  <think>; without it the reasoning dumps into the message body).

- Start with --max-model-len 32768; raise toward 262144 once it loads cleanly.
  Optional levers: --kv-cache-dtype fp8 (~2x KV), --language-model-only (text only),
  --tensor-parallel-size 2 (+ ngpus=2) for two GPUs.

- Persistence: a PBS job ends at walltime and its address changes each run. For a
  permanent internal service (RAG / Streamlit backend), ask your admin how the
  site supports long-running services. Later step, not a blocker.

- Clients are OpenAI-compatible at http://<node>:8000/v1 — point Streamlit/RAG there.
