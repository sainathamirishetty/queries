"""
fast_context.py
===============
Faster replacement for rag_pipeline.create_contextualized_documents_for_file().
worker.py calls this instead; rag_pipeline.py is left untouched (the chat
assistant and everything else keep using it as before).

Problem seen in the 5 Oct 2026 logs: indexing ran ONE gpt-oss call per
500-character chunk, one at a time, ~5.3 s each. "Pyro Bolt QAP" (238 chunks)
took 22 minutes; only 8 documents were indexed in 46 minutes.

What this does instead:
1. Bigger chunks (FAST_CHUNK_SIZE, default 1500 characters) -> about 3x fewer
   LLM calls, and each chunk carries more meaning for retrieval.
2. Several chunk-context calls at the same time (CONTEXT_MAX_CONCURRENCY,
   default 4). For this to actually run in parallel, the Ollama server that
   hosts gpt-oss must allow it: start it with OLLAMA_NUM_PARALLEL=4 (or more).
   Without that setting the calls simply queue — nothing breaks.
3. Short documents (under SHORT_DOC_NO_CONTEXT_CHARS, default 4000
   characters) skip the context call entirely: the chunk already IS most of
   the document, so the summary adds little.
4. Page numbers: each chunk's page is taken from its real position in the
   text (the old version fell back to page 1 whenever chunk overlap made the
   text search miss).

Output is the same list of Documents with the same metadata keys
(filename, page_number, chunk_number, pdf_url, chunk_hash, doc_hash,
user_name), so create_vector_store() and the chat assistant need no change.
"""

from __future__ import annotations

import concurrent.futures
import hashlib
import logging
import os
import re
from pathlib import Path

from langchain_text_splitters import RecursiveCharacterTextSplitter

import config
import rag_pipeline

logger = logging.getLogger("fast_context")


def _setting(name: str, default):
    if hasattr(config, name):
        return getattr(config, name)
    raw = os.environ.get(name)
    return default if raw is None else type(default)(raw)


FAST_CHUNK_SIZE = _setting("FAST_CHUNK_SIZE", 1500)
FAST_CHUNK_OVERLAP = _setting("FAST_CHUNK_OVERLAP", 150)
CONTEXT_MAX_CONCURRENCY = max(1, _setting("CONTEXT_MAX_CONCURRENCY", 4))
SHORT_DOC_NO_CONTEXT_CHARS = _setting("SHORT_DOC_NO_CONTEXT_CHARS", 4000)
MAX_LEFT_CONTEXT_CHARS = _setting("MAX_LEFT_CONTEXT_CHARS", 10000)
PROMPT_VERSION = getattr(config, "CONTEXT_PROMPT_VERSION", "version-1")

PAGE_PATTERN = re.compile(r"<<!PAGE (\d+)>>")


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _page_at(text: str, pos: int) -> int:
    """Page number in effect at character position `pos` (page tags look like <<!PAGE n>>)."""
    last = None
    # Allow a tag that STARTS at `pos` (a chunk that begins with its page tag
    # belongs to that page), so scan a little past pos and keep tags whose
    # start is <= pos.
    for m in PAGE_PATTERN.finditer(text, 0, max(pos, 0) + 32):
        if m.start() <= pos:
            last = m
    return int(last.group(1)) if last else 1


def _split_with_positions(text: str) -> list[tuple[str, int]]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=FAST_CHUNK_SIZE,
        chunk_overlap=FAST_CHUNK_OVERLAP,
        separators=["\n\n", "\n"],
    )
    out: list[tuple[str, int]] = []
    search_from = 0
    for chunk in splitter.split_text(text):
        piece = chunk.strip()
        if not piece:
            continue
        pos = text.find(piece, search_from)
        if pos == -1:
            pos = text.find(piece)
        if pos == -1:
            pos = search_from
        out.append((piece, pos))
        # Next chunk may overlap this one, so search from just after this
        # chunk's START (not its end) to still find it.
        search_from = pos + 1
    return out


def _context_prompt(window: str, chunk: str) -> str:
    return f"""
<document>
{window}
</document>

Here is the chunk we want to situate within the whole document
<chunk>
{chunk}
</chunk>

Please give a short succinct context to situate this chunk within the overall document for the purposes of improving search retrieval of the chunk.
Answer only with the succinct context and nothing else.
"""


def _generate_context(llm, text: str, chunk: str, pos: int) -> str:
    left = text[max(0, pos - MAX_LEFT_CONTEXT_CHARS):pos]
    response = llm.invoke(_context_prompt(left + "\n\n" + chunk, chunk))
    return str(response.content).strip()


def create_contextualized_documents_for_file(file: Path, cache: dict, user_name: str = ""):
    """Drop-in replacement for rag_pipeline.create_contextualized_documents_for_file().
    Mutates `cache` (same structure as contextual_chunks.json); the caller
    saves it."""
    Document = rag_pipeline.Document
    file = Path(file)
    markdown_dir = Path(config.MARKDOWN_OUTPUT_DIR)
    pdf_url = f"{markdown_dir}/{file.stem}/{file.stem}.pdf"

    text = file.read_text(encoding="utf-8")
    doc_hash = _sha256(text)
    pieces = _split_with_positions(text)
    use_context = len(text) > SHORT_DOC_NO_CONTEXT_CHARS

    logger.info("Processing document: %s → %d chunks (%s)", file.name, len(pieces),
                "with context" if use_context else "short document, no context call")

    contexts: dict[int, str] = {}
    todo: list[int] = []
    hits = 0
    doc_cache = cache.get(doc_hash, {})
    for i, (piece, _pos) in enumerate(pieces):
        ch = _sha256(piece)
        hit = doc_cache.get(ch)
        if hit and hit.get("prompt_version") == PROMPT_VERSION:
            contexts[i] = hit["context"]
            hits += 1
        elif use_context:
            todo.append(i)

    if todo:
        llm = rag_pipeline.get_llm()
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=CONTEXT_MAX_CONCURRENCY,
            # Named like the indexer threads so worker.py routes their log
            # lines to indexing.log.
            thread_name_prefix="indexer-loop-ctx",
        ) as ex:
            futures = {ex.submit(_generate_context, llm, text, pieces[i][0], pieces[i][1]): i for i in todo}
            for fut in concurrent.futures.as_completed(futures):
                i = futures[fut]
                contexts[i] = fut.result()  # errors propagate: the document stays at 'indexing' and is retried
                cache.setdefault(doc_hash, {})[_sha256(pieces[i][0])] = {
                    "context": contexts[i],
                    "prompt_version": PROMPT_VERSION,
                }

    documents = []
    dump = getattr(rag_pipeline, "dump_chunks_for_viewing", None)
    for i, (piece, pos) in enumerate(pieces, start=0):
        context = contexts.get(i, "")
        content = f"[CONTEXT] {context}\n\n{piece}" if context else piece
        doc = Document(
            page_content=content,
            metadata={
                "filename": file.stem,
                "page_number": _page_at(text, pos),
                "chunk_number": i + 1,
                "pdf_url": pdf_url,
                "chunk_hash": _sha256(piece),
                "doc_hash": doc_hash,
                "user_name": user_name,
            },
        )
        if dump:
            try:
                dump(file.stem, i + 1, content)
            except Exception:
                pass
        documents.append(doc)

    logger.info("  → %d chunks ready (%d context calls made, %d reused from cache)",
                len(documents), len(todo), hits)
    return documents
