"""
image_enrichment.py
===================
Faster, restart-safe replacement for document_ingestion.enrich_images_with_descriptions().
worker.py calls this instead; document_ingestion.py is left untouched.

Problems seen in the 5 Oct 2026 logs, and what this file does about each:

1. Restarts threw away all image-description work.
   Results were written only after the LAST image of a document, so the two
   "Configuration document_final ..." files restarted from image 1 on every
   restart and never finished.
   -> Each image's result is saved straight away in
      <doc folder>/image_descriptions.json (keyed by the image's SHA-256).
      After a restart, already-described images are reused, not re-sent.

2. The same two images crashed Ollama ("model runner has unexpectedly
   stopped") in every run.
   -> A failed image is remembered in the same file and skipped next time,
      instead of crashing the model again on every run.

3. Lots of time spent on tiny images (lines, logos, icons) and on very large
   images.
   -> Images smaller than MIN_IMAGE_BYTES are skipped; images larger than
      MAX_IMAGE_SIDE pixels are scaled down before sending.

4. One document with hundreds of images could hold a thread for hours.
   -> At most MAX_IMAGES_PER_DOC images are described per document; the rest
      are left without a description (the page text is still indexed).

All limits can be changed in config.py or with environment variables of the
same name; see _setting().
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import threading
import time
from pathlib import Path

import httpx
import ollama

import config

logger = logging.getLogger("image_enrichment")


def _setting(name: str, default):
    """config.py value if present, else environment variable, else default."""
    if hasattr(config, name):
        return getattr(config, name)
    raw = os.environ.get(name)
    if raw is None:
        return default
    return type(default)(raw)


MIN_IMAGE_BYTES = _setting("MIN_IMAGE_BYTES", 4096)            # skip tiny images (lines, icons)
MAX_IMAGE_SIDE = _setting("MAX_IMAGE_SIDE", 1536)              # downscale bigger images (pixels)
MAX_IMAGES_PER_DOC = _setting("MAX_IMAGES_PER_DOC", 60)        # cap per document
OLLAMA_CRASH_BACKOFF_SECONDS = _setting("OLLAMA_CRASH_BACKOFF_SECONDS", 15)
# Deliberately a NEW name: config.py's OLLAMA_IMAGE_NUM_CTX = 65536 is far more
# context than one image needs and is a likely cause of the Ollama crashes.
IMAGE_NUM_CTX = _setting("ENRICH_IMAGE_NUM_CTX", 8192)

SIDECAR_NAME = "image_descriptions.json"
SUPPORTED_EXTS = (".png", ".jpg", ".jpeg", ".webp")

PROMPT = """
You are a vision-language extraction engine.

Rules (STRICT):
- Output ONLY valid JSON
- Do NOT add explanations
- Do NOT use Markdown
- Tables MUST be in pure HTML
- If no table exists, set "table" to null

Task:
1 Describe image (max 100 words)
2 Extract table if present

Output format STRICT:

{
"description":"text",
"table":"html or null"
}
"""

_TIMEOUT = httpx.Timeout(
    connect=getattr(config, "OLLAMA_CONNECT_TIMEOUT_SECONDS", 30),
    read=getattr(config, "OLLAMA_IMAGE_TIMEOUT_SECONDS", 180),
    write=60.0,
    pool=10.0,
)

_sidecar_locks: dict[str, threading.Lock] = {}
_sidecar_guard = threading.Lock()


def _lock_for(path: Path) -> threading.Lock:
    with _sidecar_guard:
        return _sidecar_locks.setdefault(str(path), threading.Lock())


def _load_sidecar(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_sidecar(path: Path, data: dict) -> None:
    """Atomic write (temp file + rename) so a crash never leaves a half file."""
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)


def find_image(doc_dir: Path, img_rel_path: str):
    candidate = doc_dir / img_rel_path
    if candidate.exists():
        return candidate.resolve()
    stem = Path(img_rel_path).stem
    for ext in SUPPORTED_EXTS:
        matches = list(doc_dir.rglob(f"{stem}{ext}"))
        if matches:
            return matches[0]
    return None


def _image_bytes_for_model(raw: bytes) -> bytes:
    """Scale very large images down; return the original bytes if Pillow is
    missing or the image is already small enough."""
    if not MAX_IMAGE_SIDE:
        return raw
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(raw))
        if max(img.size) <= MAX_IMAGE_SIDE:
            return raw
        img.thumbnail((MAX_IMAGE_SIDE, MAX_IMAGE_SIDE))
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        out = io.BytesIO()
        img.save(out, format="JPEG", quality=90)
        return out.getvalue()
    except Exception:
        return raw


def _describe(client, image_bytes: bytes) -> dict:
    response = client.generate(
        model=config.OLLAMA_IMAGE_MODEL,
        prompt=PROMPT,
        images=[image_bytes],
        stream=False,
        options={"num_ctx": IMAGE_NUM_CTX},
    )
    raw = (response.get("response", "") if isinstance(response, dict)
           else getattr(response, "response", "")) or ""
    raw = raw.strip()
    try:
        return json.loads(raw)
    except Exception:
        return {"description": raw, "table": None}


def _is_model_crash(exc: Exception) -> bool:
    text = str(exc).lower()
    return "unexpectedly stopped" in text or "status code: 500" in text


def count_image_blocks(content_json_path: Path) -> int:
    """Number of image blocks in a MinerU content_list JSON (0 if unreadable)."""
    try:
        data = json.loads(Path(content_json_path).read_text(encoding="utf-8"))
        return sum(1 for b in data if b.get("type", "") in ("image", "figure", "img"))
    except Exception:
        return 0


def enrich_images_with_descriptions(content_json_path: Path) -> Path:
    """Same contract as document_ingestion.enrich_images_with_descriptions():
    adds block["image_description"] to every image block and rewrites the JSON."""
    content_json_path = Path(content_json_path)
    doc_dir = content_json_path.parent
    sidecar_path = doc_dir / SIDECAR_NAME
    lock = _lock_for(sidecar_path)

    content = json.loads(content_json_path.read_text(encoding="utf-8"))
    with lock:
        cache = _load_sidecar(sidecar_path)

    image_blocks = [b for b in content if b.get("type", "") in ("image", "figure", "img")]
    stats = {"reused": 0, "described": 0, "failed": 0, "small": 0, "over_limit": 0, "missing": 0}
    logger.info("Starting image enrichment → %s (%d images, %d already done earlier)",
                content_json_path.name, len(image_blocks), len(cache))

    client = ollama.Client(config.OLLAMA_IMAGE_BASE_URL, timeout=_TIMEOUT)
    sent = 0

    for block in image_blocks:
        img_rel = block.get("img_path") or block.get("image_path") or block.get("path")
        img_path = find_image(doc_dir, img_rel) if img_rel else None
        if img_path is None:
            block["image_description"] = {"description": "Image file not found", "table": None}
            stats["missing"] += 1
            continue

        raw = img_path.read_bytes()
        key = hashlib.sha256(raw).hexdigest()

        cached = cache.get(key)
        if cached is not None:
            block["image_description"] = cached["result"]
            stats["reused"] += 1
            if cached.get("status") in ("ok", "failed"):
                sent += 1  # counts toward MAX_IMAGES_PER_DOC across restarts too
            continue

        if len(raw) < MIN_IMAGE_BYTES:
            result, status = {"description": "", "table": None}, "skipped_small"
            stats["small"] += 1
        elif MAX_IMAGES_PER_DOC and sent >= MAX_IMAGES_PER_DOC:
            # Not cached: if the limit is raised later, these get described then.
            block["image_description"] = {"description": "", "table": None}
            stats["over_limit"] += 1
            continue
        else:
            sent += 1
            try:
                result, status = _describe(client, _image_bytes_for_model(raw)), "ok"
                stats["described"] += 1
            except Exception as exc:
                result = {"description": "Image description unavailable (VLM request failed or timed out)",
                          "table": None}
                status = "failed"
                stats["failed"] += 1
                logger.warning("[ENRICH] Image %s failed (%s) — remembered and will be skipped next time.",
                               img_path.name, str(exc)[:160])
                if _is_model_crash(exc):
                    # Give Ollama time to reload the model instead of hitting
                    # it again immediately.
                    time.sleep(OLLAMA_CRASH_BACKOFF_SECONDS)

        block["image_description"] = result
        with lock:
            cache[key] = {"status": status, "result": result, "image": img_path.name}
            _save_sidecar(sidecar_path, cache)

    content_json_path.write_text(json.dumps(content, indent=2, ensure_ascii=False), encoding="utf-8")
    logger.info("Images processed: %s → %s", content_json_path.name,
                ", ".join(f"{k}={v}" for k, v in stats.items() if v))
    return content_json_path
